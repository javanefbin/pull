# Money Matters: Standards Alignment and Educator Review

## (a) The standards

The current national framework is the **National Standards for Personal Financial Education** (2021). The Jump$tart Coalition and the Council for Economic Education (CEE) co-published it, working with K–12 and university educators ([Jump$tart][js], [CEE PDF][cee], [BusinessWire][bw]). It has six topic areas, numbered I–VI for reference only: **Earning Income, Spending, Saving, Investing, Managing Credit, Managing Risk**.

Each topic has the following parts:

- a Topic Summary;
- a Concept Progression;
- **Standards**, which are knowledge statements ("Students will know that…");
- lettered **Learning Outcomes** ("Students will use this knowledge to…").

Benchmarks are set for the end of **grades 4, 8 and 12** ([CEE PDF][cee], [Jump$tart presentation][jsp]).

**Code format (confirmed):** each standard is numbered by grade, and its outcomes are lettered, for example `Spending 4-1` → `4-1a`, `4-1b`, or `Investing 8-1`. Inside the grade tables, Managing Credit is shortened to "Credit" ("Credit 12-1") ([CEE PDF][cee], [grade-4 list][b4], [grade-8 list][b8]).

The mapping in `ws_standards.json` uses only the six area names. Benchmark grade is assigned by band: K–4 workshops map to the **grade-4** benchmarks and grades 5–8 to the **grade-8** benchmarks. The codes cited below were checked against the published text.

## (b) Coverage (module numbers per area)

| Grade | Earning Income | Spending | Saving | Investing | Managing Credit | Managing Risk |
|---|---|---|---|---|---|---|
| K | M3 | M1, M2, M4, M5 | M4, M5 | — | — | — |
| 1 | M3 | M1, M2, M3, M5 | M4 | — | — | — |
| 2 | M5 | M1, M2, M4, M5 | M3, M5 | — | — | — |
| 3 | M1, M5 | M2, M3, M5 | M2, M4 | — | — | M2 |
| 4 | M1 | M2, M3, M4, M5 | M2, M4, M5 | — | M4, M5 | M2 |
| 5 | M1 | M2, M4, M5 | M2, M3, M5 | M3 | M4 | M4, M5 |
| 6 | M1, M2, M5 | M3, M4, M5 | M3, M4, M5 | — | — | M3 |
| 7 | — | M1 | M5 | M5 | M2, M3 | M4 |
| 8 | M1, M2 | M5 | M5 | M4 | M1, M3 | M5 |

The K–2 coin-identification and coin-counting modules have no exact benchmark. They are mapped to Spending (payment) as the nearest fit.

## (c) Gaps and suggested fixes

**K–2 (Investing, Managing Credit and Managing Risk are all missing)**
- *Managing Risk*: none. Add a "Keep Track of It" block to K M4 or G1 M4 covering a lost mitten or lost coins, a cubby or wallet system, and why a bank is safer. This targets Managing Risk 4-3b, "develop a system to keep track of personal items and handle small amounts of money," and 4-1d.
- *Managing Credit*: none. Add a G2 M4 discussion: "Borrowing a pencil and returning it. Who would you lend to and why?" This targets Credit 4-3a/b.
- *Investing*: acceptable to leave out at K–2, but G2 M5 could add one line on putting profit to work to grow.

**3–5 (Investing is weak; insurance is missing)**
- *Investing* appears only in G5 M3. Saving vs. investing (Investing 4-1, 4-2) is never taught before the grade-4 benchmark. Add to G4 M4 or G4 M5: "Saving is for soon, investing is for someday. Investing has higher risk and can grow more."
- *Managing Risk*: emergency funds and scams are covered, but insurance (Managing Risk 4-4) is never taught. Add a G4 M2 life card: "Bike stolen. With insurance you pay $20, without it $200."
- *Earning Income*: gifts and allowance (4-6) and earning from lending or renting (4-5) are not covered. Add a debrief prompt to G3 M2.
- *Managing Credit*: creditworthiness (Credit 4-3) is missing in G3–G4.

**6–8 (strong overall; a few thin spots)**
- *Managing Risk*: the avoid/reduce/retain/transfer framework (8-5), extended warranties (8-6), and how an insurance pool works (8-3) are not covered. Expand G7 M4 or G8 M5.
- *Earning Income*: entrepreneurship (8-9) and government income support (8-8) are absent in 6–8. A G6 M1 job offer card could be "start a small business."
- *Saving*: deposit insurance (Saving 8-6) and the interest formula (8-4) are only in the game banks and G5 M3. Add FDIC/NCUA to G6 M3.
- *Investing*: CDs, mutual funds and real estate (8-2) are only implied. Add them to G8 M4.
- G6 has no Investing or Managing Credit, and G7 has no Earning Income. That is fine across the band but not for students who attend a single grade.

## (d) Educator review checklist (answer yes or no for each grade's workshop)

1. Does every activity match the grade's math (K–1 whole cents only; decimals from G2; percents from G4/5)?
2. Is the student-facing text (vocab, cards, prompts) at or below grade reading level, with picture support for K–1?
3. Is the time realistic for your class, including setup and cleanup? Is the `short` version enough on tight days? (Check the long G3 M5 fair, G6 M5 lab, G8 M2 tax sim and G8 M3 12-month debt race.)
4. Can you get the materials at low or no cost, with printable substitutes for lockboxes, stamps, hula hoops, aprons, medals and magnifying glasses?
5. Is it safe? For K–1, use jumbo or plastic coins (real coins are a choking hazard). Use tape instead of safety pins for the K badges. Do relays and hopping happen in a cleared space?
6. Does any activity use real food or candy? If so, have you checked allergies and school policy?
7. Is it sensitive to family income? Can a student do each take-home and discussion without revealing family income, rent, pay stubs, savings or a parent's job status? Is a "pretend family" option offered? (Check K M3, G3 M2's $20 allowance, G5 M5, G6 M2 and M4, and G8 M4 take-homes.)
8. Do any activities rank students by pretend pay (G5 "line up lowest to highest")? If so, frame it neutrally and do not tie it to students' real families.
9. Is every made-up rate labelled as pretend or simplified (10% city tax, 8% sales tax, the Class Bank "bonus," class tax brackets, preset market returns)?
10. Are real-world figures current as of 2026 (tuition, FDIC limit, FICA rates, rents and car costs)? Is the source or year noted?
11. Is the content neutral, with no brands, no particular bank or product endorsed, and pathways presented without bias (military, college, trades)?
12. Are online-safety steps age-appropriate? Do students practise with adults only and never type real passwords or personal information?
13. Is there an accommodation for ELL, IEP and mobility needs?
14. Are the coin and change activities updated for the end of penny production (see e1)?

## (e) Statements to correct

All workshop and game-bank math was recomputed and is correct. The issues below are about meaning, currency or framing.

| # | Where | Quoted text | Problem | Suggested wording |
|---|---|---|---|---|
| e1 | K–2 throughout; GS k2 Penny clues | penny-based prices and change, e.g. G1 M5 "7¢ change" | Not wrong, but out of date. The Mint struck its last circulating penny on Nov 12, 2025. Pennies are still legal tender, and many stores round cash totals to the nearest 5¢ ([St. Louis Fed][pen]). | Add a teacher note and a GS fact: "The U.S. stopped making new pennies in 2025. Old pennies still work, but many stores round cash totals to the nearest 5¢." |
| e2 | G4 M5 City Market Showdown | "Anything put on credit costs 10% extra at month's end." | This teaches a misconception. Cards charge interest only on a balance not paid in full by the due date. | "Any credit balance you don't pay off in full at month's end costs 10% extra (a pretend rate; real cards charge interest on unpaid balances)." |
| e3 | G3 M4 Banks Pay You? vs. 10-Week Savings Journey | "deposit $20 once and earn $2 a week; after 10 weeks you have … $40" | Inconsistent. The sim rule ("$1 for every full $10 in their account") compounds, so $20 grows to $46 by week 10. | Either "if you spend the bonus each week, after 10 weeks you've earned $20," or show the compounding chart ($20 → $46). |
| e4 | G8 M1 Pathway Price Tags | "public 4-year about $11,600 (in-state)… community college about $4,000" | These are 2024-25 figures. For 2025-26 they are **$11,950** and **$4,150** ([College Board][cb]). | Update the figures and add "(College Board, 2025-26 average published tuition and fees)". |
| e5 | G8 M1 | "a $20,000 program that raises pay by $10,000 a year earns back its cost in about 2 years" | This is a payback period, not ROI. It also ignores taxes, earnings lost while training, and loan interest. | "…pays back its cost in about 2 years (payback period, before taxes and lost wages during training)." |
| e6 | G8 M3 Reading Your Report; debrief | "free reports from the three nationwide credit bureaus"; "check… at least once a year" | Reports are now free **weekly** ([FTC][ftc]). Minors usually have no report. | "Free weekly reports from Equifax, Experian and TransUnion at AnnualCreditReport.com, the official site. Teens usually have no report yet, and a parent can check or freeze a child's credit." |
| e7 | G8 M4 Wealth-Building Toolkit | "earns a $2,500 match, an instant 100% return"; "$200 a month… at 7% grows to about $655,000" | The match may require vesting. The 7% return is an assumption, not a guarantee. | Add "(if you stay long enough to be vested)" and "assuming a steady 7% average return, which is not guaranteed and not adjusted for inflation." |
| e8 | G8 M4 Match Maximizer | "compare a Roth IRA started at 15" | A minor needs earned income and a custodial account opened by an adult. | "…a custodial Roth IRA (needs earned income; an adult opens it) started at 15…" |
| e9 | G6 M1 vocab and Hourly vs. Salary | "overtime=extra pay, usually 1.5 times… for hours over 40" | Many salaried workers are exempt from overtime, and the lesson compares salary jobs. | Add: "for most hourly workers; many salaried jobs don't pay overtime." |
| e10 | G4 M1 | "net pay=the pay you take home after taxes"; "pretend city tax is 10%" | Few cities levy income tax. Real paychecks withhold federal tax, Social Security, Medicare, and often state tax. | Use "after taxes and other deductions" and add one sentence naming the real withholdings. |
| e11 | G4 M3 | "rates vary by state; we will use 8%" | This can mislead students in states without a sales tax. | Add: "Alaska, Delaware, Montana, New Hampshire and Oregon have no statewide sales tax." |
| e12 | G5 M1, G5 M5 | "subtract 20% for taxes"; "car payment, gas, and insurance $450" | The flat 20% is not labelled as simplified. $450 a month for a car is likely low for 2026. | Label "simplified 20%," and either update the car costs from local data or label them "pretend prices." |
| e13 | G5 M3; GS bank | FDIC only | Credit unions are insured by the NCUA. | Add: "Credit union deposits are insured by the NCUA, also up to $250,000." |
| e14 | G7 M4 Password Strength Test | "12 or more characters" | NIST's 2025 guidance (SP 800-63B-4) calls for at least 15 characters for single-factor passwords ([summary][nist]). | "15 or more characters (a passphrase of 4+ random words)." |
| e15 | GS 35 order "U.S. money history" | "The U.S. issues its first paper money – 1861" | Ambiguous, because the Continental Congress issued paper money in 1775. | "The federal government issues its first national paper money (Demand Notes) – 1861." |
| e16 | G7 M5, G8 M4 market sims | preset returns; "Time in the market beats timing the market!" | The sims could read as a guarantee. | Label the cards "made-up returns for the game" and present the slogan as a common saying, not a promise. |

[js]: https://jumpstart.org/education/national-standards/
[cee]: https://www.councilforeconed.org/wp-content/uploads/2021/10/2021-National-Standards-for-Personal-Financial-Education.pdf
[bw]: https://www.businesswire.com/news/home/20211021005308/en/New-National-Standards-for-Personal-Financial-Education-Reflect-an-Increasingly-Diverse-Digital-World
[jsp]: https://www.jumpstart.org/wp-content/uploads/2023/04/Presentation-on-New-Standards-2021.pdf
[b4]: https://dort.banzai.org/curriculum/cee/national-standards/grade/4
[b8]: https://dort.banzai.org/curriculum/cee/national-standards/grade/8
[pen]: https://www.stlouisfed.org/publications/page-one-economics/2026/may/penny-costs-more-than-penny-economics-behind-ending-the-cent
[cb]: https://research.collegeboard.org/trends/college-pricing/highlights
[ftc]: https://consumer.ftc.gov/consumer-alerts/2023/10/you-now-have-permanent-access-free-weekly-credit-reports
[nist]: https://www.sakimura.org/en/2025/10/7710/
