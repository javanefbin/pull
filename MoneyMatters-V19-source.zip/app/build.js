#!/usr/bin/env node
/*
 * Money Matters build: src/index.html -> dist/MoneyMatters.html
 *
 *   node build.js                 build dist/MoneyMatters.html
 *   node build.js --check <file>  build, then compare byte-for-byte with <file>
 *                                 (exit 1 on mismatch; dist is still written)
 *
 * Directives (resolved recursively, paths relative to src/):
 *   <!--@include path-->   (HTML context)
 *   /*@include path*\/      (JS/CSS context)
 * A directive is replaced by the exact bytes of the named file. Files ending in
 * .json are inserted raw and never scanned for further directives.
 * No dependencies; Node >= 14.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'MoneyMatters.html');
const DIRECTIVE = /<!--@include ([^\s>]+?)-->|\/\*@include ([^\s*]+?)\*\//g;

function resolve(rel, stack) {
  const abs = path.resolve(SRC, rel);
  if (!abs.startsWith(SRC + path.sep)) throw new Error('include escapes src/: ' + rel);
  if (stack.includes(abs)) throw new Error('include cycle: ' + stack.concat(abs).join(' -> '));
  if (!fs.existsSync(abs)) throw new Error('missing include: ' + rel + ' (from ' + path.relative(SRC, stack[stack.length - 1] || abs) + ')');
  const text = fs.readFileSync(abs, 'utf8');
  if (rel.endsWith('.json')) return text;
  return text.replace(DIRECTIVE, (_, a, b) => resolve(a || b, stack.concat(abs)));
}

function build() {
  const out = resolve('index.html', []);
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  const bytes = Buffer.from(out, 'utf8');
  fs.writeFileSync(OUT, bytes);
  return bytes;
}

const args = process.argv.slice(2);
const bytes = build();
console.log('built ' + path.relative(process.cwd(), OUT) + ' (' + bytes.length + ' bytes)');

const ci = args.indexOf('--check');
if (ci >= 0) {
  const ref = args[ci + 1];
  if (!ref) { console.error('--check needs a file'); process.exit(2); }
  const want = fs.readFileSync(ref);
  if (want.equals(bytes)) { console.log('check OK: byte-identical to ' + ref); process.exit(0); }
  let i = 0;
  while (i < want.length && i < bytes.length && want[i] === bytes[i]) i++;
  const line = want.slice(0, i).toString('utf8').split('\n').length;
  console.error('check FAILED: sizes ' + bytes.length + ' vs ' + want.length + ', first difference at byte ' + i + ' (line ' + line + ')');
  console.error('  expected: ' + JSON.stringify(want.slice(i, i + 80).toString('utf8')));
  console.error('  got:      ' + JSON.stringify(bytes.slice(i, i + 80).toString('utf8')));
  process.exit(1);
}
