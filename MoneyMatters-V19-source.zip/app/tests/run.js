#!/usr/bin/env node
/* =====================================================================
   Money Matters · end-to-end test suite
   One command:   npm test          (builds, then runs every test)
                  node tests/run.js [--only a,b] [--file path] [--shots dir] [--headed]
   Needs: Node 18+, Playwright with Chromium (`npx playwright install chromium`
   in CI), axe-core (devDependency) for the accessibility checks.
   Each test runs in a fresh browser context (empty storage). A test fails on
   a thrown assertion, a timeout, or any uncaught page error.
   Exit code: 0 when everything passes, 1 otherwise.
   ===================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const args = process.argv.slice(2);
const argOf = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const FILE = path.resolve(argOf('--file', path.join(__dirname, '..', 'dist', 'MoneyMatters.html')));
const URL = 'file://' + FILE;
const ONLY = (argOf('--only', '') || '').split(',').filter(Boolean);
const SHOTS = argOf('--shots', '');
const HEADED = args.includes('--headed');
const PW = 'Password123!';

/* ---------- tiny harness ---------- */
const tests = [];
const test = (name, fn, opts) => tests.push({ name, fn, timeout: (opts && opts.timeout) || 90000 });
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(a, b, msg) { if (a !== b) throw new Error((msg || 'expected equal') + ` (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`); }

/* ---------- helpers ---------- */
async function newPage(ctx, errs, vp) {
  const p = await ctx.newPage();
  if (vp) await p.setViewportSize(vp);
  p.on('pageerror', e => errs.push(e.message));
  return p;
}
async function load(p) {
  await p.goto(URL);
  await p.waitForSelector('#mm-auth', { state: 'attached', timeout: 15000 });
  await p.waitForTimeout(900);
}
/** First-run setup: creates the administrator and lands on the home screen. */
async function setupAdmin(p) {
  await load(p);
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'Test Admin');
  await p.fill('#s-p1', PW); await p.fill('#s-p2', PW);
  await p.selectOption('#s-sq1', { index: 1 });
  await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]');
  await p.waitForTimeout(1400);
  await quiet(p);
}
/** Dismiss first-run helpers so they don't cover what a test clicks. */
async function quiet(p) {
  await p.evaluate(() => {
    try { localStorage.setItem('mmSetupDone', '1'); localStorage.setItem('mmTourDone', '1'); } catch (e) {}
    try { endTour(); } catch (e) {}
    try { closePanel(true); } catch (e) {}
    document.querySelectorAll('.mmrt-ov').forEach(x => x.remove());
  });
}
async function addClass(p) {
  await p.evaluate(async (pw) => {
    const MM = window.MM91;
    await MM.accounts.add({ username: 'rivera', name: 'Ms. Rivera', role: 'teacher', scope: 'all', password: pw, by: 'test' });
    ['Ava Jones', 'Ben Lee', 'Cara Diaz', 'Dev Patel'].forEach(n => MM.data.createStudent(n, '4', 'Ms. Rivera'));
    MM.accounts.ensureStudents();
  }, PW);
}
/** Capture what MMPrint would print, instead of opening the print dialog. */
async function capture(p, fn) {
  await p.evaluate(() => { window.__printed = []; MMPrint.capture = h => { window.__printed.push(h); }; });
  await p.evaluate(fn);
  await p.waitForTimeout(150);
  return p.evaluate(() => window.__printed.slice());
}
function checkPrint(html, label) {
  assert(html && html.length > 800, `${label}: printout is empty`);
  assert(/@page/.test(html), `${label}: no @page rules (headers, footers, margins)`);
  assert(!/class="(mm-topbar|panel-header|nav-btn)/.test(html), `${label}: app chrome leaked into the printout`);
  assert(!/undefined|\[object Object\]|NaN/.test(html.replace(/<script[\s\S]*?<\/script>/g, '')), `${label}: contains undefined/NaN`);
}
async function shot(p, name) { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await p.screenshot({ path: path.join(SHOTS, name + '.png') }); } }

/* =====================================================================
   TESTS
   ===================================================================== */

test('build: single self-contained file', async () => {
  assert(fs.existsSync(FILE), 'dist file missing; run node build.js');
  const html = fs.readFileSync(FILE, 'utf8');
  assert(html.length > 3e6, 'built file is suspiciously small');
  assert(!/@include/.test(html), 'unresolved @include directive');
  assert(!/<script[^>]+src=["']https?:/i.test(html), 'external script found; the app must be self-contained');
  assert(!/<link[^>]+href=["']https?:[^>]+stylesheet/i.test(html), 'external stylesheet found');
  const csp = (html.match(/http-equiv="Content-Security-Policy"\s+content="([^"]+)"/i) || [])[1] || '';
  assert(/default-src 'self'/.test(csp), 'CSP default-src is not self');
  assert(/connect-src[^;]*supabase\.co/.test(csp), 'CSP does not allow the live-game server');
});

test('sign-in screen scales from 320px phones to 4K', async ({ ctx, errs }) => {
  const fieldAt = {};
  for (const [w, h] of [[320, 640], [390, 844], [768, 1024], [1366, 900], [1920, 1080], [3840, 2160]]) {
    const p = await newPage(ctx, errs, { width: w, height: h });
    await load(p);
    await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
    const m = await p.evaluate(() => {
      const g = document.getElementById('mm-auth'), r = g && g.getBoundingClientRect();
      const card = g && g.querySelector('input,button');
      return { shown: !!(g && !g.classList.contains('mm-hidden') && r.width > 0), over: document.documentElement.scrollWidth - innerWidth, field: card ? card.getBoundingClientRect().height : 0, font: card ? parseFloat(getComputedStyle(card).fontSize) : 0 };
    });
    assert(m.shown, `${w}px: sign-in gate not shown`);
    assert(m.over <= 1, `${w}px: page scrolls sideways by ${m.over}px`);
    assert(m.field >= 36, `${w}px: first control is only ${m.field}px tall`);
    fieldAt[w] = m.field;
    if (w >= 3840) assert(m.field >= fieldAt[1366] * 1.3, `4K: controls not scaled up (${m.field}px vs ${fieldAt[1366]}px at 1366)`);
    await shot(p, `signin-${w}`);
    await p.close();
  }
});

test('setup, teacher sign-in, teacher home', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  assert(await p.isVisible('#mm-topbar'), 'top bar missing after setup');
  await addClass(p);
  await p.evaluate(() => window.MM91.gate.signOut()); await p.waitForTimeout(500);
  await p.click('[data-a=as][data-v=staff]').catch(() => {});
  await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', PW);
  await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  const who = await p.evaluate(() => ({ name: MM91.auth.displayName(), role: MM91.auth.roleKey() }));
  eq(who.role, 'teacher', 'signed-in role');
  eq(who.name, 'Ms. Rivera', 'signed-in name');
  const home = await p.evaluate(() => { const h = document.getElementById('mm-home'); return h && h.offsetParent ? h.innerText : ''; });
  assert(/class today/i.test(home) && /students/i.test(home), 'teacher home screen (class today, students) not shown');
  assert((await p.innerText('#mm-topbar')).includes('Rivera'), 'teacher profile missing from the top bar');
  await shot(p, 'teacher-home');
});

test('wrong password locks out after the policy limit', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => window.MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=staff]').catch(() => {});
  for (let i = 0; i < 5; i++) { await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', 'wrong' + i); await p.click('[data-a=login]'); await p.waitForTimeout(250); }
  await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', PW); await p.click('[data-a=login]'); await p.waitForTimeout(600);
  assert(await p.evaluate(() => !MM91.auth.get()), 'correct password accepted during lockout');
  const stored = await p.evaluate(() => JSON.stringify(localStorage));
  assert(!stored.includes(PW), 'a password is stored in plain text');
});

test('every panel opens and closes without errors', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  const ids = await p.evaluate(() => [...document.querySelectorAll('.panel')].map(x => x.id.replace('panel-', '')).filter(x => x !== 'login'));
  assert(ids.length >= 20, 'expected 20+ panels, found ' + ids.length);
  for (const id of ids) {
    await p.evaluate(i => openPanel(i), id); await p.waitForTimeout(250);
    const st = await p.evaluate(i => { const el = document.getElementById('panel-' + i); return { open: el.classList.contains('open'), text: (el.innerText || '').trim().length }; }, id);
    /* staff-only legacy panels (teacher, students) now route to the Admin Console */
    const shown = st.open || await p.evaluate(() => !!document.querySelector('.panel.open'));
    assert(shown, `panel ${id} did not open`);
    if (st.open) assert(st.text > 20, `panel ${id} is empty`);
    await p.keyboard.press('Escape'); await p.waitForTimeout(150);
    await p.evaluate(() => { try { closePanel(true); } catch (e) {} });
  }
});

test('Game Show: every mode starts; Quiz Rush plays to the podium', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('4'); MMGameShow.open(); }); await p.waitForTimeout(400);
  assert(await p.isVisible('#mm-gs'), 'Game Show did not open');
  await shot(p, 'gs-lobby');
  for (const m of ['board', 'tf', 'order', 'cash', 'who', 'guess', 'cross', 'daily']) {
    await p.evaluate(mode => MMGameShow.open(mode), m); await p.waitForTimeout(500);
    const t = await p.evaluate(() => document.getElementById('mm-gs').innerText.length);
    assert(t > 60, `mode ${m} rendered nothing`);
    await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(150);
  }
  await p.evaluate(() => { MMGameShow.open(); }); await p.waitForTimeout(300);
  await p.selectOption('[data-gs=opt][data-m=rush][data-k=n]', { index: 0 }).catch(() => {});
  await p.click('[data-gs=start][data-m=rush]');
  /* host-paced: teams lock in, host reveals, then advances (leaderboard every few questions) */
  for (let step = 0; step < 120; step++) {
    if (await p.$('[data-gs=recap]')) break;
    const st = await p.evaluate(() => { const v = s => { const e = document.querySelector('#mm-gs ' + s); return !!(e && !e.hidden && !e.disabled && e.offsetParent); }; return { lb: v('[data-gs=lb-next]'), next: v('[data-gs=q-next]'), reveal: v('[data-gs=q-reveal]'), pick: v('[data-gs=pick]') }; });
    /* the screen moves on by itself once every team locks in, so a click can miss: retry next step */
    const tap = sel => p.click(sel, { timeout: 1500 }).catch(() => {});
    if (st.lb) await tap('[data-gs=lb-next]');
    else if (st.next) await tap('[data-gs=q-next]');
    else if (st.reveal) {
      if (st.pick) for (let t = 0; t < 2; t++) await tap(`[data-gs=pick][data-t="${t}"][data-k="${(step + t) % 4}"]`);
      await tap('#mm-gs [data-gs=q-reveal]:not([hidden])');
    }
    await p.waitForTimeout(400);
  }
  assert(await p.$('[data-gs=recap]'), 'Quiz Rush never reached the podium');
  await shot(p, 'gs-podium');
}, { timeout: 240000 });

test('Live play: host and two phones complete two questions', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('5'); MMGameShow.open(); }); await p.waitForTimeout(300);
  await p.click('[data-gs=live]'); await p.waitForTimeout(600);
  const link = await p.inputValue('.gl-link');
  assert(/#join-\w+/.test(link), 'join link has no PIN: ' + link);
  const players = [];
  for (const n of ['Ava', 'Ben']) {
    const q = await newPage(ctx, errs, { width: 390, height: 800 });
    await q.goto(link); await q.waitForSelector('#lp-nick', { timeout: 10000 });
    await q.fill('#lp-nick', n); await q.click('.lp-go'); await q.waitForTimeout(400);
    players.push(q);
  }
  await p.bringToFront(); await p.waitForTimeout(500);
  const chips = await p.$$eval('.gl-chip', x => x.map(c => c.textContent));
  assert(chips.some(c => c.includes('Ava')) && chips.some(c => c.includes('Ben')), 'players missing from the host lobby: ' + chips);
  await p.click('[data-gl=go]');
  for (let r = 0; r < 2; r++) {
    for (let i = 0; i < players.length; i++) { await players[i].waitForSelector('[data-lp=ans]', { timeout: 10000 }); await players[i].click(`[data-lp=ans][data-k="${i % 2}"]`); }
    await p.waitForSelector('#gl-next:not([hidden])', { timeout: 10000 });
    await p.click('#gl-next'); await p.waitForTimeout(300);
    if (await p.$('[data-gl=next2]')) await p.click('[data-gl=next2]');
    await p.waitForTimeout(300);
  }
  const score = await players[0].evaluate(() => document.getElementById('mm-lp').innerText);
  assert(/\$|\d/.test(score), 'player screen shows no score');
  await shot(players[0], 'live-phone');
});

test('Workshops: every grade and format renders; all printouts are well formed', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => openPanel('workshops')); await p.waitForTimeout(400);
  for (const g of ['K', '1', '2', '3', '4', '5', '6', '7', '8']) {
    await p.click(`[data-ws=grade][data-g="${g}"]`).catch(async () => { await p.evaluate(x => { const b = [...document.querySelectorAll('[data-ws=grade]')].find(b => b.textContent.trim() === x); b && b.click(); }, g); });
    await p.waitForTimeout(120);
    for (const n of [1, 2, 3, 4, 5]) {
      await p.click(`[data-ws=fmt][data-n="${n}"]`); await p.waitForTimeout(60);
      const days = await p.$$eval('[data-ws=day]', x => x.length);
      eq(days, n, `grade ${g}: ${n}-day format shows wrong number of days`);
    }
    const chips = await p.evaluate(() => document.getElementById('workshopsBody').innerText);
    assert(/Spending|Saving|Earning|Investing|Credit|Risk/.test(chips), `grade ${g}: no standards shown`);
  }
  for (const [btn, label] of [['guide', 'facilitator guide'], ['passport', 'passport']]) {
    const out = await capture(p, new Function(`document.querySelector('[data-ws=${btn}]').click()`));
    assert(out.length, label + ' did not print'); checkPrint(out[0], label);
  }
  await p.fill('#ws-cname', 'Ava Jones');
  const cert = await capture(p, () => document.querySelector('[data-ws=cert-one]').click());
  assert(cert.length && cert[0].includes('Ava Jones'), 'certificate missing the student name'); checkPrint(cert[0], 'certificate');
  await p.click('[data-ws=grade][data-g="4"]').catch(() => {}); await p.waitForTimeout(150);
  await p.click('[data-ws=tab][data-t=results]'); await p.waitForTimeout(200);
  for (const btn of ['p-check', 'p-key', 'p-results']) {
    const out = await capture(p, new Function(`document.querySelector('[data-ws=${btn}]').click()`));
    assert(out.length, btn + ' did not print'); checkPrint(out[0], btn);
  }
  await shot(p, 'workshops');
}, { timeout: 180000 });

test('Lesson printouts: plan, worksheet, key, family letter, packet, workbook, guide', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('4'); openDoc('plan'); }); await p.waitForTimeout(300);
  for (const k of ['plan', 'worksheet', 'key', 'family', 'packet', 'workbook', 'guide']) {
    const out = await capture(p, new Function(`MMPrint.doc('${k}')`));
    assert(out.length, k + ' did not print'); checkPrint(out[0], k);
    if (k === 'plan') assert(/Learning objective|Objective/i.test(out[0]), 'plan missing objective');
    if (k === 'key') assert(/answer/i.test(out[0]), 'answer key has no answers');
    if (k === 'workbook') assert((out[0].match(/class="[^"]*\bdivider\b/g) || []).length >= 6, 'workbook is missing unit dividers');
    if (k === 'guide') assert((out[0].match(/class="page"/g) || []).length >= 72, 'teacher guide does not cover all 36 weeks');
  }
  await p.evaluate(() => closePanel(true));
});

test('Resource Guide: links are valid, filters work, guide prints', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  const data = await p.evaluate(() => MMResources.data);
  assert(data.resources.length >= 50, 'fewer than 50 resources');
  const urls = data.resources.map(r => r.url);
  urls.forEach(u => assert(/^https:\/\/[^\s]+\.[a-z]{2,}/i.test(u), 'bad URL: ' + u));
  eq(new Set(urls).size, urls.length, 'duplicate resource URLs');
  await p.evaluate(() => openPanel('resources')); await p.waitForTimeout(300);
  const all = await p.$$eval('#panel-resources a[href^="https"]', x => x.length);
  assert(all >= 50, 'resource links not rendered');
  const ext = await p.$$eval('#panel-resources a[href^="https"]', x => x.every(a => a.target === '_blank' && /noopener/.test(a.rel)));
  assert(ext, 'outside links must open in a new tab with rel=noopener');
  const out = await capture(p, () => MMResources.print(false));
  checkPrint(out[0], 'resource guide');
  assert((out[0].match(/<svg/g) || []).length >= 50, 'resource guide is missing QR codes');
});

test('Spanish and Portuguese: game show, workshops and printouts translate', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  for (const [lang, title, ws, page] of [['es', 'Apréndelo', 'Talleres de dinero', 'Página'], ['pt', 'Aprenda', 'Oficinas', 'Página']]) {
    await p.evaluate(l => { setLang(l); setGrade('4'); MMGameShow.open(); }, lang); await p.waitForTimeout(500);
    const t = await p.evaluate(() => document.getElementById('mm-gs').innerText);
    assert(t.includes(title), `${lang}: game show lobby not translated`);
    await p.evaluate(() => { MMGameShow.close(); openPanel('workshops'); }); await p.waitForTimeout(500);
    const w = await p.evaluate(() => document.getElementById('panel-workshops').innerText);
    assert(w.includes(ws), `${lang}: workshops panel not translated`);
    await p.evaluate(() => { closePanel(true); openDoc('plan'); }); await p.waitForTimeout(200);
    const out = await capture(p, () => MMPrint.doc('plan'));
    assert(out[0].includes(page), `${lang}: printout footer not translated`);
    assert(!/Lesson plan<|Learning objective</.test(out[0]), `${lang}: English headings left in printout`);
    await p.evaluate(() => closePanel(true));
  }
  await p.evaluate(() => setLang('en'));
});

test('Privacy, Security, Terms and FAQ are current', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await load(p);
  const t = await p.evaluate(() => document.getElementById('panel-legal').textContent);
  assert(!/no accounts/i.test(t), 'privacy policy still says there are no accounts');
  assert(!/Teacher\/Parent\/Parent/.test(t), 'FAQ typo is back');
  assert(/Last updated: October 26, 2026/.test(t), 'last-updated date missing');
  for (const s of ['Supabase', 'Resource Guide', 'salted SHA-256', 'not strong security', 'reviewed by an attorney']) assert(t.includes(s), 'legal text missing: ' + s);
  for (const id of ['privacy', 'security', 'terms', 'faq']) assert(await p.$('#legal-' + id), 'missing legal tab ' + id);
});

test('Accessibility: no critical or serious axe violations; Escape and focus return work', async ({ ctx, errs }) => {
  const axe = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
  const p = await newPage(ctx, errs);
  const run = async (label, sel) => {
    await p.addScriptTag({ content: axe }).catch(() => {});
    const r = await p.evaluate(async s => {
      const res = await axe.run(s ? document.querySelector(s) : document, { resultTypes: ['violations'], rules: { 'color-contrast': { enabled: true } } });
      return res.violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length }));
    }, sel);
    const bad = r.filter(v => v.impact === 'critical' || v.impact === 'serious');
    assert(!bad.length, `${label}: axe violations ${JSON.stringify(bad)}`);
    return r;
  };
  await load(p); await p.click('#consent-accept-btn').catch(() => {});
  const report = { signin: await run('sign-in', '#mm-auth') };
  await setupAdmin(p);
  report.home = await run('home', null);
  await p.evaluate(() => MMGameShow.open()); await p.waitForTimeout(300);
  report.gameshow = await run('game show', '#mm-gs');
  await p.evaluate(() => MMGameShow.close());
  for (const id of ['workshops', 'resources', 'legal']) {
    await p.evaluate(i => openPanel(i), id); await p.waitForTimeout(300);
    report[id] = await run(id, '#panel-' + id);
    await p.evaluate(() => closePanel(true));
  }
  /* keyboard: open a panel from a focused control, Escape closes it, focus returns */
  await p.evaluate(() => { const b = document.createElement('button'); b.id = '__opener'; b.textContent = 'open'; b.onclick = () => openPanel('help'); document.body.appendChild(b); b.focus(); });
  await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  assert(await p.evaluate(() => document.getElementById('panel-help').classList.contains('open')), 'Enter did not open the panel');
  assert(await p.evaluate(() => document.getElementById('scene') ? document.getElementById('scene').hasAttribute('inert') : true), 'background is not inert under an open panel');
  await p.keyboard.press('Escape'); await p.waitForTimeout(400);
  assert(await p.evaluate(() => !document.querySelector('.panel.open')), 'Escape did not close the panel');
  const minor = Object.entries(report).flatMap(([k, v]) => v.map(x => `${k}:${x.id}(${x.n})`));
  if (minor.length) console.log('      note: moderate/minor axe findings: ' + minor.join(', '));
});

/* =====================================================================
   RUNNER
   ===================================================================== */
(async () => {
  const pick = ONLY.length ? tests.filter(t => ONLY.some(o => t.name.toLowerCase().includes(o.toLowerCase()))) : tests;
  const browser = await chromium.launch({ headless: !HEADED });
  let failed = 0; const t0 = Date.now();
  console.log(`Money Matters tests · ${pick.length} of ${tests.length} · ${path.relative(process.cwd(), FILE)}\n`);
  for (const t of pick) {
    const ctx = await browser.newContext({ viewport: { width: 1366, height: 900 } });
    const errs = []; const s = Date.now();
    let err = null;
    try {
      await Promise.race([t.fn({ ctx, errs }), new Promise((_, rej) => setTimeout(() => rej(new Error(`timed out after ${t.timeout / 1000}s`)), t.timeout))]);
      if (errs.length) throw new Error('uncaught page errors: ' + JSON.stringify([...new Set(errs)].slice(0, 5)));
    } catch (e) { err = e; }
    await ctx.close().catch(() => {});
    const ms = ((Date.now() - s) / 1000).toFixed(1) + 's';
    if (err) { failed++; console.log(`  ✗ ${t.name}  (${ms})\n      ${String(err.message).split('\n')[0]}`); }
    else console.log(`  ✓ ${t.name}  (${ms})`);
  }
  await browser.close();
  console.log(`\n${pick.length - failed} passed, ${failed} failed · ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  process.exit(failed ? 1 : 0);
})();
