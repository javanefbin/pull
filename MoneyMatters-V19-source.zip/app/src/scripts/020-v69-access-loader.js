(function(){var K='mmAccess_v1',c='';try{c=localStorage.getItem(K)||'';}catch(e){}
if(!c||!/^https?:$/.test(location.protocol))return;
try{var x=new XMLHttpRequest();x.open('GET','/api/content',false);x.setRequestHeader('Authorization','Bearer '+c);x.send();
if(x.status===200){var f=JSON.parse(x.responseText);window.__MM_LICENSE=f.__label||'';delete f.__label;window.__MM_FULL=f;}
else if(x.status===401||x.status===403){try{localStorage.removeItem(K);}catch(e){}window.__MM_ACCESS_ERR=1;}}catch(e){}})();
