/* Patch layers: v46-v66 are additive scripts above; changelog entries v55-v66 are merged here. */
(function(){try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'August 2026',items:['Added a role-first sign-in experience with Student or Teacher selection before the login form.','Added a username/password-style login interface with clear Student and Teacher indicators, per-tab sessions, remember-me username support, password visibility control, and role-specific recovery guidance.','Student sign-in uses the student name plus the roster verification code; Teacher sign-in uses the existing teacher passcode.','Ensured student verification codes exist for local student profiles.','Reinforced the game reflection workflow so answer-based games pause after three incorrect attempts without revealing the answer.']});}}catch(e){}})();
(function(){try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'September 2026',items:['Owner/private startup now opens on the Money Matters home classroom instead of the Teacher panel.','Student sign-in now routes directly to the grade-specific Financial Literacy Assessment before lessons begin.','New student creation and switching between student profiles also route to the Financial Literacy Assessment.','Teacher/Parent mode remains on the normal Teacher workspace and is not redirected to the student assessment.']});}}catch(e){}})();
(function(){try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'September 2026',items:['Student Financial Literacy Profile now drives a personalized learning path after assessment.','Added assessment history, progress checks, growth tracking, and a student reflection response.','Added skill-priority guidance, application evidence, and game-to-domain evidence.','Added a professional class financial literacy overview for teachers.','Enhanced student dashboard with financial literacy level, next instructional focus, and personalized path access.','Enhanced reports with growth, application, game evidence, reflection evidence, and teacher action steps.','Added family-friendly language and preserved enrolled grade while allowing below-grade instructional recommendations.']});}}catch(e){}})();
(function(){try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'September 2026',items:['Rebuilt the Financial Literacy Assessment into a focused one-question-at-a-time experience with stable navigation and no page jump after answers.','Simplified assessment progress, answer selection, and completion controls for mobile and desktop.','Reduced Teacher workspace visual density with quick actions and collapsible setup/tools.','Cleaned spacing, button density, cards, and responsive behavior across the updated assessment and teacher areas.']});}}catch(e){}})();
(function(){'use strict';
var PK='mmPrefs_v1',H=document.documentElement,P={};
function $(i){return document.getElementById(i);}
try{P=JSON.parse(localStorage.getItem(PK)||'{}')||{};}catch(e){P={};}
function apply(){H.classList.toggle('mm-t1',P.t===1);H.classList.toggle('mm-t2',P.t===2);H.classList.toggle('mm-hc',!!P.hc);H.classList.toggle('mm-dark',!!P.dk);H.classList.toggle('mm-dys',!!P.dy);H.classList.toggle('mm-rm',!!P.rm||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches));}
function save(){try{localStorage.setItem(PK,JSON.stringify(P));}catch(e){}apply();}
if(!('dk' in P)&&window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches){P.dk=0;}
apply();
function toast(m){try{infoToast(m,3500);}catch(e){alert(m);}}
function exportData(){var d={};try{Object.keys(localStorage).forEach(function(k){if(/^mm[A-Za-z0-9_]+$/.test(k))d[k]=localStorage.getItem(k);});}catch(e){}
var b=new Blob([JSON.stringify({app:'MoneyMatters',v:1,at:new Date().toISOString(),data:d})],{type:'application/json'});
var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='MoneyMatters-backup-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},500);toast('Backup downloaded. It contains student names, so keep it private.');}
function importData(f){if(!f)return;if(f.size>5242880){toast('That file is too large to be a Money Matters backup.');return;}
var r=new FileReader();r.onload=function(){try{var o=JSON.parse(r.result);if(!o||o.app!=='MoneyMatters'||typeof o.data!=='object')throw 0;
var ks=Object.keys(o.data).filter(function(k){return /^mm[A-Za-z0-9_]+$/.test(k)&&typeof o.data[k]==='string';});if(!ks.length)throw 0;
if(!confirm('Restore '+ks.length+' saved items from this backup? This replaces current progress on this device.'))return;
ks.forEach(function(k){localStorage.setItem(k,o.data[k]);});toast('Backup restored. Reloading...');setTimeout(function(){location.reload();},900);}catch(e){toast('That file is not a valid Money Matters backup.');}};r.readAsText(f);}
var css=document.createElement('style');css.textContent='html.mm-t1 .panel-body,html.mm-t1 #mm-login-gate{zoom:1.15}html.mm-t2 .panel-body,html.mm-t2 #mm-login-gate{zoom:1.3}'+
'html.mm-hc body{filter:contrast(1.25)}html.mm-hc *{border-color:#000!important}html.mm-hc button:focus-visible,html.mm-hc input:focus-visible{outline:3px solid #000!important}'+
'html.mm-dark body{filter:invert(1) hue-rotate(180deg)}html.mm-dark img,html.mm-dark video{filter:invert(1) hue-rotate(180deg)}'+
'html.mm-dys body,html.mm-dys button,html.mm-dys input,html.mm-dys textarea{font-family:Verdana,Tahoma,"Trebuchet MS",sans-serif!important;letter-spacing:.04em;word-spacing:.12em;line-height:1.7}'+
'html.mm-rm *,html.mm-rm *:before,html.mm-rm *:after{animation:none!important;transition:none!important;scroll-behavior:auto!important}'+
'#mm-set-btn{position:fixed;left:max(10px,env(safe-area-inset-left));bottom:max(10px,env(safe-area-inset-bottom));z-index:99990;width:44px;height:44px;border-radius:50%;border:2px solid #c4912e;background:#231a0a;color:#f7e8c4;font-size:20px;cursor:pointer}'+
'#mm-set-pop{position:fixed;left:max(10px,env(safe-area-inset-left));bottom:64px;z-index:99991;width:min(300px,calc(100vw - 20px));max-height:70vh;overflow:auto;background:#fff8e8;color:#1a1208;border:2px solid #c4912e;border-radius:12px;padding:12px;font:14px system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.35);display:none}'+
'#mm-set-pop h3{font-size:15px;margin:0 0 8px}#mm-set-pop label{display:flex;align-items:center;gap:8px;min-height:36px}#mm-set-pop button{min-height:40px;margin:4px 4px 0 0;padding:6px 12px;border:1px solid #7c4e28;border-radius:8px;background:#f7e8c4;color:#1a1208;cursor:pointer}'+
'.mm-pg{display:flex;gap:8px;justify-content:space-between;align-items:center;margin:10px 0}.mm-pg button{min-height:44px;flex:1;border-radius:10px;border:2px solid #7c4e28;background:#f7e8c4;font-size:15px;cursor:pointer}.mm-pg button:disabled{opacity:.4}.mm-pg span{font:600 13px system-ui,sans-serif;white-space:nowrap}'+
'.mm-demo-row{display:flex;flex-direction:column;gap:8px;margin-top:10px}.mm-demo-row button{min-height:44px;border-radius:10px;border:2px solid #c4912e;background:transparent;color:inherit;font-size:15px;cursor:pointer}';
document.head.appendChild(css);
function build(){if($('mm-set-btn'))return;var b=document.createElement('button');b.id='mm-set-btn';b.type='button';b.setAttribute('aria-label','Settings, accessibility and backup');b.setAttribute('aria-expanded','false');b.textContent='\u2699';
var p=document.createElement('div');p.id='mm-set-pop';p.setAttribute('role','dialog');p.setAttribute('aria-label','Settings, accessibility and backup');
p.innerHTML='<h3>Accessibility</h3><div><button type="button" data-a="t-">A\u2212 Smaller</button><button type="button" data-a="t+">A+ Larger</button></div>'+
'<label><input type="checkbox" data-k="hc"> High contrast</label><label><input type="checkbox" data-k="dk"> Dark mode</label><label><input type="checkbox" data-k="dy"> Easy-read text</label><label><input type="checkbox" data-k="rm"> Reduce motion</label>'+
'<h3 style="margin-top:10px">Back up progress</h3><div style="font-size:12px;margin-bottom:4px">Progress is saved only on this device. Back it up before clearing browser data or switching devices.</div><button type="button" data-a="ex">Download backup</button><button type="button" data-a="im">Restore backup</button><input type="file" id="mm-imp" accept="application/json,.json" hidden>';
document.body.appendChild(b);document.body.appendChild(p);
p.querySelectorAll('input[data-k]').forEach(function(c){c.checked=!!P[c.dataset.k];c.addEventListener('change',function(){P[c.dataset.k]=c.checked?1:0;save();});});
p.addEventListener('click',function(e){var a=e.target.dataset&&e.target.dataset.a;if(!a)return;if(a==='t+')P.t=Math.min(2,(P.t||0)+1);if(a==='t-')P.t=Math.max(0,(P.t||0)-1);if(a==='t+'||a==='t-')save();if(a==='ac'){if(window.__MM_FULL){try{localStorage.removeItem('mmAccess_v1');}catch(e){}location.reload();}else unlock();}if(a==='ex')exportData();if(a==='im')$('mm-imp').click();});
$('mm-imp').addEventListener('change',function(e){importData(e.target.files[0]);e.target.value='';});
b.addEventListener('click',function(){var o=p.style.display==='block';p.style.display=o?'none':'block';b.setAttribute('aria-expanded',String(!o));});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&p.style.display==='block'){p.style.display='none';b.setAttribute('aria-expanded','false');b.focus();}});}
var QS='Quick start (about 60 seconds)\n\nTeachers and Parents/Guardians: choose Teacher or Parent/Guardian, set a passcode, add your learners, then open a week. Each learner gets a sign-in code.\n\nStudents: sign in with your code, read the lesson, do the worksheet, take the quiz, and write your reflection.\n\nParents/Guardians: open the Family Guide inside any lesson for talking points and at-home activities.\n\nTry the Story in the menu for a choice-based lesson. Progress stays on this device. Use the gear button to back it up.';
function demoBtns(){var g=$('mm-login-gate');if(!g||g.querySelector('.mm-demo-row')||!g.querySelector('.mm-role-choice'))return;var d=document.createElement('div');d.className='mm-demo-row';
d.innerHTML='<button type="button" data-d="demo">\uD83D\uDC40 Try a sample lesson (no sign-in)</button><button type="button" data-d="qs">\u2753 60-second quick start</button>';
d.addEventListener('click',function(e){var k=e.target.dataset&&e.target.dataset.d;if(k==='unlock'){unlock();}if(k==='qs'){try{mmAlert(QS,'\u2753');}catch(x){alert(QS);}}
if(k==='demo'){try{sessionStorage.setItem('mmDemo','1');g.classList.add('mm-hidden');if(typeof openPanel==='function')openPanel('lessons');toast('Sample mode: explore the lesson. Sign in to save progress.');}catch(x){}}});
var t=g.querySelector('.mm-login-note');(t&&t.parentNode?t.parentNode:g).appendChild(d);}
function unlock(){var go=function(c){c=(c||'').trim();if(!c)return;fetch('/api/content',{headers:{Authorization:'Bearer '+c}}).then(function(r){if(!r.ok)throw 0;try{localStorage.setItem('mmAccess_v1',c);}catch(e){}location.reload();}).catch(function(){toast('That access code is not valid, has expired, or could not be checked. Check it and your internet connection.');});};
try{mmInput('Access code','',{icon:'\uD83D\uDD11',okLabel:'Unlock'}).then(go);}catch(e){go(prompt('Access code'));}}
if(window.__MM_ACCESS_ERR)setTimeout(function(){toast('Your access code has expired or was revoked. Enter a new code to keep the full curriculum.');},1800);
if(window.__MM_LICENSE){var ps=document.createElement('style');ps.textContent='@media print{body:after{content:"Licensed to '+String(window.__MM_LICENSE).replace(/[^\w .,&\-]/g,'')+' • Money Matters © 2026. Do not redistribute.";position:fixed;bottom:2mm;left:0;right:0;text-align:center;font:9px system-ui,sans-serif;color:#555}}';document.head.appendChild(ps);}
var pg={};
function paginate(fid,bid){var f=$(fid),bt=$(bid);if(!f)return;var items=f.querySelectorAll('.q-item'),nv=$('mm-pg-'+fid);
if(items.length<2){if(nv)nv.remove();return;}
var st=pg[fid];if(!st||st.first!==items[0]){st=pg[fid]={first:items[0],cur:0};if(nv){nv.remove();nv=null;}}
var graded=Array.prototype.some.call(f.querySelectorAll('.q-fb'),function(x){return x.textContent.trim();});
if(graded){items.forEach(function(i){i.style.display='';});if(nv)nv.remove();if(bt)bt.style.display='';return;}
if(!nv){nv=document.createElement('div');nv.id='mm-pg-'+fid;nv.className='mm-pg';nv.innerHTML='<button type="button" data-p="-1">\u2190 Back</button><span aria-live="polite"></span><button type="button" data-p="1">Next \u2192</button>';
nv.addEventListener('click',function(e){var d=+(e.target.dataset&&e.target.dataset.p);if(!d)return;st.cur=Math.max(0,Math.min(items.length-1,st.cur+d));show();});
(bt&&bt.parentNode?bt.parentNode.insertBefore(nv,bt):f.parentNode.appendChild(nv));}
function show(){items.forEach(function(i,n){i.style.display=n===st.cur?'':'none';});var s=nv.querySelector('span');s.textContent='Question '+(st.cur+1)+' of '+items.length;
nv.querySelector('[data-p="-1"]').disabled=st.cur===0;nv.querySelector('[data-p="1"]').disabled=st.cur===items.length-1;if(bt)bt.style.display=st.cur===items.length-1?'':'none';}
show();}
function watch(fid,bid){var f=$(fid);if(!f||f.__mm)return;f.__mm=1;var t;new MutationObserver(function(){clearTimeout(t);t=setTimeout(function(){paginate(fid,bid);},30);}).observe(f,{childList:true,subtree:true,characterData:true});paginate(fid,bid);}
function fb(){if(typeof submitFeedback!=='function'||submitFeedback.__mm)return;var o=submitFeedback;var w=function(){var el=$('feedbackText'),txt=el?el.value:'',n=(typeof loadFeedback==='function')?loadFeedback().length:0;o.apply(this,arguments);
try{var em=window.MM_SUPPORT_EMAIL;if(em&&txt&&txt.trim()&&loadFeedback().length>n){location.href='mailto:'+em+'?subject='+encodeURIComponent('Money Matters feedback')+'&body='+encodeURIComponent(txt.trim().slice(0,1000));}}catch(e){}};w.__mm=1;submitFeedback=w;}
function init(){build();fb();watch('quizForm','quizButtons');watch('testForm','testButtons');demoBtns();}
window.MM_SUPPORT_EMAIL=window.MM_SUPPORT_EMAIL||'';
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
new MutationObserver(function(){demoBtns();watch('quizForm','quizButtons');watch('testForm','testButtons');}).observe(document.body,{childList:true,subtree:true});
try{if(typeof CHANGELOG!=='undefined')CHANGELOG.unshift({date:'September 2026',items:['Public launch build: owner bypass removed.','Added accessibility settings: text size, high contrast, dark mode, easy-read text, reduce motion.','Added progress backup and restore.','Quizzes and section tests now show one question at a time.','Added a sample lesson and a 60-second quick start on the sign-in screen.','Updated sign-in and privacy wording.']});}catch(e){}
})();
