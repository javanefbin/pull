/* =====================================================================
   V92 · ACCOUNTS & SECURITY  (MM92)
     MM.accounts  user accounts (admin · teacher · guardian · student),
                  hashed passwords, lockout, temporary passwords,
                  recovery questions, security policy, sign-in log
     MM.gate      unified username + password sign-in (replaces v91 gate)
     MM.session   keep-me-signed-in, idle timeout, activity tracking
     MM.trend     daily snapshots for 30-day trends
     MM.theme     native dark theme toggle
     MM.i18n      Spanish / Portuguese for the professional suite UI
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91,U=MM.util,D=MM.data,A=MM.auth,S=MM.shell,$=U.$,E=U.E;
MM.VERSION='92';
var KEY='mmAccounts_v1',LOG='mmAuthLog_v1',KEEP='mmKeep_v1',ACT='mmLastActivity',SNAP='mmSnapshots_v1';
var ROLES={admin:'Administrator',teacher:'Teacher',coteacher:'Co-teacher',guardian:'Parent / Guardian',student:'Student'};
/* Scope enforcement: staff accounts limited to specific grades only see those students.
   D.listAll stays unfiltered for account bookkeeping and sign-in. */
if(!D.listAll){D.listAll=D.list;D.list=function(){var all=D.listAll(),a=A.get();if(!a||a.role!=='teacher'||A.isAdmin()||!Array.isArray(a.scope))return all;return all.filter(function(st){return a.scope.indexOf(st.grade||'K')>-1;});};}
var LALL=function(){return D.listAll();};
var STAFF=['admin','teacher','coteacher','guardian'];
var SECQ=['What was the name of your first pet?','What city were you born in?','What was the name of your elementary school?','What is your mother\u2019s maiden name?','What was your childhood nickname?','What is the name of the street you grew up on?','What was the make of your first car?','What is your favorite teacher\u2019s last name?','What is the title of your favorite book?','In what city did your parents meet?'];
var DEF_POLICY={minLen:6,lockAfter:5,lockMins:15,idleMins:30,keepDays:7,mustChangeNew:true,nameLogin:true,backupDays:7};

/* ---------- hashing (Web Crypto when available) ---------- */
function salt(){try{var a=new Uint8Array(8);crypto.getRandomValues(a);return Array.from(a).map(function(b){return b.toString(16).padStart(2,'0');}).join('');}catch(e){return Math.random().toString(16).slice(2,18);}}
function hash(pw,s){var v=String(pw||'');if(typeof _sha256==='function'){return _sha256(s+':'+v).then(function(h){return h?('sha256:'+h):('plain:'+v);});}return Promise.resolve('plain:'+v);}
function check(pw,s,stored){if(!stored)return Promise.resolve(false);if(stored.indexOf('plain:')===0)return Promise.resolve(stored==='plain:'+pw);return hash(pw,s).then(function(h){return h===stored;});}

/* ---------- MM.accounts ---------- */
var ACC=MM.accounts={
  ROLES:ROLES,STAFF:STAFF,
  load:function(){try{var o=JSON.parse(localStorage.getItem(KEY)||'null');if(o&&o.list)return o;}catch(e){}return {list:{},policy:{}};},
  save:function(o){try{localStorage.setItem(KEY,JSON.stringify(o));}catch(e){}},
  policy:function(){var o=ACC.load();return Object.assign({},DEF_POLICY,o.policy||{});},
  setPolicy:function(p){var o=ACC.load();o.policy=Object.assign({},o.policy||{},p);ACC.save(o);},
  norm:function(u){return String(u||'').trim().toLowerCase().replace(/\s+/g,'.').replace(/[^a-z0-9._@-]/g,'').replace(/\.{2,}/g,'.').replace(/^\.+|\.+$/g,'').slice(0,40);},
  get:function(u){var o=ACC.load();return o.list[ACC.norm(u)]||null;},
  list:function(){var o=ACC.load();return Object.keys(o.list).map(function(k){return o.list[k];});},
  staff:function(){return ACC.list().filter(function(a){return a.role!=='student';});},
  admins:function(){return ACC.list().filter(function(a){return a.role==='admin'&&!a.locked;});},
  update:function(u,fn){var o=ACC.load(),k=ACC.norm(u);if(!o.list[k])return false;fn(o.list[k],o);ACC.save(o);return true;},
  remove:function(u){var o=ACC.load();delete o.list[ACC.norm(u)];ACC.save(o);},
  uniqueUsername:function(base){base=ACC.norm(base)||'user';var o=ACC.load(),u=base,n=1;while(o.list[u]){n++;u=base+n;}return u;},
  tempPassword:function(){var w=['Oak','Maple','River','Coin','Penny','Sunny','Maple','Cedar','Lark','Harbor','Acorn','Dime'],x=w[Math.floor(Math.random()*w.length)];return x+'-'+String(1000+Math.floor(Math.random()*9000));},
  add:function(opts){var o=ACC.load(),u=opts.username?ACC.norm(opts.username):ACC.uniqueUsername(opts.name);if(!u)return Promise.resolve({error:'Enter a username.'});if(o.list[u])return Promise.resolve({error:'That username is already taken.'});
    var rec={u:u,name:String(opts.name||u).trim().slice(0,60),email:String(opts.email||'').trim().slice(0,80),role:ROLES[opts.role]?opts.role:'teacher',scope:opts.scope||'all',studentId:opts.studentId||null,locked:!!opts.pending,pending:!!opts.pending,mustChange:!!opts.mustChange,created:new Date().toISOString(),createdBy:opts.by||'',lastSignIn:null,failures:0,salt:salt()};
    var pw=opts.password||ACC.tempPassword();
    return hash(pw,rec.salt).then(function(h){rec.hash=h;o.list[u]=rec;ACC.save(o);ACC.log('user-add',u,ROLES[rec.role],opts.by);return {account:rec,password:pw};});},
  setPassword:function(u,pw,o2){o2=o2||{};var acc=ACC.get(u);if(!acc)return Promise.resolve(false);return hash(pw,acc.salt).then(function(h){ACC.update(u,function(a){a.hash=h;a.mustChange=!!o2.mustChange;a.failures=0;a.lockUntil=0;});ACC.log(o2.reset?'pw-reset':'pw-set',ACC.norm(u),'',o2.by);return true;});},
  reset:function(u,by){var pw=ACC.tempPassword();return ACC.setPassword(u,pw,{mustChange:true,reset:true,by:by}).then(function(ok){return ok?pw:null;});},
  lock:function(u,locked,by){ACC.update(u,function(a){a.locked=!!locked;if(!locked){a.failures=0;a.lockUntil=0;}});ACC.log(locked?'user-lock':'user-unlock',ACC.norm(u),'',by);},
  SECQ:SECQ,
  /* security questions: two question/answer pairs, answers stored hashed */
  setSecurity:function(u,pairs){var acc=ACC.get(u);if(!acc)return Promise.resolve(false);var clean=(pairs||[]).filter(function(p){return p&&p.q&&String(p.a||'').trim();}).slice(0,3);if(!clean.length)return Promise.resolve(false);
    return Promise.all(clean.map(function(p){return hash(String(p.a).trim().toLowerCase().replace(/\s+/g,' '),acc.salt).then(function(h){return {q:p.q,h:h};});})).then(function(list){ACC.update(u,function(a){a.secQ=list;});ACC.log('security-set',ACC.norm(u),list.length+' questions',u);return true;});},
  hasSecurity:function(acc){return !!(acc&&acc.secQ&&acc.secQ.length);},
  checkSecurity:function(u,answers){var acc=ACC.get(u);if(!acc||!acc.secQ||!acc.secQ.length)return Promise.resolve(false);
    return Promise.all(acc.secQ.map(function(q,i){return check(String(answers[i]||'').trim().toLowerCase().replace(/\s+/g,' '),acc.salt,q.h);})).then(function(r){return r.every(Boolean);});},
  approve:function(u,by){ACC.update(u,function(a){a.pending=false;a.locked=false;a.failures=0;a.lockUntil=0;});ACC.log('user-approve',ACC.norm(u),'',by);},
  pending:function(){return ACC.list().filter(function(a){return a.pending;});},
  setRecovery:function(u,q,a){var acc=ACC.get(u);if(!acc)return Promise.resolve(false);return hash(String(a||'').trim().toLowerCase(),acc.salt).then(function(h){ACC.update(u,function(x){x.recQ=q;x.recA=h;});return true;});},
  checkRecovery:function(u,a){var acc=ACC.get(u);if(!acc||!acc.recA)return Promise.resolve(false);return check(String(a||'').trim().toLowerCase(),acc.salt,acc.recA);},
  verify:function(u,pw){var acc=ACC.get(u);if(!acc)return Promise.resolve(null);return check(pw,acc.salt,acc.hash).then(function(ok){return ok?acc:null;});},
  isLockedOut:function(acc){return !!(acc.lockUntil&&acc.lockUntil>Date.now());},
  recordFail:function(acc){var p=ACC.policy();ACC.update(acc.u,function(a){a.failures=(a.failures||0)+1;if(a.failures>=p.lockAfter){a.lockUntil=Date.now()+p.lockMins*60000;a.failures=0;}});},
  recordSuccess:function(acc){ACC.update(acc.u,function(a){a.failures=0;a.lockUntil=0;a.lastSignIn=new Date().toISOString();});},
  /* every roster student gets a login: username first.l, password = sign-in code */
  studentUsername:function(st){var p=String(st.name||'student').trim().split(/\s+/),base=(p[0]+(p.length>1?'.'+p[p.length-1].charAt(0):'')).toLowerCase();return ACC.norm(base)||'student';},
  ensureStudents:function(){var o=ACC.load(),changed=false,byId={};var ROSTER=LALL();Object.keys(o.list).forEach(function(k){var a=o.list[k];if(a.role==='student'&&a.studentId)byId[a.studentId]=a;});
    ROSTER.forEach(function(st){if(byId[st.id]){if(byId[st.id].name!==st.name){byId[st.id].name=st.name;changed=true;}return;}var base=ACC.studentUsername(st),u=base,n=1;while(o.list[u]){n++;u=base+n;}o.list[u]={u:u,name:st.name,email:'',role:'student',scope:st.grade||'K',studentId:st.id,locked:false,mustChange:false,created:st.created||new Date().toISOString(),createdBy:'roster',lastSignIn:null,failures:0,salt:salt(),hash:''};changed=true;});
    /* drop accounts whose student was removed */
    var ids={};ROSTER.forEach(function(st){ids[st.id]=1;});Object.keys(o.list).forEach(function(k){var a=o.list[k];if(a.role==='student'&&a.studentId&&!ids[a.studentId]){delete o.list[k];changed=true;}});
    if(changed)ACC.save(o);},
  forStudent:function(id){return ACC.list().filter(function(a){return a.role==='student'&&a.studentId===id;})[0]||null;},
  scopeLabel:function(a){if(!a||a.scope==='all'||!a.scope)return 'All grades';var s=Array.isArray(a.scope)?a.scope:[a.scope];return s.map(function(g){return D.gradeLabel(g);}).join(', ');},
  /* sign-in log */
  log:function(ev,u,note,by){try{var l=JSON.parse(localStorage.getItem(LOG)||'[]');l.unshift({t:new Date().toISOString(),ev:ev,u:u||'',note:note||'',by:by||''});if(l.length>600)l.length=600;localStorage.setItem(LOG,JSON.stringify(l));}catch(e){}},
  logList:function(){try{return JSON.parse(localStorage.getItem(LOG)||'[]');}catch(e){return [];}},
  clearLog:function(){try{localStorage.removeItem(LOG);}catch(e){}}
};

/* ---------- role → session ---------- */
function startSession(acc,opts){opts=opts||{};var role=acc.role==='student'?'student':'teacher';
  try{sessionStorage.setItem('mmRole',role);sessionStorage.setItem('mmLoginRole',role);}catch(e){}
  if(acc.role==='student'){var st=D.get(acc.studentId);if(!st)return false;A.set({role:'student',name:st.name,id:st.id,u:acc.u});window.__mmLogin=1;try{switchStudent(st.id);}catch(e){try{setTabActive(st.id);}catch(x){}}window.__mmLogin=0;}
  else{A.set({role:'teacher',name:acc.name||acc.u,id:acc.role==='admin'?'admin':'teacher',u:acc.u,scope:acc.scope||'all',acctRole:acc.role});if(acc.role!=='admin'){try{addTeacherName(acc.name||acc.u);}catch(e){}}}
  ACC.recordSuccess(acc);ACC.log('signin',acc.u,ROLES[acc.role]);
  if(opts.keep)SES.persist();
  SES.touch();
  return true;}
function finish(acc){GATE.hide();try{applyRole();buildNav();}catch(e){}
  /* administrators open their console; teachers, co-teachers and guardians land on the classroom home like students */
  if(acc.role==='admin'){try{openPanel('admin');}catch(e){}}
  else if(acc.role!=='student'){try{closePanel(true);}catch(e){}try{S.topbar();S.renderHome();}catch(e){}}
  U.toast('Welcome, '+(acc.name||acc.u)+'.',2500);}

/* ---------- MM.session: keep-signed-in + idle timeout ---------- */
var SES=MM.session={
  persist:function(){try{var p=ACC.policy();localStorage.setItem(KEEP,JSON.stringify({auth:A.get(),role:sessionStorage.getItem('mmRole'),exp:Date.now()+p.keepDays*86400000}));}catch(e){}},
  clearPersist:function(){try{localStorage.removeItem(KEEP);}catch(e){}},
  restore:function(){if(A.get())return false;try{var k=JSON.parse(localStorage.getItem(KEEP)||'null');if(!k||!k.auth||k.exp<Date.now()){if(k)localStorage.removeItem(KEEP);return false;}
      if(k.auth.u){var acc=ACC.get(k.auth.u);if(!acc||acc.locked){localStorage.removeItem(KEEP);return false;}}
      sessionStorage.setItem('mmRole',k.role||'student');sessionStorage.setItem('mmLoginRole',k.role||'student');A.set(k.auth);
      if(k.auth.role==='student'&&k.auth.id){window.__mmLogin=1;try{setTabActive(k.auth.id);var s=loadStore();s.active=k.auth.id;saveStore(s);}catch(e){}window.__mmLogin=0;}
      SES.touch();return true;}catch(e){return false;}},
  touch:function(){try{sessionStorage.setItem(ACT,String(Date.now()));}catch(e){}},
  idleCheck:function(){if(!A.get()||GATE.visible())return;var p=ACC.policy();if(!p.idleMins)return;var last=0;try{last=parseInt(sessionStorage.getItem(ACT)||'0',10);}catch(e){}if(!last){SES.touch();return;}
    if(Date.now()-last>p.idleMins*60000){var a=A.get();ACC.log('timeout',a&&a.u||a&&a.name||'','Signed out after '+p.idleMins+' minutes without activity');GATE.signOut('Signed out after '+p.idleMins+' minutes without activity. Sign in again.');}}
};
(function(){var th=0;['pointerdown','keydown','touchstart','wheel'].forEach(function(ev){document.addEventListener(ev,function(){var n=Date.now();if(n-th>15000){th=n;SES.touch();}},{passive:true});});setInterval(SES.idleCheck,20000);document.addEventListener('visibilitychange',function(){if(!document.hidden)SES.idleCheck();});})();

/* ---------- MM.gate: unified sign-in ---------- */
var GATE=MM.gate;
(function(){
  var el=null,view='signin',msg='',msgCls='',busy=false,pending=null,created=null,returnAfterPanel=false,recoverU='',sampleRole='student';
  function ensure(){if(el)return el;el=$('mm-auth');if(!el){el=document.createElement('div');el.id='mm-auth';el.className='mm-hidden';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label','Sign in');document.body.appendChild(el);}
    if(!el.__v92){el.__v92=1;U.on(el,'click','[data-a]',function(e,b){e.preventDefault();act(b.getAttribute('data-a'),b);});
      el.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target&&/^(INPUT|SELECT)$/.test(e.target.tagName)){e.preventDefault();submit();}});}
    return el;}
  function setMsg(m,cls){msg=m||'';msgCls=cls||'';var x=el&&el.querySelector('.msg');if(x){x.textContent=msg;x.className='msg '+msgCls;}}
  function show(opts){opts=opts||{};ensure();if(visible()&&!opts.view&&!opts.message)return;view=opts.view||'signin';created=null;if(opts.message){msg=opts.message;msgCls=opts.messageClass||'';}
    if(view==='signin'&&!ACC.admins().length&&!legacyAdminPossible()&&!legacyPin())view='setup';
    el.classList.remove('mm-hidden');document.documentElement.classList.add('mm-gated');render();try{S.topbar();}catch(e){}}
  function hide(){if(el)el.classList.add('mm-hidden');document.documentElement.classList.remove('mm-gated');setMsg('');try{S.topbar();}catch(e){}}
  function visible(){return !!(el&&!el.classList.contains('mm-hidden'));}
  function legacyPin(){try{return typeof _hasPin==='function'&&_hasPin();}catch(e){return false;}}
  function legacyAdminPossible(){try{return !!localStorage.getItem('mmAdmin_v1')&&typeof window.mmV55Login==='function';}catch(e){return false;}}
  function fld(label,id,attrs,eye){return '<label class="lbl" for="'+id+'">'+E(label)+'</label><div class="fld"><input id="'+id+'" '+attrs+'>'+(eye?'<button type="button" class="eye" data-a="eye" data-for="'+id+'" aria-label="Show">👁</button>':'')+'</div>';}
  function secFields(prefix,count){var h='<label class="lbl">Security questions <span style="font-weight:600;text-transform:none;letter-spacing:0;color:var(--ink-light)">(used to reset a forgotten password)</span></label>';for(var i=0;i<count;i++){h+='<div class="fld" style="margin-bottom:8px"><select id="'+prefix+'q'+i+'" aria-label="Security question '+(i+1)+'">'+SECQ.map(function(q,j){return '<option value="'+E(q)+'"'+(j===i?' selected':'')+'>'+E(q)+'</option>';}).join('')+'</select></div><div class="fld" style="margin-bottom:10px"><input id="'+prefix+'a'+i+'" type="text" autocomplete="off" placeholder="Answer '+(i+1)+'"></div>';}return h;}
  function secRead(prefix,count){var out=[];for(var i=0;i<count;i++){var q=val(prefix+'q'+i),a=val(prefix+'a'+i).trim();if(q&&a)out.push({q:q,a:a});}return out;}
  function secValid(prefix,count){var pairs=secRead(prefix,count);if(pairs.length<count)return 'Answer both security questions.';var qs=pairs.map(function(p){return p.q;});if(new Set(qs).size!==qs.length)return 'Choose two different security questions.';return '';}
  function brand(sub){var sch='';try{sch=getSchoolName();}catch(e){}var init=(sch||'Money Matters').trim().charAt(0).toUpperCase();return '<div class="mm-login-brand"><div class="logo" aria-hidden="true">'+E(init)+'</div><div><h1>'+E(sch||'Money Matters')+'</h1><p>'+E(sub||'K–8 Financial Literacy Classroom')+'</p></div></div>';}
  function foot(){var sch='';try{sch=getSchoolName();}catch(e){}return '<div class="foot"><span>'+E(sch?sch+' · Money Matters':'Money Matters')+'</span><span>K–8 Financial Literacy Classroom</span></div>';}
  function vSignin(){var u='';try{u=localStorage.getItem('mmLoginUser_v1')||'';}catch(e){}var noAdmin=!ACC.admins().length;
    var stu=loginAs()==='student';
    return brand('Sign in to your classroom')
      +'<div class="mm-who" role="group" aria-label="I am signing in as"><button type="button" data-a="as" data-v="student" aria-pressed="'+stu+'">Student</button><button type="button" data-a="as" data-v="staff" aria-pressed="'+(!stu)+'">Teacher, parent or admin</button></div>'
      +fld('Username','mm55-user','type="text" autocomplete="username" autocapitalize="off" spellcheck="false" value="'+E(u)+'"')
      +(stu?fld('Sign-in code','mm55-pass','type="password" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="12" placeholder="6-character code"',true)+'<div class="mm-who-hint">Your teacher gives you a username and a 6-character sign-in code.</div>'
           :fld('Password','mm55-pass','type="password" autocomplete="current-password"',true))
      +'<label class="keep"><input type="checkbox" id="a-keep" '+(u?'checked':'')+'> Keep me signed in on this device for '+ACC.policy().keepDays+' days</label>'
      +'<div class="msg '+msgCls+'" id="mm55-error" role="alert">'+E(msg)+'</div>'
      +'<button type="button" class="go" data-a="login">Sign in</button>'
      +'<div class="links"><button type="button" data-a="create">Create a profile</button><button type="button" data-a="forgot">Forgot password?</button></div>'
      +sampleCta()
      +(noAdmin?'<div class="hint" style="text-align:center">First time here? <button type="button" class="back" style="display:inline" data-a="setup">Set up the administrator account</button></div>':'')
      +foot();}
  function vSetup(){var needPin=legacyPin();return brand('Administrator setup')+'<div class="hint">Create the first administrator account for this device. The administrator adds teachers and students, sets security policy, and manages backups.</div>'
      +fld('Username','s-u','type="text" autocomplete="off" autocapitalize="off" value="admin"')+fld('Display name','s-n','type="text" autocomplete="off" placeholder="e.g. Ms. Rivera"')+fld('Email (optional)','s-e','type="email" autocomplete="off"')
      +'<div class="two">'+fld('Password','s-p1','type="password" autocomplete="new-password"',true)+fld('Confirm password','s-p2','type="password" autocomplete="new-password"')+'</div>'
      +secFields('s-s',2)
      +(needPin?fld('Current teacher passcode','s-pin','type="password" autocomplete="off"',true)+'<div class="hint">A teacher passcode already protects this device. Enter it to authorize the new administrator.</div>':'')
      +'<div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go green" data-a="dosetup">Create administrator</button>'
      +(ACC.admins().length||legacyAdminPossible()||needPin?'<button type="button" class="back" data-a="back">← Back to sign in</button>':'')+sampleCta()+foot();}
  function vCreate(){return '<button type="button" class="back" data-a="back">← Back to sign in</button>'+brand('Create a profile')+'<div class="hint">Who is this profile for?</div>'
      +'<button type="button" class="mm-list-row clickable" data-a="createStudent" style="width:100%;text-align:left">'+U.avatar('S','sm')+'<div class="main"><div class="title">Student</div><div class="sub">Lessons, quizzes, games, and the story. Gets a username and a 6-character sign-in code.</div></div><span aria-hidden="true">›</span></button>'
      +'<button type="button" class="mm-list-row clickable" data-a="createTeacher" style="width:100%;text-align:left">'+U.avatar('T','sm teacher')+'<div class="main"><div class="title">Teacher</div><div class="sub">Class roster, student profiles, reports, and lesson guides. '+(ACC.admins().length?'An administrator approves new teacher profiles.':'Becomes active right away.')+'</div></div><span aria-hidden="true">›</span></button>'
      +'<div class="hint" style="text-align:center;margin-top:4px">Administrator accounts are created by an existing administrator in Users.</div>'+foot();}
  function vCreateStudent(){var gs=D.GRADES.map(function(g){return '<option value="'+g+'"'+(g===(currentGrade||'K')?' selected':'')+'>'+E(D.gradeLabel(g))+'</option>';}).join('');
    return '<button type="button" class="back" data-a="create">← Back</button>'+brand('Create a student profile')+fld('Student name','c-name','type="text" autocomplete="off" autocapitalize="words" maxlength="40"')+'<label class="lbl" for="c-grade">Grade</label><div class="fld"><select id="c-grade">'+gs+'</select></div>'+fld('Teacher or class (optional)','c-teacher','type="text" list="c-teachers" autocomplete="off" maxlength="60"')+'<datalist id="c-teachers">'+D.teachers().map(function(n){return '<option value="'+E(n)+'">';}).join('')+'</datalist>'
      +'<div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go" data-a="docreate">Create student profile</button><div class="hint" style="text-align:center">A username and a 6-character sign-in code are created automatically.</div>'+foot();}
  function vCreateTeacher(){var p=ACC.policy(),needPin=legacyPin(),hasAdmin=ACC.admins().length>0;
    return '<button type="button" class="back" data-a="create">← Back</button>'+brand('Create a teacher profile')+fld('Full name','t-name','type="text" autocomplete="name" autocapitalize="words" maxlength="60" placeholder="e.g. Ms. Rivera"')+fld('Username','t-u','type="text" autocomplete="username" autocapitalize="off" spellcheck="false" placeholder="e.g. ms.rivera"')+fld('Email (optional)','t-e','type="email" autocomplete="email"')
      +'<div class="two">'+fld('Password','t-p1','type="password" autocomplete="new-password"',true)+fld('Confirm password','t-p2','type="password" autocomplete="new-password"')+'</div>'
      +'<label class="lbl">Grades you teach</label><div class="mm-row" id="t-grades"><button type="button" class="mm-btn sm primary" data-a="tg" data-g="all" aria-pressed="true">All grades</button>'+D.GRADES.map(function(g){return '<button type="button" class="mm-btn sm secondary" data-a="tg" data-g="'+g+'" aria-pressed="false">'+E(D.gradeShort(g))+'</button>';}).join('')+'</div>'
      +secFields('t-s',2)
      +(needPin?fld('Teacher passcode (optional)','t-pin','type="password" autocomplete="off"',true)+'<div class="hint">Enter the device teacher passcode to activate the profile immediately. Without it, an administrator approves the profile first.</div>':(hasAdmin?'<div class="hint">An administrator reviews and approves new teacher profiles in Users before the first sign-in.</div>':''))
      +'<div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go green" data-a="docreateTeacher">Create teacher profile</button><div class="hint" style="text-align:center">Use at least '+p.minLen+' characters for the password.</div>'+foot();}
  function vCreated(){var acc=ACC.forStudent(created.id);return brand('Profile created')+'<div class="hint">'+E(created.name)+' is enrolled in '+E(D.gradeLabel(created.grade))+'. Write down these sign-in details.</div><div class="code-show"><div class="mm-label">Username</div><div class="big" style="font-size:22px;letter-spacing:.06em;padding-left:0">'+E(acc?acc.u:'')+'</div><div class="mm-label" style="margin-top:6px">Password (sign-in code)</div><div class="big">'+E(created.verifyCode)+'</div></div><div class="msg"></div><button type="button" class="go green" data-a="continue">Continue to the classroom</button>'+foot();}
  function vChange(){var p=ACC.policy();return brand('Set a new password')+'<div class="hint">'+(pending&&pending.reason?E(pending.reason):'Your password is temporary. Choose a new one to continue.')+' Use at least '+p.minLen+' characters.</div>'+fld('New password','n-p1','type="password" autocomplete="new-password"',true)+fld('Confirm new password','n-p2','type="password" autocomplete="new-password"')+'<div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go green" data-a="dochange">Save password and continue</button><button type="button" class="back" data-a="cancelchange">Cancel</button>'+foot();}
  function vRecover(){var acc=ACC.get(recoverU);if(acc&&ACC.hasSecurity(acc)){return '<button type="button" class="back" data-a="back">← Back to sign in</button>'+brand('Reset your password')+'<div class="hint">Answer the security questions for <b>'+E(acc.u)+'</b>, then choose a new password.</div>'+acc.secQ.map(function(q,i){return '<label class="lbl" for="r-s'+i+'">'+E(q.q)+'</label><div class="fld"><input id="r-s'+i+'" type="text" autocomplete="off" placeholder="Your answer"></div>';}).join('')+'<div class="two">'+fld('New password','r-p1','type="password" autocomplete="new-password"',true)+fld('Confirm','r-p2','type="password" autocomplete="new-password"')+'</div><div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go green" data-a="dorecover">Set new password</button><div class="hint">Answers are not case-sensitive. After three wrong attempts the account is locked and an administrator must reset it.</div>'+foot();}
    return '<button type="button" class="back" data-a="back">← Back to sign in</button>'+brand('Recover your password')+(acc&&acc.recQ?'<div class="hint">Answer your recovery question to set a new password.</div><div class="mm-card tight" style="font:600 14px var(--mm-ui)">'+E(acc.recQ)+'</div>'+fld('Your answer','r-a','type="text" autocomplete="off"')+'<div class="two">'+fld('New password','r-p1','type="password" autocomplete="new-password"',true)+fld('Confirm','r-p2','type="password" autocomplete="new-password"')+'</div><div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go green" data-a="dorecover">Set new password</button>'
      :fld('Username','r-u','type="text" autocomplete="username" autocapitalize="off" value="'+E(recoverU)+'"')+'<div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go" data-a="findrecover">Continue</button><div class="hint">No security questions on the account? Ask an administrator to reset your password. Students: ask your teacher for your sign-in code.</div>')+foot();}
  /* ---------- V95: free sample (one grade · Lesson 1, Story Mode, Games) ---------- */
  function sampleCta(){return '<div class="sample-cta" role="group" aria-label="Free sample"><div class="sample-cta-text"><b>Just looking?</b> Try a free sample of one grade — Lesson 1, Story Mode, and the Games — as a student or a teacher. No account needed.</div><button type="button" class="sample-btn" data-a="sample">🔎 Try a free sample</button></div>';}
  function vSample(){var cur='K';try{cur=currentGrade||'K';}catch(e){}var gs=D.GRADES.map(function(g){return '<option value="'+g+'"'+(g===cur?' selected':'')+'>'+E(D.gradeLabel(g))+'</option>';}).join('');var teacher=sampleRole==='teacher';
    return '<button type="button" class="back" data-a="back">← Back to sign in</button>'+brand('Try a free sample')
      +'<div class="hint">Explore one grade with no account. Lesson 1, Story Mode, and the Games are open; everything else unlocks with a subscription. Nothing you do in the sample is saved.</div>'
      +'<label class="lbl" id="smp-role-lbl">Sample as</label><div class="sample-roles" role="group" aria-labelledby="smp-role-lbl">'
      +'<button type="button" class="sample-role'+(teacher?'':' on')+'" data-a="srole" data-r="student" aria-pressed="'+(!teacher)+'"><span class="ic" aria-hidden="true">🎒</span><span class="t">Student</span><span class="d">Lesson, worksheet, quiz, story, and games</span></button>'
      +'<button type="button" class="sample-role'+(teacher?' on':'')+'" data-a="srole" data-r="teacher" aria-pressed="'+teacher+'"><span class="ic" aria-hidden="true">👩‍🏫</span><span class="t">Teacher</span><span class="d">Adds the lesson plan and answer key</span></button></div>'
      +'<label class="lbl" for="smp-grade">Grade</label><div class="fld"><select id="smp-grade" aria-label="Grade to sample">'+gs+'</select></div>'
      +'<div class="sample-incl"><div class="row ok"><span aria-hidden="true">✓</span><div><b>Lesson 1</b> · lesson, worksheet, and quiz'+(teacher?', plus the lesson plan and answer key':'')+'</div></div><div class="row ok"><span aria-hidden="true">✓</span><div><b>Story Mode</b> · the four-act money story for this grade</div></div><div class="row ok"><span aria-hidden="true">✓</span><div><b>Games</b> · every mini-game for this grade</div></div><div class="row lock"><span aria-hidden="true">🔒</span><div>Weeks 2–36, other grades, section tests, certificates, the assessment, '+(teacher?'class reports, and the Teacher Console':'and teacher tools')+' unlock with a subscription</div></div></div>'
      +'<div class="msg '+msgCls+'" role="alert">'+E(msg)+'</div><button type="button" class="go green" data-a="dosample">Start the sample</button>'+foot();}
  function doSample(){var g=val('smp-grade')||'K';if(!MM.sample||typeof MM.sample.start!=='function'){setMsg('Sample mode is not available in this build.');return;}setBusy(true);var ok=false;try{ok=MM.sample.start(sampleRole,g);}catch(e){console.warn('V95 sample start',e);}setBusy(false);if(!ok)setMsg('Could not start the sample. Please try again.');}
  /* V18: brand panel shown beside the form on wide screens */
  function aside(){var sch='';try{sch=getSchoolName();}catch(e){}return '<aside class="mm-auth-aside" aria-label="About Money Matters"><div class="mm-aa-brand"><span class="mm-aa-mark" aria-hidden="true">$</span><div><b>Money Matters</b><small>K–8 Financial Literacy</small></div></div><div><h2>Real-world money skills, <span>one lesson at a time.</span></h2><ul><li><b>324 lessons</b> across K–8 with quizzes, worksheets and checkpoints</li><li><b>Game Show</b> rounds and hands-on <b>Workshops</b> for the whole class</li><li><b>Private by design:</b> accounts and progress stay on this device</li></ul></div><div class="mm-aa-foot">'+E(sch?sch+' · Money Matters':'Money Matters · K–8 Financial Literacy Classroom')+'</div></aside>';}
  function loginAs(){try{return localStorage.getItem('mmLoginAs_v1')==='student'?'student':'staff';}catch(e){return 'staff';}}
  function render(){ensure();var v={signin:vSignin,setup:vSetup,create:vCreate,createStudent:vCreateStudent,createTeacher:vCreateTeacher,created:vCreated,change:vChange,recover:vRecover,sample:vSample}[view]||vSignin;el.innerHTML='<div class="mm-auth-shell">'+aside()+'<div class="mm-login">'+v()+'</div></div>';try{MM.i18n&&MM.i18n.apply(el);}catch(e){}
    setTimeout(function(){var f=el.querySelector('input:not([readonly]):not([type=checkbox])');if(f&&!f.value)try{f.focus({preventScroll:true});}catch(e){}else{var p=el.querySelector('input[type=password]');if(p)try{p.focus({preventScroll:true});}catch(e){}}},60);}
  function val(id){var x=$(id);return x?x.value:'';}
  function setBusy(b){busy=b;var g=el&&el.querySelector('.go');if(g)g.disabled=b;}
  function act(a,b){switch(a){
    case 'eye':{var i=$(b.getAttribute('data-for'));if(i){i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'👁':'🙈';}break;}
    case 'login':submit();break;
    case 'create':view='create';msg='';render();break;
    case 'createStudent':view='createStudent';msg='';render();break;
    case 'createTeacher':view='createTeacher';msg='';render();break;
    case 'tg':{var g=b.getAttribute('data-g'),row=$('t-grades');if(!row)return;if(g==='all'){row.querySelectorAll('button').forEach(function(x){var on=x.getAttribute('data-g')==='all';x.className='mm-btn sm '+(on?'primary':'secondary');x.setAttribute('aria-pressed',String(on));});}
      else{var all=row.querySelector('[data-g="all"]');all.className='mm-btn sm secondary';all.setAttribute('aria-pressed','false');var on=b.getAttribute('aria-pressed')!=='true';b.className='mm-btn sm '+(on?'primary':'secondary');b.setAttribute('aria-pressed',String(on));if(!row.querySelector('[aria-pressed="true"]')){all.className='mm-btn sm primary';all.setAttribute('aria-pressed','true');}}break;}
    case 'docreate':doCreate();break;
    case 'docreateTeacher':doCreateTeacher();break;
    case 'continue':finishCreated();break;
    case 'setup':view='setup';msg='';render();break;
    case 'dosetup':doSetup();break;
    case 'forgot':recoverU=val('mm55-user');view='recover';msg='';render();break;
    case 'findrecover':{recoverU=ACC.norm(val('r-u'));var acc=ACC.get(recoverU);if(!acc){setMsg('No account with that username.');return;}if(acc.locked){setMsg('This account is locked. Ask an administrator to unlock or reset it.','info');return;}if(!ACC.hasSecurity(acc)&&!acc.recQ){setMsg('This account has no security questions. Ask an administrator to reset the password.','info');return;}render();break;}
    case 'dorecover':doRecover();break;
    case 'dochange':doChange();break;
    case 'cancelchange':pending=null;A.clear();view='signin';msg='';render();break;
    case 'sample':view='sample';msg='';render();break;
    case 'as':{var keepU=val('mm55-user');try{localStorage.setItem('mmLoginAs_v1',b.getAttribute('data-v'));}catch(e){}msg='';render();var ue=$('mm55-user');if(ue&&keepU)ue.value=keepU;var pe=$('mm55-pass');if(pe)try{pe.focus();}catch(e){}break;}
    case 'srole':{sampleRole=b.getAttribute('data-r')==='teacher'?'teacher':'student';var sg=val('smp-grade');msg='';render();if(sg){var se=$('smp-grade');if(se)se.value=sg;}break;}
    case 'dosample':doSample();break;
    case 'back':view='signin';msg='';render();break;}}
  function submit(){if(busy)return;({signin:signIn,setup:doSetup,create:function(){},createStudent:doCreate,createTeacher:doCreateTeacher,created:finishCreated,change:doChange,sample:doSample,recover:function(){if($('r-a'))doRecover();else act('findrecover');}}[view]||signIn)();}
  function doCreateTeacher(){var name=val('t-name').trim(),u=ACC.norm(val('t-u')||name),e=val('t-e').trim(),p1=val('t-p1'),p2=val('t-p2'),pol=ACC.policy();setMsg('');
    if(!name){setMsg('Enter your full name.');return;}if(!u){setMsg('Enter a username.');return;}if(ACC.get(u)){setMsg('That username is already taken.');return;}if(p1.length<pol.minLen){setMsg('Use at least '+pol.minLen+' characters for the password.');return;}if(p1!==p2){setMsg('The passwords do not match.');return;}
    var sv2=secValid('t-s',2);if(sv2){setMsg(sv2);return;}
    var sel=[].slice.call(document.querySelectorAll('#t-grades [aria-pressed="true"]')).map(function(x){return x.getAttribute('data-g');}),scope=(!sel.length||sel.indexOf('all')>-1)?'all':sel;
    var hasAdmin=ACC.admins().length>0,pin=val('t-pin');
    var create=function(approved){setBusy(true);ACC.add({username:u,name:name,email:e,role:'teacher',scope:scope,password:p1,pending:!approved,by:'self'}).then(function(r){if(r.error){setBusy(false);setMsg(r.error);return null;}return ACC.setSecurity(u,secRead('t-s',2)).then(function(){return r;});}).then(function(r){if(!r)return;setBusy(false);try{addTeacherName(name);D.setTeacherMeta(name,{title:'Teacher'});}catch(x){}
        if(approved){startSession(r.account,{});finish(r.account);}else{view='signin';msg='Your teacher profile was created and is waiting for administrator approval. You will be able to sign in once it is approved.';msgCls='info';render();}});};
    if(!hasAdmin){create(true);return;}
    if(pin&&legacyPin()){_verifyPin(pin).then(function(ok){if(!ok){setMsg('The teacher passcode is incorrect. Leave it blank to request approval instead.');return;}create(true);});return;}
    create(false);}
  function fail(text){setMsg(text);var p=$('mm55-pass');if(p){p.value='';p.focus();}}
  function signIn(){var uRaw=val('mm55-user').trim(),pw=val('mm55-pass'),keep=!!($('a-keep')&&$('a-keep').checked);setMsg('');
    if(!uRaw){setMsg('Enter your username.');return;}if(!pw){setMsg('Enter your password.');return;}
    var u=ACC.norm(uRaw),acc=ACC.get(u),p=ACC.policy();
    try{if(keep)localStorage.setItem('mmLoginUser_v1',uRaw);else localStorage.removeItem('mmLoginUser_v1');}catch(e){}
    setBusy(true);
    var done=function(a){setBusy(false);if(!a)return;if(a.mustChange&&a.role!=='student'){pending={acc:a,keep:keep,reason:'Your password is temporary. Choose a new one to continue.'};view='change';msg='';render();return;}if(!startSession(a,{keep:keep})){setMsg('This student profile no longer exists.');return;}finish(a);};
    if(acc){if(acc.pending){setBusy(false);ACC.log('fail',u,'pending approval');fail('This teacher profile is waiting for administrator approval.');return;}
      if(acc.locked){setBusy(false);ACC.log('fail',u,'account locked');fail('This account is locked. Ask an administrator to unlock it.');return;}
      if(ACC.isLockedOut(acc)){setBusy(false);fail('Too many attempts. Try again in '+Math.ceil((acc.lockUntil-Date.now())/60000)+' minute(s).');return;}
      if(acc.role==='student'){var st=D.get(acc.studentId);setBusy(false);if(st&&pw.trim().toUpperCase()===D.codeOf(st)){done(acc);}else{ACC.recordFail(acc);ACC.log('fail',u,'wrong code');fail('Username or password is incorrect.');}return;}
      ACC.verify(u,pw).then(function(ok){if(ok){done(ok);return;}ACC.recordFail(acc);var a2=ACC.get(u);ACC.log(ACC.isLockedOut(a2)?'locked':'fail',u,ACC.isLockedOut(a2)?'locked for '+p.lockMins+' min':'wrong password');setBusy(false);fail(ACC.isLockedOut(a2)?'Too many attempts. Account locked for '+p.lockMins+' minutes.':'Username or password is incorrect.');});return;}
    /* students may sign in with their full name */
    if(p.nameLogin){var m=LALL().filter(function(st){return String(st.name).trim().toLowerCase()===uRaw.trim().toLowerCase()&&D.codeOf(st)===pw.trim().toUpperCase();});if(m.length===1){ACC.ensureStudents();var sa=ACC.forStudent(m[0].id);setBusy(false);if(sa){done(sa);return;}}}
    /* legacy administrator (v70) */
    if(u==='admin'&&typeof window.mmV55Login==='function'){var uu=$('mm55-user');if(uu)uu.value='admin';try{window.mmV55Login();}catch(e){}var t0=Date.now();(function chk(){if(A.isAdmin()){ACC.add({username:'admin',name:'Administrator',role:'admin',password:pw,by:'migration'}).then(function(){var a=ACC.get('admin');ACC.recordSuccess(a);ACC.log('signin','admin','Administrator (migrated)');if(keep)SES.persist();SES.touch();setBusy(false);hide();try{applyRole();buildNav();if(openPanelId!=='admin')openPanel('admin');}catch(e){}});return;}if(Date.now()-t0<2200)setTimeout(chk,120);else{setBusy(false);ACC.log('fail','admin','legacy admin');fail('Username or password is incorrect.');}})();return;}
    /* legacy shared teacher passcode */
    if(legacyPin()){_verifyPin(pw).then(function(ok){if(!ok){setBusy(false);ACC.log('fail',u,'no account');fail('Username or password is incorrect.');return;}ACC.add({username:u,name:uRaw,role:'teacher',password:pw,by:'migration'}).then(function(r){setBusy(false);if(r.account)done(r.account);});});return;}
    setBusy(false);ACC.log('fail',u,'no account');fail('Username or password is incorrect.');}
  function doSetup(){var u=ACC.norm(val('s-u')),n=val('s-n').trim(),e=val('s-e').trim(),p1=val('s-p1'),p2=val('s-p2'),pol=ACC.policy();setMsg('');
    if(!u){setMsg('Enter a username.');return;}if(p1.length<pol.minLen){setMsg('Use at least '+pol.minLen+' characters for the password.');return;}if(p1!==p2){setMsg('The passwords do not match.');return;}
    var sv=secValid('s-s',2);if(sv){setMsg(sv);return;}
    var go=function(){setBusy(true);ACC.add({username:u,name:n||'Administrator',email:e,role:'admin',password:p1,by:'setup'}).then(function(r){if(r.error){setBusy(false);setMsg(r.error);return;}ACC.setSecurity(u,secRead('s-s',2)).then(function(){setBusy(false);startSession(r.account,{});finish(r.account);});});};
    if(legacyPin()){_verifyPin(val('s-pin')).then(function(ok){if(!ok){setMsg('The teacher passcode is incorrect.');return;}go();});}else go();}
  function doCreate(){var name=val('c-name').trim(),g=val('c-grade')||'K',tn=val('c-teacher').trim();setMsg('');if(!name){setMsg('Enter the student name.');return;}
    if(D.list().some(function(st){return st.name.trim().toLowerCase()===name.toLowerCase()&&(st.grade||'K')===g;})){setMsg('A student with this name already exists in '+D.gradeLabel(g)+'. Sign in instead, or add a last initial.');return;}
    var rec=D.createStudent(name,g,tn);if(!rec){setMsg('Could not create the profile.');return;}ACC.ensureStudents();ACC.log('user-add',ACC.forStudent(rec.id).u,'Student (self-registered)');created=rec;view='created';render();}
  function finishCreated(){if(!created)return;var acc=ACC.forStudent(created.id);created=null;if(acc){startSession(acc,{});}hide();try{setGrade(D.get(acc.studentId).grade);applyRole();buildNav();}catch(e){}try{if(typeof window.mmV59StudentAssessment==='function')window.mmV59StudentAssessment();else openPanel('dashboard');}catch(e){}}
  function doChange(){if(!pending)return;var p1=val('n-p1'),p2=val('n-p2'),pol=ACC.policy();setMsg('');if(p1.length<pol.minLen){setMsg('Use at least '+pol.minLen+' characters.');return;}if(p1!==p2){setMsg('The passwords do not match.');return;}
    setBusy(true);ACC.setPassword(pending.acc.u,p1,{mustChange:false,by:pending.acc.u}).then(function(){var acc=ACC.get(pending.acc.u),keep=pending.keep;pending=null;setBusy(false);startSession(acc,{keep:keep});finish(acc);});}
  function doRecover(){var a=val('r-a'),p1=val('r-p1'),p2=val('r-p2'),pol=ACC.policy(),acc=ACC.get(recoverU);setMsg('');if(p1.length<pol.minLen){setMsg('Use at least '+pol.minLen+' characters.');return;}if(p1!==p2){setMsg('The passwords do not match.');return;}
    var verify=ACC.hasSecurity(acc)?ACC.checkSecurity(recoverU,acc.secQ.map(function(q,i){return val('r-s'+i);})):ACC.checkRecovery(recoverU,a);
    setBusy(true);verify.then(function(ok){
      if(!ok){setBusy(false);ACC.log('fail',recoverU,'recovery answer');var tries=0;try{tries=parseInt(sessionStorage.getItem('mmRecFail_'+recoverU)||'0',10)+1;sessionStorage.setItem('mmRecFail_'+recoverU,String(tries));}catch(e){}
        if(tries>=3){ACC.lock(recoverU,true,'recovery');ACC.log('locked',recoverU,'3 failed recovery attempts');setMsg('Too many wrong answers. The account is locked; ask an administrator to reset it.');}else setMsg('Those answers are not correct. '+(3-tries)+' attempt'+(3-tries===1?'':'s')+' left.');return;}
      try{sessionStorage.removeItem('mmRecFail_'+recoverU);}catch(e){}
      ACC.setPassword(recoverU,p1,{by:recoverU}).then(function(){ACC.log('pw-reset',recoverU,'via security questions',recoverU);setBusy(false);view='signin';msg='Password updated. Sign in with your new password.';msgCls='ok';render();});});}
  function signOut(reason){var a=A.get();if(a)ACC.log('signout',a.u||a.name||'',reason||'');A.clear();SES.clearPersist();try{sessionStorage.removeItem('mmAdminStash_v1');}catch(e){}try{setTabActive(null);}catch(e){}try{closePanel(true);}catch(e){}try{applyRole();buildNav();}catch(e){}show({message:reason||'',messageClass:''});}
  function afterPanelClose(){if(returnAfterPanel&&!A.get()){returnAfterPanel=false;show();}}
  Object.assign(GATE,{show:show,hide:hide,visible:visible,signOut:signOut,showCreate:function(){show({view:'createStudent'});},afterPanelClose:afterPanelClose,changePassword:function(reason){var a=A.get();if(!a||!a.u)return;pending={acc:ACC.get(a.u),keep:false,reason:reason};view='change';msg='';ensure();el.classList.remove('mm-hidden');render();}});
})();

/* ---------- MM.trend: daily snapshots ---------- */
var TR=MM.trend={
  load:function(){try{return JSON.parse(localStorage.getItem(SNAP)||'{}');}catch(e){return {};}},
  key:function(d){d=d||new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');},
  snap:function(force){var o=TR.load(),k=TR.key();if(o[k]&&!force)return;var list=D.list(),cs=D.classStats(list),stu={};list.forEach(function(st){stu[st.id]=D.stats(st).pct;});o[k]={n:cs.n,pct:cs.avgPct,quiz:cs.avgQuiz,active7:cs.active7,assessed:cs.assessed,fa:cs.faAvg,complete:cs.complete,stu:stu};
    var keys=Object.keys(o).sort();while(keys.length>120){delete o[keys.shift()];}try{localStorage.setItem(SNAP,JSON.stringify(o));}catch(e){}},
  series:function(field,days,sid){var o=TR.load(),out=[],d=new Date();for(var i=days-1;i>=0;i--){var x=new Date(d);x.setDate(d.getDate()-i);var k=TR.key(x),v=o[k];out.push({k:k,v:v?(sid?(v.stu&&v.stu[sid]!=null?v.stu[sid]:null):(v[field]!=null?v[field]:null)):null});}return out;},
  spark:function(series,cls){var pts=series.filter(function(p){return p.v!=null;});if(pts.length<2)return '<div class="mm-muted" style="padding:14px 0">Trend appears after a few days of use.</div>';var W=240,H=56,max=Math.max.apply(null,pts.map(function(p){return p.v;}))||1,min=Math.min.apply(null,pts.map(function(p){return p.v;})),rng=(max-min)||1,n=series.length,xs=function(i){return 4+(W-8)*i/(n-1);},ys=function(v){return H-6-(H-14)*((v-min)/rng);},d='',first=true,last=null;
    series.forEach(function(p,i){if(p.v==null)return;d+=(first?'M':'L')+xs(i).toFixed(1)+' '+ys(p.v).toFixed(1)+' ';first=false;last={x:xs(i),y:ys(p.v)};});
    var area=d+'L'+last.x.toFixed(1)+' '+(H-4)+' L'+xs(series.findIndex(function(p){return p.v!=null;})).toFixed(1)+' '+(H-4)+' Z';
    return '<svg class="mm-spark '+(cls||'')+'" viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" aria-hidden="true"><path class="area" d="'+area+'"/><path class="line" d="'+d+'"/><circle class="dot" cx="'+last.x.toFixed(1)+'" cy="'+last.y.toFixed(1)+'" r="3"/></svg>';},
  delta:function(series){var pts=series.filter(function(p){return p.v!=null;});if(pts.length<2)return null;var a=pts[0].v,b=pts[pts.length-1].v;return b-a;}
};

/* ---------- MM.theme: native dark mode ---------- */
var TH=MM.theme={
  prefs:function(){try{return JSON.parse(localStorage.getItem('mmPrefs_v1')||'{}')||{};}catch(e){return {};}},
  isDark:function(){return document.documentElement.classList.contains('mm-dark');},
  set:function(dark){var p=TH.prefs();p.dk=dark?1:0;try{localStorage.setItem('mmPrefs_v1',JSON.stringify(p));}catch(e){}document.documentElement.classList.toggle('mm-dark',!!dark);var cb=document.querySelector('#mm-set-pop input[data-k="dk"]');if(cb)cb.checked=!!dark;try{document.querySelector('meta[name=theme-color]').setAttribute('content',dark?'#1d150e':'#231a0a');}catch(e){}},
  toggle:function(){TH.set(!TH.isDark());}
};

/* ---------- MM.i18n: Spanish / Portuguese for the suite ---------- */
var I18N=MM.i18n={dict:{es:{},pt:{}},
  lang:function(){try{return loadLang();}catch(e){return 'en';}},
  T:function(s){var l=I18N.lang();return (I18N.dict[l]&&I18N.dict[l][s])||s;},
  apply:function(root){var l=I18N.lang();if(l==='en'||!root)return;var d=I18N.dict[l];if(!d)return;var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null);var nodes=[];while(w.nextNode())nodes.push(w.currentNode);
    nodes.forEach(function(n){var t=n.nodeValue,k=t.trim();if(!k)return;if(d[k]!=null){n.nodeValue=t.replace(k,d[k]);return;}var m=k.match(/^(\S+\s)(.+)$/);if(m&&/^[^\w]/.test(m[1])&&d[m[2]]!=null)n.nodeValue=t.replace(m[2],d[m[2]]);});
    root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(function(x){['placeholder','title','aria-label'].forEach(function(at){var v=x.getAttribute(at);if(v&&d[v]!=null)x.setAttribute(at,d[v]);});});}
};
(function(){var es=I18N.dict.es,pt=I18N.dict.pt;function add(en,s,p){es[en]=s;pt[en]=p;}
  add('Username','Nombre de usuario','Nome de usuário');add('Password','Contraseña','Senha');add('Sign in','Iniciar sesión','Entrar');add('Sign out','Cerrar sesión','Sair');add('Create a profile','Crear un perfil','Criar um perfil');add('Forgot password?','¿Olvidaste tu contraseña?','Esqueceu a senha?');add('K–8 Financial Literacy Classroom','Aula de educación financiera K–8','Sala de educação financeira K–8');add('Enter your username.','Escribe tu nombre de usuario.','Digite seu nome de usuário.');add('Enter your password.','Escribe tu contraseña.','Digite sua senha.');add('Username or password is incorrect.','El usuario o la contraseña son incorrectos.','Usuário ou senha incorretos.');add('Create profile','Crear perfil','Criar perfil');add('Student name','Nombre del estudiante','Nome do aluno');add('Grade','Grado','Série');add('Continue to the classroom','Ir al aula','Ir para a sala');
  add('Admin Console','Consola de administración','Console de administração');add('My Dashboard','Mi panel','Meu painel');add('Switch profile','Cambiar perfil','Trocar perfil');add('Return to Admin','Volver a administración','Voltar ao admin');add('Administrator','Administrador','Administrador');add('Teacher','Maestro/a','Professor/a');add('Student','Estudiante','Aluno');add('Guest','Invitado','Convidado');add('Admin view','Vista de administrador','Visão do admin');
  add('Learn','Aprender','Aprender');add('Assess','Evaluar','Avaliar');add('Documents','Documentos','Documentos');add('Admin','Admin','Admin');add('More','Más','Mais');add('Financial Profile','Perfil financiero','Perfil financeiro');add('Session details','Detalles de la sesión','Detalhes da sessão');add('My session','Mi sesión','Minha sessão');add('Session & switch profile','Sesión y cambio de perfil','Sessão e troca de perfil');
  add('Manage','Gestionar','Gerenciar');add('Program','Programa','Programa');add('Security','Seguridad','Segurança');add('Device','Dispositivo','Dispositivo');add('Overview','Resumen','Visão geral');add('Users','Usuarios','Usuários');add('Students','Estudiantes','Alunos');add('Teachers','Maestros','Professores');add('Classes','Clases','Turmas');add('Curriculum','Currículo','Currículo');add('Reports','Informes','Relatórios');add('Roles & capabilities','Roles y permisos','Funções e permissões');add('Security policy','Política de seguridad','Política de segurança');add('Sign-in log','Registro de accesos','Registro de acessos');add('Data & Backup','Datos y copias','Dados e backup');add('Settings','Configuración','Configurações');add('System','Sistema','Sistema');
  add('Active this week','Activos esta semana','Ativos esta semana');add('Avg mastery','Dominio promedio','Domínio médio');add('Avg quiz score','Promedio de cuestionarios','Média dos quizzes');add('Assessed','Evaluados','Avaliados');add('Grade complete','Grado completo','Série concluída');add('Story runs','Historias jugadas','Histórias jogadas');add('Needs attention','Requiere atención','Precisa de atenção');add('Recent activity','Actividad reciente','Atividade recente');add('Enrollment by grade','Inscripción por grado','Matrículas por série');add('Learner status','Estado de los estudiantes','Status dos alunos');add('Setup checklist','Lista de configuración','Lista de configuração');add('On track','En camino','No caminho certo');add('Needs support','Necesita apoyo','Precisa de apoio');add('Not started','No iniciado','Não iniciado');add('Inactive 14+ days','Inactivo 14+ días','Inativo 14+ dias');
  add('Add student','Agregar estudiante','Adicionar aluno');add('Add user','Agregar usuario','Adicionar usuário');add('Add a user','Agregar un usuario','Adicionar um usuário');add('Profile','Perfil','Perfil');add('Report','Informe','Relatório');add('Lock','Bloquear','Bloquear');add('Unlock','Desbloquear','Desbloquear');add('Set password','Definir contraseña','Definir senha');add('Reset','Restablecer','Redefinir');add('Remove','Eliminar','Remover');add('Save','Guardar','Salvar');add('Cancel','Cancelar','Cancelar');add('Back up','Copia de seguridad','Backup');add('Mastery','Dominio','Domínio');add('Quiz avg','Prom. cuestionario','Média quiz');add('Checkpoints','Puntos de control','Checkpoints');add('Last active','Última actividad','Última atividade');add('Status','Estado','Status');add('Summary','Resumen','Resumo');add('Lessons','Lecciones','Lições');add('Assessments','Evaluaciones','Avaliações');add('Games & Story','Juegos e historia','Jogos e história');add('Reflections','Reflexiones','Reflexões');add('Notes','Notas','Notas');add('Roster','Lista','Lista');add('Class insights','Datos de la clase','Dados da turma');add('Details','Detalles','Detalhes');add('Weeks mastered','Semanas dominadas','Semanas dominadas');add('Quiz average','Promedio de cuestionarios','Média dos quizzes');add('Checkpoints passed','Puntos de control aprobados','Checkpoints aprovados');add('Financial literacy','Educación financiera','Educação financeira');add('Story Mode','Modo historia','Modo história');add('Game accuracy','Precisión en juegos','Precisão nos jogos');add('Lessons viewed','Lecciones vistas','Lições vistas');add('Next step','Siguiente paso','Próximo passo');add('Unit progress','Progreso por unidad','Progresso por unidade');add('Danger zone','Zona de riesgo','Zona de risco');add('All grades','Todos los grados','Todas as séries');add('All teachers','Todos los maestros','Todos os professores');add('Any status','Cualquier estado','Qualquer status');add('All roles','Todos los roles','Todas as funções');add('Today','Hoy','Hoje');add('Yesterday','Ayer','Ontem');add('Never','Nunca','Nunca');add('Continue','Continuar','Continuar');add('My progress','Mi progreso','Meu progresso');add('This week','Esta semana','Esta semana');add('Word of the day','Palabra del día','Palavra do dia');add('Readiness','Preparación','Prontidão');add('Class today','Clase hoy','Turma hoje');add('Quick actions','Acciones rápidas','Ações rápidas');add('Dark mode','Modo oscuro','Modo escuro');add('Light mode','Modo claro','Modo claro');add('Backup reminder','Recordatorio de copia','Lembrete de backup');add('30-day trend','Tendencia de 30 días','Tendência de 30 dias');
})();
U.T=I18N.T;

/* ---------- boot ---------- */
function boot(){try{ACC.ensureStudents();}catch(e){}
  try{var p=TH.prefs();if(p.dk)document.documentElement.classList.add('mm-dark');}catch(e){}
  /* keep-signed-in restore before the gate decides to show */
  var restored=false;try{restored=SES.restore();}catch(e){}
  if(A.get()){GATE.hide();if(restored){try{applyRole();buildNav();}catch(e){}}}
  else{var demo='';try{demo=sessionStorage.getItem('mmDemo')||'';}catch(e){}if(!demo)GATE.show();}
  try{TR.snap();}catch(e){}
  /* translate shell surfaces whenever they re-render */
  if(!S.topbar.__i18n){var ot=S.topbar;var wt=function(){ot.apply(this,arguments);try{I18N.apply($('mm-topbar'));I18N.apply($('mm-home'));I18N.apply($('nav'));}catch(e){}};wt.__i18n=1;S.topbar=wt;}
  if(typeof saveStore==='function'&&!saveStore.__v92){var os=saveStore;var ws=function(x){os(x);try{ACC.ensureStudents();}catch(e){}};ws.__v92=true;saveStore=ws;}
}
document.addEventListener('DOMContentLoaded',function(){setTimeout(boot,300);setTimeout(function(){try{S.topbar();}catch(e){}},1400);});
})();
