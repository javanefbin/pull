/* =====================================================================
   V19 · PRINT ENGINE  (window.MMPrint)
   Every printable document is rendered as its own clean page (never the
   app screen), with one professional stylesheet, a cover band, numbered
   sections, and running headers/footers with page numbers.
   Printing goes through a hidden frame, so pop-up blockers don't matter.

   Documents
     Lesson plan · Student worksheet · Worksheet answer key · Family letter
     Weekly packet (plan + worksheet + key + family letter)
     Student workbook (cover, contents, unit dividers, every worksheet)
     Teacher's guide (year at a glance, scope and sequence, pacing calendar,
       per-week plans with worksheet and quiz answer keys)
     Plus a shared shell used by Workshops, the Resource Guide, Game Show
     recaps and the admin reports (MM91.util.openHTML).
   Word downloads (.doc) use the same templates with a Word-safe style subset.
   ===================================================================== */
(function(){
'use strict';
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function T(s,v){var o=s;try{if(window.MMI18N)o=window.MMI18N.t(s);}catch(e){}if(v)Object.keys(v).forEach(function(k){o=o.split('{'+k+'}').join(v[k]);});return o;}
function arr(x){return Array.isArray(x)?x:(x?[x]:[]);}
function school(){try{return (typeof getSchoolName==='function'&&getSchoolName())||localStorage.getItem('mmSchoolName')||'';}catch(e){return '';}}
function teacherName(){try{var a=MM91.auth.get();if(a&&MM91.auth.roleKey()!=='student')return MM91.auth.displayName()||'';}catch(e){}return '';}
function g(){try{return currentGrade||'K';}catch(e){return 'K';}}
function gl(x){try{return (typeof gradeLabel==='function'?gradeLabel(x):GRADE_LABEL[x])||('Grade '+x);}catch(e){return x==='K'?'Kindergarten':'Grade '+x;}}
function theme(x){try{return GRADE_THEME[x]||'';}catch(e){return '';}}
function lessonsOf(){try{return lessons();}catch(e){return [];}}
function lang(){try{return loadLang()||'en';}catch(e){return 'en';}}
function today(){return new Date().toLocaleDateString(lang()==='en'?'en-US':lang(),{year:'numeric',month:'long',day:'numeric'});}
function unitName(x,u){try{var src=(lang()!=='en'&&typeof SECTION_TESTS_L!=='undefined'&&SECTION_TESTS_L[lang()]&&SECTION_TESTS_L[lang()][x])||(typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[x])||[];var t=src[u];if(t&&t.title)return String(t.title).replace(/^[^:]*:\s*/,'');}catch(e){}return T('Unit')+' '+(u+1);}
function quizFor(x,week){try{var src=(lang()!=='en'&&typeof LESSON_QUIZ_L!=='undefined'&&LESSON_QUIZ_L[lang()]&&LESSON_QUIZ_L[lang()][x])||(typeof LESSON_QUIZ!=='undefined'&&LESSON_QUIZ[x])||[];var w=src.filter(function(q){return +q.week===+week;})[0];return w?(w.questions||[]):[];}catch(e){return [];}}
function splitCheck(c){var m=String(c||'').match(/^([\s\S]*?)\s*\(Answer:\s*([\s\S]*?)\)\s*$/);return m?{q:m[1],a:m[2]}:{q:String(c||''),a:''};}
function ican(obj){if(lang()!=='en')return String(obj||'');return String(obj||'').replace(/^Students will\s+/i,'I can ').replace(/^Los estudiantes\s+/i,'').replace(/^Os alunos\s+/i,'');}
function reword(s){try{return typeof rewordWrite==='function'?rewordWrite(s):s;}catch(e){return s;}}

/* ---------- stylesheet ---------- */
var CSS=[
'@page{size:letter;margin:.72in .7in .8in}',
'*{box-sizing:border-box}html{-webkit-print-color-adjust:exact;print-color-adjust:exact}',
'body{margin:0;font:10.5pt/1.5 "Helvetica Neue",Helvetica,Arial,sans-serif;color:#1d1a14;background:#fff}',
'h1,h2,h3,h4{font-family:Georgia,"Times New Roman",serif;color:#1d1a14;margin:0;line-height:1.2;break-after:avoid;page-break-after:avoid}',
'p{margin:.35em 0}ul,ol{margin:.3em 0 .3em 1.3em;padding:0}li{margin:.18em 0}',
'.mm-screen-note{font:13px system-ui,sans-serif;background:#fff7df;border:1px solid #e3c98a;padding:10px 14px;border-radius:8px;margin:0 0 16px}@media print{.mm-screen-note{display:none}}',
'.page{break-before:page;page-break-before:always}.page:first-child,.first{break-before:auto;page-break-before:auto}',
'.avoid{break-inside:avoid;page-break-inside:avoid}.page-break{break-before:page;page-break-before:always}.paper{max-width:none!important;box-shadow:none!important;margin:0!important}',
/* header band */
'.dh{border-top:6px solid #1f4d36;padding:14px 0 12px;margin-bottom:14px;border-bottom:1.5px solid #b8862b;display:grid;grid-template-columns:1fr auto;gap:14px;align-items:end}',
'.dh .k{font:700 8.5pt/1.2 "Helvetica Neue",Arial,sans-serif;letter-spacing:.16em;text-transform:uppercase;color:#1f4d36}',
'.dh h1{font-size:22pt;margin:5px 0 3px}.dh .sub{color:#5a4f3c;font-size:10.5pt;max-width:44em}',
'.dh .mark{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:700 20pt Georgia,serif;color:#2a1d10;background:radial-gradient(circle at 35% 30%,#fff2c4,#e0b24a 55%,#a9802a);border:1.5px solid #8a6420}',
'.badge{display:inline-block;font:700 7.5pt Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;padding:3px 8px;border-radius:99px;border:1px solid #1f4d36;color:#1f4d36;margin-left:6px;vertical-align:middle}',
'.badge.key{background:#1f4d36;color:#fff}.badge.gold{border-color:#a87924;color:#7a5413}',
/* meta grid */
'.meta{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid #d9cdb4;border-radius:6px;margin:0 0 14px;overflow:hidden}',
'.meta div{padding:6px 9px;border-right:1px solid #e8dfcc;min-height:38px}.meta div:last-child{border-right:0}',
'.meta b{display:block;font:700 7pt Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#7a6a4e;margin-bottom:2px}',
'.meta .fill{border-bottom:1px solid #b9ad94;height:16px}',
/* sections */
'.sec{margin:14px 0 6px;break-inside:auto}',
'.sec>h2{font-size:13pt;display:flex;align-items:center;gap:9px;padding-bottom:4px;border-bottom:1px solid #d9cdb4;margin-bottom:7px}',
'.sec>h2 .n{flex:none;width:22px;height:22px;border-radius:50%;background:#1f4d36;color:#fff;font:700 9pt/22px Arial,sans-serif;text-align:center}',
'.sec>h2 .t{flex:1}.sec>h2 .min{font:700 8.5pt Arial,sans-serif;color:#7a5413;background:#f7ecd2;border-radius:99px;padding:2px 9px}',
'h3{font-size:11pt;margin:8px 0 3px;color:#1f4d36}',
'.two{display:grid;grid-template-columns:1fr 1fr;gap:14px}.three{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}',
'.box{border:1px solid #d9cdb4;border-radius:6px;padding:9px 11px;background:#fffdf8;break-inside:avoid}',
'.box h3{margin-top:0}',
'.goal{border-left:5px solid #1f4d36;background:#f1f7f2;border-radius:0 6px 6px 0;padding:9px 12px;margin:0 0 10px;break-inside:avoid}',
'.goal b{font:700 7.5pt Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#1f4d36;display:block}',
'.call{border-left:5px solid #b8862b;background:#fbf5e6;border-radius:0 6px 6px 0;padding:8px 12px;margin:6px 0;break-inside:avoid}',
'.ans{color:#1f4d36;font-weight:700}.ans::before{content:"\\2713  "}',
'.chips span{display:inline-block;border:1px solid #cfc2a5;border-radius:99px;padding:1px 8px;margin:2px 4px 2px 0;font-size:8.5pt;color:#4a4033}',
/* tables */
'table.t{width:100%;border-collapse:collapse;margin:6px 0 4px;font-size:9.5pt}',
'table.t th{background:#1f4d36;color:#fff;text-align:left;font:700 7.5pt Arial,sans-serif;letter-spacing:.1em;text-transform:uppercase;padding:6px 7px}',
'table.t td{border-bottom:1px solid #e3d9c4;padding:6px 7px;vertical-align:top}table.t tr:nth-child(even) td{background:#fbf8f1}',
'table.t td.c{text-align:center}table.t td.time{white-space:nowrap;font-weight:700;color:#1f4d36}',
'table.t tr{break-inside:avoid;page-break-inside:avoid}thead{display:table-header-group}',
'dl.v{display:grid;grid-template-columns:auto 1fr;gap:3px 12px;margin:0}dl.v dt{font-weight:700}dl.v dd{margin:0}',
/* checklists and answer space */
'ul.ck{list-style:none;margin-left:0}ul.ck li{padding-left:20px;position:relative}ul.ck li::before{content:"";position:absolute;left:0;top:.28em;width:11px;height:11px;border:1.3px solid #6b5d44;border-radius:2px}',
'.lines div{border-bottom:1px solid #9d9077;height:24px}',
'.q{margin:0 0 12px;break-inside:avoid;page-break-inside:avoid;display:grid;grid-template-columns:26px 1fr;gap:6px}',
'.q .no{width:22px;height:22px;border-radius:50%;border:1.5px solid #1f4d36;color:#1f4d36;font:700 9pt/19px Arial,sans-serif;text-align:center}',
'.q .wr{border-bottom:1px solid #9d9077;height:26px;margin-top:4px}.q .bx{border:1px solid #9d9077;border-radius:4px;height:80px;margin-top:6px}',
'.namebar{display:grid;grid-template-columns:2.2fr 1.2fr 1.2fr .9fr;gap:12px;margin:0 0 12px}',
'.namebar div{font:700 7.5pt Arial,sans-serif;letter-spacing:.1em;text-transform:uppercase;color:#7a6a4e}.namebar div i{display:block;border-bottom:1px solid #6b5d44;height:20px;margin-top:2px}',
'.self{display:flex;gap:18px;flex-wrap:wrap;font-size:9.5pt}.self span::before{content:"";display:inline-block;width:11px;height:11px;border:1.3px solid #6b5d44;border-radius:2px;margin-right:6px;vertical-align:-1px}',
'.wordbank{display:flex;flex-wrap:wrap;gap:6px}.wordbank span{border:1.3px dashed #b8862b;border-radius:6px;padding:2px 9px;font-weight:700}',
/* cover */
'.cover{min-height:9in;display:flex;flex-direction:column;justify-content:space-between;border:2px solid #1f4d36;outline:1px solid #b8862b;outline-offset:-8px;padding:.6in .55in;text-align:center}',
'.cover .k{font:700 9pt Arial,sans-serif;letter-spacing:.26em;text-transform:uppercase;color:#1f4d36}',
'.cover h1{font-size:34pt;margin:.25in 0 .1in}.cover .sub{font:italic 13pt Georgia,serif;color:#5a4f3c}',
'.cover .mark{width:84px;height:84px;margin:0 auto;border-radius:50%;display:flex;align-items:center;justify-content:center;font:700 36pt Georgia,serif;color:#2a1d10;background:radial-gradient(circle at 35% 30%,#fff2c4,#e0b24a 55%,#a9802a);border:2px solid #8a6420}',
'.cover .fields{display:grid;grid-template-columns:1fr 1fr;gap:18px 28px;text-align:left;max-width:5.6in;margin:0 auto;width:100%}',
'.cover .fields div{font:700 8pt Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#7a6a4e}.cover .fields i{display:block;border-bottom:1.2px solid #6b5d44;min-height:24px;padding-top:5px;font:400 12pt Georgia,serif;font-style:normal;letter-spacing:0;text-transform:none;color:#1d1a14}',
'.divider{min-height:8.6in;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;border-left:10px solid #1f4d36;padding:0 .5in}',
'.divider .k{font:700 10pt Arial,sans-serif;letter-spacing:.24em;text-transform:uppercase;color:#a87924}.divider h1{font-size:30pt;margin:10px 0}',
'.toc{width:100%;border-collapse:collapse}.toc td{padding:5px 4px;border-bottom:1px dotted #b9ad94}.toc td.w{width:78px;white-space:nowrap;font-weight:700;color:#1f4d36}.toc td.c{width:24px}.toc tr.u td{border:0;padding-top:12px;font:700 8.5pt Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#a87924}',
/* letter */
'.letterhead{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #1f4d36;padding-bottom:8px;margin-bottom:16px}',
'.letterhead b{font:700 15pt Georgia,serif}.letterhead span{font-size:9pt;color:#5a4f3c;text-align:right}',
'.slip{margin-top:18px;border-top:1.5px dashed #6b5d44;padding-top:10px;break-inside:avoid}.slip .cut{font-size:8pt;color:#7a6a4e;margin-top:-20px;background:#fff;display:inline-block;padding-right:6px}',
'body.letter{font-size:10pt}body.letter .sec{margin:9px 0 4px}body.letter .box{padding:7px 10px}body.letter .letterhead{margin-bottom:10px}body.letter p{margin:.25em 0}body.letter .slip{margin-top:10px}',
'.sig{display:grid;grid-template-columns:1fr 1fr;gap:28px;margin-top:20px}.sig div{border-top:1px solid #6b5d44;padding-top:3px;font-size:8.5pt;color:#5a4f3c}',
/* misc */
'.small{font-size:8.5pt;color:#5a4f3c}.muted{color:#6b5d44}.center{text-align:center}',
'.qr{width:62px;height:62px}.qr svg{width:100%;height:100%;display:block}',
'.res{display:grid;grid-template-columns:62px 1fr;gap:10px;padding:8px 0;border-bottom:1px solid #e3d9c4;break-inside:avoid}',
'.res h4{font-size:10.5pt;margin:0}.res .url{font:8pt ui-monospace,Menlo,Consolas,monospace;color:#1f4d36;word-break:break-all}',
'a{color:#1f4d36}',
/* legacy report classes used by MM91.util.openHTML callers */
'.k{font-size:8.5pt;letter-spacing:.14em;text-transform:uppercase;color:#1f4d36;font-weight:800}.sub{color:#5a4f3c}',
'.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0}.stat{border:1px solid #d9cdb4;border-radius:6px;padding:8px}.stat b{display:block;font-size:16pt;color:#1f4d36}.stat span{font-size:7.5pt;text-transform:uppercase;letter-spacing:.08em;color:#6b5d44}',
'.note{padding:8px 11px;border-left:4px solid #b8862b;background:#fbf5e6;border-radius:0 6px 6px 0;font-size:9.5pt}.foot{margin-top:18px;padding-top:8px;border-top:1px solid #d9cdb4;color:#7a6a4e;font-size:8pt}',
'body.legacy h1{font-size:20pt;margin:4px 0}body.legacy h2{font:700 8.5pt Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#1f4d36;border-bottom:1.5px solid #b8862b;padding-bottom:3px;margin:16px 0 6px}',
'body.legacy table{width:100%;border-collapse:collapse;font-size:9pt}body.legacy th{background:#1f4d36;color:#fff;text-align:left;padding:5px 6px;font-size:7.5pt;letter-spacing:.08em;text-transform:uppercase}body.legacy td{border-bottom:1px solid #e3d9c4;padding:5px 6px;vertical-align:top}'
].join('\n');
/* Word ignores grid/flex; this subset keeps documents tidy in Word */
var WORD_CSS='body{font-family:Arial,sans-serif;font-size:10.5pt;color:#1d1a14}h1,h2,h3{font-family:Georgia,serif}h1{font-size:20pt}h2{font-size:13pt;border-bottom:1px solid #b8862b;padding-bottom:3px}h3{font-size:11pt;color:#1f4d36}.k{font-size:8pt;letter-spacing:2px;text-transform:uppercase;color:#1f4d36;font-weight:bold}table{border-collapse:collapse;width:100%}th{background:#1f4d36;color:#fff;font-size:8pt;text-align:left;padding:4px}td{border:1px solid #d9cdb4;padding:4px;vertical-align:top}.goal,.call,.box{border:1px solid #d9cdb4;padding:6px;background:#fbf8f1}.ans{color:#1f4d36;font-weight:bold}.page{page-break-before:always}.q .wr{border-bottom:1px solid #888;height:22px}.mark,.n,.no{display:none}';

/* ---------- document shell ---------- */
function pageCSS(o){var hl=(o.headerLeft||'Money Matters').replace(/"/g,'\\"'),hr=(o.headerRight||school()||'').replace(/"/g,'\\"'),fl=(o.footerLeft||T('Money Matters · K–8 Financial Literacy')).replace(/"/g,'\\"');
  return '@page{@top-left{content:"'+hl+'";font:8pt Arial,sans-serif;color:#6b5d44}@top-right{content:"'+hr+'";font:8pt Arial,sans-serif;color:#6b5d44}@bottom-left{content:"'+fl+'";font:7.5pt Arial,sans-serif;color:#8a7c62}@bottom-right{content:"'+T('Page')+' " counter(page) " / " counter(pages);font:7.5pt Arial,sans-serif;color:#8a7c62}}'+(o.cover?'@page:first{@top-left{content:none}@top-right{content:none}@bottom-left{content:none}@bottom-right{content:none}}':'')+(o.landscape?'@page{size:letter landscape;margin:.4in}':'');}
function wrap(title,body,o){o=o||{};return '<!DOCTYPE html><html lang="'+esc(lang())+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><style>'+CSS+'\n'+pageCSS(o)+(o.css||'')+'</style></head><body class="'+(o.bodyClass||'')+'">'+body+'</body></html>';}
/* print through a hidden frame (no pop-up); preview opens a tab instead */
function printHTML(html,o){o=o||{};try{if(window.MMI18N&&MMI18N.lang()!=='en')html=MMI18N.applyHTML(html);}catch(e){}if(window.MMPrint&&typeof window.MMPrint.capture==='function'){window.MMPrint.capture(html,o);return;}/* test hook */var blob=new Blob([html],{type:'text/html'}),url=URL.createObjectURL(blob);
  if(o.preview){var w=window.open(url,'_blank');if(!w)toast(T('Allow pop-ups to preview, or use Print.'));setTimeout(function(){URL.revokeObjectURL(url);},120000);return;}
  var f=document.getElementById('mm-print-frame');if(f)f.remove();f=document.createElement('iframe');f.id='mm-print-frame';f.title='Print';f.setAttribute('aria-hidden','true');f.style.cssText='position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
  f.onload=function(){setTimeout(function(){try{f.contentWindow.focus();f.contentWindow.print();}catch(e){var w=window.open(url,'_blank');if(!w)toast(T('Printing is blocked in this browser.'));}},350);};
  f.src=url;document.body.appendChild(f);setTimeout(function(){URL.revokeObjectURL(url);},120000);}
function toast(m){try{infoToast(m,4000);}catch(e){}}
function open(title,body,o){printHTML(wrap(title,body,o),o);}
function word(title,body,file){var html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+esc(title)+'</title><style>'+WORD_CSS+'</style></head><body>'+body+'</body></html>';
  try{var b=new Blob(['\ufeff'+html],{type:'application/msword'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=file;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){toast(T('Download not supported in this browser. Use Print / Save PDF instead.'));}}

/* ---------- building blocks ---------- */
function head(kicker,title,sub,badge){return '<header class="dh"><div><div class="k">'+esc(kicker)+(badge||'')+'</div><h1>'+esc(title)+'</h1>'+(sub?'<div class="sub">'+esc(sub)+'</div>':'')+'</div><div class="mark" aria-hidden="true">$</div></header>';}
function meta(cells){return '<div class="meta" style="grid-template-columns:repeat('+cells.length+',1fr)">'+cells.map(function(c){return '<div><b>'+esc(c[0])+'</b>'+(c[1]===null?'<div class="fill"></div>':esc(c[1]))+'</div>';}).join('')+'</div>';}
function sec(n,title,body,min){return '<section class="sec"><h2>'+(n?'<span class="n">'+n+'</span>':'')+'<span class="t">'+esc(title)+'</span>'+(min?'<span class="min">'+esc(min)+'</span>':'')+'</h2>'+body+'</section>';}
function ul(a,cls){a=arr(a);return a.length?'<ul'+(cls?' class="'+cls+'"':'')+'>'+a.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul>':'';}
function ol(a){a=arr(a);return a.length?'<ol>'+a.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ol>':'';}
function vocab(v){v=arr(v);return v.length?'<dl class="v">'+v.map(function(x){return typeof x==='string'?'<dt>'+esc(x)+'</dt><dd></dd>':'<dt>'+esc(x.term||x[0])+'</dt><dd>'+esc(x.def||x[1]||'')+'</dd>';}).join('')+'</dl>':'';}
function lines(n){var h='<div class="lines">';for(var i=0;i<n;i++)h+='<div></div>';return h+'</div>';}
function minutes(d){var m=/(\d+)/.exec(String(d||''));return m?+m[1]:45;}
/* split a lesson's minutes across its phases (multiples of 5, totals exactly) */
function pacing(total){var w=[['warm',.1],['mini',.2],['guided',.25],['indep',.2],['discuss',.1],['check',.05],['exit',.1]],out={},sum=0;
  w.forEach(function(x){var v=Math.max(5,Math.round(total*x[1]/5)*5);out[x[0]]=v;sum+=v;});out.indep=Math.max(5,out.indep+(total-sum));return out;}

/* ---------- lesson documents ---------- */
function unitOf(l){return Math.min(5,Math.floor(((+l.week||1)-1)/6));}
function planHTML(l,x,opts){opts=opts||{};x=x||g();var tot=minutes(l.duration),p=pacing(tot),ck=splitCheck(l.check),d=l.differentiation||{},u=unitOf(l);
  var h=head(T('Money Matters')+' · '+gl(x)+' · '+T('Lesson Plan'),T('Week')+' '+l.week+': '+l.title,l.sub);
  h+=meta([[T('Grade'),gl(x)],[T('Unit'),(u+1)+' · '+unitName(x,u)],[T('Duration'),l.duration||(tot+' min')],[T('Teacher'),teacherName()||null],[T('Date taught'),null]]);
  h+='<div class="goal"><b>'+esc(T('Learning objective'))+'</b>'+esc(l.objective)+'</div>';
  h+='<div class="two"><div class="box"><h3>'+esc(T('Success criteria'))+'</h3>'+ul([ican(l.objective),T('I can answer the quick check: {q}',{q:ck.q}),T('I can complete the exit ticket on my own.')],'ck')+'</div><div class="box"><h3>'+esc(T('Standards'))+'</h3><div class="chips">'+arr(l.standards).map(function(s){return '<span>'+esc(s)+'</span>';}).join('')+'</div></div></div>';
  h+=sec(1,T('Prepare'),'<div class="two"><div><h3>'+esc(T('Materials'))+'</h3>'+ul(l.materials,'ck')+'</div><div><h3>'+esc(T('Before class'))+'</h3><p>'+esc(l.prep||T('Review the lesson and gather materials.'))+'</p><h3>'+esc(T('Key vocabulary'))+'</h3>'+vocab(l.vocab)+'</div></div>');
  var rows=[[p.warm,T('Warm-up'),l.warmUp,T('Share ideas with a partner, then with the class.')],[p.mini,T('Mini-lesson (model)'),l.mini,T('Listen, watch the example, and ask questions.')],
    [p.guided,T('Guided practice'),'<ol>'+arr(l.guidedPractice).map(function(s){return '<li>'+esc(s)+'</li>';}).join('')+'</ol>',T('Work each step together; explain thinking aloud.'),1],
    [p.indep,T('Independent practice'),l.independent,T('Complete the worksheet on their own.')],[p.discuss,T('Discussion'),'<ul>'+arr(l.discussion).map(function(s){return '<li>'+esc(s)+'</li>';}).join('')+'</ul>',T('Discuss in pairs, then share.'),1],
    [p.check,T('Check for understanding'),esc(ck.q)+(ck.a?'<div class="ans">'+esc(ck.a)+'</div>':''),T('Answer on whiteboards or by show of hands.'),1],[p.exit,T('Exit ticket'),l.exit,T('Write a response and hand it in.')]];
  var t=0;h+=sec(2,T('Lesson sequence'),'<table class="t"><thead><tr><th style="width:12%">'+esc(T('Time'))+'</th><th style="width:18%">'+esc(T('Phase'))+'</th><th>'+esc(T('Teacher does'))+'</th><th style="width:24%">'+esc(T('Students do'))+'</th></tr></thead><tbody>'
    +rows.map(function(r){var s=t;t+=r[0];return '<tr><td class="time">'+s+'–'+t+' '+esc(T('min'))+'</td><td><b>'+esc(r[1])+'</b></td><td>'+(r[4]?r[2]:esc(r[2]))+'</td><td>'+esc(r[3])+'</td></tr>';}).join('')+'</tbody></table>',tot+' '+T('minutes'));
  h+=sec(3,T('Differentiation'),'<div class="three"><div class="box"><h3>'+esc(T('Support'))+'</h3><p>'+esc(d.support||'')+'</p></div><div class="box"><h3>'+esc(T('Challenge'))+'</h3><p>'+esc(d.challenge||'')+'</p></div><div class="box"><h3>'+esc(T('Language support'))+'</h3><p>'+esc(T('Pre-teach the key vocabulary with pictures or real objects, and offer sentence frames such as “I think… because…”.'))+'</p></div></div>');
  h+=sec(4,T('Family connection'),'<p>'+esc(l.homeExtension||'')+'</p>');
  if(!opts.noReflect)h+=sec(5,T('Teacher reflection'),'<div class="two"><div><h3>'+esc(T('What worked'))+'</h3>'+lines(3)+'</div><div><h3>'+esc(T('Adjust next time'))+'</h3>'+lines(3)+'</div></div><p class="small">'+esc(T('Students who need follow-up:'))+'</p>'+lines(2));
  return h;}
function worksheetHTML(l,x,key){x=x||g();var items=arr(l.worksheet&&l.worksheet.items),young=x==='K'||x==='1'||x==='2';
  var h=head(T('Money Matters')+' · '+gl(x)+' · '+(key?T('Answer Key'):T('Student Worksheet')),T('Week')+' '+l.week+': '+l.title,key?T('For the teacher or family member. Keep separate from student copies.'):l.sub,key?'<span class="badge key">'+esc(T('Answer key'))+'</span>':'');
  if(!key)h+='<div class="namebar"><div>'+esc(T('Name'))+'<i></i></div><div>'+esc(T('Date'))+'<i></i></div><div>'+esc(T('Class'))+'<i></i></div><div>'+esc(T('Score'))+'<i></i></div></div>';
  h+='<div class="goal"><b>'+esc(T('Learning goal'))+'</b>'+esc(ican(l.objective))+'</div>';
  if(arr(l.vocab).length)h+='<div class="box avoid" style="margin-bottom:10px"><h3>'+esc(T('Words to know'))+'</h3>'+(young?'<div class="wordbank">'+arr(l.vocab).map(function(v){return '<span>'+esc(v.term)+'</span>';}).join('')+'</div>':vocab(l.vocab))+'</div>';
  h+='<p><b>'+esc(T('Directions'))+':</b> '+esc(reword(l.worksheet&&l.worksheet.intro||''))+'</p>';
  items.forEach(function(it,i){var long=/draw|describe|explain|why/i.test(it.q)||String(it.answer||'').length>40;
    h+='<div class="q"><div class="no">'+(i+1)+'</div><div><div>'+esc(reword(it.q))+'</div>'+(key?'<div class="ans">'+esc(it.answer)+'</div>':(/draw/i.test(it.q)?'<div class="bx"></div>':'<div class="wr"></div>'+(long?'<div class="wr"></div>':'')))+'</div></div>';});
  if(!young){var n=items.length+1;h+='<div class="q"><div class="no">'+n+'</div><div><b>'+esc(T('Money Matters Challenge'))+':</b> '+esc(T('Explain one real-life choice where you could use today’s lesson. What would you do, and why?'))+(key?'<div class="ans">'+esc(T('Answers will vary. Look for a realistic situation that applies the lesson idea and a clear reason.'))+'</div>':'<div class="bx"></div>')+'</div></div>';}
  if(key){var ck=splitCheck(l.check);h+=sec(0,T('Lesson checks'),'<div class="call"><b>'+esc(T('Quick check'))+':</b> '+esc(ck.q)+(ck.a?'<div class="ans">'+esc(ck.a)+'</div>':'')+'</div><div class="call"><b>'+esc(T('Exit ticket'))+':</b> '+esc(l.exit)+'<div class="small">'+esc(T('Look for an answer that uses the key vocabulary correctly.'))+'</div></div>');
    var qz=quizFor(x,l.week);if(qz.length)h+=sec(0,T('Weekly quiz answer key'),'<table class="t"><thead><tr><th style="width:6%">#</th><th>'+esc(T('Question'))+'</th><th style="width:34%">'+esc(T('Correct answer'))+'</th></tr></thead><tbody>'+qz.map(function(q,i){return '<tr><td class="c">'+(i+1)+'</td><td>'+esc(q.q)+'</td><td class="ans">'+esc(q.options&&q.options[q.answer])+'</td></tr>';}).join('')+'</tbody></table>');}
  else h+='<div class="box avoid" style="margin-top:12px"><h3>'+esc(T('How did I do?'))+'</h3><div class="self"><span>'+esc(T('I can do this on my own'))+'</span><span>'+esc(T('I can do this with a little help'))+'</span><span>'+esc(T('I am not there yet'))+'</span></div></div>';
  return h;}
function familyHTML(l,x){x=x||g();var ck=splitCheck(l.check),sch=school();
  var h='<div class="letterhead"><b>'+esc(sch||T('Money Matters'))+'</b><span>'+esc(gl(x))+' · '+esc(T('Week'))+' '+l.week+'<br>'+esc(today())+'</span></div>';
  h+='<p>'+esc(T('Dear family,'))+'</p><p>'+esc(T('This week in our Money Matters financial literacy lessons, your child is learning about “{t}.” {s}',{t:l.title,s:l.sub||''}))+'</p>';
  h+='<div class="goal"><b>'+esc(T('Your child’s goal this week'))+'</b>'+esc(ican(l.objective))+'</div>';
  h+='<div class="two"><div class="box"><h3>'+esc(T('Words to know'))+'</h3>'+vocab(l.vocab)+'</div><div class="box"><h3>'+esc(T('Talk about it together'))+'</h3>'+ul(l.discussion)+'</div></div>';
  h+=sec(0,T('Try it at home'),'<p>'+esc(l.homeExtension||'')+'</p>'+(l.independent?'<p class="small">'+esc(T('In class:'))+' '+esc(l.independent)+'</p>':''));
  if(ck.q)h+=sec(0,T('Quick check'),'<div class="call">'+esc(ck.q)+(ck.a?'<div class="small"><i>'+esc(T('Answer for the adult:'))+' '+esc(ck.a)+'</i></div>':'')+'</div>');
  h+=sec(0,T('Ways to help'),ul([T('Ask your child to teach you this week’s words.'),T('Point out real examples when you shop, pay a bill, or save for something.'),T('Praise effort and ask, “How did you figure that out?”')]));
  h+='<p>'+esc(T('Thank you for supporting your child’s learning.'))+'</p><div class="sig"><div>'+esc(teacherName()||T('Teacher'))+'</div><div>'+esc(T('Contact'))+'</div></div>';
  h+='<div class="slip"><span class="cut">✂ '+esc(T('Cut here and return to school'))+'</span><p><b>'+esc(T('Family reply · Week {w}: {t}',{w:l.week,t:l.title}))+'</b></p><p>'+esc(T('Student name'))+': ______________________________ &nbsp; '+esc(T('We talked about this week’s money words.'))+' ☐</p><p>'+esc(T('One thing we did together:'))+'</p>'+lines(2)+'<div class="sig"><div>'+esc(T('Family member signature'))+'</div><div>'+esc(T('Date'))+'</div></div></div>';
  return h;}
function current(){try{return L();}catch(e){return null;}}
function canPrint(){try{if(loadRole()!=='teacher'&&typeof lessonViewed==='function'&&!lessonViewed(currentIndex)){toast(T('Finish the lesson first to unlock this download.'));return false;}}catch(e){}return true;}
function packetBody(l){return '<div class="first">'+planHTML(l)+'</div><div class="page">'+worksheetHTML(l)+'</div><div class="page">'+worksheetHTML(l,null,true)+'</div><div class="page">'+familyHTML(l)+'</div>';}
function workbookBody(){var x=g(),all=lessonsOf(),ls=all.filter(function(l,i){try{return weekUnlocked(i);}catch(e){return true;}}),hidden=all.length-ls.length;
  var h='<div class="cover first"><div><div class="k">'+esc(T('Money Matters · K–8 Financial Literacy'))+'</div><h1>'+esc(T('{g} Student Workbook',{g:gl(x)}))+'</h1><div class="sub">'+esc(theme(x))+'</div></div><div class="mark" aria-hidden="true">$</div><div class="fields"><div>'+esc(T('Name'))+'<i></i></div><div>'+esc(T('Class'))+'<i></i></div><div>'+esc(T('Teacher'))+'<i></i></div><div>'+esc(T('School year'))+'<i></i></div></div><div class="small">'+esc(school())+'</div></div>';
  h+='<div class="page">'+head(gl(x)+' · '+T('Workbook'),T('Contents'),T('Check off each worksheet when you finish it.'))+'<table class="toc"><tbody>';var lastU=-1;
  ls.forEach(function(l){var u=unitOf(l);if(u!==lastU){h+='<tr class="u"><td colspan="3">'+esc(T('Unit {n}',{n:u+1}))+' · '+esc(unitName(x,u))+'</td></tr>';lastU=u;}h+='<tr><td class="w">'+esc(T('Week'))+' '+l.week+'</td><td>'+esc(l.title)+'</td><td class="c">☐</td></tr>';});
  h+='</tbody></table>'+(hidden>0?'<div class="call">'+esc(T('{n} later weeks unlock after the earlier quizzes are passed.',{n:hidden}))+'</div>':'')+'<div class="box" style="margin-top:12px"><h3>'+esc(T('How to use this workbook'))+'</h3>'+ul([T('Complete one worksheet after each lesson.'),T('Use the Words to know box if you get stuck.'),T('Rate yourself at the bottom of each page.')])+'</div></div>';
  lastU=-1;ls.forEach(function(l){var u=unitOf(l);if(u!==lastU){h+='<div class="page divider"><div class="k">'+esc(T('Unit {n}',{n:u+1}))+'</div><h1>'+esc(unitName(x,u))+'</h1><p class="muted">'+esc(T('Weeks {a}–{b}',{a:u*6+1,b:u*6+6}))+'</p></div>';lastU=u;}h+='<div class="page">'+worksheetHTML(l)+'</div>';});
  return h;}
function guideBody(){var x=g(),ls=lessonsOf();
  var h='<div class="cover first"><div><div class="k">'+esc(T('Money Matters · K–8 Financial Literacy'))+'</div><h1>'+esc(T('{g} Teacher’s Guide',{g:gl(x)}))+'</h1><div class="sub">'+esc(theme(x))+'</div></div><div class="mark" aria-hidden="true">$</div><div class="small">'+esc(school())+(teacherName()?' · '+esc(teacherName()):'')+'<br>'+esc(T('36 weekly lessons · 6 units · checkpoint tests · answer keys'))+'</div></div>';
  h+='<div class="page">'+head(gl(x)+' · '+T('Teacher’s Guide'),T('How to use this guide'),'')+'<div class="three"><div class="box"><h3>'+esc(T('Each week'))+'</h3><p>'+esc(T('One lesson of about 45 minutes: warm-up, mini-lesson, guided practice, worksheet, discussion, quick check and exit ticket.'))+'</p></div><div class="box"><h3>'+esc(T('Assessment'))+'</h3><p>'+esc(T('A short quiz each week (75% unlocks the next week) and a checkpoint test after every 6 weeks.'))+'</p></div><div class="box"><h3>'+esc(T('Families'))+'</h3><p>'+esc(T('Send the family letter home each week. It has talk prompts, a home activity and a reply slip.'))+'</p></div></div>';
  h+=sec(1,T('Year at a glance'),'<table class="t"><thead><tr><th>'+esc(T('Unit'))+'</th><th>'+esc(T('Weeks'))+'</th><th>'+esc(T('Lessons'))+'</th><th>'+esc(T('Checkpoint'))+'</th></tr></thead><tbody>'+[0,1,2,3,4,5].map(function(u){var b=ls.slice(u*6,u*6+6);return '<tr><td><b>'+(u+1)+' · '+esc(unitName(x,u))+'</b></td><td>'+(u*6+1)+'–'+(u*6+6)+'</td><td>'+b.map(function(l){return esc(l.title);}).join(' · ')+'</td><td>'+esc(T('Test {n}',{n:u+1}))+'</td></tr>';}).join('')+'</tbody></table>');
  h+='</div><div class="page">'+head(gl(x)+' · '+T('Teacher’s Guide'),T('Scope, sequence and pacing'),T('Write your planned dates in the last column.'))+'<table class="t"><thead><tr><th style="width:7%">'+esc(T('Week'))+'</th><th style="width:26%">'+esc(T('Lesson'))+'</th><th>'+esc(T('Objective'))+'</th><th style="width:16%">'+esc(T('Date'))+'</th></tr></thead><tbody>'+ls.map(function(l){return '<tr><td class="c"><b>'+l.week+'</b></td><td>'+esc(l.title)+'</td><td>'+esc(l.objective)+'</td><td></td></tr>';}).join('')+'</tbody></table></div>';
  ls.forEach(function(l){h+='<div class="page">'+planHTML(l,x,{noReflect:true})+'</div><div class="page">'+worksheetHTML(l,x,true)+'</div>';});
  return h;}
function docTitle(kind,l){var x=g();return {plan:T('Lesson Plan'),worksheet:T('Worksheet'),key:T('Answer Key'),family:T('Family Letter'),packet:T('Weekly Packet'),workbook:T('Workbook'),guide:T('Teacher’s Guide')}[kind]+' · '+gl(x)+(l&&kind!=='workbook'&&kind!=='guide'?' · '+T('Week')+' '+l.week:'');}
function bodyFor(kind){var l=current();if(kind==='workbook')return workbookBody();if(kind==='guide')return guideBody();if(!l)return '';
  if(kind==='plan')return '<div class="first">'+planHTML(l)+'</div>';if(kind==='worksheet')return '<div class="first">'+worksheetHTML(l)+'</div>';if(kind==='key')return '<div class="first">'+worksheetHTML(l,null,true)+'</div>';
  if(kind==='family')return '<div class="first">'+familyHTML(l)+'</div>';if(kind==='packet')return packetBody(l);return '';}
function bodyClassFor(kind){return kind==='family'?'letter':'';}
function printDoc(kind){kind=kind||(typeof currentDoc!=='undefined'?currentDoc:'plan');if(kind==='guide'){try{if(loadRole()!=='teacher')kind='plan';}catch(e){}}if(!canPrint())return;var l=current(),cover=kind==='workbook'||kind==='guide';
  open(docTitle(kind,l),bodyFor(kind),{headerLeft:T('Money Matters')+' · '+docTitle(kind,l),cover:cover,bodyClass:bodyClassFor(kind)});}
function wordDoc(kind){kind=kind||(typeof currentDoc!=='undefined'?currentDoc:'plan');if(kind==='guide'){try{if(loadRole()!=='teacher')kind='plan';}catch(e){}}if(!canPrint())return;var l=current();
  var file='MoneyMatters_'+String(gl(g())).replace(/\s+/g,'')+'_'+({plan:'LessonPlan',worksheet:'Worksheet',key:'AnswerKey',family:'FamilyLetter',packet:'Packet',workbook:'Workbook',guide:'TeachersGuide'}[kind]||kind)+(l&&kind!=='workbook'&&kind!=='guide'?'_Wk'+l.week:'')+'.doc';
  word(docTitle(kind,l),bodyFor(kind),file);}

/* ---------- hooks into the app ---------- */
window.downloadDoc=function(kind){wordDoc(kind);};
/* legacy builders (used by the weekly packet in student profiles) now return the new templates */
window.docPlan=function(l){return '<div>'+planHTML(l)+'</div>';};window.docWorksheet=function(l){return '<div>'+worksheetHTML(l)+'</div>';};window.docFamily=function(l){return '<div>'+familyHTML(l)+'</div>';};
window.downloadPacket=function(){wordDoc('packet');};
/* the legacy report window gets the same look */
function hookReports(){try{var U=MM91.util;if(U&&U.openHTML&&!U.openHTML.__v19){var o=U.openHTML;U.openHTML=function(title,body,extraCss){open(title,body,{bodyClass:'legacy',css:extraCss||'',headerLeft:T('Money Matters')+' · '+title});};U.openHTML.__v19=1;U.openHTML.__orig=o;}}catch(e){}}
hookReports();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',hookReports);
/* the Documents panel previews the same pages that print (the student worksheet stays interactive) */
function installPreview(){if(typeof window.renderDoc!=='function'||window.renderDoc.__v19)return;var o=window.renderDoc;
  var w=function(){var kind=(typeof currentDoc!=='undefined'?currentDoc:'plan'),area=document.getElementById('printArea');
    if(!area||kind==='worksheet'||!lessonsOf().length)return o.apply(this,arguments);
    try{if(kind==='plan'&&typeof weekUnlocked==='function'&&!weekUnlocked(currentIndex))return o.apply(this,arguments);if(kind==='guide'&&loadRole()!=='teacher')kind='plan';}catch(e){}
    var l=current(),html=wrap(docTitle(kind,l),'<style>body{padding:.55in .6in;background:#fff}.page{margin-top:.5in;padding-top:.5in;border-top:2px dashed #d9cdb4}</style>'+bodyFor(kind),{headerLeft:docTitle(kind,l)}),url=URL.createObjectURL(new Blob([html],{type:'text/html'}));
    area.innerHTML='<div class="mm-docbar"><span>'+esc(T('Print preview'))+' · '+esc(docTitle(kind,l))+'</span></div><iframe class="mm-docframe" title="'+esc(docTitle(kind,l))+'" src="'+url+'"></iframe>';
    var f=area.querySelector('iframe');f.onload=function(){try{var d=f.contentDocument;f.style.height=Math.max(600,d.documentElement.scrollHeight+20)+'px';}catch(e){f.style.height='1100px';}setTimeout(function(){URL.revokeObjectURL(url);},5000);};};
  w.__v19=1;window.renderDoc=w;}
installPreview();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installPreview);
window.MMPrint={open:open,wrap:wrap,html:printHTML,word:word,esc:esc,T:T,head:head,meta:meta,sec:sec,ul:ul,ol:ol,vocab:vocab,lines:lines,doc:printDoc,wordDoc:wordDoc,bodyFor:bodyFor,
  current:function(){printDoc();},preview:function(kind){var l=current();printHTML(wrap(docTitle(kind,l),bodyFor(kind),{headerLeft:T('Money Matters')+' · '+docTitle(kind,l),cover:kind==='workbook'||kind==='guide'}),{preview:true});}};
})();
