(function(){
'use strict';
var root=document.documentElement;
function isKey(){try{return loadRole()==='teacher';}catch(e){return false;}}
function esc2(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function banner(txt){var b=document.createElement('div');b.className='mm-key-banner';b.textContent=txt;return b;}
function quiz(){var f=document.getElementById('quizForm');
 if(!f||!isKey()||f.querySelector('.mm-key-banner')||!f.querySelector('.q-item'))return;
 if(typeof quizQs==='undefined'||!quizQs||!quizQs.length)return;
 f.insertBefore(banner('Teacher / Parent view: questions and correct answers are highlighted. Students do not see this.'),f.firstChild);
 quizQs.forEach(function(q,i){var it=document.getElementById('qi-'+i);if(!it)return;it.classList.add('mm-key-item');
  var o=document.getElementById('qo-'+i+'-'+q.answer);if(o)o.classList.add('mm-key-correct');
  if(q.explain){var n=document.createElement('div');n.className='mm-key-note';n.textContent='Why: '+q.explain;it.appendChild(n);}});
 var sb=document.querySelector('#quizButtons [onclick^="submitQuiz"]');if(sb)sb.style.display='none';}
function ws(){var a=document.getElementById('printArea');
 if(!a||!isKey()||typeof currentDoc==='undefined'||currentDoc!=='worksheet'||a.querySelector('.mm-key-banner'))return;
 var l=L();if(!l||!l.worksheet||!l.worksheet.items)return;
 var d=a.querySelector('.ws-directions');if(d&&d.parentNode)d.parentNode.insertBefore(banner('Teacher / Parent view: answers are shown under each question.'),d);
 var items=a.querySelectorAll('.ws-item:not(.challenge-item)');
 items.forEach(function(el,i){var it=l.worksheet.items[i];if(!it||!it.answer)return;el.classList.add('mm-key-q');
  var x=document.createElement('div');x.className='mm-key-ans';x.innerHTML='<b>\u2713 Answer:</b> '+esc2(it.answer);el.appendChild(x);});}
function sync(){root.classList.toggle('mm-key-view',isKey());quiz();ws();}
function init(){
 [['quizForm'],['printArea']].forEach(function(p){var el=document.getElementById(p[0]);if(el){try{new MutationObserver(sync).observe(el,{childList:true});}catch(e){}}});
 sync();setInterval(sync,1000);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
