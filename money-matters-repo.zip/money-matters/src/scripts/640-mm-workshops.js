/* Workshop content: 9 grades x 5 themed days (title, mission, outcomes, modules with timed blocks). */
var WS_DATA=/*@include data/WS_DATA.json*/;
/* Spanish and Portuguese versions (same structure) and the standards mapping (review/standards.md) */
var WS_DATA_L={es:/*@include data/WS_DATA_es.json*/,pt:/*@include data/WS_DATA_pt.json*/};
var WS_STANDARDS=/*@include data/WS_STANDARDS.json*/;
var WS_FRAME={k2:{w:15,b:15,g:20,r:15,cap:180},'35':{w:15,b:15,g:25,r:20,cap:210},'68':{w:15,b:15,g:25,r:20,cap:240}};
var WS_GROUPS={1:[[0,1,2,3,4]],2:[[0,1,2],[3,4]],3:[[0,1],[2,3],[4]],4:[[0],[1],[2,3],[4]],5:[[0],[1],[2],[3],[4]]};
function wsBand(g){return (g==='K'||g==='1'||g==='2')?'k2':(g==='3'||g==='4'||g==='5')?'35':'68';}
/* Build one day's agenda: frame blocks + module blocks, fitted to 2–4 hours */
function wsCompose(W,g,fmt,di){
  var F=WS_FRAME[wsBand(g)],idx=WS_GROUPS[fmt][di],mods=idx.map(function(i){return W.modules[i];}),single=mods.length===1;
  var content=[];
  mods.forEach(function(m,mi){m.blocks.forEach(function(b,bi){if(single||b.core)content.push({kind:b.kind,title:b.title,min:b.min,short:b.short,core:!!b.core,how:b.how,fun:b.fun,materials:b.materials||[],mod:idx[mi],bi:bi});});});
  var game={kind:'game',title:'',min:F.g,short:15,core:true,mod:idx[idx.length-1]},wel={kind:'welcome',min:F.w,short:10,core:true},ref={kind:'reflect',min:F.r,short:15,core:true};
  function sum(){return wel.min+ref.min+game.min+content.reduce(function(a,b){return a+b.min;},0)+breaks()*F.b;}
  function breaks(){var c=wel.min+ref.min+game.min+content.reduce(function(a,b){return a+b.min;},0);return c+F.b>=165?2:1;}
  /* too long: trim the longest content blocks toward their short length, then the frame */
  var guard=0;while(sum()>F.cap&&guard++<400){var big=null;content.forEach(function(b){var floor=b.core?b.short:10;if(b.min>floor&&(!big||b.min>big.min))big=b;});
    if(big)big.min-=5;else if(game.min>15)game.min-=5;else if(wel.min>10)wel.min-=5;else if(ref.min>15)ref.min-=5;else break;}
  /* room to spare on merged days: add back the enrichment blocks */
  if(!single){mods.forEach(function(m,mi){m.blocks.forEach(function(b,bi){if(b.core)return;var nb={kind:b.kind,title:b.title,min:b.min,short:10,core:false,how:b.how,fun:b.fun,materials:b.materials||[],mod:idx[mi],bi:bi,extra:true};content.push(nb);if(sum()>F.cap-10){nb.min=Math.min(nb.min,15);if(sum()>F.cap-5)content.pop();}});});
    content.sort(function(a,b){return a.mod-b.mod||a.bi-b.bi;});}
  /* assemble with breaks spaced through the content */
  var nB=breaks(),out=[wel],half=content.reduce(function(a,b){return a+b.min;},0)/(nB+1),acc=0,placed=0;
  content.forEach(function(b){out.push(b);acc+=b.min;if(placed<nB&&acc>=half*(placed+1)){out.push({kind:'break',min:F.b});placed++;}});
  while(placed<nB){out.splice(out.length,0,{kind:'break',min:F.b});placed++;}
  if(out[out.length-1].kind==='break'){var br=out.pop();out.splice(out.length-1,0,br);}
  out.push(game);out.push(ref);
  return {mods:idx,blocks:out,total:out.reduce(function(a,b){return a+b.min;},0)};
}

/* =====================================================================
   MONEY WORKSHOPS  ·  window.MMWorkshops  ·  panel "workshops"
   Intensive, hands-on workshops for every grade, separate from the
   weekly student lessons and the teacher/parent lesson guides.
   Each grade has a 5-day progression of themed days (WS_DATA). The
   1-, 2-, 3-, 4- and 5-day formats are composed from those days by
   wsCompose(): every day runs 2–4 hours and ends with a certificate.
     Views   Overview · format picker · day agenda with clock times ·
             facilitator notes (staff) · materials · vocabulary ·
             debrief · take-home · Game Show launch · certificates
     Prints  Facilitator guide · student passport · day certificates
             (one name or the whole class)
     Store   mmWorkshop_v1 {fmt:{grade:n}, start:'09:00', done:{sid:{key:date}}}
   ===================================================================== */
(function(){
'use strict';
var KEY='mmWorkshop_v1';
function st(){try{var o=JSON.parse(localStorage.getItem(KEY)||'{}');o.fmt=o.fmt||{};o.done=o.done||{};o.start=o.start||'09:00';return o;}catch(e){return {fmt:{},done:{},start:'09:00'};}}
function put(o){try{localStorage.setItem(KEY,JSON.stringify(o));}catch(e){}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function $(id){return document.getElementById(id);}
function M(){return window.MM91||{};}
function auth(){try{return M().auth.get();}catch(e){return null;}}
function isStudent(){try{return M().auth.roleKey()==='student';}catch(e){var a=auth();return !!a&&a.role==='student';}}
function isStaff(){return !!auth()&&!isStudent();}
function sampleOn(){try{return !!(M().sample&&M().sample.active());}catch(e){return false;}}
function grade(){try{return (sampleOn()&&M().sample.grade&&M().sample.grade())||currentGrade||'K';}catch(e){return 'K';}}
function gradeName(g){try{if(typeof GRADE_LABEL!=='undefined'&&GRADE_LABEL[g])return GRADE_LABEL[g];}catch(e){}return g==='K'?'Kindergarten':'Grade '+g;}
function school(){try{return (typeof getSchoolName==='function'&&getSchoolName())||localStorage.getItem('mmSchoolName')||'';}catch(e){return '';}}
function roster(g){try{return (M().data.list()||[]).filter(function(s){return (s.grade||'K')===g;});}catch(e){return [];}}
function toast(m){try{infoToast(m,3500);}catch(e){}}
var KIND={welcome:['Welcome','#6b5137'],learn:['Mini-lesson','#1e4d7a'],sim:['Simulation','#2a6b4a'],challenge:['Challenge','#8a5e10'],create:['Create','#7a1e4d'],discuss:['Discuss','#5a2d7a'],break:['Break','#6b6b6b'],game:['Game Show','#b0761a'],reflect:['Reflect + Certificate','#1e6b6b']};
var FMT_NAME={1:'1-Day Intensive',2:'2-Day Workshop',3:'3-Day Workshop',4:'4-Day Workshop',5:'5-Day Camp'};
function hm(min){var h=Math.floor(min/60),m=min%60;return (h?h+' h':'')+(h&&m?' ':'')+(m?m+' min':'');}
function clock(start,add){var p=String(start||'09:00').split(':'),t=(+p[0])*60+(+p[1]||0)+add,h=Math.floor(t/60)%24,m=t%60,ap=h>=12?'PM':'AM',h12=h%12||12;return h12+':'+String(m).padStart(2,'0')+' '+ap;}
function wsLang(){try{return loadLang()||'en';}catch(e){return 'en';}}
function W(g){var l=wsLang();if(l!=='en'&&typeof WS_DATA_L!=='undefined'&&WS_DATA_L[l]&&WS_DATA_L[l][g])return WS_DATA_L[l][g];return (typeof WS_DATA!=='undefined'&&WS_DATA[g])||null;}
function fmtOf(g){var f=+st().fmt[g]||3;if(sampleOn())f=1;return f;}
function day(g,f,d){return wsCompose(W(g),g,f,d);}
function dayTitle(g,f,d){var w=W(g),idx=WS_GROUPS[f][d];if(f===1)return 'Money Workshop Intensive';return idx.map(function(i){return w.modules[i].title;}).join(' + ');}
function gameName(id){try{return window.MMGameShow?window.MMGameShow.name(id):id;}catch(e){return id;}}
function frameText(b,g,f,d){var w=W(g),idx=WS_GROUPS[f][d],m0=w.modules[idx[0]],ml=w.modules[idx[idx.length-1]];
  if(b.kind==='welcome')return {title:d===0?'Welcome and Money Warm-Up':'Welcome Back and Recap',how:(d===0?'Introduce the workshop mission: '+w.mission+' Share today’s “I can” goals, set team names, and explain how teams earn points today.':'Ask three volunteers to share how the last take-home challenge went, then preview today’s goals.')+' Warm-up: teach the word "'+(m0.vocab[0]&&m0.vocab[0][0])+'" and ask a quick “Would you rather…?” money question.',fun:'Team names and a points board start the energy right away.'};
  if(b.kind==='break')return {title:'Brain Break and Snack',how:g==='K'||g==='1'||g==='2'?'Snack, water, and a movement song. Keep play money and supplies put away during the break.':'Stretch, snack, and water. Optional: a one-minute “price is right” guess about something in the room.',fun:'Movement resets attention for the next activity.'};
  if(b.kind==='game')return {title:'Game Show: '+gameName(ml.game),how:'Project the Money Game Show and play '+gameName(ml.game)+' in teams. Questions come from this grade’s curriculum, so the round reviews today’s ideas. Award bonus points to the winning team.',fun:'A live scoreboard, timers, and a podium finish.'};
  return {title:'Reflect and Earn Your Certificate',how:'Debrief with the questions below, share the take-home challenge, then present today’s certificate to each student who completed the day.',fun:'Every student leaves with a certificate for the day.'};}

/* ---------- render ---------- */
var view={day:0,tab:'plan',quiz:null};
function lockedView(g,w){var staff=isStaff();return '<div class="ws"><section class="ws-hero"><div><div class="ws-k">'+esc(('Money Workshops'))+' · '+esc(gradeName(g))+'</div><h2>'+esc(w.title)+'</h2><p>'+esc(w.mission)+'</p></div>'+(w.outcomes&&w.outcomes.length?'<div><div class="ws-k">'+esc(('By the end, students can say'))+'</div><ul>'+w.outcomes.map(function(o){return '<li>'+esc(o)+'</li>';}).join('')+'</ul></div>':'')+'</section>'
  +'<div class="ws-lock" role="note"><p><b>🔒 '+esc(('Workshops are included with a subscription.'))+'</b> '+esc(('Five formats for every grade, from a 1-day intensive to a 5-day camp, each 2 to 4 hours a day, with facilitator guides, student passports, check-ins and a certificate for every day.'))+'</p>'
  +(staff?'<button type="button" class="ws-btn" onclick="MMLicense.prompt(\'Workshops\')">🔑 '+esc(('Unlock workshops'))+'</button>':'<p>'+esc(('Your teacher can unlock workshops with a school access code.'))+'</p>')+'</div></div>';}
function render(){var el=$('workshopsBody');if(!el)return;var g=grade(),w=W(g);if(!w){el.innerHTML='<p>Workshops are not available for this grade.</p>';return;}
  if(w.locked||(window.MMLicense&&!MMLicense.has()&&!sampleOn())){el.innerHTML=lockedView(g,w);return;}
  var f=fmtOf(g);if(view.day>=f)view.day=0;var staff=isStaff()&&!sampleOn(),s=st();
  var h='<div class="ws">';
  h+='<section class="ws-hero"><div class="ws-hero-main"><div class="ws-k">Money Workshops · '+esc(gradeName(g))+'</div><h2>'+esc(w.title)+'</h2><p class="ws-mission">'+esc(w.mission)+'</p></div><div class="ws-outcomes"><div class="ws-k">By the end, students can say</div><ul>'+w.outcomes.map(function(o){return '<li>'+esc(o)+'</li>';}).join('')+'</ul></div></section>';
  if(staff)h+='<div class="ws-tools"><span class="ws-k">Grade</span><div class="ws-grades" role="group" aria-label="Grade">'+['K','1','2','3','4','5','6','7','8'].map(function(x){return '<button type="button" data-ws="grade" data-g="'+x+'" aria-pressed="'+(x===g)+'">'+(x==='K'?'K':x)+'</button>';}).join('')+'</div><span class="ws-sp"></span><button type="button" class="ws-btn ghost" data-ws="guide">Print facilitator guide</button><button type="button" class="ws-btn ghost" data-ws="passport">Print student passport</button></div>';
  var stu=isStudent()&&!sampleOn();
  if(staff||stu)h+='<div class="ws-tabs" role="tablist" aria-label="Workshop views"><button type="button" role="tab" data-ws="tab" data-t="plan" aria-selected="'+(view.tab!=='results')+'">'+(stu?'Workshop plan':'Plan and run')+'</button><button type="button" role="tab" data-ws="tab" data-t="results" aria-selected="'+(view.tab==='results')+'">'+(stu?'My check-in and check-out':'Check-in, check-out and results')+'</button></div>';
  if(view.tab==='results'&&(staff||stu)){h+=stu?studentChecks(g):resultsHTML(g);h+='</div>';el.innerHTML=h;return;}
  h+='<div class="ws-k" style="margin-top:4px">Choose a format</div><div class="ws-formats">'+[1,2,3,4,5].map(function(n){var lens=[];for(var d=0;d<n;d++)lens.push(day(g,n,d).total);var lo=Math.min.apply(null,lens),hi=Math.max.apply(null,lens),lock=sampleOn()&&n>1;
    return '<button type="button" class="ws-fmt'+(n===f?' on':'')+'" data-ws="fmt" data-n="'+n+'" aria-pressed="'+(n===f)+'"'+(lock?' disabled title="Included with a subscription"':'')+'><b>'+esc(FMT_NAME[n])+'</b><span>'+(n===1?hm(lo):n+' days · '+(lo===hi?hm(lo):hm(lo)+'–'+hm(hi))+' each')+'</span>'+(lock?'<em>Subscription</em>':'')+'</button>';}).join('')+'</div>';
  h+='<div class="ws-days" role="tablist" aria-label="Workshop days">'+Array.from({length:f},function(_,d){return '<button type="button" role="tab" class="ws-day'+(d===view.day?' on':'')+'" aria-selected="'+(d===view.day)+'" data-ws="day" data-d="'+d+'"><span>Day '+(d+1)+'</span><b>'+esc(dayTitle(g,f,d))+'</b></button>';}).join('')+'</div>';
  h+=dayHTML(g,f,view.day,staff,s);
  h+='</div>';el.innerHTML=h;}
function dayHTML(g,f,d,staff,s){var w=W(g),D=day(g,f,d),idx=D.mods,mods=idx.map(function(i){return w.modules[i];}),last=mods[mods.length-1],t=0,mats={},vocab=[],seenV={};
  D.blocks.forEach(function(b){(b.materials||[]).forEach(function(m){mats[m]=1;});});mods.forEach(function(m){m.vocab.forEach(function(v){if(!seenV[v[0]]){seenV[v[0]]=1;vocab.push(v);}});});
  var h='<section class="ws-dayhead"><div><div class="ws-k">Day '+(d+1)+' of '+f+' · '+hm(D.total)+'</div><h3>'+esc(dayTitle(g,f,d))+'</h3><p>'+mods.map(function(m){return '<span class="ws-tag">'+esc(m.tagline)+'</span>';}).join(' ')+'</p>'+(function(){var a=[];idx.forEach(function(i){stdOf(g,i).forEach(function(x){if(a.indexOf(x)<0)a.push(x);});});return a.length?'<p class="ws-std"><span>Standards</span> '+a.map(function(x){return '<b>'+esc(x)+'</b>';}).join('')+'</p>':'';})()+'</div>'
   +(staff?'<label class="ws-start">Start time <select data-ws-ch="start">'+['07:30','08:00','08:30','09:00','09:30','10:00','12:00','12:30','13:00','13:30','14:00','15:00'].map(function(x){return '<option value="'+x+'"'+(x===s.start?' selected':'')+'>'+clock(x,0)+'</option>';}).join('')+'</select></label>':'')+'</section>';
  h+='<div class="ws-grid"><div class="ws-agenda"><div class="ws-k">Agenda</div><ol class="ws-blocks">';
  D.blocks.forEach(function(b,i){var k=KIND[b.kind]||['Activity','#555'],txt=b.how?b:frameText(b,g,f,d),start=clock(s.start,t);t+=b.min;
    var mod=b.mod!=null?w.modules[b.mod]:null,isGame=b.kind==='game';
    h+='<li class="ws-block" style="--kc:'+k[1]+'"><div class="ws-time"><b>'+start+'</b><span>'+b.min+' min</span></div><div class="ws-bbody"><div class="ws-bhead"><span class="ws-kind">'+k[0]+'</span>'+(mods.length>1&&mod&&b.kind!=='game'&&b.kind!=='break'?'<span class="ws-from">'+esc(mod.title)+'</span>':'')+'</div><h4>'+esc(txt.title)+'</h4>'
      +(staff?'<p>'+esc(txt.how)+'</p>':'')+(txt.fun?'<p class="ws-fun">'+esc(txt.fun)+'</p>':'')
      +(staff&&b.materials&&b.materials.length?'<p class="ws-mat"><b>Materials:</b> '+esc(b.materials.join(', '))+'</p>':'')
      +(isGame?'<button type="button" class="ws-btn" data-ws="game" data-m="'+esc(last.game)+'">Launch '+esc(gameName(last.game))+'</button>':'')
      +'</div></li>';});
  h+='</ol></div><aside class="ws-side">';
  h+='<div class="ws-card"><div class="ws-k">Real-world connection</div>'+mods.map(function(m){return '<p>'+esc(m.realWorld)+'</p>';}).join('')+'</div>';
  if(staff)h+='<div class="ws-card"><div class="ws-k">Facilitator goals</div><ul>'+mods.map(function(m){return '<li>'+esc(m.goal)+'</li>';}).join('')+'</ul></div>';
  h+='<div class="ws-card"><div class="ws-k">Words of the day</div><dl class="ws-vocab">'+vocab.map(function(v){return '<dt>'+esc(v[0])+'</dt><dd>'+esc(v[1])+'</dd>';}).join('')+'</dl></div>';
  if(staff){var mk=Object.keys(mats);if(mk.length)h+='<div class="ws-card"><div class="ws-k">Materials checklist</div><ul class="ws-check">'+mk.map(function(m){return '<li><label><input type="checkbox"> '+esc(m)+'</label></li>';}).join('')+'</ul></div>';}
  h+='<div class="ws-card"><div class="ws-k">Debrief</div><ul>'+[].concat.apply([],mods.map(function(m){return m.debrief;})).slice(0,4).map(function(q){return '<li>'+esc(q)+'</li>';}).join('')+'</ul></div>';
  h+='<div class="ws-card ws-home"><div class="ws-k">Take-home challenge</div><p>'+esc(last.takeHome)+'</p></div>';
  h+=certCard(g,f,d,staff,s);
  h+='</aside></div>';return h;}
/* completion is keyed by the themed days covered, so changing the format keeps earlier marks */
function dkey(g,f,d){return g+'|m'+WS_GROUPS[f][d].join('-');}
function certCard(g,f,d,staff,s){var key=dkey(g,f,d),h='<div class="ws-card ws-cert"><div class="ws-k">Day '+(d+1)+' certificate</div>';
  if(isStudent()){var a=auth(),done=a&&s.done[a.id]&&s.done[a.id][key];h+=done?'<p>You completed this day on '+esc(new Date(done).toLocaleDateString())+'.</p><button type="button" class="ws-btn" data-ws="cert-me">Print my certificate</button>':'<p>Your teacher marks the day complete at the end of the session. Then you can print your certificate here.</p>';return h+'</div>';}
  h+='<label class="ws-lbl" for="ws-cname">Student name</label><div class="ws-row"><input id="ws-cname" class="ws-in" maxlength="60" placeholder="e.g. Ava Jones"><button type="button" class="ws-btn" data-ws="cert-one">Print</button></div>';
  var r=staff?roster(g):[];
  if(r.length){var n=r.filter(function(x){return s.done[x.id]&&s.done[x.id][key];}).length;
    h+='<div class="ws-k" style="margin-top:10px">Class completion · '+n+' of '+r.length+'</div><ul class="ws-roster">'+r.map(function(x){var on=!!(s.done[x.id]&&s.done[x.id][key]);return '<li><label><input type="checkbox" data-ws-done="'+esc(x.id)+'"'+(on?' checked':'')+'> '+esc(x.name)+'</label></li>';}).join('')+'</ul>'
     +'<div class="ws-row"><button type="button" class="ws-btn ghost" data-ws="all-done">Mark all complete</button><button type="button" class="ws-btn" data-ws="cert-class"'+(n?'':' disabled')+'>Print '+n+' certificate'+(n===1?'':'s')+'</button></div>';}
  else if(staff)h+='<p class="ws-note">Add students to this grade to track completion and print a certificate for everyone at once.</p>';
  return h+'</div>';}

/* ---------- printing (MMPrint shell: cover band, numbered sections, running header/footer) ---------- */
function P(){return window.MMPrint;}
function stdOf(g,i){try{return (typeof WS_STANDARDS!=='undefined'&&WS_STANDARDS[g]&&WS_STANDARDS[g][i])||[];}catch(e){return [];}}
function fmtLabel(f){return FMT_NAME[f];}
function daySpan(g,f,d,start){var D=day(g,f,d);return clock(start,0)+' – '+clock(start,D.total);}
function agendaTable(g,f,d,start,staff){var D=day(g,f,d),t=0,w=W(g),E=P().esc;
  return '<table class="t"><thead><tr><th style="width:13%">Time</th><th style="width:16%">Block</th><th>'+(staff?'How to run it':'What we do')+'</th><th style="width:20%">Materials</th></tr></thead><tbody>'+D.blocks.map(function(b){var txt=b.how?b:frameText(b,g,f,d),k=(KIND[b.kind]||['Activity'])[0],s0=clock(start,t);t+=b.min;var mod=b.mod!=null?w.modules[b.mod]:null;
    return '<tr><td class="time">'+s0+'<div class="small">'+b.min+' min</div></td><td><b>'+E(k)+'</b>'+(mod&&b.kind!=='game'&&b.kind!=='break'&&D.mods.length>1?'<div class="small">'+E(mod.title)+'</div>':'')+'</td><td><b>'+E(txt.title)+'</b>'+(staff?'<div>'+E(txt.how)+'</div>':'')+(txt.fun?'<div class="small"><i>'+E(txt.fun)+'</i></div>':'')+'</td><td class="small">'+E((b.materials||[]).join(', '))+'</td></tr>';}).join('')+'</tbody></table>';}
function printGuide(g,f){var w=W(g),s=st(),M=P(),E=M.esc,sch=school(),fac='';try{fac=MM91.auth.displayName()||'';}catch(e){}
  var h='<div class="cover first"><div><div class="k">Money Matters Workshops · Facilitator Guide</div><h1>'+E(w.title)+'</h1><div class="sub">'+E(gradeName(g))+' · '+E(fmtLabel(f))+'</div></div><div class="mark" aria-hidden="true">$</div>'
   +'<div class="fields"><div>School<i>'+E(sch)+'</i></div><div>Facilitator<i>'+E(fac)+'</i></div><div>Dates<i></i></div><div>Room<i></i></div></div><div class="small">'+E(w.mission)+'</div></div>';
  h+='<div class="page">'+M.head('Facilitator Guide · '+gradeName(g),'Workshop at a glance',w.mission);
  h+=M.meta([['Grade',gradeName(g)],['Format',fmtLabel(f)],['Days',String(f)],['Daily start',clock(s.start,0)],['Total time',hm((function(){var t=0;for(var d=0;d<f;d++)t+=day(g,f,d).total;return t;})())]]);
  h+=M.sec(1,'Daily schedule','<table class="t"><thead><tr><th>Day</th><th>Focus</th><th>Time</th><th>Length</th><th>Game Show round</th></tr></thead><tbody>'+Array.from({length:f},function(_,d){var D=day(g,f,d),mods=D.mods.map(function(i){return w.modules[i];});return '<tr><td class="c"><b>'+(d+1)+'</b></td><td><b>'+E(dayTitle(g,f,d))+'</b><div class="small">'+E(mods.map(function(m){return m.tagline;}).join(' '))+'</div></td><td>'+daySpan(g,f,d,s.start)+'</td><td>'+hm(D.total)+'</td><td>'+E(gameName(mods[mods.length-1].game))+'</td></tr>';}).join('')+'</tbody></table>');
  h+=M.sec(2,'Learning outcomes','<div class="two"><div>'+M.ul(w.outcomes,'ck')+'</div><div class="box"><h3>Standards alignment</h3><p class="small">National Standards for Personal Financial Education (Jump$tart and CEE, 2021)</p><table class="t"><tbody>'+w.modules.map(function(m,i){return '<tr><td><b>'+E(m.title)+'</b></td><td class="small">'+E(stdOf(g,i).join(', ')||'—')+'</td></tr>';}).join('')+'</tbody></table></div></div>');
  var mats={};w.modules.forEach(function(m,mi){m.blocks.forEach(function(b){(b.materials||[]).forEach(function(x){(mats[x]=mats[x]||[]).push(mi+1);});});});
  h+=M.sec(3,'Master materials list','<table class="t"><thead><tr><th style="width:6%"></th><th>Item</th><th style="width:22%">Used on themed day</th><th style="width:14%">Have</th></tr></thead><tbody>'+Object.keys(mats).sort().map(function(x){return '<tr><td class="c">☐</td><td>'+E(x)+'</td><td>'+mats[x].filter(function(v,i,a){return a.indexOf(v)===i;}).join(', ')+'</td><td></td></tr>';}).join('')+'</tbody></table>');
  h+=M.sec(4,'Before the workshop','<ul class="ck"><li>Print one Money Passport per student and the check-in quiz (Workshops → Check-in, check-out and results).</li><li>Print the day certificates, or plan to print them at the end of each day.</li><li>Gather and label materials by day; set up stations the evening before.</li><li>Test the Money Game Show on the classroom projector (Games → Money Game Show).</li><li>Share the family letter or take-home challenges with families.</li><li>Plan for allergies before any snack activity, and for students who need movement or quiet breaks.</li></ul>')+'</div>';
  for(var d=0;d<f;d++){var D=day(g,f,d),mods=D.mods.map(function(i){return w.modules[i];}),vocab=[],seen={};mods.forEach(function(m){m.vocab.forEach(function(v){if(!seen[v[0]]){seen[v[0]]=1;vocab.push(v);}});});
    h+='<div class="page">'+M.head('Day '+(d+1)+' of '+f+' · '+gradeName(g)+' · '+w.title,dayTitle(g,f,d),mods.map(function(m){return m.tagline;}).join(' '));
    h+=M.meta([['Day',(d+1)+' of '+f],['Time',daySpan(g,f,d,s.start)],['Length',hm(D.total)],['Standards',mods.map(function(m){return stdOf(g,w.modules.indexOf(m)).join(', ');}).join(', ')||'—'],['Room',null]]);
    h+='<div class="two"><div class="goal"><b>Facilitator goals</b>'+E(mods.map(function(m){return m.goal;}).join(' '))+'</div><div class="goal" style="border-color:#b8862b;background:#fbf5e6"><b style="color:#7a5413">Real-world connection</b>'+E(mods.map(function(m){return m.realWorld;}).join(' '))+'</div></div>';
    h+=M.sec(1,'Agenda',agendaTable(g,f,d,s.start,true),hm(D.total));
    h+=M.sec(2,'Words of the day',M.vocab(vocab.map(function(v){return {term:v[0],def:v[1]};})));
    h+='<div class="two">'+M.sec(3,'Debrief questions',M.ol([].concat.apply([],mods.map(function(m){return m.debrief;}))))+M.sec(4,'Take-home challenge','<div class="call">'+E(mods[mods.length-1].takeHome)+'</div>')+'</div>';
    h+=M.sec(5,'End of day','<ul class="ck"><li>Mark each student complete in Workshops and print the Day '+(d+1)+' certificates.</li><li>Stamp each Money Passport.</li>'+(d===f-1?'<li>Give the check-out quiz and record scores.</li>':'')+'</ul><p class="small">Notes for tomorrow</p>'+M.lines(3))+'</div>';}
  M.open(w.title+' · Facilitator guide',h,{headerLeft:'Money Matters Workshops · '+w.title,cover:true});}
function printPassport(g,f){var w=W(g),M=P(),E=M.esc;
  var h='<div class="cover first"><div><div class="k">Money Matters Workshops</div><h1>My Money Passport</h1><div class="sub">'+E(w.title)+' · '+E(gradeName(g))+'</div></div><div class="mark" aria-hidden="true">$</div><div class="fields"><div>My name<i></i></div><div>Teacher<i></i></div><div>School<i>'+E(school())+'</i></div><div>Dates<i></i></div></div><div class="box" style="text-align:left"><h3>Our mission</h3><p>'+E(w.mission)+'</p><h3>By the end I can…</h3>'+M.ul(w.outcomes,'ck')+'</div></div>';
  for(var d=0;d<f;d++){var D=day(g,f,d),mods=D.mods.map(function(i){return w.modules[i];});
    h+='<div class="page">'+M.head('My Money Passport · Day '+(d+1)+' of '+f,dayTitle(g,f,d),mods.map(function(m){return m.tagline;}).join(' '));
    h+='<div class="two"><div>'+M.sec(1,'What we did today','<ul class="ck">'+D.blocks.filter(function(b){return b.how;}).map(function(b){return '<li>'+E(b.title)+'</li>';}).join('')+'</ul>')+'</div><div class="box center" style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:150px"><div style="width:120px;height:120px;border:2px dashed #b8862b;border-radius:50%;display:flex;align-items:center;justify-content:center;font:700 9pt Arial,sans-serif;color:#a87924;letter-spacing:.12em">STAMP<br>DAY '+(d+1)+'</div></div></div>';
    h+=M.sec(2,'My money words','<table class="t"><thead><tr><th style="width:24%">Word</th><th style="width:38%">What it means</th><th>In my own words or a picture</th></tr></thead><tbody>'+[].concat.apply([],mods.map(function(m){return m.vocab;})).map(function(v){return '<tr><td><b>'+E(v[0])+'</b></td><td>'+E(v[1])+'</td><td style="height:34px"></td></tr>';}).join('')+'</tbody></table>');
    h+=M.sec(3,'Think about it',[].concat.apply([],mods.map(function(m){return m.debrief;})).slice(0,2).map(function(q){return '<p><b>'+E(q)+'</b></p>'+M.lines(2);}).join(''));
    h+=M.sec(4,'Take-home challenge','<div class="call">'+E(mods[mods.length-1].takeHome)+'</div><p class="small">What happened when I tried it:</p>'+M.lines(2)+'<div class="sig"><div>Family member signature</div><div>Date</div></div>')+'</div>';}
  M.open('Money Passport · '+w.title,h,{headerLeft:'My Money Passport · '+w.title,cover:true});}
var CERT_CSS='@page{size:letter landscape;margin:.35in}@page{@top-left{content:none}@top-right{content:none}@bottom-left{content:none}@bottom-right{content:none}}body{font-family:Georgia,"Times New Roman",serif}.c{position:relative;height:7.75in;padding:.5in .7in;border:10px double #b8862b;outline:2px solid #1f4d36;outline-offset:-22px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;break-after:page;page-break-after:always;background:radial-gradient(circle at 50% 0,#fffaf0,#fff 60%)}.c:last-child{break-after:auto;page-break-after:auto}.c .kk{font:700 10pt Arial,sans-serif;letter-spacing:.3em;text-transform:uppercase;color:#1f4d36}.c .tt{font-size:42pt;margin:8px 0 2px;color:#7a5413}.c .ss{font-size:14pt;font-style:italic;color:#5b4a30}.c .nn{font-size:36pt;margin:16px 0 4px;padding:0 30px 6px;border-bottom:2px solid #b8862b;min-width:60%}.c .dd{font-size:15pt;max-width:8in;line-height:1.45;margin:10px 0}.c .dd b{color:#1f4d36}.c .sk{font:10pt/1.5 Arial,sans-serif;color:#4a4033;max-width:8in;margin-top:4px}.c .ff{display:flex;justify-content:space-between;width:100%;margin-top:30px;font:9pt Arial,sans-serif;color:#555}.c .ff div{width:28%;border-top:1px solid #777;padding-top:5px}.c .seal{position:absolute;right:.85in;top:.7in;width:96px;height:96px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#ffe9a8,#c99a3a 60%,#8a6420);display:flex;align-items:center;justify-content:center;color:#fff;font:700 10pt/1.2 Arial,sans-serif;text-align:center;box-shadow:0 0 0 4px #fff,0 0 0 6px #c99a3a}.c .logo{position:absolute;left:.85in;top:.75in;width:54px;height:54px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:700 24pt Georgia,serif;color:#2a1d10;background:radial-gradient(circle at 35% 30%,#fff2c4,#e0b24a 55%,#a9802a);border:1.5px solid #8a6420}';
function certHTML(name,g,f,d){var w=W(g),idx=WS_GROUPS[f][d],mods=idx.map(function(i){return w.modules[i];}),words=[],E=P().esc;mods.forEach(function(m){m.vocab.forEach(function(v){if(words.indexOf(v[0])<0)words.push(v[0]);});});var sch=school();
  return '<div class="c"><div class="logo" aria-hidden="true">$</div><div class="kk">'+E(sch?sch+' · ':'')+'Money Matters Workshops</div><div class="tt">Certificate of Achievement</div><div class="ss">'+E(FMT_NAME[f])+' · Day '+(d+1)+' of '+f+'</div><div class="nn">'+E(name||' ')+'</div>'
   +'<div class="dd">completed <b>'+E(dayTitle(g,f,d))+'</b> in the <b>'+E(w.title)+'</b> workshop for '+E(gradeName(g))+'.</div><div class="sk"><b>Real-world skills practiced:</b> '+E(mods.map(function(m){return m.realWorld.replace(/\.$/,'');}).join('; '))+'.<br><b>Money words:</b> '+E(words.join(', '))+'</div>'
   +'<div class="ff"><div>Date: '+E(new Date().toLocaleDateString())+'</div><div>Facilitator</div><div>Family member</div></div><div class="seal">DAY '+(d+1)+'<br>COMPLETE</div></div>';}
function printCerts(names,g,f,d){if(!names.length)return;P().open('Workshop certificates',names.map(function(n){return certHTML(n,g,f,d);}).join(''),{css:CERT_CSS});}
function printCheck(g,key){var w=W(g),items=checkItems(g),M=P(),E=M.esc;
  var h=M.head('Money Matters Workshops · '+gradeName(g)+' · '+(key?'Answer key':'Check-in / Check-out'),w.title+': Money Words Check',key?'Use the same 10 items before Day 1 and after the last day; record scores in Workshops.':'Circle the best meaning for each money word.',key?'<span class="badge key">Answer key</span>':'');
  if(!key)h+='<div class="namebar"><div>Name<i></i></div><div>Date<i></i></div><div>☐ Check-in &nbsp; ☐ Check-out<i></i></div><div>Score / '+items.length+'<i></i></div></div>';
  items.forEach(function(it,i){h+='<div class="q"><div class="no">'+(i+1)+'</div><div><b>'+E(it.q)+'</b><ol type="A" style="margin-top:4px">'+it.opts.map(function(o,k){return '<li'+(key&&k===it.answer?' class="ans"':'')+'>'+E(o)+'</li>';}).join('')+'</ol></div></div>';});
  if(key)h+=M.sec(0,'Scoring','<p>One point per item. Growth = check-out percent minus check-in percent. Enter paper scores under Workshops → Check-in, check-out and results.</p>');
  M.open((key?'Answer key':'Money words check')+' · '+w.title,h,{headerLeft:'Money Matters Workshops · '+w.title});}
function printResults(g){var w=W(g),r=roster(g),M=P(),E=M.esc,n=checkItems(g).length;
  var rows=r.map(function(x){var c=checksOf(x.id,g);return {x:x,c:c,d:modulesDone(x.id,g)};}),both=rows.filter(function(o){return o.c.pre&&o.c.post;}),avg=function(a){return a.length?Math.round(a.reduce(function(s,v){return s+v;},0)/a.length):null;};
  var aPre=avg(rows.filter(function(o){return o.c.pre;}).map(function(o){return pct(o.c.pre);})),aPost=avg(rows.filter(function(o){return o.c.post;}).map(function(o){return pct(o.c.post);})),aGr=avg(both.map(function(o){return pct(o.c.post)-pct(o.c.pre);}));
  var h=M.head('Money Matters Workshops · Results report',w.title,gradeName(g)+(school()?' · '+school():'')+' · prepared '+new Date().toLocaleDateString());
  h+='<div class="grid"><div class="stat"><b>'+r.length+'</b><span>Students</span></div><div class="stat"><b>'+(aPre==null?'—':aPre+'%')+'</b><span>Average check-in</span></div><div class="stat"><b>'+(aPost==null?'—':aPost+'%')+'</b><span>Average check-out</span></div><div class="stat"><b>'+(aGr==null?'—':(aGr>=0?'+':'')+aGr)+'</b><span>Average growth (points)</span></div></div>';
  h+=M.sec(1,'Student results','<table class="t"><thead><tr><th>Student</th><th>Themed days completed</th><th>Check-in</th><th>Check-out</th><th>Growth</th></tr></thead><tbody>'+rows.map(function(o){var gr=o.c.pre&&o.c.post?pct(o.c.post)-pct(o.c.pre):null;return '<tr><td><b>'+E(o.x.name)+'</b></td><td>'+o.d+' of 5</td><td>'+(o.c.pre?o.c.pre.s+'/'+n+' ('+pct(o.c.pre)+'%)':'—')+'</td><td>'+(o.c.post?o.c.post.s+'/'+n+' ('+pct(o.c.post)+'%)':'—')+'</td><td>'+(gr==null?'—':'<b>'+(gr>=0?'+':'')+gr+'</b>')+'</td></tr>';}).join('')+'</tbody></table>');
  h+=M.sec(2,'About these measures','<p class="small">The check-in and check-out use the same 10 vocabulary items drawn from this workshop, so the difference reflects learning during the workshop. Small groups and single short checks are noisy; use them alongside observation and student work.</p>');
  M.open('Workshop results · '+w.title,h,{headerLeft:'Money Matters Workshops · Results'});}

/* ---------- events ---------- */
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#workshopsBody [data-ws]');if(!b||b.disabled)return;var a=b.getAttribute('data-ws'),g=grade(),f=fmtOf(g),s=st();
  if(a==='grade'){try{setGrade(b.getAttribute('data-g'));}catch(x){try{currentGrade=b.getAttribute('data-g');}catch(y){}}view.day=0;render();return;}
  if(a==='fmt'){if(!isStaff()||sampleOn())return;s.fmt[g]=+b.getAttribute('data-n');put(s);view.day=0;render();return;}
  if(a==='day'){view.day=+b.getAttribute('data-d');render();var t=$('workshopsBody').querySelector('.ws-dayhead');if(t)t.scrollIntoView({block:'start',behavior:'smooth'});return;}
  if(a==='game'){if(window.MMGameShow)window.MMGameShow.open(b.getAttribute('data-m'),{grade:g});return;}
  if(a==='guide')return printGuide(g,f);
  if(a==='passport')return printPassport(g,f);
  if(a==='cert-one'){var n=($('ws-cname')||{}).value||'';if(!n.trim()){var i=$('ws-cname');if(i)i.focus();toast('Type the student’s name first.');return;}printCerts([n.trim()],g,f,view.day);return;}
  if(a==='cert-me'){var au=auth();printCerts([au&&au.name||''],g,f,view.day);return;}
  if(a==='all-done'){var k=dkey(g,f,view.day),now=Date.now();roster(g).forEach(function(x){s.done[x.id]=s.done[x.id]||{};s.done[x.id][k]=s.done[x.id][k]||now;});put(s);render();return;}
  if(a==='cert-class'){var k2=dkey(g,f,view.day);printCerts(roster(g).filter(function(x){return s.done[x.id]&&s.done[x.id][k2];}).map(function(x){return x.name;}),g,f,view.day);return;}});
document.addEventListener('change',function(e){var el=e.target;if(!el.closest||!el.closest('#workshopsBody'))return;var s=st();
  if(el.getAttribute('data-ws-ch')==='start'){s.start=el.value;put(s);render();var f1=document.querySelector('#workshopsBody [data-ws-ch=start]');if(f1)f1.focus();return;}
  var id=el.getAttribute('data-ws-done');if(id){var g=grade(),k=dkey(g,fmtOf(g),view.day);s.done[id]=s.done[id]||{};if(el.checked)s.done[id][k]=Date.now();else delete s.done[id][k];put(s);render();var f2=document.querySelector('#workshopsBody [data-ws-done="'+id.replace(/"/g,'')+'"]');if(f2)f2.focus();}});
/* ---------- measurement: check-in (before) and check-out (after) ----------
   The same 10 vocabulary items, in the same order, before and after the workshop, so growth
   is a fair comparison. Items are built from the grade's workshop vocabulary with a fixed seed.
   Stored in mmWorkshop_v1.checks[studentId][grade] = {pre:{s,n,t,via}, post:{…}}. */
function seeded(str){var h=1779033703^str.length;for(var i=0;i<str.length;i++){h=Math.imul(h^str.charCodeAt(i),3432918353);h=h<<13|h>>>19;}return function(){h=Math.imul(h^h>>>16,2246822507);h=Math.imul(h^h>>>13,3266489909);h^=h>>>16;return (h>>>0)/4294967296;};}
function sshuffle(a,r){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(r()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;}
function checkItems(g){var w=W(g),r=seeded('mm-check|'+g),pool=[],seen={};w.modules.forEach(function(m,mi){m.vocab.forEach(function(v){var k=String(v[0]).toLowerCase();if(seen[k])return;seen[k]=1;pool.push({t:v[0],d:v[1],m:mi});});});
  var items=[];[0,1,2,3,4].forEach(function(mi){sshuffle(pool.filter(function(x){return x.m===mi;}),r).slice(0,2).forEach(function(x){items.push(x);});});
  return items.map(function(x){var wrong=sshuffle(pool.filter(function(y){return y.t!==x.t;}),r).slice(0,3).map(function(y){return y.d;}),opts=sshuffle([x.d].concat(wrong),r);return {q:'What does “'+x.t+'” mean?',term:x.t,opts:opts,answer:opts.indexOf(x.d),m:x.m};});}
function checksOf(sid,g){var s=st();return (s.checks&&s.checks[sid]&&s.checks[sid][g])||{};}
function putCheck(sid,g,kind,val){var s=st();s.checks=s.checks||{};s.checks[sid]=s.checks[sid]||{};s.checks[sid][g]=s.checks[sid][g]||{};if(val==null)delete s.checks[sid][g][kind];else s.checks[sid][g][kind]=val;put(s);}
function pct(c){return c&&c.n?Math.round(c.s/c.n*100):null;}
function modulesDone(sid,g){var s=st(),d=(s.done&&s.done[sid])||{},m={};Object.keys(d).forEach(function(k){var x=/^([^|]+)\|m([\d-]+)$/.exec(k);if(x&&x[1]===g)x[2].split('-').forEach(function(i){m[i]=1;});});return Object.keys(m).length;}
function studentChecks(g){var a=auth(),sid=a&&a.id,c=checksOf(sid,g),items=checkItems(g);
  if(view.quiz){var q=view.quiz;return '<section class="ws-quiz" aria-labelledby="ws-qh"><h3 id="ws-qh">'+(q.kind==='pre'?'Check-in':'Check-out')+' · '+items.length+' questions</h3><p class="ws-note">Choose the best meaning for each money word. '+(q.kind==='pre'?'It’s fine not to know them yet. This shows how much you learn.':'Show what you learned!')+'</p><ol class="ws-qlist">'
    +items.map(function(it,i){return '<li><fieldset><legend>'+esc(it.q)+'</legend>'+it.opts.map(function(o,k){return '<label><input type="radio" name="wsq'+i+'" value="'+k+'"> '+esc(o)+'</label>';}).join('')+'</fieldset></li>';}).join('')+'</ol><div class="ws-row"><button type="button" class="ws-btn" data-ws="q-submit">Submit</button><button type="button" class="ws-btn ghost" data-ws="q-cancel">Cancel</button></div><p class="ws-note" id="ws-qmsg" role="alert"></p></section>';}
  var card=function(kind,title,when){var r=c[kind];return '<div class="ws-card"><div class="ws-k">'+title+'</div>'+(r?'<p class="ws-score">'+r.s+' / '+r.n+' <span>('+pct(r)+'%)</span></p><p class="ws-note">Taken '+esc(new Date(r.t).toLocaleDateString())+'</p>':'<p>'+when+'</p><button type="button" class="ws-btn" data-ws="q-start" data-k="'+kind+'">Start the '+title.toLowerCase()+'</button>')+'</div>';};
  var growth=c.pre&&c.post?pct(c.post)-pct(c.pre):null;
  return '<div class="ws-grid2">'+card('pre','Check-in','Take this before Day 1. It takes about 5 minutes.')+card('post','Check-out','Take this after the last day of the workshop.')
    +'<div class="ws-card ws-home"><div class="ws-k">My growth</div>'+(growth==null?'<p>Your growth appears after both checks.</p>':'<p class="ws-score">'+(growth>=0?'+':'')+growth+' points</p><p class="ws-note">From '+pct(c.pre)+'% to '+pct(c.post)+'%.</p>')+'<p class="ws-note">Themed days completed: '+modulesDone(sid,g)+' of 5</p></div></div>';}
function resultsHTML(g){var r=roster(g),items=checkItems(g),rows=r.map(function(x){var c=checksOf(x.id,g);return {x:x,pre:c.pre,post:c.post,days:modulesDone(x.id,g)};}),both=rows.filter(function(o){return o.pre&&o.post;});
  var avg=function(a){return a.length?Math.round(a.reduce(function(s,v){return s+v;},0)/a.length):null;},aPre=avg(rows.filter(function(o){return o.pre;}).map(function(o){return pct(o.pre);})),aPost=avg(rows.filter(function(o){return o.post;}).map(function(o){return pct(o.post);})),aGr=avg(both.map(function(o){return pct(o.post)-pct(o.pre);})),grew=both.filter(function(o){return pct(o.post)>pct(o.pre);}).length;
  var h='<div class="ws-stats"><div><b>'+(aPre==null?'—':aPre+'%')+'</b><span>Average check-in</span></div><div><b>'+(aPost==null?'—':aPost+'%')+'</b><span>Average check-out</span></div><div><b>'+(aGr==null?'—':(aGr>=0?'+':'')+aGr)+'</b><span>Average growth (points)</span></div><div><b>'+(both.length?grew+' of '+both.length:'—')+'</b><span>Students who improved</span></div></div>';
  h+='<div class="ws-tools"><button type="button" class="ws-btn ghost" data-ws="p-check">Print paper check (student copy)</button><button type="button" class="ws-btn ghost" data-ws="p-key">Print answer key</button><span class="ws-sp"></span><button type="button" class="ws-btn ghost" data-ws="p-results"'+(r.length?'':' disabled')+'>Print results report</button><button type="button" class="ws-btn" data-ws="csv"'+(r.length?'':' disabled')+'>Download results (CSV)</button></div>';
  if(!r.length)return h+'<p class="ws-note">Add students to '+esc(gradeName(g))+' to track check-ins, check-outs and completed days.</p>';
  h+='<p class="ws-note">Students take the checks on their own device under Workshops, or on paper. For paper checks, type the score out of '+items.length+'.</p><div class="ws-tablewrap"><table class="ws-table"><thead><tr><th scope="col">Student</th><th scope="col">Days completed</th><th scope="col">Check-in</th><th scope="col">Check-out</th><th scope="col">Growth</th></tr></thead><tbody>'
    +rows.map(function(o){var cell=function(kind,c){return '<td>'+(c?'<span class="ws-pill">'+c.s+'/'+c.n+' · '+pct(c)+'%</span> <button type="button" class="ws-mini" data-ws="clr" data-sid="'+esc(o.x.id)+'" data-k="'+kind+'" aria-label="Clear '+kind+' score for '+esc(o.x.name)+'">×</button>':'<input type="number" min="0" max="'+items.length+'" class="ws-score-in" data-ws-score="'+esc(o.x.id)+'|'+kind+'" aria-label="'+(kind==='pre'?'Check-in':'Check-out')+' score for '+esc(o.x.name)+' (out of '+items.length+')" placeholder="/'+items.length+'">')+'</td>';};
      var gr=o.pre&&o.post?pct(o.post)-pct(o.pre):null;return '<tr><th scope="row">'+esc(o.x.name)+'</th><td>'+o.days+' of 5</td>'+cell('pre',o.pre)+cell('post',o.post)+'<td>'+(gr==null?'—':'<b class="'+(gr>0?'ws-up':gr<0?'ws-down':'')+'">'+(gr>=0?'+':'')+gr+'</b>')+'</td></tr>';}).join('')+'</tbody></table></div>';
  return h;}
function csv(g){var r=roster(g),lines=[['Student','Grade','Themed days completed (of 5)','Check-in score','Check-in %','Check-out score','Check-out %','Growth (points)']];
  r.forEach(function(x){var c=checksOf(x.id,g);lines.push([x.name,gradeName(g),modulesDone(x.id,g),c.pre?c.pre.s+'/'+c.pre.n:'',c.pre?pct(c.pre):'',c.post?c.post.s+'/'+c.post.n:'',c.post?pct(c.post):'',c.pre&&c.post?pct(c.post)-pct(c.pre):'']);});
  var txt=lines.map(function(l){return l.map(function(v){v=String(v);return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}).join(',');}).join('\r\n');
  try{var b=new Blob(['\ufeff'+txt],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='MoneyMatters_Workshop_'+gradeName(g).replace(/\s+/g,'')+'_results.csv';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){toast('Download is not available in this browser.');}}
/* all grades, for the admin/teacher Reports tab */
function reportHTML(){if(W('K')&&W('K').locked)return '<p>Workshops are included with a subscription. Enter a school access code in Settings to unlock them.</p>';var rows=[];['K','1','2','3','4','5','6','7','8'].forEach(function(g){roster(g).forEach(function(x){var c=checksOf(x.id,g),d=modulesDone(x.id,g);if(c.pre||c.post||d)rows.push({x:x,g:g,c:c,d:d});});});
  if(!rows.length)return '<div class="mm-empty"><div style="font-size:30px">🎓</div><b>No workshop activity yet</b><p>Completed days and check-in/check-out scores appear here once a workshop runs.</p></div>';
  return '<div class="mm-table-wrap"><table class="mm-table"><thead><tr><th>Student</th><th>Grade</th><th>Workshop</th><th class="num">Days</th><th class="num">Check-in</th><th class="num">Check-out</th><th class="num">Growth</th></tr></thead><tbody>'+rows.map(function(o){var gr=o.c.pre&&o.c.post?pct(o.c.post)-pct(o.c.pre):null;return '<tr><td class="name">'+esc(o.x.name)+'</td><td>'+esc(gradeName(o.g))+'</td><td>'+esc(W(o.g).title)+'</td><td class="num">'+o.d+'/5</td><td class="num">'+(o.c.pre?pct(o.c.pre)+'%':'—')+'</td><td class="num">'+(o.c.post?pct(o.c.post)+'%':'—')+'</td><td class="num">'+(gr==null?'—':(gr>=0?'+':'')+gr)+'</td></tr>';}).join('')+'</tbody></table></div>';}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#workshopsBody [data-ws]');if(!b||b.disabled)return;var a=b.getAttribute('data-ws'),g=grade();
  if(a==='tab'){view.tab=b.getAttribute('data-t');view.quiz=null;render();var t=document.querySelector('#workshopsBody [data-ws=tab][aria-selected=true]');if(t)t.focus();return;}
  if(a==='q-start'){view.quiz={kind:b.getAttribute('data-k')};render();var f=document.querySelector('#workshopsBody .ws-quiz input');if(f)f.focus();return;}
  if(a==='q-cancel'){view.quiz=null;render();return;}
  if(a==='q-submit'){var items=checkItems(g),score=0,miss=0;items.forEach(function(it,i){var c=document.querySelector('#workshopsBody input[name="wsq'+i+'"]:checked');if(!c)miss++;else if(+c.value===it.answer)score++;});
    if(miss){var m=document.getElementById('ws-qmsg');if(m)m.textContent='Answer all '+items.length+' questions first ('+miss+' left).';return;}
    var au=auth();putCheck(au&&au.id,g,view.quiz.kind,{s:score,n:items.length,t:Date.now(),via:'app'});view.quiz=null;render();toast('Saved: '+score+' of '+items.length+'.');return;}
  if(a==='clr'){putCheck(b.getAttribute('data-sid'),g,b.getAttribute('data-k'),null);render();return;}
  if(a==='csv')return csv(g);
  if(a==='p-check')return printCheck(g,false);
  if(a==='p-key')return printCheck(g,true);
  if(a==='p-results')return printResults(g);});
document.addEventListener('change',function(e){var el=e.target;if(!el.closest||!el.closest('#workshopsBody'))return;var k=el.getAttribute('data-ws-score');if(!k)return;var p=k.split('|'),g=grade(),n=checkItems(g).length,v=Math.round(+el.value);if(!(v>=0&&v<=n)){el.value='';return;}putCheck(p[0],g,p[1],{s:v,n:n,t:Date.now(),via:'paper'});render();});
window.MMWorkshops={render:render,reportHTML:reportHTML,checkItems:checkItems,open:function(){try{openPanel('workshops');}catch(e){}}};
try{if(typeof _panelRenderers!=='undefined')_panelRenderers.workshops=render;}catch(e){}
})();
