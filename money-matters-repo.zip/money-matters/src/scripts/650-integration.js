/* =====================================================================
   V18 · INTEGRATION
   Wires the Game Show and Workshops into the classroom shell:
   dock navigation, the teacher's classroom home cards, and the
   first-run tour. Loaded after every earlier layer.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;var S=MM.shell,A=MM.auth;
/* dock: Workshops sits next to Games in the Learn group */
if(S&&S.navGroups&&!S.navGroups.__v18){var on=S.navGroups;S.navGroups=function(){var g=on.apply(this,arguments);try{var learn=g[0];if(learn&&!learn.items.some(function(x){return /workshops/.test(x[2]);}))learn.items.push(['🎓','Workshops',"openPanel('workshops')"]);}catch(e){}return g;};S.navGroups.__v18=1;}
/* teacher home: the fourth card launches the class activities */
if(S&&S.homeCards&&!S.homeCards.__v18){var oh=S.homeCards;S.homeCards=function(){var c=oh.apply(this,arguments)||[];try{var a=A.get();if(a&&!a.sample&&A.roleKey()!=='student'&&!A.isAdmin()&&c.length){c[c.length-1]={k:'🎲 Class activities',v:'Game Show and Workshops',s:'Play a class game show or run a 1–5 day workshop.',a:'<button class="mm-btn sm primary" onclick="MMGameShow.open()">Game Show</button><button class="mm-btn sm secondary" onclick="openPanel(\'workshops\')">Workshops</button>'};}}catch(e){}return c;};S.homeCards.__v18=1;}
/* rebuild the dock once so the new entry appears */
function refresh(){try{buildNav();}catch(e){}try{S.topbar&&S.topbar();}catch(e){}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(refresh,1600);});else setTimeout(refresh,400);
})();
