/* ---------- Game Show content banks (by grade band: k2 = K–2, 35 = 3–5, 68 = 6–8) ----------
   Quiz Rush, Money Board, Cash or Case and Daily 5 draw from each grade's own lesson quizzes
   and checkpoint tests. The banks below add statements, clue sets, ordering sets and
   word-problem generators written for financial literacy. */
var GS_TF={
k2:[
["Coins and bills are both kinds of money.",1,"Coins and bills are both money we can use to buy things."],
["A dime is worth more than a nickel.",1,"A dime is 10 cents. A nickel is 5 cents."],
["A nickel is worth more than a dime because it is bigger.",0,"Size does not tell value. A dime (10¢) is worth more than a nickel (5¢)."],
["A quarter is worth 25 cents.",1,"Four quarters make one dollar: 25 + 25 + 25 + 25 = 100 cents."],
["A need is something you must have to live, like food.",1,"Needs are things like food, water, clothes, and a home."],
["A video game is a need.",0,"It is a want: nice to have, but you can live without it."],
["Saving means keeping money to use later.",1,"When you save, you put money away for a goal."],
["Four quarters make one dollar.",1,"25¢ × 4 = 100¢, and 100¢ is one dollar."],
["A penny is worth 10 cents.",0,"A penny is worth 1 cent. A dime is worth 10 cents."],
["When you buy something, you trade money for it.",1,"Buying is a trade: your money for the item."],
["Once you spend your money, you can spend that same money again.",0,"Spent money is gone. Saving some helps you later."],
["People earn money by working at jobs.",1,"Work earns money called pay or income."],
["Giving money or things to help others is called donating.",1,"Donating and sharing help people in your community."],
["Ten dimes make one dollar.",1,"10¢ × 10 = 100¢, which is one dollar."],
["A bank keeps money safe for people.",1,"Banks keep money safe and let you take it out when you need it."],
["You should always buy the first thing you see.",0,"Comparing choices first helps you spend wisely."],
["Two nickels are worth the same as one dime.",1,"5¢ + 5¢ = 10¢, the same as a dime."],
["A goal is something you plan and work toward.",1,"A savings goal could be a book, a toy, or a gift."],
["Money grows on trees.",0,"People earn money by working. It does not grow on trees!"],
["Change is the money you get back when you pay more than the price.",1,"Pay $1 for a 75¢ snack and you get 25¢ in change."],
["A five-dollar bill is worth more than a one-dollar bill.",1,"$5 is five times as much as $1."],
["A want is something you must have to stay alive.",0,"That is a need. A want is something nice to have."]
],
"35":[
["A budget is a plan for how to spend and save money.",1,"A budget helps you make sure you do not spend more than you have."],
["Interest is money a bank pays you for keeping savings there.",1,"Savers earn interest. Borrowers pay interest."],
["Sales tax is added to the price of many things you buy.",1,"Sales tax helps pay for things like roads and schools."],
["Opportunity cost is the next-best choice you give up.",1,"Every choice has a trade-off: what you did not pick."],
["A debit card spends money that you borrowed.",0,"A debit card takes money from your own bank account. A credit card borrows."],
["A credit card lets you borrow money that you must pay back.",1,"If you do not pay the full bill, interest is added."],
["Income is the money you spend.",0,"Income is money you receive. Expenses are what you spend."],
["Comparing unit prices can help you find the better deal.",1,"Unit price is the cost for one item or one ounce."],
["A deposit is money you take out of the bank.",0,"That is a withdrawal. A deposit is money you put in."],
["An entrepreneur is someone who starts a business.",1,"Entrepreneurs take risks to turn an idea into a business."],
["Profit is the money left after a business pays its costs.",1,"Profit = money earned − costs."],
["Buying something on sale always saves you money.",0,"You only save if you needed it anyway."],
["Scarcity means people cannot have everything they want.",1,"Resources are limited, so we must make choices."],
["An emergency fund is savings for surprise expenses.",1,"A flat tire or broken glasses are good reasons to have one."],
["Advertisements are designed to make you want to buy things.",1,"Ads use music, colors, and stars to catch your attention."],
["Saving a little each week can add up over time.",1,"$5 a week for a year is $260."],
["Goods are things you can touch; services are work done for you.",1,"Shoes are goods. A haircut is a service."],
["Borrowing money is free as long as you pay it back.",0,"Lenders usually charge interest, so borrowing costs extra."],
["A check tells a bank to pay money from your account.",1,"Checks have a routing number and an account number."],
["Prices can rise when many people want something and there is not much of it.",1,"That is supply and demand."],
["A receipt is a coupon for your next purchase.",0,"A receipt is proof of what you bought and what you paid."],
["Gross pay is the amount you take home after taxes.",0,"That is net pay. Gross pay is before taxes and deductions."]
],
"68":[
["Compound interest earns interest on your interest.",1,"That is why money saved early can grow much faster."],
["A credit score helps lenders decide how risky it is to lend to you.",1,"Paying on time is the biggest factor in most scores."],
["Paying only the minimum on a credit card avoids all interest.",0,"Interest is charged on any balance you do not pay in full."],
["Diversification means spreading money across different investments.",1,"It lowers the risk that one bad investment hurts you badly."],
["Net pay is your pay after taxes and deductions.",1,"It is the amount actually deposited in your account."],
["Stocks always go up in value.",0,"Stock prices rise and fall. Investing involves risk."],
["Inflation means prices rise over time, so each dollar buys less.",1,"Inflation reduces the purchasing power of money."],
["The Rule of 72 estimates how many years it takes money to double.",1,"Divide 72 by the interest rate: at 6%, about 12 years."],
["A higher interest rate makes a loan cheaper.",0,"A higher rate means more interest, so the loan costs more."],
["FDIC insurance protects deposits up to $250,000 per depositor, per insured bank, per ownership category.",1,"FDIC insurance covers deposit accounts, not investments like stocks."],
["Identity theft is when someone uses your personal information without permission.",1,"Protect your Social Security number, passwords, and account numbers."],
["Checking your bank statement helps you spot mistakes and fraud.",1,"Review every transaction you do not recognize."],
["A W-4 tells your employer how much federal income tax to withhold.",1,"You fill it out when you start a new job."],
["Investing early gives your money more time to grow.",1,"Time lets compounding do more of the work."],
["A bond is a share of ownership in a company.",0,"A bond is a loan to a company or government. A stock is ownership."],
["Insurance helps protect you from large financial losses.",1,"You pay a premium so a big loss does not fall entirely on you."],
["Rent is usually a fixed expense.",1,"Fixed expenses stay about the same each month."],
["Buying a car with a loan costs more than the price once interest is added.",1,"The total cost is the price plus all the interest paid."],
["Real banks ask for your password by email or text.",0,"That is phishing. Banks do not ask for passwords that way."],
["Social Security and Medicare taxes are called FICA.",1,"Employees pay 6.2% for Social Security and 1.45% for Medicare."],
["An index fund holds many companies, which spreads out risk.",1,"Owning many companies is a simple way to diversify."],
["Your credit report lists your borrowing and payment history.",1,"You can check it for free and dispute errors."]
]};

var GS_WHO={
k2:[
{a:"Quarter",w:["Penny","Dime","Nickel"],c:["I am round and made of metal.","I have ridges around my edge.","Four of me make one dollar.","I am worth 25 cents."],f:"A quarter is the largest everyday U.S. coin."},
{a:"Penny",w:["Nickel","Dime","Quarter"],c:["I am a coin with Abraham Lincoln on the front.","I am the color of copper.","One hundred of me make a dollar.","I am worth 1 cent."],f:"A penny is worth the least of all U.S. coins. The U.S. stopped making new pennies in 2025, but old ones still work."},
{a:"Dime",w:["Penny","Nickel","Quarter"],c:["I am the smallest U.S. coin in size.","I have ridges around my edge.","Ten of me make a dollar.","I am worth 10 cents."],f:"Small but mighty: a dime is worth more than a bigger nickel."},
{a:"Nickel",w:["Penny","Dime","Quarter"],c:["I am a silver-colored coin with a smooth edge.","Thomas Jefferson is on my front.","Twenty of me make a dollar.","I am worth 5 cents."],f:"A nickel is worth 5 pennies."},
{a:"Bank",w:["Store","Library","Park"],c:["I am a building you can find in many towns.","People trust me with something valuable.","You can make deposits and withdrawals with me.","I keep your money safe."],f:"Banks keep money safe and help it grow."},
{a:"Need",w:["Want","Gift","Toy"],c:["Everyone has me.","Without me, you cannot stay healthy and safe.","Food, water and a home are examples of me.","I am something you must have to live."],f:"Take care of needs before wants."},
{a:"Want",w:["Need","Bill","Job"],c:["I am fun to dream about.","You can live without me.","Toys and candy are examples of me.","I am nice to have but not necessary."],f:"It is okay to have wants. Plan and save for them."},
{a:"Saving",w:["Spending","Borrowing","Trading"],c:["I take patience.","I help you buy bigger things later.","A piggy bank helps you do me.","I mean keeping money to use later."],f:"Saving a little at a time adds up."},
{a:"Job",w:["Gift","Want","Change"],c:["Many grown-ups go to me most days.","I help people earn money.","Teachers, doctors and bakers each have one.","I am the work you do to earn money."],f:"Jobs let people earn money and help others."},
{a:"Price",w:["Change","Savings","Goal"],c:["Stores put me on tags and signs.","I can go up or down.","I am a number with a dollar or cent sign.","I tell you how much something costs."],f:"Always check the price before you buy."},
{a:"Change",w:["Price","Gift","Savings"],c:["I come back to you at the store.","I happen when you pay more than you need to.","If a snack costs 75¢ and you pay $1, I am 25¢.","I am the money you get back after paying."],f:"Count your change to make sure it is right."},
{a:"Goal",w:["Want","Coin","Bill"],c:["I am in the future.","You make a plan to reach me.","Saving $10 for a book could be me.","I am something you work toward."],f:"Writing down a goal makes it easier to reach."},
{a:"Donating",w:["Spending","Saving","Borrowing"],c:["I make other people smile.","Food banks and shelters are glad to get me.","Some kids set aside part of their money for me.","I mean giving money or things to help others."],f:"Spend, save, and share: three good jobs for money."}
],
"35":[
{a:"Budget",w:["Receipt","Loan","Profit"],c:["I am a plan, not a store.","I list income and expenses.","I help you decide where every dollar goes.","I am a plan for spending and saving money."],f:"A budget helps you avoid spending more than you earn."},
{a:"Interest",w:["Tax","Profit","Allowance"],c:["Banks and borrowers both care about me.","I am often written as a percent.","Savers earn me; borrowers pay me.","I am the extra money paid for using money."],f:"5% interest on $100 for one year is $5."},
{a:"Sales tax",w:["Discount","Interest","Coupon"],c:["Governments collect me.","I help pay for roads, schools and parks.","I am added at the register.","I am a percent added to the price of things you buy."],f:"Sales tax rates are different from place to place."},
{a:"Opportunity cost",w:["Sales tax","Profit","Discount"],c:["Every choice has me.","You will not see me on a receipt.","I am what you give up.","I am the next-best choice you did not pick."],f:"Choosing soccer camp might mean giving up art class."},
{a:"Profit",w:["Price","Loan","Budget"],c:["Businesses hope to make me.","A lemonade stand can have me.","I am what is left after costs.","I equal money earned minus costs."],f:"Sell $30 of lemonade with $12 of costs: $18 profit."},
{a:"Entrepreneur",w:["Consumer","Employee","Banker"],c:["I take risks.","I have a business idea.","I might start small, like a dog-walking service.","I am a person who starts a business."],f:"Entrepreneurs create jobs and new products."},
{a:"Debit card",w:["Credit card","Coupon","Receipt"],c:["I am a small plastic card.","I am linked to a checking account.","When you use me, money leaves your account right away.","I let you pay with money you already have."],f:"Keep track of your balance when you use a debit card."},
{a:"Credit card",w:["Debit card","Coupon","Receipt"],c:["I am a small plastic card.","I am a loan in your wallet.","If you do not pay me off, interest adds up.","I let you buy now and pay later."],f:"Paying the full balance each month avoids interest."},
{a:"Emergency fund",w:["Allowance","Wish list","Paycheck"],c:["I am saved for surprises.","A flat tire might use me.","It is smart to build me before you need me.","I am savings for unexpected expenses."],f:"Even a small emergency fund helps."},
{a:"Receipt",w:["Coupon","Check","Budget"],c:["I am usually paper, or sometimes an email.","I prove what you bought.","You may need me to return an item.","I list what you paid and when."],f:"Check your receipt for mistakes before you leave."},
{a:"Coupon",w:["Receipt","Tax","Check"],c:["I can be paper or digital.","I might expire.","I lower the price of something.","I am a ticket for a discount."],f:"A coupon only saves money on things you planned to buy."},
{a:"Deposit",w:["Withdrawal","Loan","Expense"],c:["Banks are happy to get me.","I make your balance go up.","I am the opposite of a withdrawal.","I am money you put into an account."],f:"Deposits can be cash, checks, or direct deposits from a job."},
{a:"Scarcity",w:["Surplus","Profit","Interest"],c:["Economists talk about me a lot.","I am why we must make choices.","There is never enough of everything for everyone.","I mean limited resources and unlimited wants."],f:"Scarcity is the reason every choice has a trade-off."}
],
"68":[
{a:"Compound interest",w:["Simple interest","Inflation","Dividend"],c:["Time is my best friend.","I am often compared to a snowball.","The Rule of 72 estimates how fast I double money.","I am interest earned on your savings and on past interest."],f:"$1,000 at 6% compounded yearly is about $1,791 after 10 years."},
{a:"Credit score",w:["Interest rate","Account number","Credit limit"],c:["I am a three-digit number.","Lenders and landlords check me.","Paying bills on time raises me.","I rate how likely you are to repay borrowed money."],f:"Payment history is the biggest part of most credit scores."},
{a:"Inflation",w:["Deflation","Depreciation","Dividend"],c:["The Consumer Price Index measures me.","The Federal Reserve aims to keep me near 2% a year.","I make the same $20 buy fewer groceries over time.","I am the general rise in prices over time."],f:"Savings that earn less than inflation lose buying power."},
{a:"Stock",w:["Bond","Certificate of deposit","Savings account"],c:["I am traded on exchanges.","My price can change every second the market is open.","Owning me makes you a part-owner.","I am a share of ownership in a company."],f:"Stocks have higher risk and higher long-term growth potential."},
{a:"Bond",w:["Stock","Dividend","Credit card"],c:["Governments and companies issue me.","I usually pay a fixed amount of interest.","I am usually less risky than stocks.","I am a loan you make to a company or government."],f:"U.S. Treasury bonds are backed by the federal government."},
{a:"Diversification",w:["Speculation","Inflation","Compounding"],c:["I am a strategy, not a product.","Index funds make me easier.","I am the opposite of putting all your eggs in one basket.","I spread money across investments to reduce risk."],f:"Diversifying does not remove risk, but it lowers it."},
{a:"Net pay",w:["Gross pay","Salary","Bonus"],c:["I am smaller than gross pay.","Taxes and deductions come out before you get me.","I am what lands in your bank account.","I am your take-home pay."],f:"Budget with net pay, not gross pay."},
{a:"APR",w:["ATM","FDIC","IRA"],c:["I am three letters.","Credit card offers must show me.","I show the yearly cost of borrowing as a percent.","I stand for Annual Percentage Rate."],f:"A lower APR means borrowing costs less."},
{a:"Insurance",w:["Investment","Loan","Budget"],c:["I have premiums and deductibles.","You hope you never need me.","I can cover a car, a home or your health.","I protect you from big losses for a regular payment."],f:"The deductible is what you pay before insurance pays."},
{a:"FDIC",w:["IRS","SEC","APR"],c:["I was created in 1933.","I am an independent agency of the U.S. government.","Look for my sign at banks.","I insure bank deposits up to $250,000 per depositor, per bank, per ownership category."],f:"No depositor has lost a penny of FDIC-insured funds since 1934."},
{a:"Identity theft",w:["Inflation","Bankruptcy","Overdraft"],c:["I often start with a phishing message.","Shredding papers helps stop me.","Freezing your credit can block me.","I am when someone uses your personal information to commit fraud."],f:"Report it at IdentityTheft.gov."},
{a:"Overdraft",w:["Deposit","Dividend","Refund"],c:["Banks may charge a fee for me.","I happen in checking accounts.","Tracking your balance helps you avoid me.","I happen when you spend more than your account holds."],f:"Turning on balance alerts helps prevent overdrafts."},
{a:"Dividend",w:["Interest","Premium","Deductible"],c:["Not every company pays me.","I am often paid every three months.","Shareholders receive me.","I am a share of a company's profits paid to investors."],f:"Some investors reinvest dividends to buy more shares."},
{a:"Mortgage",w:["Lease","Insurance","Bond"],c:["I often last 15 or 30 years.","The house is the collateral for me.","A down payment usually comes first.","I am a loan used to buy a home."],f:"A bigger down payment means a smaller mortgage."},
{a:"401(k)",w:["W-2","Mortgage","Savings bond"],c:["I am named after a section of the tax code.","Employers sometimes match what you put in me.","I am built for the long term.","I am a retirement savings plan offered through work."],f:"An employer match is like a raise you only get if you save."}
]};

/* ordering sets: [card text, sort key, label shown on reveal] */
var GS_ORDER={
k2:[
{t:"Coins from least to most value",items:[["Penny",1,"1¢"],["Nickel",5,"5¢"],["Dime",10,"10¢"],["Quarter",25,"25¢"]]},
{t:"Bills from least to most value",items:[["One-dollar bill",1,"$1"],["Five-dollar bill",5,"$5"],["Ten-dollar bill",10,"$10"],["Twenty-dollar bill",20,"$20"]]},
{t:"Buying something at a store, first step first",items:[["Choose what you want",1,"Step 1"],["Check the price",2,"Step 2"],["Pay the cashier",3,"Step 3"],["Get your change and receipt",4,"Step 4"]]},
{t:"Saving for a toy, first step first",items:[["Pick a goal",1,"Step 1"],["Find out the price",2,"Step 2"],["Save a little each week",3,"Step 3"],["Buy it when you have enough",4,"Step 4"]]},
{t:"Amounts from smallest to largest",items:[["3 pennies",3,"3¢"],["1 nickel",5,"5¢"],["2 nickels",10,"10¢"],["1 quarter",25,"25¢"]]},
{t:"Amounts from smallest to largest",items:[["2 dimes",20,"20¢"],["1 quarter",25,"25¢"],["3 dimes",30,"30¢"],["2 quarters",50,"50¢"]]},
{t:"Running a lemonade stand, first step first",items:[["Plan what you will sell",1,"Step 1"],["Buy lemons and cups",2,"Step 2"],["Sell lemonade to customers",3,"Step 3"],["Count the money you made",4,"Step 4"]]}
],
"35":[
{t:"Making a budget, first step first",items:[["Write down your income",1,"Step 1"],["List your expenses",2,"Step 2"],["Subtract expenses from income",3,"Step 3"],["Adjust spending to save more",4,"Step 4"]]},
{t:"Amounts from smallest to largest",items:[["10% of $50",5,"$5"],["25% of $40",10,"$10"],["Half of $30",15,"$15"],["4 × $5",20,"$20"]]},
{t:"Amounts from smallest to largest",items:[["$0.75",75,"$0.75"],["4 quarters",100,"$1.00"],["$1.10",110,"$1.10"],["12 dimes",120,"$1.20"]]},
{t:"U.S. money history, earliest first",items:[["The U.S. Mint is created",1792,"1792"],["The federal government issues its first national paper money (Demand Notes)",1861,"1861"],["The Federal Reserve is created",1913,"1913"],["The first ATM opens in the U.S.",1969,"1969"]]},
{t:"Starting a business, first step first",items:[["Come up with a business idea",1,"Step 1"],["Figure out your costs",2,"Step 2"],["Sell your product",3,"Step 3"],["Subtract costs from sales to find profit",4,"Step 4"]]},
{t:"Lowest to highest price per pen",items:[["10 pens for $5",50,"50¢ each"],["4 pens for $3",75,"75¢ each"],["2 pens for $2",100,"$1.00 each"],["1 pen for $1.25",125,"$1.25 each"]]},
{t:"Saving for a bike, first step first",items:[["Find the price of the bike",1,"Step 1"],["Decide how much to save each week",2,"Step 2"],["Deposit your savings every week",3,"Step 3"],["Buy the bike when you reach your goal",4,"Step 4"]]}
],
"68":[
{t:"U.S. money milestones, earliest first",items:[["The U.S. Mint is created",1792,"1792"],["The Federal Reserve System is created",1913,"1913"],["The FDIC is created",1933,"1933"],["Social Security becomes law",1935,"1935"]]},
{t:"Modern money tools, earliest first",items:[["The first widely used charge card (Diners Club)",1950,"1950"],["The first ATM opens in the U.S.",1969,"1969"],["The 401(k) plan is created by law",1978,"1978"],["The Roth IRA is created",1997,"1997"]]},
{t:"Money through history, earliest first",items:[["Lydia mints some of the first coins",-600,"c. 600 BCE"],["China begins using paper money",1000,"c. 1000s"],["The U.S. Mint is created",1792,"1792"],["The first ATM opens in the U.S.",1969,"1969"]]},
{t:"From paycheck to budget, first step first",items:[["Earn gross pay",1,"Step 1"],["Taxes and deductions are withheld",2,"Step 2"],["Net pay is deposited",3,"Step 3"],["Spend and save using your budget",4,"Step 4"]]},
{t:"Lowest to highest interest earned in one year",items:[["$1,000 at 2%",20,"$20"],["$500 at 6%",30,"$30"],["$2,000 at 2.5%",50,"$50"],["$800 at 10%",80,"$80"]]},
{t:"Getting a first job, first step first",items:[["Find a job opening",1,"Step 1"],["Submit a résumé and application",2,"Step 2"],["Interview with the employer",3,"Step 3"],["Fill out a W-4 on your first day",4,"Step 4"]]},
{t:"Generally lowest to highest risk",items:[["Insured savings account",1,"Lowest"],["U.S. Treasury bond",2,"Low"],["Broad stock index fund",3,"Higher"],["One company's stock",4,"Highest"]]}
]};

/* word-problem generators for Closest Guess: return {q,a,u,x} (u: '$','¢','weeks','years') */
var GS_GUESS=(function(){
function ri(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function pick(a){return a[Math.floor(Math.random()*a.length)];}
function m(n){return '$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2});}
return {
k2:[
function(){var q=ri(0,3),d=ri(1,4),p=ri(0,5),a=q*25+d*10+p;return {q:'You have '+q+' quarter'+(q===1?'':'s')+', '+d+' dime'+(d===1?'':'s')+' and '+p+' penn'+(p===1?'y':'ies')+'. How many cents is that?',a:a,u:'¢',x:q+' × 25¢ + '+d+' × 10¢ + '+p+' × 1¢ = '+a+'¢'};},
function(){var h=ri(8,20),c=ri(2,h-1);return {q:'You have $'+h+'. You buy a book for $'+c+'. How many dollars are left?',a:h-c,u:'$',x:'$'+h+' − $'+c+' = $'+(h-c)};},
function(){var s=pick([1,2,3]),w=ri(3,8),p=s*w;return {q:'A toy costs $'+p+'. You save $'+s+' each week. How many weeks until you can buy it?',a:w,u:'weeks',x:'$'+p+' ÷ $'+s+' a week = '+w+' weeks'};},
function(){var c=pick([5,10]),n=ri(3,9);return {q:'Stickers cost '+c+'¢ each. How many cents for '+n+' stickers?',a:c*n,u:'¢',x:n+' × '+c+'¢ = '+(c*n)+'¢'};},
function(){var a=pick([15,20,25,30,35,40]),b=pick([10,15,20,25,30]);return {q:'A pencil costs '+a+'¢ and an eraser costs '+b+'¢. How many cents for both?',a:a+b,u:'¢',x:a+'¢ + '+b+'¢ = '+(a+b)+'¢'};},
function(){var p=pick([35,40,55,60,65,80,85,90]);return {q:'A snack costs '+p+'¢. You pay with $1 (100¢). How many cents of change do you get?',a:100-p,u:'¢',x:'100¢ − '+p+'¢ = '+(100-p)+'¢'};}
],
"35":[
function(){var s=ri(3,12),w=ri(4,15);return {q:'You save $'+s+' every week for '+w+' weeks. How much do you save in all?',a:s*w,u:'$',x:'$'+s+' × '+w+' = '+m(s*w)};},
function(){var p=pick([20,30,40,50,60,80,100,120]),r=pick([10,20,25,50]),a=p*(100-r)/100;return {q:'A $'+p+' jacket is '+r+'% off. What is the sale price?',a:a,u:'$',x:r+'% of $'+p+' is '+m(p*r/100)+', so $'+p+' − '+m(p*r/100)+' = '+m(a)};},
function(){var p=pick([25,50,75,100]),r=8,a=p*1.08;return {q:'A $'+p+' game has 8% sales tax added. What is the total cost?',a:Math.round(a*100)/100,u:'$',x:'8% of $'+p+' is '+m(p*.08)+', so the total is '+m(a)};},
function(){var inc=ri(16,40)*5,e1=ri(4,12)*5,e2=ri(2,6)*5,e3=ri(1,4)*5;if(e1+e2+e3>=inc)inc=e1+e2+e3+ri(2,8)*5;return {q:'You earn $'+inc+' this month. You spend $'+e1+' on food, $'+e2+' on fun and $'+e3+' on a gift. How much is left to save?',a:inc-e1-e2-e3,u:'$',x:'$'+inc+' − $'+e1+' − $'+e2+' − $'+e3+' = '+m(inc-e1-e2-e3)};},
function(){var n=pick([4,5,6,8,10,12]),e=pick([25,30,40,50,60,75]),p=n*e/100;return {q:'A pack of '+n+' juice boxes costs '+m(p)+'. How many cents is each juice box?',a:e,u:'¢',x:m(p)+' ÷ '+n+' = '+e+'¢ each'};},
function(){var p=pick([100,200,300,400,500]),r=pick([2,3,4,5]);return {q:'You keep $'+p+' in a savings account that pays '+r+'% interest a year. How much interest do you earn in one year?',a:p*r/100,u:'$',x:r+'% of $'+p+' = '+m(p*r/100)};},
function(){var w=pick([10,12,15]),h=ri(3,8);return {q:'You earn $'+w+' an hour walking dogs and work '+h+' hours. How much do you earn?',a:w*h,u:'$',x:'$'+w+' × '+h+' hours = '+m(w*h)};}
],
"68":[
function(){var P=ri(1,10)*500,r=pick([2,3,4,5,6]),t=ri(2,5),I=P*r*t/100;return {q:'You invest $'+P.toLocaleString()+' at '+r+'% simple interest for '+t+' years. How much interest do you earn?',a:I,u:'$',x:'I = P × r × t = $'+P.toLocaleString()+' × '+(r/100)+' × '+t+' = '+m(I)};},
function(){var P=pick([1000,2000,5000]),r=pick([4,5,6,8,10]),t=pick([2,3]),A=Math.round(P*Math.pow(1+r/100,t));return {q:'$'+P.toLocaleString()+' earns '+r+'% interest compounded yearly for '+t+' years. About what is the ending balance, to the nearest dollar?',a:A,u:'$',x:'$'+P.toLocaleString()+' × '+(1+r/100)+'^'+t+' ≈ '+m(A)};},
function(){var r=pick([3,4,6,8,9,12]);return {q:'Using the Rule of 72, about how many years does it take money to double at '+r+'% a year?',a:72/r,u:'years',x:'72 ÷ '+r+' = '+(72/r)+' years'};},
function(){var g=ri(12,30)*50,w=pick([15,18,20,22,25]),n=g*(100-w)/100;return {q:'Your gross pay is $'+g.toLocaleString()+'. '+w+'% is withheld for taxes and deductions. What is your net pay?',a:n,u:'$',x:'$'+g.toLocaleString()+' × '+((100-w)/100)+' = '+m(n)};},
function(){var b=ri(4,20)*100,r=pick([15,18,20,24]);return {q:'A $'+b.toLocaleString()+' credit card balance at '+r+'% APR stays unpaid for a year. Using simple interest, about how much interest is that?',a:b*r/100,u:'$',x:'$'+b.toLocaleString()+' × '+(r/100)+' = '+m(b*r/100)};},
function(){var inc=ri(8,20)*250;return {q:'With the 50/30/20 rule, how much of a $'+inc.toLocaleString()+' monthly take-home pay goes to savings?',a:inc*.2,u:'$',x:'20% of $'+inc.toLocaleString()+' = '+m(inc*.2)};},
function(){var g=ri(20,60)*50;return {q:'How much FICA tax (6.2% Social Security + 1.45% Medicare) comes out of a $'+g.toLocaleString()+' paycheck?',a:Math.round(g*7.65)/100,u:'$',x:'7.65% of $'+g.toLocaleString()+' = '+m(Math.round(g*7.65)/100)};}
]};})();

/* =====================================================================
   MONEY GAME SHOW  ·  window.MMGameShow
   A classroom game show adapted from Japarty for financial literacy.
   One shared screen (projector, laptop, tablet or phone) for 1–8
   players or teams. Questions come from the active grade's own lesson
   quizzes, checkpoint tests and vocabulary, plus the banks above.
     Modes  Quiz Rush · Money Board (Daily Double, Final Wager) ·
            True or False Blitz · Put It in Order · Cash or Case ·
            What Am I? · Closest Guess · Money Crossword · Daily 5
     Public MMGameShow.open(modeId?, {grade}) · MMGameShow.close()
     Store  mmGSPrefs_v1 · mmGSHistory_v1 · mmGSDaily_v1 · mmGSSeen_v1
   ===================================================================== */
(function(){
'use strict';
/* ---------- helpers ---------- */
var ROOT=null;
function $(id){return document.getElementById(id);}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function shuffle(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;}
function money(n){n=Number(n)||0;var neg=n<0,v=Math.abs(n),d=Math.abs(v-Math.round(v))>0.001;return (neg?'−':'')+'$'+v.toLocaleString('en-US',{minimumFractionDigits:d?2:0,maximumFractionDigits:d?2:0});}
function load(k,def){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?def:v;}catch(e){return def;}}
function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function reduced(){try{return matchMedia('(prefers-reduced-motion: reduce)').matches;}catch(e){return false;}}
function say(t){var l=$('gs-live');if(l){l.textContent='';setTimeout(function(){l.textContent=t;},30);}}
function todayKey(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function seedRng(str){var h=1779033703^str.length;for(var i=0;i<str.length;i++){h=Math.imul(h^str.charCodeAt(i),3432918353);h=h<<13|h>>>19;}
  return function(){h=Math.imul(h^h>>>16,2246822507);h=Math.imul(h^h>>>13,3266489909);h^=h>>>16;return (h>>>0)/4294967296;};}

/* ---------- app context ---------- */
function MM(){return window.MM91||{};}
function authObj(){try{return MM().auth.get();}catch(e){return null;}}
function roleKey(){try{return MM().auth.roleKey();}catch(e){var a=authObj();return a&&a.role==='student'?'student':(a?'teacher':'guest');}}
function isStudent(){return roleKey()==='student';}
function isStaff(){var a=authObj();return !!a&&roleKey()!=='student';}
function sampleOn(){try{return !!(MM().sample&&MM().sample.active());}catch(e){return false;}}
function appGrade(){try{if(sampleOn()&&MM().sample.grade)return MM().sample.grade()||currentGrade||'K';}catch(e){}try{return currentGrade||'K';}catch(e){return 'K';}}
var GRADES=['K','1','2','3','4','5','6','7','8'];
function gradeName(g){try{if(typeof GRADE_LABEL!=='undefined'&&GRADE_LABEL[g])return GRADE_LABEL[g];}catch(e){}return g==='K'?'Kindergarten':'Grade '+g;}
function band(g){return (g==='K'||g==='1'||g==='2')?'k2':(g==='3'||g==='4'||g==='5')?'35':'68';}
function lang(){try{return loadLang()||'en';}catch(e){return 'en';}}
function localized(base,locName,g){var l=lang();
  try{if(l!=='en'){var src=locName==='LESSON_QUIZ_L'?(typeof LESSON_QUIZ_L!=='undefined'?LESSON_QUIZ_L:null):locName==='SECTION_TESTS_L'?(typeof SECTION_TESTS_L!=='undefined'?SECTION_TESTS_L:null):(typeof LESSONS_L!=='undefined'?LESSONS_L:null);if(src&&src[l]&&src[l][g]&&src[l][g].length)return src[l][g];}}catch(e){}
  return (base&&base[g])||[];}
function quizWeeks(g){return localized(typeof LESSON_QUIZ!=='undefined'?LESSON_QUIZ:null,'LESSON_QUIZ_L',g);}
function testsFor(g){return localized(typeof SECTION_TESTS!=='undefined'?SECTION_TESTS:null,'SECTION_TESTS_L',g);}
function lessonsFor(g){return localized(typeof LESSONS!=='undefined'?LESSONS:null,'LESSONS_L',g);}
function maxWeek(){return sampleOn()?6:99;}
function unitName(g,u){var t=testsFor(g)[u],s=t&&t.title?String(t.title).replace(/^[^:]*:\s*/,''):'';return s||('Unit '+(u+1));}
function lessonTitle(g,wk){var l=lessonsFor(g).filter(function(x){return +x.week===+wk;})[0];return l?l.title:'Week '+wk;}
var POOL_CACHE={};
function pool(g){var key=g+'|'+lang()+'|'+maxWeek();if(POOL_CACHE[key])return POOL_CACHE[key];var out=[];
  quizWeeks(g).forEach(function(w){var wk=+w.week||0;if(wk>maxWeek())return;var u=Math.min(5,Math.floor((wk-1)/6));
    (w.questions||[]).forEach(function(q){if(!q||!q.q||!Array.isArray(q.options)||q.options.length<2)return;var a=+q.answer;if(!(a>=0&&a<q.options.length))return;
      out.push({q:q.q,options:q.options,answer:a,fact:q.explain||'',unit:u,week:wk,cat:sampleOn()?lessonTitle(g,wk):unitName(g,u)});});});
  return (POOL_CACHE[key]=out);}
function testPool(g){var out=[];testsFor(g).forEach(function(t,u){if(sampleOn()&&u>0)return;(t.questions||[]).forEach(function(q){if(q&&q.q&&Array.isArray(q.options)&&q.options[q.answer]!=null)out.push({q:q.q,options:q.options,answer:+q.answer,fact:q.explain||'',unit:u,cat:unitName(g,u)});});});return out.length?out:pool(g);}
var KEEP_ORDER=/^(all|none|both)\b|of the above/i;
function toItem(p){var keep=p.options.some(function(o){return KEEP_ORDER.test(String(o));});var idx=p.options.map(function(_,i){return i;});if(!keep)idx=shuffle(idx);
  return {cat:p.cat,q:p.q,opts:idx.map(function(i){return p.options[i];}),correct:idx.indexOf(p.answer),fact:p.fact,unit:p.unit,week:p.week};}
/* avoid repeats across games */
function seenKey(){return 'mmGSSeen_v1';}
function pickFresh(list,n,keyFn){var seen=load(seenKey(),[]),set={};seen.forEach(function(k){set[k]=1;});
  var a=shuffle(list.filter(function(x){return !set[keyFn(x)];})),b=shuffle(list.filter(function(x){return set[keyFn(x)];})),out=a.concat(b).slice(0,n);
  out.forEach(function(x){seen.push(keyFn(x));});if(seen.length>600)seen=seen.slice(-600);save(seenKey(),seen);return out;}

/* ---------- sound (synthesized, no files) ---------- */
var AC=null;
function ac(){if(!prefs.sfx)return null;try{if(!AC){var C=window.AudioContext||window.webkitAudioContext;if(!C)return null;AC=new C();}if(AC.state==='suspended')AC.resume();return AC;}catch(e){return null;}}
function tone(hz,t,d,type,vol){var c=ac();if(!c)return;var o=c.createOscillator(),g=c.createGain();o.type=type||'triangle';o.frequency.value=hz;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol||.12,t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+d+.05);}
function sfx(n){var c=ac();if(!c)return;var t=c.currentTime+.01;
  if(n==='tick')tone(1600,t,.05,'square',.03);
  else if(n==='lock'){tone(660,t,.08);tone(990,t+.06,.12);}
  else if(n==='select')tone(880,t,.07,'triangle',.08);
  else if(n==='correct')[523,659,784,1047].forEach(function(f,i){tone(f,t+i*.07,.35);});
  else if(n==='wrong'){tone(240,t,.35,'sawtooth',.06);tone(180,t+.18,.45,'sawtooth',.06);}
  else if(n==='whoosh')tone(420,t,.25,'sine',.05);
  else if(n==='timesup'){tone(440,t,.22,'square',.05);tone(330,t+.24,.4,'square',.05);}
  else if(n==='ring')for(var k=0;k<2;k++)for(var j=0;j<8;j++)tone(j%2?620:480,t+k*.8+j*.05,.05,'sine',.07);
  else if(n==='dd')[262,330,392,523,659,784].forEach(function(f,i){tone(f,t+i*.06,.3);});
  else if(n==='fanfare'){[[523,0],[659,.13],[784,.26],[1047,.42]].forEach(function(x){tone(x[0],t+x[1],.4,'sawtooth',.05);tone(x[0]/2,t+x[1],.4,'triangle',.06);});[1047,1319,1568].forEach(function(f){tone(f,t+.62,1.2,'triangle',.05);});}}

/* ---------- state ---------- */
var COLORS=['#2f7dd1','#e0b24a','#2f9e6b','#d0603f','#8a5cc7','#1aa3a3','#d6649a','#8796a6'];
var TEAM_NAMES=['Savers','Investors','Budgeters','Earners','Planners','Bankers','Traders','Givers'];
var prefs=load('mmGSPrefs_v1',{sfx:true,big:false,auto:0,playAs:'teams',names:null,opt:{}});
if(!prefs.opt)prefs.opt={};
function savePrefs(){save('mmGSPrefs_v1',prefs);}
var teams=[],mode='lobby',G=null,lastMode=null,prevRank=null,chosenGrade=null,recap=[],tally={right:0,total:0};
function U(){var p=prefs.playAs==='players';return {one:p?'player':'team',One:p?'Player':'Team',many:p?'players':'teams',Many:p?'Players':'Teams'};}
function defName(i){return prefs.playAs==='players'?'Player '+(i+1):'Team '+TEAM_NAMES[i];}
function nameKey(){return (isStudent()?'student:':'')+prefs.playAs;}
function initTeams(){if(isStudent()&&!(prefs.names&&prefs.names[nameKey()]))prefs.playAs='players';var names=prefs.names&&prefs.names[nameKey()];
  if(!names||!names.length){if(isStudent()){var a=authObj();names=[a&&a.name?String(a.name).split(' ')[0]:'Player 1'];}else names=[defName(0),defName(1)];}
  teams=names.slice(0,8).map(function(n,i){return {name:n||defName(i),color:COLORS[i],score:0,streak:0,last:0,members:[]};});}
function rememberNames(){if(!prefs.names)prefs.names={};prefs.names[nameKey()]=teams.map(function(t){return t.name;});savePrefs();}
function grade(){return chosenGrade||appGrade();}
function ranked(){return teams.map(function(_,i){return i;}).sort(function(a,b){return teams[b].score-teams[a].score||a-b;});}
var MODES=[
 {id:'rush',name:'Quiz Rush',tag:'Fastest wins',mc:'#e0b24a',desc:'Timed multiple choice from this grade’s lessons. Faster correct answers earn up to $1,000, plus a streak bonus.',opts:[['count','Questions',[[10,'10'],[15,'15',1],[20,'20']]],['time','Timer',[[10,'10 seconds'],[20,'20 seconds',1],[30,'30 seconds'],[0,'Off · host reveals']]]]},
 {id:'board',mt:'#5b98db',name:'Money Board',tag:'Classic',mc:'#2f7dd1',desc:'Six categories, five clues each. The team in control picks a clue and everyone answers. Find the hidden Daily Double, then finish with a Final Wager.',opts:[['time','Clue timer',[[20,'20 seconds'],[30,'30 seconds',1],[45,'45 seconds'],[0,'Off · host reveals']]],['neg','Wrong answers',[[1,'Lose the value',1],[0,'Lose nothing']]]]},
 {id:'tf',mt:'#d97d62',name:'True or False Blitz',tag:'Warm-up',mc:'#d0603f',desc:'Ten-second rounds of money statements, each with a quick explanation. A great way to open class.',opts:[['count','Statements',[[10,'10',1],[15,'15']]]]},
 {id:'order',mt:'#32a872',name:'Put It in Order',tag:'Take turns',mc:'#2f9e6b',desc:'Teams take turns arranging four cards: coins by value, steps of a budget, or milestones in money history. $250 a spot and a $500 bonus for a perfect order.',opts:[['time','Turn timer',[[30,'30 seconds'],[45,'45 seconds',1],[60,'60 seconds']]]]},
 {id:'cash',mt:'#a886d5',name:'Cash or Case',tag:'Risk and reward',mc:'#8a5cc7',desc:'Pick a case, open the others, and decide: take the Banker’s sure offer or keep the risk? Shows the average of the unopened cases so students can weigh the odds.',opts:[['cases','Cases',[[16,'16 · quicker',1],[24,'24 · longer']]]]},
 {id:'who',mt:'#1ba7a7',name:'What Am I?',tag:'Clue by clue',mc:'#1aa3a3',desc:'Four clues about a money idea appear one at a time, hardest first. Lock in early for $1,000, or wait for an easier clue and earn less.',opts:[['count','Rounds',[[5,'5'],[8,'8',1],[12,'12']]]]},
 {id:'guess',mt:'#da74a5',name:'Closest Guess',tag:'Estimate',mc:'#d6649a',desc:'Word problems about saving, prices, tax and interest. Every team types a number; the closer the guess, the bigger the payout. A bullseye pays $1,000; the closest non-bullseye guess earns a $200 bonus.',opts:[['count','Problems',[[5,'5'],[8,'8',1],[10,'10']]]]},
 {id:'cross',name:'Money Crossword',tag:'Vocabulary',mc:'#8796a6',desc:'A fresh crossword built from this grade’s vocabulary every game. Take turns picking clues; longer words pay more, and you can buy a letter.',opts:[['size','Words',[[8,'8'],[12,'12',1],[16,'16']]],['time','Turn timer',[[0,'Off',1],[45,'45 seconds'],[60,'60 seconds']]]]}
];
var MODE_NAME={daily:'Daily 5'};MODES.forEach(function(m){MODE_NAME[m.id]=m.name;});
function opt(m,k){var md=MODES.filter(function(x){return x.id===m;})[0],v=prefs.opt[m]&&prefs.opt[m][k];if(v!=null)return +v;var d=md?md.opts.filter(function(o){return o[0]===k;})[0]:null;if(!d)return 0;var s=d[2].filter(function(x){return x[2];})[0]||d[2][0];return +s[0];}

/* ---------- shell ---------- */
function build(){if(ROOT)return;ROOT=document.createElement('div');ROOT.id='mm-gs';ROOT.hidden=true;ROOT.setAttribute('role','dialog');ROOT.setAttribute('aria-modal','true');ROOT.setAttribute('aria-label','Money Game Show');
  ROOT.innerHTML='<header class="gs-bar" id="gs-bar"></header><div class="gs-strip" id="gs-strip"></div><main class="gs-main" id="gs-main" tabindex="-1"></main>'
   +'<div class="gs-modal" id="gs-modal" hidden><div class="gs-modal-card" id="gs-mc" role="dialog" aria-modal="true"></div></div>'
   +'<div class="gs-auto" id="gs-auto" hidden><span id="gs-auto-l"></span><span class="tr"><i id="gs-auto-b"></i></span><button class="gs-btn sm" data-gs="auto-now">Go now</button><button class="gs-btn sm ghost" data-gs="auto-stop">Stop</button></div>'
   +'<canvas id="gs-confetti"></canvas><div class="gs-sr" aria-live="polite" id="gs-live"></div>';
  document.body.appendChild(ROOT);
  ROOT.addEventListener('click',onClick);
  ROOT.addEventListener('change',onChange);
  ROOT.addEventListener('input',onInput);
  ROOT.addEventListener('submit',function(e){e.preventDefault();var f=e.target;if(f&&f.id==='gs-cwf')cwCheck();});
  document.addEventListener('keydown',onKey,true);
  document.addEventListener('fullscreenchange',bar);}
function bar(){var b=$('gs-bar');if(!b)return;var inGame=mode!=='lobby',pod=mode==='podium';
  b.innerHTML=(inGame?'<button class="gs-btn sm ghost" data-gs="lobby" aria-label="Back to the game show lobby">‹ Lobby</button>':'')
   +'<button class="gs-brand" data-gs="'+(inGame?'lobby':'close')+'" aria-label="Money Game Show"><span class="gs-mark" aria-hidden="true">$</span><span><small>Money Matters</small><b>Game Show</b></span></button>'
   +(inGame?'<span class="gs-mode">'+esc(MODE_NAME[lastMode]||'')+'</span><span class="gs-prog" id="gs-prog"></span>':'<span class="gs-pill">'+esc(gradeName(grade()))+'</span>')
   +'<span class="gs-sp"></span><div class="gs-tools">'
   +'<button class="gs-ic" data-gs="sfx" aria-pressed="'+prefs.sfx+'" title="Sound effects" aria-label="Sound effects">'+(prefs.sfx?'🔊':'🔈')+'</button>'
   +'<button class="gs-ic" data-gs="big" aria-pressed="'+!!prefs.big+'" title="Bigger text" aria-label="Bigger text">A+</button>'
   +'<button class="gs-ic" data-gs="fs" title="Full screen" aria-label="Full screen">'+(document.fullscreenElement?'🗗':'⛶')+'</button>'
   +(inGame&&!pod?'<button class="gs-btn sm ghost" data-gs="quit">End game</button>':'<button class="gs-btn sm ghost" data-gs="close">Close</button>')+'</div>';
  ROOT.classList.toggle('big',!!prefs.big);}
function progress(t){var p=$('gs-prog');if(p)p.textContent=t;}
function main(h){var m=$('gs-main');m.innerHTML='<div class="gs-wrap">'+h+'</div>';m.scrollTop=0;}
function setInert(on){['gs-bar','gs-strip','gs-main'].forEach(function(id){var e=$(id);if(e){if(on)e.setAttribute('inert','');else e.removeAttribute('inert');}});}
function modal(h,label){var w=$('gs-modal'),c=$('gs-mc');c.innerHTML=h;c.setAttribute('aria-label',label||'Game');w.hidden=false;setInert(true);setTimeout(function(){var f=c.querySelector('input:not([disabled]),.gs-btn');if(f)try{f.focus({preventScroll:true});}catch(e){}},40);}
function closeModal(){var w=$('gs-modal');if(w)w.hidden=true;setInert(false);}
function activeTeam(){return mode==='board'&&G?G.active:mode==='order'&&G?G.team:mode==='cash'&&G?G.turn:mode==='cross'&&G&&teams.length>1?G.turn:-1;}
function strip(){var s=$('gs-strip');if(!s)return;if(mode==='lobby'||mode==='podium'||mode==='daily'||mode==='live'){s.innerHTML='';return;}
  var a=activeTeam();s.innerHTML=teams.map(function(t,i){var inner='<i style="--tc:'+t.color+'"></i><span>'+esc(t.name)+'</span><b>'+money(t.score)+'</b>'+(i===a?'<em>'+(mode==='board'?'In control':'Turn')+'</em>':'');
    return mode==='board'?'<button class="gs-chip'+(i===a?' on':'')+'" style="--tc:'+t.color+'" data-gs="ctl" data-t="'+i+'" aria-label="Give control to '+esc(t.name)+'">'+inner+'</button>':'<div class="gs-chip'+(i===a?' on':'')+'" style="--tc:'+t.color+'">'+inner+'</div>';}).join('');}

/* ---------- timers + auto-advance ---------- */
var clockIv=null,readyTO=null,autoIv=null,autoFn=null;
/* the clock looks its element up by id on every tick, so re-rendering a screen never stops it.
   T=0 means untimed: the clock shows an infinity sign and the host reveals manually. */
function startClock(T,id,onEnd){stopClock();if(!T){var t0u=performance.now();var eu=$(id);if(eu){eu.querySelector('span').textContent='∞';eu.setAttribute('aria-label','No time limit');}return t0u;}var t0=performance.now(),last=null;function upd(){var left=Math.max(0,T-(performance.now()-t0)/1000),s=Math.ceil(left),el=$(id);if(el){el.style.setProperty('--p',left/T);var sp=el.querySelector('span');if(sp)sp.textContent=s;el.classList.toggle('hot',left<=5);}if(s!==last){last=s;if(s<=5&&s>0)sfx('tick');if(s===10||s===5)say(s+' seconds left');}if(left<=0){stopClock();say('Time is up');onEnd();}}upd();clockIv=setInterval(upd,100);return t0;}
function stopClock(){clearInterval(clockIv);clockIv=null;}
function autoNext(fn,label){cancelAuto();var n=+prefs.auto;if(!n)return;autoFn=fn;var left=n,box=$('gs-auto'),l=$('gs-auto-l'),b=$('gs-auto-b');box.hidden=false;l.textContent=label+' in '+left+'s';
  b.style.transition='none';b.style.transform='scaleX(0)';void b.offsetWidth;b.style.transition='transform '+n+'s linear';b.style.transform='scaleX(1)';
  autoIv=setInterval(function(){left--;if(left<=0){var f=autoFn;cancelAuto();if(f)f();}else l.textContent=label+' in '+left+'s';},1000);}
function cancelAuto(){clearInterval(autoIv);autoIv=null;autoFn=null;var a=$('gs-auto');if(a)a.hidden=true;}
function stopAll(){stopClock();cancelAuto();clearTimeout(readyTO);if(G&&G.clueIv)clearInterval(G.clueIv);if(G&&G.endTO)clearTimeout(G.endTO);}

/* ---------- lobby ---------- */
var leaveHooks=[];function runLeave(){leaveHooks.forEach(function(f){try{f();}catch(e){}});}
function lobby(){runLeave();stopAll();closeModal();if(G&&G.savedTeams)teams=G.savedTeams;mode='lobby';G=null;teams.forEach(function(t){t.score=0;t.streak=0;t.last=0;});bar();strip();
  var g=grade(),n=pool(g).length,u=U(),staff=isStaff()&&!sampleOn(),roster=staff?rosterNames(g):[];
  var h='<section class="gs-hero"><div><div class="gs-k">Money Matters · Class Game Show</div><h1>Learn it. Play it. <span>Win it.</span></h1><p>Game-show rounds built from '+esc(gradeName(g))+' lessons. Play on one shared screen with the whole class, in small groups, or on your own for practice.</p></div>'
   +'<div class="gs-gradebox">'+(staff?'<label class="gs-k" for="gs-grade">Grade</label><select id="gs-grade" data-gs-ch="grade">'+GRADES.map(function(x){return '<option value="'+x+'"'+(x===g?' selected':'')+'>'+esc(gradeName(x))+'</option>';}).join('')+'</select>':'<span class="gs-pill">'+esc(gradeName(g))+'</span>')
   +'<span class="gs-note">'+n.toLocaleString()+' curriculum questions'+(sampleOn()?' · sample: Unit 1 only':'')+'</span></div></section>';
  var d=load('mmGSDaily_v1',{}),done=d.last===todayKey();
  h+='<section class="gs-daily"><div><div class="gs-k">Daily 5 · on your own</div><h2>Five questions a day</h2><p class="gs-muted">The same five questions for everyone in '+esc(gradeName(g))+' today.'+(d.streak?' <span class="gs-streak">Streak: '+d.streak+' day'+(d.streak===1?'':'s')+'</span>':'')+'</p></div><button class="gs-btn" data-gs="start" data-m="daily">'+(done?'Practice again':'Play today’s 5')+'</button></section>';
  if(staff&&window.MMGameShowLive)h+='<section class="gs-daily gs-livecard"><div><div class="gs-k">Live · everyone plays on their own device</div><h2>Play live on phones and tablets</h2><p class="gs-muted">Show this screen on the projector. Students join with a game PIN or QR code and answer on their own device. No student accounts needed.</p></div><button class="gs-btn" data-gs="live">Host a live game</button></section>';
  h+='<div class="gs-lobby"><aside class="gs-panel" aria-label="Players and teams"><div class="gs-k">Play as</div><div class="gs-seg" role="group" aria-label="Play as"><button data-gs="playas" data-v="teams" aria-pressed="'+(prefs.playAs!=='players')+'">Teams</button><button data-gs="playas" data-v="players" aria-pressed="'+(prefs.playAs==='players')+'">Players</button></div>'
   +'<div class="gs-k">'+u.Many+' · 1 to 8</div><div id="gs-teams" style="display:flex;flex-direction:column;gap:10px">'+teams.map(function(t,i){return '<div class="gs-team" style="--tc:'+t.color+'"><i></i><input data-gs-name="'+i+'" value="'+esc(t.name)+'" maxlength="24" aria-label="'+u.One+' '+(i+1)+' name"><button class="gs-x" data-gs="rm" data-i="'+i+'" aria-label="Remove '+esc(t.name)+'"'+(teams.length<=1?' disabled':'')+'>×</button>'+(t.members.length?'<small>'+esc(t.members.join(', '))+'</small>':'')+'</div>';}).join('')+'</div>'
   +'<div class="gs-row"><button class="gs-btn sm ghost" data-gs="add"'+(teams.length>=8?' disabled':'')+'>+ Add a '+u.one+'</button></div>'
   +(roster.length?'<div class="gs-row"><button class="gs-btn sm ghost" data-gs="split">Split my class into '+teams.length+' team'+(teams.length===1?'':'s')+'</button></div><p class="gs-note">'+roster.length+' '+esc(gradeName(g))+' student'+(roster.length===1?'':'s')+' on your roster.</p>':'')
   +'<div class="gs-k">Auto-advance</div><select data-gs-ch="auto" aria-label="Auto-advance" style="min-height:40px;border-radius:10px;border:1px solid var(--line);background:var(--bg2);padding:6px 8px">'+[[0,'Off · host clicks Next'],[3,'3 seconds'],[5,'5 seconds']].map(function(o){return '<option value="'+o[0]+'"'+(+prefs.auto===o[0]?' selected':'')+'>'+o[1]+'</option>';}).join('')+'</select>'
   +'<p class="gs-note">Tip: put this on the projector. Each '+u.one+' taps its own answer buttons, or the host clicks for them.</p></aside>';
  h+='<div style="display:flex;flex-direction:column;gap:16px;min-width:0"><div class="gs-modes">'+MODES.map(function(m){return '<article class="gs-mode-card" style="--mc:'+m.mc+(m.mt?';--mt:'+m.mt:'')+'"><div class="gs-mode-top"><h2>'+esc(m.name)+'</h2><span>'+esc(m.tag)+'</span></div><div class="gs-mode-body"><p>'+esc(m.desc)+'</p><div class="gs-opts">'
    +m.opts.map(function(o){var cur=opt(m.id,o[0]);return '<label>'+esc(o[1])+'<select data-gs-opt="'+m.id+'|'+o[0]+'">'+o[2].map(function(x){return '<option value="'+x[0]+'"'+(+x[0]===cur?' selected':'')+'>'+esc(x[1])+'</option>';}).join('')+'</select></label>';}).join('')
    +'</div><button class="gs-btn" data-gs="start" data-m="'+m.id+'">Play '+esc(m.name)+'</button></div></article>';}).join('')+'</div>';
  var hist=load('mmGSHistory_v1',[]).slice(-5).reverse();
  if(hist.length)h+='<div class="gs-k">Recent games on this device</div><div class="gs-hist">'+hist.map(function(x){var w=x.list&&x.list[0];return '<div><span>'+esc(MODE_NAME[x.m]||x.m)+' · '+esc(gradeName(x.g))+' · '+new Date(x.t).toLocaleDateString()+'</span><b>'+(w?esc(w.n)+' '+money(w.s):'')+'</b></div>';}).join('')+'</div>';
  h+='</div></div>';
  main(h);}
function rosterNames(g){try{var D=MM().data;return (D.list()||[]).filter(function(s){return (s.grade||'K')===g;}).map(function(s){return String(s.name||'').trim();}).filter(Boolean);}catch(e){return [];}}
function splitRoster(){var names=shuffle(rosterNames(grade()));if(!names.length)return;if(prefs.playAs!=='teams'){prefs.playAs='teams';}
  if(teams.length<2&&names.length>1)addTeam();teams.forEach(function(t){t.members=[];});names.forEach(function(n,i){teams[i%teams.length].members.push(n);});lobby();say('Class split into '+teams.length+' teams.');}
function addTeam(){if(teams.length>=8)return;var i=teams.length;teams.push({name:defName(i),color:COLORS[i],score:0,streak:0,last:0,members:[]});}

/* ---------- launching ---------- */
function launch(m){rememberNames();lastMode=m;mode=m;prevRank=null;recap=[];tally={right:0,total:0};teams.forEach(function(t){t.score=0;t.streak=0;t.last=0;});
  if(m==='daily'&&teams.length>1){G={savedTeams:teams};teams=[{name:teams[0].name,color:COLORS[0],score:0,streak:0,last:0,members:[]}];}else G=null;
  bar();({rush:function(){startQuiz('rush');},tf:function(){startQuiz('tf');},who:function(){startQuiz('who');},daily:function(){startQuiz('daily');},board:startBoard,order:startOrder,cash:startCash,guess:startGuess,cross:startCross})[m]();strip();}
function noContent(msg){main('<div class="gs-q"><div class="gs-qtext">'+esc(msg)+'</div></div><div class="gs-actions"><button class="gs-btn" data-gs="lobby">Back to the lobby</button></div>');}

/* ---------- quiz engine: Quiz Rush · True/False · What Am I? · Daily 5 ---------- */
var LET=['A','B','C','D'],CLS=['c0','c1','c2','c3'],WHO_CL=6,WHO_PTS=[1000,750,500,250];
/* localized content banks (GS_TF_L.es etc.) when the app language is Spanish or Portuguese */
function bank(name){var l=lang(),L=window[name+'_L'];return (l!=='en'&&L&&L[l])||window[name];}
function quizItems(kind){var g=grade(),b=band(g);
  if(kind==='tf')return pickFresh(bank('GS_TF')[b],opt('tf','count'),function(x){return 'tf|'+x[0];}).map(function(x){return {cat:'True or false?',q:x[0],opts:['True','False'],correct:x[1]?0:1,fact:x[2]};});
  if(kind==='who')return pickFresh(bank('GS_WHO')[b],opt('who','count'),function(x){return 'who|'+x.a;}).map(function(x){var o=shuffle([x.a].concat(x.w));return {cat:'What am I?',q:'What am I?',clues:x.c,opts:o,correct:o.indexOf(x.a),fact:x.f};});
  if(kind==='daily'){var p=pool(g);if(!p.length)return [];var r=seedRng(todayKey()+'|'+g),idx=[],tries=0;while(idx.length<Math.min(5,p.length)&&tries<200){var k=Math.floor(r()*p.length);if(idx.indexOf(k)<0)idx.push(k);tries++;}return idx.map(function(k){return toItem(p[k]);});}
  var P=pool(g);return pickFresh(P,opt('rush','count'),function(x){return g+'|'+x.q;}).map(toItem);}
function startQuiz(kind){var T=kind==='tf'?10:kind==='who'?WHO_CL*4:kind==='daily'?20:opt('rush','time'),items=quizItems(kind);
  if(!items.length)return noContent('No questions are available for '+gradeName(grade())+' yet.');
  var saved=G&&G.savedTeams;G={kind:kind,items:items,i:-1,T:T,savedTeams:saved};nextQ();}
function nextQ(){cancelAuto();G.i++;if(G.i>=G.items.length)return podium();
  var it=G.items[G.i],two=it.opts.length===2;G.locks={};G.phase='ready';G.cls=two?['c2','c3']:CLS;G.letters=two?['T','F']:LET;
  progress((G.kind==='who'?'Round ':'Question ')+(G.i+1)+' of '+G.items.length);
  main('<div class="gs-q"><div class="gs-eyebrow">'+esc(it.cat)+'</div><div class="gs-timer" id="gs-timer" role="timer" aria-label="Time left"><span>'+G.T+'</span></div><h2 class="gs-qtext">'+esc(it.q)+'</h2>'+(it.clues?'<ol class="gs-clues" id="gs-clues"></ol>':'')+'<div class="gs-ready" id="gs-ready"><span>'+(it.clues?'Get ready for the first clue':'Read the question')+'</span><span class="bar"><i></i></span></div></div>'
   +'<div class="gs-answers'+(two?' two':'')+'" id="gs-answers"></div><div class="gs-fact" id="gs-fact" hidden></div><div class="gs-locks" id="gs-locks"></div>'
   +'<div class="gs-actions"><button class="gs-btn ghost" data-gs="q-reveal" id="gs-reveal" hidden>Reveal answer now</button><button class="gs-btn" data-gs="q-next" id="gs-next" hidden>Next</button></div>');
  sfx('whoosh');say(it.q);clearTimeout(readyTO);readyTO=setTimeout(openAnswers,reduced()?700:2400);}
function solo(){return teams.length===1;}
function openAnswers(){if(!G||G.phase!=='ready')return;var it=G.items[G.i];G.phase='answer';var r=$('gs-ready');if(r)r.remove();
  $('gs-answers').innerHTML=it.opts.map(function(o,k){var tag=solo()?'button':'div';return '<'+tag+' class="gs-ans '+G.cls[k]+'"'+(solo()?' data-gs="pick" data-t="0" data-k="'+k+'"':'')+' style="animation-delay:'+k*60+'ms"><b>'+G.letters[k]+'</b><span>'+esc(o)+'</span><em class="gs-pickers" id="gs-pk-'+k+'"></em></'+tag+'>';}).join('');
  $('gs-locks').innerHTML=solo()?'':teams.map(function(t,ti){return '<div class="gs-lock" id="gs-lk-'+ti+'" style="--tc:'+t.color+'"><div class="nm"><i style="width:12px;height:12px;border-radius:50%;background:'+t.color+'"></i>'+esc(t.name)+'</div><div class="btns" style="--n:'+it.opts.length+'">'+it.opts.map(function(o,k){return '<button class="gs-pick '+G.cls[k]+'" data-gs="pick" data-t="'+ti+'" data-k="'+k+'" aria-label="'+esc(t.name)+' picks '+G.letters[k]+': '+esc(o)+'">'+G.letters[k]+'</button>';}).join('')+'</div><div class="st">Pick an answer</div></div>';}).join('');
  $('gs-reveal').hidden=false;
  if(it.clues){var cl=$('gs-clues'),n=0;var addClue=function(){if(!G||G.phase!=='answer')return;if(n<it.clues.length){cl.insertAdjacentHTML('beforeend','<li>'+esc(it.clues[n])+'</li>');n++;G.clueN=n;sfx('select');say(it.clues[n-1]);}};addClue();G.clueIv=setInterval(addClue,WHO_CL*1000);}
  G.t0=startClock(G.T,'gs-timer',function(){sfx('timesup');reveal();});}
function pick(t,k){if(!G||G.phase!=='answer'||G.locks[t])return;G.locks[t]={k:k,s:(performance.now()-G.t0)/1000};sfx('lock');
  var c=$('gs-lk-'+t);if(c){c.classList.add('locked');c.querySelector('.st').textContent='Locked in';}
  if(Object.keys(G.locks).length===teams.length)reveal();}
function quizGain(it,L,tm){if(it.clues)return WHO_PTS[Math.min(3,Math.floor(L.s/WHO_CL))];var TT=G.T||30;return Math.round((1000*(1-Math.min(1,L.s/TT)/2))/10)*10+Math.min(500,(tm.streak-1)*100);}
function reveal(){cancelAuto();if(!G||G.phase!=='answer')return;G.phase='reveal';stopClock();clearInterval(G.clueIv);var it=G.items[G.i],any=false;prevRank=ranked();
  if(it.clues){var cl=$('gs-clues');if(cl)cl.innerHTML=it.clues.map(function(c){return '<li>'+esc(c)+'</li>';}).join('');}
  teams.forEach(function(tm,t){var L=G.locks[t],gain=0;if(L&&L.k===it.correct){tm.streak++;gain=quizGain(it,L,tm);any=true;}else tm.streak=0;tm.score+=gain;tm.last=gain;
    if(L){var pk=$('gs-pk-'+L.k);if(pk)pk.insertAdjacentHTML('beforeend','<i role="img" aria-label="'+esc(tm.name)+'" style="--tc:'+tm.color+'" title="'+esc(tm.name)+'"></i>');}
    var c=$('gs-lk-'+t);if(c){c.classList.add('locked');c.querySelector('.st').innerHTML=gain?'<span class="gs-gain">+'+money(gain)+'</span>'+(tm.streak>1&&!it.clues?' · '+tm.streak+' in a row':'')+(it.clues?' · clue '+Math.min(4,1+Math.floor(L.s/WHO_CL)):''):'<span class="gs-gain zero">'+(L?'Not this time':'No answer')+'</span>';}});
  tally.total++;if(G.locks[0]&&G.locks[0].k===it.correct)tally.right++;
  recap.push({c:it.cat,q:it.clues?it.clues.join(' '):it.q,a:it.opts[it.correct],f:it.fact});
  var A=$('gs-answers');A.querySelectorAll('.gs-ans').forEach(function(el,k){el.classList.toggle('right',k===it.correct);if(k===it.correct)el.insertAdjacentHTML('beforeend','<span class="gs-sr"> (correct answer)</span>');if(el.tagName==='BUTTON')el.disabled=true;});A.classList.add('revealed');
  if(solo()){var L0=G.locks[0];var msg=L0&&L0.k===it.correct?'Correct! +'+money(teams[0].last):(L0?'Not quite.':'Time is up.');var f0=$('gs-fact');f0.hidden=false;f0.innerHTML='<span class="gs-k">'+esc(msg)+'</span>';}
  if(it.fact){var f=$('gs-fact');f.hidden=false;f.innerHTML+='<span class="gs-k">Why it matters</span><span>'+esc(it.fact)+'</span>';}
  sfx(any?'correct':'wrong');say('Correct answer: '+G.letters[it.correct]+', '+it.opts[it.correct]+'. '+teams.map(function(t){return t.name+(t.last?' plus '+money(t.last):' no points');}).join('. '));strip();
  $('gs-reveal').hidden=true;var nx=$('gs-next');nx.hidden=false;var last=G.i+1>=G.items.length;nx.textContent=last?'See final results':(solo()?'Next question':'Leaderboard');try{nx.focus({preventScroll:true});}catch(e){}
  autoNext(qNext,last?'Final results':(solo()?'Next question':'Leaderboard'));}
function qNext(){if(!G)return;if(G.i+1>=G.items.length)return podium();if(solo())return nextQ();leaderboard(nextQ,'Next question');}

/* ---------- leaderboard ---------- */
function leaderboard(next,label){cancelAuto();G.lbNext=next;var r=ranked(),max=Math.max.apply(null,[1].concat(teams.map(function(t){return t.score;})));
  main('<div class="gs-head"><h2>Leaderboard</h2><button class="gs-btn" data-gs="lb-next">'+esc(label)+'</button></div><div class="gs-lb">'+r.map(function(t,pos){var tm=teams[t],was=prevRank?prevRank.indexOf(t):pos;
    return '<div class="gs-lbrow" style="--tc:'+tm.color+';--w:'+Math.max(0,tm.score)/max*100+'%;animation-delay:'+pos*60+'ms"><span class="bar"></span><span class="rk">'+(pos+1)+'</span><span class="nm"><i></i>'+esc(tm.name)+(was>pos?' <span class="up">▲ '+(was-pos)+'</span>':'')+'</span><span class="dl">'+(tm.last>0?'+'+money(tm.last):'')+'</span><span class="sc">'+money(tm.score)+'</span></div>';}).join('')+'</div>');
  autoNext(next,label);}

/* ---------- Money Board ---------- */
var VALUES=[200,400,600,800,1000];
function startBoard(){var g=grade(),P=pool(g),groups={};
  P.forEach(function(p){var key=sampleOn()?p.week:p.unit;(groups[key]=groups[key]||[]).push(p);});
  var cats=Object.keys(groups).sort(function(a,b){return a-b;}).slice(0,6).map(function(k){var items=pickFresh(groups[k],5,function(x){return g+'|'+x.q;}).sort(function(a,b){return a.week-b.week||a.q.length-b.q.length;}).map(toItem);return {name:groups[k][0].cat,items:items};}).filter(function(c){return c.items.length;});
  if(!cats.length)return noContent('No questions are available for this grade yet.');
  var ids=[];cats.forEach(function(c,ci){c.items.forEach(function(_,r){if(r>=1)ids.push(ci+'-'+r);});});
  G={cats:cats,total:cats.reduce(function(n,c){return n+c.items.length;},0),used:{},active:0,dd:ids.length?ids[Math.floor(Math.random()*ids.length)]:null,T:opt('board','time'),neg:!!opt('board','neg'),cur:null,finalDone:false};
  renderBoard();}
function renderBoard(){var used=Object.keys(G.used).length,left=G.total-used,h='';
  h+='<div class="gs-head"><div><h2>'+esc(teams[G.active].name)+' picks a clue</h2><p class="gs-muted">'+(left?left+' of '+G.total+' clues left · tap a score above to change who is in control':'Board cleared. Time for the Final Wager!')+'</p></div><button class="gs-btn'+(left?' ghost':' gs-pulse')+'" data-gs="final"'+(G.finalDone?' disabled':'')+'>Final Wager</button></div>';
  h+='<div class="gs-board" style="--cols:'+G.cats.length+'">'+G.cats.map(function(c){return '<div class="gs-cat">'+esc(c.name)+'</div>';}).join('');
  for(var r=0;r<5;r++)G.cats.forEach(function(c,ci){var it=c.items[r],id=ci+'-'+r;if(!it){h+='<div></div>';return;}var u=!!G.used[id];h+='<button class="gs-tile" data-gs="tile" data-c="'+ci+'" data-r="'+r+'" style="animation-delay:'+(r*G.cats.length+ci)*15+'ms"'+(u?' disabled':'')+' aria-label="'+esc(c.name)+', '+money(VALUES[r])+(u?', answered':'')+'">'+(u?'':money(VALUES[r]))+'</button>';});
  h+='</div>';main(h);progress(used+' of '+G.total+' clues played');strip();}
function openTile(c,r){var id=c+'-'+r;if(G.used[id]||G.cur||G.fin)return;var it=G.cats[c].items[r];G.cur={id:id,it:it,value:VALUES[r],dd:id===G.dd};
  if(G.cur.dd){var tm=teams[G.active],max=Math.max(tm.score,1000);G.cur.max=max;sfx('dd');
    modal('<div class="gs-mhead"><div><div class="gs-k">'+esc(it.cat)+'</div><div class="gs-val">Hidden bonus clue</div></div></div><div class="gs-big">Daily Double!</div><p class="gs-center">'+esc(tm.name)+' found it. Wager any amount from $5 to '+money(max)+'. Only '+esc(tm.name)+' answers.</p><div class="gs-wager"><label class="gs-k" for="gs-dd">Wager</label><input id="gs-dd" type="number" inputmode="numeric" min="5" max="'+max+'" step="100" value="'+Math.min(max,1000)+'"></div><div class="gs-actions"><button class="gs-btn" data-gs="dd-lock">Lock wager</button></div>','Daily Double');}
  else{sfx('select');showClue();}}
function clueModal(it,head,answerers){G.locks={};G.phase='answer';G.answerers=answerers;var one=answerers.length===1;
  modal('<div class="gs-mhead"><div><div class="gs-k">'+esc(it.cat)+'</div><div class="gs-val">'+esc(head)+'</div></div><div class="gs-timer dark" id="gs-timer" role="timer" aria-label="Time left"><span>'+G.T+'</span></div></div>'
   +'<div class="gs-q" style="min-height:0"><h2 class="gs-qtext" style="padding-right:0">'+esc(it.q)+'</h2></div>'
   +'<div class="gs-answers" id="gs-answers">'+it.opts.map(function(o,k){var t=one?'button':'div';return '<'+t+' class="gs-ans '+CLS[k]+'"'+(one?' data-gs="bpick" data-t="'+answerers[0]+'" data-k="'+k+'"':'')+'><b>'+LET[k]+'</b><span>'+esc(o)+'</span><em class="gs-pickers" id="gs-pk-'+k+'"></em></'+t+'>';}).join('')+'</div>'
   +(one?'':'<div class="gs-locks">'+answerers.map(function(ti){var t=teams[ti];return '<div class="gs-lock" id="gs-lk-'+ti+'" style="--tc:'+t.color+'"><div class="nm">'+esc(t.name)+'</div><div class="btns" style="--n:'+it.opts.length+'">'+it.opts.map(function(o,k){return '<button class="gs-pick '+CLS[k]+'" data-gs="bpick" data-t="'+ti+'" data-k="'+k+'" aria-label="'+esc(t.name)+' picks '+LET[k]+'">'+LET[k]+'</button>';}).join('')+'</div><div class="st">Pick an answer</div></div>';}).join('')+'</div>')
   +'<div class="gs-fact" id="gs-fact" hidden></div><div class="gs-actions" id="gs-cact"><button class="gs-btn ghost" data-gs="b-reveal">Reveal answer now</button></div>',head);
  G.t0=startClock(G.T,'gs-timer',function(){sfx('timesup');boardReveal();});}
function showClue(){var tm=teams[G.active];clueModal(G.cur.it,G.cur.dd?'Daily Double · '+money(G.cur.value)+' wagered by '+tm.name:money(G.cur.value)+' · picked by '+tm.name,G.cur.dd?[G.active]:teams.map(function(_,i){return i;}));}
function bpick(t,k){if(!G||G.phase!=='answer'||G.locks[t])return;G.locks[t]={k:k,s:(performance.now()-G.t0)/1000};sfx('lock');var c=$('gs-lk-'+t);if(c){c.classList.add('locked');c.querySelector('.st').textContent='Locked in';}
  if(Object.keys(G.locks).length===G.answerers.length)(G.cur?boardReveal:finalReveal)();}
function markAnswers(it){var A=$('gs-answers');if(!A)return;A.querySelectorAll('.gs-ans').forEach(function(el,k){el.classList.toggle('right',k===it.correct);if(el.tagName==='BUTTON')el.disabled=true;});A.classList.add('revealed');
  Object.keys(G.locks).forEach(function(t){var L=G.locks[t],pk=$('gs-pk-'+L.k);if(pk)pk.insertAdjacentHTML('beforeend','<i role="img" aria-label="'+esc(teams[t].name)+'" style="--tc:'+teams[t].color+'"></i>');});}
function boardReveal(){if(!G||G.phase!=='answer')return;G.phase='reveal';stopClock();var it=G.cur.it,best=null;prevRank=ranked();teams.forEach(function(t){t.last=0;});
  G.answerers.forEach(function(t){var L=G.locks[t],tm=teams[t],c=$('gs-lk-'+t),d=0;if(L&&L.k===it.correct){d=G.cur.value;if(!best||L.s<best.s)best={t:t,s:L.s};}else if(G.cur.dd||(L&&G.neg))d=-G.cur.value;tm.score+=d;tm.last=d;
    if(c){c.classList.add('locked');c.querySelector('.st').innerHTML=d>0?'<span class="gs-gain">+'+money(d)+'</span>':'<span class="gs-gain zero">'+(d<0?money(d):L?'Not this time':'No answer')+'</span>';}});
  if(teams.length===1||G.cur.dd){var L1=G.locks[G.answerers[0]];var f0=$('gs-fact');f0.hidden=false;f0.innerHTML='<span class="gs-k">'+(L1&&L1.k===it.correct?'Correct! +'+money(G.cur.value):'Not this time'+(teams[G.answerers[0]].last<0?' · '+money(teams[G.answerers[0]].last):''))+'</span>';}
  tally.total++;if(G.locks[0]&&G.locks[0].k===it.correct)tally.right++;
  if(best)G.active=best.t;markAnswers(it);recap.push({c:it.cat,q:it.q,a:it.opts[it.correct],f:it.fact});
  if(it.fact){var f=$('gs-fact');f.hidden=false;f.innerHTML+='<span class="gs-k">Why it matters</span><span>'+esc(it.fact)+'</span>';}
  say('Correct answer: '+LET[it.correct]+', '+it.opts[it.correct]+'.');sfx(best?'correct':'wrong');strip();$('gs-cact').innerHTML='<button class="gs-btn" data-gs="b-done">Back to the board</button>';
  try{$('gs-cact').querySelector('button').focus({preventScroll:true});}catch(e){}autoNext(boardDone,'Back to the board');}
function boardDone(){cancelAuto();if(!G||!G.cur)return;G.used[G.cur.id]=1;G.cur=null;closeModal();renderBoard();}
function startFinal(){var g=grade(),p=testPool(g),it=toItem(p[Math.floor(Math.random()*p.length)]);G.fin={it:it,w:[]};sfx('dd');
  modal('<div class="gs-mhead"><div><div class="gs-k">Final Wager</div><div class="gs-val">Category: '+esc(it.cat)+'</div></div></div><p>Each '+U().one+' secretly picks a wager from $0 up to its current score. Anyone at $0 or below can only wager $0.</p><div class="gs-judge">'
   +teams.map(function(t,i){var mx=Math.max(0,t.score);return '<div class="gs-jrow" style="--tc:'+t.color+'"><i></i><label for="gs-fw-'+i+'"><b>'+esc(t.name)+'</b> <span class="gs-muted">up to '+money(mx)+'</span></label><input id="gs-fw-'+i+'" type="number" inputmode="numeric" min="0" max="'+mx+'" step="100" value="0"'+(mx?'':' disabled')+'></div>';}).join('')
   +'</div><div class="gs-actions"><button class="gs-btn" data-gs="fw-lock">Lock wagers and show the question</button>'+(Object.keys(G.used).length<G.total?'<button class="gs-btn ghost" data-gs="fw-cancel">Back to the board</button>':'')+'</div>','Final Wager');}
function finalLock(){G.fin.w=teams.map(function(t,i){var el=$('gs-fw-'+i),mx=Math.max(0,t.score),v=Math.round(+((el&&el.value)||0));return Math.max(0,Math.min(mx,isFinite(v)?v:0));});G.T=Math.max(G.T,30);
  clueModal(G.fin.it,'Final Wager',teams.map(function(_,i){return i;}));}
function finalReveal(){if(!G||G.phase!=='answer')return;G.phase='reveal';stopClock();var it=G.fin.it;teams.forEach(function(t,i){var L=G.locks[i],d=L&&L.k===it.correct?G.fin.w[i]:-G.fin.w[i];t.score+=d;t.last=d;
  var c=$('gs-lk-'+i);if(c){c.classList.add('locked');c.querySelector('.st').innerHTML=d>0?'<span class="gs-gain">+'+money(d)+'</span>':'<span class="gs-gain zero">'+(d<0?money(d):'No change')+'</span>';}});
  markAnswers(it);recap.push({c:'Final Wager · '+it.cat,q:it.q,a:it.opts[it.correct],f:it.fact});
  if(it.fact){var f=$('gs-fact');f.hidden=false;f.innerHTML='<span class="gs-k">Why it matters</span><span>'+esc(it.fact)+'</span>';}
  G.finalDone=true;sfx('correct');strip();$('gs-cact').innerHTML='<button class="gs-btn" data-gs="podium">See final results</button>';}

/* ---------- Put It in Order ---------- */
function startOrder(){var sets=bank('GS_ORDER')[band(grade())],per=teams.length<=3?2:1,n=teams.length*per,fresh=pickFresh(sets,Math.min(n,sets.length),function(x){return 'ord|'+x.t+x.items[0][0];}),list=[];
  for(var i=0;i<n;i++)list.push(fresh[i%fresh.length]);G={sets:list,i:-1,T:opt('order','time')};nextOrder();}
function nextOrder(){cancelAuto();G.i++;if(G.i>=G.sets.length)return podium();G.team=G.i%teams.length;G.set=G.sets[G.i];G.cards=shuffle(G.set.items.map(function(e,k){return {t:e[0],y:e[1],l:e[2],k:k};}));G.seq=[null,null,null,null];G.phase='play';
  progress('Round '+(G.i+1)+' of '+G.sets.length);strip();renderOrder();G.t0=startClock(G.T,'gs-timer',function(){sfx('timesup');submitOrder();});}
function renderOrder(){var tm=teams[G.team],play=G.phase==='play',ev=G.set.items,filled=G.seq.filter(function(k){return k!=null;}).length;
  var h='<div class="gs-head"><div><div class="gs-turn"><i style="--tc:'+tm.color+'"></i>'+esc(tm.name)+(play?', your turn':'')+'</div><p class="gs-muted" style="margin-top:4px">'+esc(G.set.t)+'. Tap the cards in order.</p></div>'+(play?'<div class="gs-timer dark" id="gs-timer" role="timer" aria-label="Time left"><span>'+G.T+'</span></div>':'')+'</div>';
  h+='<div class="gs-order"><div class="gs-col"><span class="gs-k">'+(play?'Cards':'Correct order')+'</span>';
  if(play)h+=G.cards.filter(function(c){return G.seq.indexOf(c.k)<0;}).map(function(c,i){return '<button class="gs-card" data-gs="o-card" data-k="'+c.k+'" style="animation-delay:'+i*50+'ms">'+esc(c.t)+'</button>';}).join('')+(filled===4?'<p class="gs-note">All four placed. Tap a slot to take a card back, or lock it in.</p>':'');
  else h+='<ol class="gs-answer-list">'+ev.slice().sort(function(a,b){return a[1]-b[1];}).map(function(e){return '<li><b>'+esc(e[2])+'</b><span>'+esc(e[0])+'</span></li>';}).join('')+'</ol>';
  h+='</div><div class="gs-col"><span class="gs-k">Your order · first to last</span>'+[0,1,2,3].map(function(j){var k=G.seq[j],e=k!=null?ev[k]:null,res=!play&&G.res?(G.res[j]?' right':' wrong'):'';return '<button class="gs-slot'+(e?' filled':'')+res+'" data-gs="o-slot" data-j="'+j+'"'+(play?'':' disabled')+'><b>'+(j+1)+'</b><span>'+(e?esc(e[0]):'Tap a card to place it here')+'</span>'+(!play&&e?'<span class="yr">'+esc(e[2])+'</span>':'')+'</button>';}).join('')+'</div></div>';
  if(!play)h+='<p class="gs-result">'+G.resText+'</p>';
  h+='<div class="gs-actions">'+(play?'<button class="gs-btn" data-gs="o-submit"'+(filled<4?' disabled':'')+'>Lock in this order</button>':'<button class="gs-btn" data-gs="o-next">'+(G.i+1>=G.sets.length?'See final results':teams.length>1?'Leaderboard':'Next round')+'</button>')+'</div>';
  main(h);}
function oCard(k){if(G.phase!=='play')return;var j=G.seq.indexOf(null);if(j<0)return;G.seq[j]=k;sfx('select');renderOrder();}
function oSlot(j){if(G.phase!=='play'||G.seq[j]==null)return;G.seq[j]=null;renderOrder();}
function submitOrder(){if(!G||G.phase!=='play')return;G.phase='reveal';stopClock();prevRank=ranked();var ev=G.set.items,sorted=ev.slice().sort(function(a,b){return a[1]-b[1];}),right=0;
  G.res=[0,1,2,3].map(function(j){var k=G.seq[j],ok=k!=null&&ev[k][1]===sorted[j][1];if(ok)right++;return ok;});
  var pts=right*250+(right===4?500:0),tm=teams[G.team];teams.forEach(function(t){t.last=0;});tm.score+=pts;tm.last=pts;tally.total++;if(right===4&&G.team===0)tally.right++;
  G.resText=pts?'<span class="gs-gain">+'+money(pts)+'</span> '+esc(tm.name)+' placed '+right+' of 4 correctly'+(right===4?'. A perfect order!':'.'):'<span class="gs-gain zero">No points this round.</span>';
  recap.push({c:'Put It in Order',q:G.set.t,a:sorted.map(function(e){return e[0]+' ('+e[2]+')';}).join(' → '),f:''});
  sfx(right===4?'correct':right>=2?'lock':'wrong');renderOrder();strip();autoNext(oNext,'Next');}
function oNext(){if(G.i+1>=G.sets.length)return podium();if(teams.length===1)return nextOrder();leaderboard(nextOrder,'Next round');}

/* ---------- Cash or Case ---------- */
var CASH={16:{v:[1,5,10,25,50,100,250,500,750,1000,2500,5000,10000,25000,50000,100000],s:[4,3,3,2,1,1]},24:{v:[1,2,5,10,20,30,50,75,100,150,200,300,500,750,1000,1500,2500,5000,7500,10000,20000,40000,70000,100000],s:[6,5,4,3,2,1,1]}};
function niceAmt(x){var st=x<100?1:x<1000?10:x<10000?50:x<100000?500:1000;return Math.max(1,Math.round(x/st)*st);}
function cashNeed(r){return CASH[G.n].s.slice(0,r+1).reduce(function(a,b){return a+b;},0);}
function cashLeft(){return G.board.filter(function(_,i){return G.opened.indexOf(i)<0;});}
function cashAvg(){var l=cashLeft();return l.reduce(function(a,b){return a+b;},0)/Math.max(1,l.length);}
function startCash(){var n=opt('cash','cases');G={n:CASH[n]?n:16,turn:0};G.R=CASH[G.n].s.length;cashTurn();}
function cashTurn(){closeModal();var tm=teams[G.turn];G.board=shuffle(CASH[G.n].v);G.own=null;G.opened=[];G.r=0;G.step='pick';G.offers=[];G.bonus=false;
  progress(tm.name+' · turn '+(G.turn+1)+' of '+teams.length);strip();renderCash();}
function renderCash(){var tm=teams[G.turn],n=G.n,need=cashNeed(G.r),left=need-G.opened.length,v=CASH[n].v,off={};G.opened.forEach(function(i){off[G.board[i]]=1;});
  var sub=G.step==='pick'?'Pick the case you will keep. It stays closed until the end.':G.step==='open'?'Round '+(G.r+1)+' of '+G.R+': open '+left+' more case'+(left===1?'':'s')+'. Small amounts are good news.':'';
  var col=function(a){return a.map(function(x){return '<span class="'+(off[x]?'off':'')+(x>=v[v.length-4]?' hi':'')+'">'+money(x)+'</span>';}).join('');},half=Math.ceil(n/2);
  var h='<div class="gs-head"><div><div class="gs-turn"><i style="--tc:'+tm.color+'"></i>'+esc(tm.name)+'</div><p class="gs-muted" style="margin-top:4px">'+esc(sub)+'</p></div>'+(G.own!=null?'<div class="gs-case mine" aria-label="Your case">'+(G.own+1)+'</div>':'')+'</div>';
  if(G.opened.length)h+='<div class="gs-insight">Average of the '+cashLeft().length+' unopened cases: <b>'+money(Math.round(cashAvg()))+'</b>. That average is what playing on is "worth" on paper, but any single case could hold much less or much more.</div>';
  h+='<div class="gs-cash"><div class="gs-vb">'+col(v.slice(0,half))+'</div><div class="gs-cases" style="--cols:'+(n===24?6:4)+'">'+G.board.map(function(val,i){if(i===G.own)return '<div class="gs-case gone" aria-hidden="true"></div>';if(G.opened.indexOf(i)>-1)return '<div class="gs-case open"><small>#'+(i+1)+'</small>'+money(val)+'</div>';var can=G.step==='pick'||(G.step==='open'&&left>0);return '<button class="gs-case" data-gs="case" data-i="'+i+'"'+(can?'':' disabled')+' aria-label="Case '+(i+1)+'">'+(i+1)+'</button>';}).join('')+'</div><div class="gs-vb">'+col(v.slice(half))+'</div></div>';
  main(h);}
function cashClick(i){if(!G||G.board==null)return;if(G.step==='pick'){G.own=i;G.step='open';sfx('lock');renderCash();return;}
  if(G.step!=='open'||i===G.own||G.opened.indexOf(i)>-1)return;var need=cashNeed(G.r);if(G.opened.length>=need)return;G.opened.push(i);var val=G.board[i],v=CASH[G.n].v;sfx(val>=v[Math.floor(v.length/2)]?'wrong':'correct');renderCash();
  if(G.opened.length===need){G.step='wait';setTimeout(cashAsk,900);}}
function cashAsk(){if(!G||G.step!=='wait')return;var P=pool(grade());if(!P.length){G.bonus=false;return cashOffer();}var it=toItem(P[Math.floor(Math.random()*P.length)]);G.q=it;G.step='q';
  modal('<div class="gs-mhead"><div><div class="gs-k">Bonus question · '+esc(it.cat)+'</div><div class="gs-val">Answer right and the Banker’s offer goes up 10%.</div></div></div><div class="gs-q" style="min-height:0"><h2 class="gs-qtext" style="padding-right:0">'+esc(it.q)+'</h2></div><div class="gs-answers" id="gs-answers">'+it.opts.map(function(o,k){return '<button class="gs-ans '+CLS[k]+'" data-gs="c-ans" data-k="'+k+'"><b>'+LET[k]+'</b><span>'+esc(o)+'</span></button>';}).join('')+'</div><div id="gs-cq"></div>','Bonus question');}
function cashAnswer(k){if(!G||G.step!=='q')return;var it=G.q;G.bonus=k===it.correct;G.step='qdone';tally.total++;if(G.bonus&&G.turn===0)tally.right++;recap.push({c:it.cat,q:it.q,a:it.opts[it.correct],f:it.fact});
  var A=$('gs-answers');A.querySelectorAll('.gs-ans').forEach(function(b,i){b.disabled=true;b.classList.toggle('right',i===it.correct);});A.classList.add('revealed');sfx(G.bonus?'correct':'wrong');
  $('gs-cq').innerHTML='<p class="gs-result">'+(G.bonus?'Right! The offer goes up 10%.':'Not this time.')+'</p>'+(it.fact?'<div class="gs-fact"><span class="gs-k">Why it matters</span><span>'+esc(it.fact)+'</span></div>':'')+'<div class="gs-actions" style="margin-top:12px"><button class="gs-btn" data-gs="c-offer">Hear the Banker’s offer</button></div>';}
function cashOffer(){var avg=cashAvg(),amt=niceAmt(avg*(.15+.75*(G.R>1?G.r/(G.R-1):1))*(G.bonus?1.1:1));G.amt=amt;G.step='offer';G.offers.push(amt);sfx('ring');var pct=Math.round(amt/avg*100);
  var nextOpen=G.r+1<G.R?CASH[G.n].s[G.r+1]:0;
  modal('<div class="gs-mhead"><div><div class="gs-k">Round '+(G.r+1)+' of '+G.R+'</div><div class="gs-val">'+esc(teams[G.turn].name)+'</div></div></div><p class="gs-center gs-k">The Banker offers</p><div class="gs-big">'+money(amt)+'</div>'+(G.bonus?'<p class="gs-center"><span class="gs-pill">+10% bonus included</span></p>':'')
   +'<div class="gs-insight">The average of the unopened cases is <b>'+money(Math.round(avg))+'</b>, so this offer is <b>'+pct+'%</b> of that average. Taking it is a sure thing. Playing on is a risk: the result could be higher or lower.</div>'
   +(G.offers.length>1?'<p class="gs-note gs-center">Earlier offers: '+G.offers.slice(0,-1).map(money).join(' · ')+'</p>':'')
   +'<p class="gs-center gs-muted">Take the cash, or keep playing and '+(nextOpen?'open '+nextOpen+' more case'+(nextOpen>1?'s':''):'go to the final choice')+'?</p><div class="gs-actions"><button class="gs-btn" data-gs="c-deal">Take the cash</button><button class="gs-btn ghost" data-gs="c-play">Keep playing</button></div>','Banker offer');}
function cashPlayOn(){if(G.r+1<G.R){G.r++;G.step='open';G.bonus=false;closeModal();renderCash();return;}
  var other=-1;G.board.forEach(function(_,i){if(other<0&&i!==G.own&&G.opened.indexOf(i)<0)other=i;});G.other=other;G.step='final';
  modal('<div class="gs-mhead"><div><div class="gs-k">Final choice</div><div class="gs-val">'+esc(teams[G.turn].name)+'</div></div></div><p class="gs-qtext" style="font-size:clamp(20px,2.4vw,30px)">Two cases are left: yours (#'+(G.own+1)+') and #'+(other+1)+'. Keep yours or swap?</p><div class="gs-actions"><button class="gs-btn" data-gs="c-keep">Keep case #'+(G.own+1)+'</button><button class="gs-btn ghost" data-gs="c-swap">Swap for #'+(other+1)+'</button></div>','Final choice');}
function cashFinish(kind){var tm=teams[G.turn],ownV=G.board[G.own],won,line,best=Math.max.apply(null,[0].concat(G.offers));
  if(kind==='deal'){won=G.amt;line='Your case #'+(G.own+1)+' held '+money(ownV)+'. '+(won>=ownV?'You beat the Banker by '+money(won-ownV)+'.':'Your case was worth '+money(ownV-won)+' more this time.');}
  else{var p=kind==='swap'?G.other:G.own,alt=G.board[kind==='swap'?G.own:G.other];won=G.board[p];line=(kind==='swap'?'You swapped. Your old case held '+money(alt)+'.':'The other case held '+money(alt)+'.')+(best?(won>=best?' You beat every offer, up to '+money(best)+'.':' The best offer you turned down was '+money(best)+'.'):'');}
  prevRank=ranked();tm.score=won;tm.last=won;G.step='done';strip();sfx(won>=10000?'fanfare':'correct');recap.push({c:'Cash or Case · '+tm.name,q:'Final result',a:money(won),f:line});
  var last=G.turn+1>=teams.length;
  modal('<div class="gs-mhead"><div><div class="gs-k">Result</div><div class="gs-val">'+esc(tm.name)+'</div></div></div><p class="gs-center gs-k">'+esc(tm.name)+' wins</p><div class="gs-big">'+money(won)+'</div><p class="gs-center">'+esc(line)+'</p><div class="gs-fact"><span class="gs-k">Money lesson</span><span>A sure offer below the average trades some possible reward for certainty. That is the same choice people weigh with insurance, savings accounts, and investing.</span></div><div class="gs-actions"><button class="gs-btn" data-gs="c-next">'+(last?'See final results':esc(teams[G.turn+1].name)+'’s turn')+'</button></div>','Result');}

/* ---------- Closest Guess ---------- */
function fmtU(v,u){return u==='$'?money(v):u==='¢'?Math.round(v)+'¢':(Math.round(v*100)/100)+' '+u;}
function startGuess(){var gens=bank('GS_GUESS')[band(grade())],n=opt('guess','count'),items=[],order=shuffle(gens);for(var i=0;i<n;i++){items.push(order[i%order.length]());}G={items:items,i:-1};nextGuess();}
function nextGuess(){cancelAuto();G.i++;if(G.i>=G.items.length)return podium();var it=G.items[G.i];G.phase='answer';G.locks={};progress('Problem '+(G.i+1)+' of '+G.items.length);
  var unit=it.u==='$'?'dollars':it.u==='¢'?'cents':it.u;
  main('<div class="gs-q"><div class="gs-eyebrow">Closest Guess · answer in '+esc(unit)+'</div><h2 class="gs-qtext" style="padding-right:0">'+esc(it.q)+'</h2></div>'
   +'<div class="gs-locks">'+teams.map(function(t,ti){return '<div class="gs-lock" id="gs-lk-'+ti+'" style="--tc:'+t.color+'"><div class="nm">'+esc(t.name)+'</div><input type="number" inputmode="decimal" step="any" id="gs-gi-'+ti+'" aria-label="'+esc(t.name)+' answer in '+esc(unit)+'" placeholder="'+(it.u==='$'?'$':'')+'0"><button class="gs-btn sm" data-gs="g-lock" data-t="'+ti+'">Lock in</button><div class="st"></div></div>';}).join('')+'</div>'
   +'<div class="gs-fact" id="gs-fact" hidden></div><div class="gs-actions"><button class="gs-btn ghost" data-gs="g-reveal" id="gs-greveal">Reveal answer</button><button class="gs-btn" data-gs="g-next" id="gs-next" hidden>Next</button></div>');
  setTimeout(function(){var f=$('gs-gi-0');if(f)try{f.focus({preventScroll:true});}catch(e){}},60);}
function gLock(t){if(!G||G.phase!=='answer'||G.locks[t]!=null)return;var el=$('gs-gi-'+t),v=parseFloat(el&&el.value);if(!isFinite(v)){if(el)el.focus();return;}G.locks[t]=v;el.disabled=true;sfx('lock');var c=$('gs-lk-'+t);c.classList.add('locked');c.querySelector('.st').textContent='Locked in';c.querySelector('button').disabled=true;
  if(Object.keys(G.locks).length===teams.length)gReveal();}
function gReveal(){if(!G||G.phase!=='answer')return;teams.forEach(function(_,t){if(G.locks[t]==null){var el=$('gs-gi-'+t),v=parseFloat(el&&el.value);if(isFinite(v))G.locks[t]=v;}});G.phase='reveal';prevRank=ranked();
  var it=G.items[G.i],tol=Math.max(Math.abs(it.a)*.5,it.u==='¢'?10:it.u==='$'?2:2),bestErr=Infinity,bestT=[];
  teams.forEach(function(t,i){var v=G.locks[i];if(v==null)return;var e=Math.abs(v-it.a);if(e<bestErr-1e-9){bestErr=e;bestT=[i];}else if(Math.abs(e-bestErr)<1e-9)bestT.push(i);});
  teams.forEach(function(tm,i){var v=G.locks[i],c=$('gs-lk-'+i),gain=0,txt;if(v==null){txt='<span class="gs-gain zero">No answer</span>';}else{var e=Math.abs(v-it.a);gain=e<1e-9?1000:Math.max(0,Math.round(1000*(1-e/tol)/10)*10);if(teams.length>1&&bestT.indexOf(i)>-1&&gain>0&&e>=1e-9)gain+=200;txt=(gain?'<span class="gs-gain">+'+money(gain)+'</span>':'<span class="gs-gain zero">Too far</span>')+' · guessed '+esc(fmtU(v,it.u))+(e<1e-9?' · Bullseye!':teams.length>1&&bestT.indexOf(i)>-1?' · closest':'');}
    tm.score+=gain;tm.last=gain;if(c){c.classList.add('locked');c.querySelector('.st').innerHTML=txt;var b=c.querySelector('button');if(b)b.disabled=true;var inp=c.querySelector('input');if(inp)inp.disabled=true;}});
  tally.total++;if(G.locks[0]!=null&&Math.abs(G.locks[0]-it.a)<=Math.max(.01,Math.abs(it.a)*.05))tally.right++;
  var f=$('gs-fact');f.hidden=false;f.innerHTML='<span class="gs-k">Answer: '+esc(fmtU(it.a,it.u))+'</span><span>'+esc(it.x)+'</span>';recap.push({c:'Closest Guess',q:it.q,a:fmtU(it.a,it.u),f:it.x});
  sfx(bestErr<1e-9?'correct':'lock');strip();$('gs-greveal').hidden=true;var nx=$('gs-next');nx.hidden=false;var last=G.i+1>=G.items.length;nx.textContent=last?'See final results':teams.length>1?'Leaderboard':'Next problem';autoNext(gNext,'Next');}
function gNext(){if(G.i+1>=G.items.length)return podium();if(teams.length===1)return nextGuess();leaderboard(nextGuess,'Next problem');}

/* ---------- Money Crossword (built from the grade's vocabulary) ---------- */
function cwNorm(t){return String(t||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toUpperCase().replace(/[^A-Z]/g,'');}
function cwBank(g){var out=[],seen={};lessonsFor(g).forEach(function(l){if(+l.week>maxWeek())return;(l.vocab||[]).forEach(function(v){if(!v||!v.term||!v.def)return;var ans=cwNorm(v.term);if(ans.length<3||ans.length>12||seen[ans])return;seen[ans]=1;
  var words=String(v.term).trim().split(/\s+/).length,re=new RegExp(String(v.term).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'ig'),clue=String(v.def).replace(re,'___');out.push([ans,clue+(words>1?' ('+words+' words)':'')]);});});return out;}
function cwCells(w){var a=[];for(var k=0;k<w.ans.length;k++)a.push([w.r+(w.dir==='d'?k:0),w.c+(w.dir==='a'?k:0)]);return a;}
function cwBuild(bank,count,max){var best=null;
  for(var attempt=0;attempt<30;attempt++){var poolW=shuffle(bank).slice(0,Math.min(bank.length,count*4)),start=poolW.slice(0,6).sort(function(a,b){return b[0].length-a[0].length;})[0];if(!start)break;
    var grid={},dirs={},words=[],minR=0,maxR=0,minC=0,maxC=0;
    var put=function(ans,clue,r,c,d){for(var k=0;k<ans.length;k++){var rr=r+(d==='d'?k:0),cc=c+(d==='a'?k:0),key=rr+','+cc;grid[key]=ans[k];(dirs[key]=dirs[key]||{})[d]=1;minR=Math.min(minR,rr);maxR=Math.max(maxR,rr);minC=Math.min(minC,cc);maxC=Math.max(maxC,cc);}words.push({ans:ans,clue:clue,r:r,c:c,dir:d});};
    put(start[0],start[1],0,0,'a');
    var fit=function(ans,r,c,d){var dr=d==='d'?1:0,dc=d==='a'?1:0,cross=0;if(grid[(r-dr)+','+(c-dc)]||grid[(r+dr*ans.length)+','+(c+dc*ans.length)])return -1;
      for(var k=0;k<ans.length;k++){var rr=r+dr*k,cc=c+dc*k,key=rr+','+cc,ex=grid[key];if(ex){if(ex!==ans[k]||dirs[key][d])return -1;cross++;}else{var s1=d==='a'?(rr-1)+','+cc:rr+','+(cc-1),s2=d==='a'?(rr+1)+','+cc:rr+','+(cc+1);if(grid[s1]||grid[s2])return -1;}}
      var nR=Math.min(minR,r),xR=Math.max(maxR,r+dr*(ans.length-1)),nC=Math.min(minC,c),xC=Math.max(maxC,c+dc*(ans.length-1));if(xR-nR+1>max||xC-nC+1>max)return -1;return cross;};
    poolW.forEach(function(e){var ans=e[0];if(words.length>=count||words.some(function(w){return w.ans===ans;}))return;var cands=[];
      Object.keys(grid).forEach(function(key){var p=key.split(',').map(Number),ch=grid[key];for(var i=0;i<ans.length;i++){if(ans[i]!==ch)continue;['a','d'].forEach(function(d){if(dirs[key][d])return;var r0=d==='d'?p[0]-i:p[0],c0=d==='a'?p[1]-i:p[1],x=fit(ans,r0,c0,d);if(x>0)cands.push({r:r0,c:c0,d:d,x:x});});}});
      if(!cands.length)return;cands.sort(function(a,b){return b.x-a.x||Math.random()-.5;});put(ans,e[1],cands[0].r,cands[0].c,cands[0].d);});
    var score=words.length*100-((maxR-minR+1)*(maxC-minC+1))/10;
    if(!best||score>best.score)best={score:score,words:words.map(function(w){return {ans:w.ans,clue:w.clue,r:w.r-minR,c:w.c-minC,dir:w.dir};}),h:maxR-minR+1,w:maxC-minC+1};
    if(best.words.length>=count&&attempt>6)break;}
  if(!best)return null;var starts={};best.words.forEach(function(w){starts[w.r+','+w.c]=1;});var order=Object.keys(starts).map(function(k){return k.split(',').map(Number);}).sort(function(a,b){return a[0]-b[0]||a[1]-b[1];}),num={};order.forEach(function(p,i){num[p[0]+','+p[1]]=i+1;});
  best.words.forEach(function(w){w.n=num[w.r+','+w.c];w.id=w.n+w.dir;});best.words.sort(function(a,b){return a.n-b.n||(a.dir<b.dir?-1:1);});return best;}
function cwPts(w,h){return Math.max(50,100+20*w.ans.length-20*(h||0));}
function startCross(){var bank=cwBank(grade());if(bank.length<4)return noContent('Not enough vocabulary for a crossword in this grade yet.');var P=cwBuild(bank,opt('cross','size'),13);if(!P||P.words.length<3)return noContent('Could not build a crossword this time. Please try again.');
  G={puz:P,solved:{},hints:{},turn:0,sel:P.words[0],T:opt('cross','time'),msg:''};cwTurn();}
function cwLetter(r,c){for(var i=0;i<G.puz.words.length;i++){var w=G.puz.words[i],idx=-1;cwCells(w).forEach(function(p,k){if(p[0]===r&&p[1]===c)idx=k;});if(idx<0)continue;if(G.solved[w.id]!=null)return w.ans[idx];if(G.hints[w.id]&&G.hints[w.id][idx])return w.ans[idx];}return '';}
function cwColor(r,c){for(var i=0;i<G.puz.words.length;i++){var w=G.puz.words[i];if(G.solved[w.id]==null)continue;if(cwCells(w).some(function(p){return p[0]===r&&p[1]===c;}))return teams[G.solved[w.id]].color;}return null;}
function cwTurn(){stopClock();cancelAuto();var left=G.puz.words.filter(function(w){return G.solved[w.id]==null;}).length;progress(left+' of '+G.puz.words.length+' clues left');strip();renderCross();
  if(G.T)G.t0=startClock(G.T,'gs-timer',function(){sfx('timesup');G.msg='Time is up.';cwPass();});setTimeout(function(){var i=$('gs-cwi');if(i&&!('ontouchstart' in window))try{i.focus({preventScroll:true});}catch(e){}},50);}
function renderCross(){var P=G.puz,sel=G.sel,tm=teams[G.turn],many=teams.length>1,cells={},nums={},selSet={};P.words.forEach(function(w){cwCells(w).forEach(function(p){cells[p[0]+','+p[1]]=1;});nums[w.r+','+w.c]=w.n;});if(sel)cwCells(sel).forEach(function(p){selSet[p[0]+','+p[1]]=1;});
  var g='';for(var r=0;r<P.h;r++)for(var c=0;c<P.w;c++){var k=r+','+c;if(!cells[k]){g+='<span class="gs-xcell" aria-hidden="true"></span>';continue;}var L=cwLetter(r,c),col=cwColor(r,c);g+='<button class="gs-cell'+(selSet[k]?' sel':'')+(col?' on':'')+'" data-gs="cw-cell" data-r="'+r+'" data-c="'+c+'"'+(col?' style="--tc:'+col+'"':'')+' aria-label="Cell'+(nums[k]?' '+nums[k]:'')+(L?', '+L:'')+'">'+(nums[k]?'<i>'+nums[k]+'</i>':'')+'<b>'+L+'</b></button>';}
  var solved=sel&&G.solved[sel.id]!=null,hn=sel&&G.hints[sel.id]?Object.keys(G.hints[sel.id]).length:0;
  var li=function(w){return '<li><button class="'+(G.solved[w.id]!=null?'done':'')+(sel&&sel.id===w.id?' sel':'')+'" data-gs="cw-pick" data-id="'+w.id+'"><b>'+w.n+'</b><span>'+esc(w.clue)+' <small class="gs-muted">('+w.ans.length+')</small></span></button></li>';};
  main('<div class="gs-head"><div><div class="gs-turn"><i style="--tc:'+tm.color+'"></i>'+(many?esc(tm.name)+'’s turn':esc(tm.name))+'</div><p class="gs-muted" style="margin-top:4px">'+(many?'Pick any clue and type the answer. A wrong answer passes the turn.':'Pick any clue and type the answer.')+'</p></div>'+(G.T?'<div class="gs-timer dark" id="gs-timer" role="timer" aria-label="Time left"><span>'+G.T+'</span></div>':'')+'</div>'
   +'<div class="gs-cw"><div class="gs-grid" style="--cols:'+P.w+'">'+g+'</div><div class="gs-cwside"><form class="gs-cwform" id="gs-cwf" autocomplete="off"><span class="gs-k">'+(sel?sel.n+' '+(sel.dir==='a'?'Across':'Down')+' · '+sel.ans.length+' letters · worth '+money(cwPts(sel,hn)):'Pick a clue')+'</span><p style="font-weight:700">'+(sel?esc(sel.clue):'')+'</p>'
   +'<div class="gs-row"><input id="gs-cwi" maxlength="'+(sel?sel.ans.length+6:26)+'" autocapitalize="characters" spellcheck="false" aria-label="Your answer"'+(solved||!sel?' disabled':'')+'><button class="gs-btn" type="submit"'+(solved||!sel?' disabled':'')+'>Check</button></div>'
   +'<div class="gs-row"><button type="button" class="gs-btn sm ghost" data-gs="cw-hint"'+(!sel||solved||hn>=sel.ans.length-1?' disabled':'')+'>Buy a letter (−$20)</button>'+(many?'<button type="button" class="gs-btn sm ghost" data-gs="cw-pass">Pass the turn</button>':'')+'<button type="button" class="gs-btn sm ghost" data-gs="podium">Finish puzzle</button></div><p aria-live="polite" style="min-height:22px;font-weight:700">'+esc(G.msg||(solved?'Solved by '+teams[G.solved[sel.id]].name+'.':''))+'</p></form>'
   +'<div class="gs-clist"><div><span class="gs-k">Across</span><ol>'+P.words.filter(function(w){return w.dir==='a';}).map(li).join('')+'</ol></div><div><span class="gs-k">Down</span><ol>'+P.words.filter(function(w){return w.dir==='d';}).map(li).join('')+'</ol></div></div></div></div>');}
function cwSelect(id){var w=G.puz.words.filter(function(x){return x.id===id;})[0];if(!w)return;G.sel=w;G.msg='';sfx('select');renderCross();var i=$('gs-cwi');if(i&&!i.disabled)try{i.focus({preventScroll:true});}catch(e){}}
function cwCheck(){if(!G||!G.sel||G.solved[G.sel.id]!=null)return;var el=$('gs-cwi'),g=cwNorm(el&&el.value),w=G.sel;if(!g)return;
  if(g===w.ans){var hn=G.hints[w.id]?Object.keys(G.hints[w.id]).length:0,pts=cwPts(w,hn),tm=teams[G.turn];G.solved[w.id]=G.turn;tm.score+=pts;tm.last=pts;G.msg='Right! '+tm.name+' +'+money(pts);tally.total++;if(G.turn===0)tally.right++;recap.push({c:'Crossword',q:w.clue,a:w.ans,f:''});sfx('correct');
    var next=G.puz.words.filter(function(x){return G.solved[x.id]==null;})[0];strip();if(!next){stopClock();renderCross();G.endTO=setTimeout(function(){if(mode==='cross')podium();},1500);return;}G.sel=next;cwTurn();return;}
  sfx('wrong');G.msg='Not quite.'+(teams.length>1?' The turn passes.':' Try again.');if(teams.length>1)return cwPass();renderCross();}
function cwPass(){G.turn=(G.turn+1)%teams.length;cwTurn();}
function cwHint(){if(!G.sel||G.solved[G.sel.id]!=null)return;var w=G.sel,h=G.hints[w.id]=G.hints[w.id]||{},free=[];cwCells(w).forEach(function(p,i){if(!cwLetter(p[0],p[1]))free.push(i);});if(free.length<=1)return;h[free[Math.floor(Math.random()*free.length)]]=1;sfx('select');G.msg='';renderCross();}
function cwCell(r,c){var ws=G.puz.words.filter(function(w){return cwCells(w).some(function(p){return p[0]===r&&p[1]===c;});});if(!ws.length)return;var open=ws.filter(function(w){return G.solved[w.id]==null;}),list=open.length?open:ws,cur=-1;list.forEach(function(w,i){if(G.sel&&w.id===G.sel.id)cur=i;});cwSelect(list[(cur+1)%list.length].id);}

/* ---------- podium, history, recap ---------- */
function podium(){if(mode==='podium')return;stopAll();closeModal();var kind=lastMode;mode='podium';bar();strip();progress('Final results');
  var r=ranked(),top=r.slice(0,3),tie=r.length>1&&teams[r[0]].score===teams[r[1]].score,h='';
  if(kind==='daily'){var d=load('mmGSDaily_v1',{}),tk=todayKey(),first=d.last!==tk;if(first){var y=new Date();y.setDate(y.getDate()-1);var yk=y.getFullYear()+'-'+String(y.getMonth()+1).padStart(2,'0')+'-'+String(y.getDate()).padStart(2,'0');d.streak=d.last===yk?(d.streak||0)+1:1;d.best=Math.max(d.best||0,d.streak);d.last=tk;save('mmGSDaily_v1',d);}
    h='<div class="gs-pod"><div class="gs-k">Daily 5 · '+esc(gradeName(grade()))+'</div><h2>'+tally.right+' of '+tally.total+' correct</h2><p class="gs-muted">'+money(teams[0].score)+' earned'+(d.streak?' · streak '+d.streak+' day'+(d.streak===1?'':'s'):'')+'. Come back tomorrow for five new questions.</p>';}
  else{h='<div class="gs-pod"><h2>'+(teams.length===1?'Final score: '+money(teams[0].score):tie?'It’s a tie!':esc(teams[r[0]].name)+' wins!')+'</h2>'+(teams.length>1?'<div class="gs-stands">'+[1,0,2].filter(function(i){return top[i]!==undefined;}).map(function(i){var tm=teams[top[i]];return '<div class="gs-stand p'+(i+1)+'" style="--tc:'+tm.color+'"><div class="n">'+esc(tm.name)+'</div><div class="s">'+money(tm.score)+'</div><div class="blk">'+(i+1)+'</div></div>';}).join('')+'</div>':'<p class="gs-muted">'+tally.right+' of '+tally.total+' correct</p>')
    +(r.length>3?'<div class="gs-rest">'+r.slice(3).map(function(t,i){return '<div><span>'+(i+4)+'. '+esc(teams[t].name)+'</span><b>'+money(teams[t].score)+'</b></div>';}).join('')+'</div>':'');}
  h+='<div class="gs-row c"><button class="gs-btn" data-gs="again">'+(kind==='daily'?'Practice again':'Play again')+'</button>'+(recap.length?'<button class="gs-btn ghost" data-gs="recap">What we learned</button>':'')+'<button class="gs-btn ghost" data-gs="lobby">Back to the lobby</button></div></div>';
  main(h);sfx('fanfare');confetti();
  var hist=load('mmGSHistory_v1',[]);hist.push({t:Date.now(),m:kind,g:grade(),list:r.map(function(t){return {n:teams[t].name,s:teams[t].score};})});save('mmGSHistory_v1',hist.slice(-40));
  if(isStudent()&&teams.length===1&&tally.total){try{if(typeof mmRecordGame==='function')mmRecordGame('Game Show: '+MODE_NAME[kind],{k2:'easy','35':'medium','68':'challenge'}[band(grade())],tally.right,tally.total);}catch(e){}}
  if(G&&G.savedTeams){teams=G.savedTeams;}}
function showRecap(){var h='<div class="gs-mhead"><div><div class="gs-k">'+esc(MODE_NAME[lastMode]||'')+' · '+esc(gradeName(grade()))+'</div><h2 style="font:700 26px var(--disp)">What we learned</h2></div><button class="gs-x" data-gs="m-close" aria-label="Close">×</button></div><div class="gs-recap">'
   +recap.map(function(x,i){return '<div><div class="gs-k">'+(i+1)+' · '+esc(x.c)+'</div><div style="font-weight:700">'+esc(x.q)+'</div><div class="a">'+esc(x.a)+'</div>'+(x.f?'<div class="gs-muted">'+esc(x.f)+'</div>':'')+'</div>';}).join('')+'</div><div class="gs-actions"><button class="gs-btn" data-gs="recap-print">Print the recap</button><button class="gs-btn ghost" data-gs="m-close">Close</button></div>';modal(h,'What we learned');}
function printRecap(){var body='<div class="k">Money Matters · Game Show recap</div><h1>What we learned</h1><p class="sub">'+esc(MODE_NAME[lastMode]||'')+' · '+esc(gradeName(grade()))+' · '+new Date().toLocaleDateString()+'</p><ol>'+recap.map(function(x){return '<li style="margin:0 0 12px"><div style="font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#7a5a1e">'+esc(x.c)+'</div><b>'+esc(x.q)+'</b><div style="color:#1d6b47;font-weight:700">'+esc(x.a)+'</div>'+(x.f?'<div style="color:#555">'+esc(x.f)+'</div>':'')+'</li>';}).join('')+'</ol>';
  try{if(MM().util&&MM().util.openHTML){MM().util.openHTML('Game Show recap',body);return;}}catch(e){}
  try{var w=window.open('','_blank');if(w){w.document.write('<!doctype html><title>Recap</title><body style="font-family:system-ui;padding:24px">'+body);w.document.close();w.print();}}catch(e){}}
function confetti(){if(reduced())return;var cv=$('gs-confetti');if(!cv)return;var W=cv.width=ROOT.clientWidth,H=cv.height=ROOT.clientHeight,ctx=cv.getContext('2d'),P=[],cols=['#e0b24a','#2f9e6b','#2f7dd1','#d0603f','#f6f0e2'];
  for(var i=0;i<140;i++)P.push({x:Math.random()*W,y:-20-Math.random()*H*.5,vx:(Math.random()-.5)*3,vy:2+Math.random()*3,r:4+Math.random()*5,a:Math.random()*6,c:cols[i%cols.length]});var t0=performance.now();
  (function f(now){ctx.clearRect(0,0,W,H);P.forEach(function(p){p.x+=p.vx;p.y+=p.vy;p.a+=.1;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.a);ctx.fillStyle=p.c;ctx.fillRect(-p.r/2,-p.r/4,p.r,p.r/2);ctx.restore();});if(now-t0<3500&&mode==='podium')requestAnimationFrame(f);else ctx.clearRect(0,0,W,H);})(t0);}

/* ---------- events ---------- */
function onClick(e){var b=e.target.closest('[data-gs]');if(!b||!ROOT.contains(b)||b.disabled)return;var a=b.getAttribute('data-gs'),t=+b.getAttribute('data-t'),k=+b.getAttribute('data-k');
  switch(a){
  case 'close':close();break;
  case 'lobby':if(mode==='lobby'||mode==='podium'){lobby();break;}confirmQuit(lobby);break;
  case 'quit':confirmQuit(lobby);break;
  case 'sfx':prefs.sfx=!prefs.sfx;savePrefs();bar();if(prefs.sfx)sfx('select');break;
  case 'big':prefs.big=!prefs.big;savePrefs();bar();break;
  case 'fs':try{if(document.fullscreenElement)document.exitFullscreen();else ROOT.requestFullscreen();}catch(x){}break;
  case 'playas':prefs.playAs=b.getAttribute('data-v');initTeams();lobby();break;
  case 'add':addTeam();rememberNames();lobby();break;
  case 'rm':if(teams.length>1){teams.splice(+b.getAttribute('data-i'),1);teams.forEach(function(x,i){x.color=COLORS[i];});rememberNames();lobby();}break;
  case 'split':splitRoster();break;
  case 'start':launch(b.getAttribute('data-m'));break;
  case 'live':if(window.MMGameShowLive)window.MMGameShowLive.host();break;
  case 'pick':pick(t,k);break;
  case 'q-reveal':reveal();break;
  case 'q-next':cancelAuto();qNext();break;
  case 'lb-next':cancelAuto();if(G&&G.lbNext)G.lbNext();break;
  case 'ctl':if(mode==='board'&&G&&!G.cur&&!G.fin){G.active=t;renderBoard();}break;
  case 'tile':openTile(+b.getAttribute('data-c'),+b.getAttribute('data-r'));break;
  case 'dd-lock':{var el=$('gs-dd'),v=Math.round(+el.value||0);G.cur.value=Math.max(5,Math.min(G.cur.max,v));showClue();break;}
  case 'bpick':bpick(t,k);break;
  case 'b-reveal':(G.cur?boardReveal:finalReveal)();break;
  case 'b-done':boardDone();break;
  case 'final':if(!G.finalDone&&!G.cur&&!G.fin)startFinal();break;
  case 'fw-cancel':G.fin=null;closeModal();break;
  case 'fw-lock':finalLock();break;
  case 'podium':podium();break;
  case 'o-card':oCard(k);break;
  case 'o-slot':oSlot(+b.getAttribute('data-j'));break;
  case 'o-submit':submitOrder();break;
  case 'o-next':cancelAuto();oNext();break;
  case 'case':cashClick(+b.getAttribute('data-i'));break;
  case 'c-ans':cashAnswer(k);break;
  case 'c-offer':cashOffer();break;
  case 'c-deal':cashFinish('deal');break;
  case 'c-play':cashPlayOn();break;
  case 'c-keep':cashFinish('keep');break;
  case 'c-swap':cashFinish('swap');break;
  case 'c-next':if(G.turn+1>=teams.length)podium();else{G.turn++;cashTurn();}break;
  case 'g-lock':gLock(t);break;
  case 'g-reveal':gReveal();break;
  case 'g-next':cancelAuto();gNext();break;
  case 'cw-pick':cwSelect(b.getAttribute('data-id'));break;
  case 'cw-cell':cwCell(+b.getAttribute('data-r'),+b.getAttribute('data-c'));break;
  case 'cw-hint':cwHint();break;
  case 'cw-pass':cwPass();break;
  case 'again':launch(lastMode);break;
  case 'recap':showRecap();break;
  case 'recap-print':printRecap();break;
  case 'm-close':closeModal();break;
  case 'auto-now':{var f=autoFn;cancelAuto();if(f)f();break;}
  case 'auto-stop':cancelAuto();break;}}
function onChange(e){var el=e.target;if(el.hasAttribute('data-gs-opt')){var p=el.getAttribute('data-gs-opt').split('|');prefs.opt[p[0]]=prefs.opt[p[0]]||{};prefs.opt[p[0]][p[1]]=+el.value;savePrefs();}
  else if(el.getAttribute('data-gs-ch')==='grade'){chosenGrade=el.value;lobby();}
  else if(el.getAttribute('data-gs-ch')==='auto'){prefs.auto=+el.value;savePrefs();}}
function onInput(e){var el=e.target;if(el.hasAttribute('data-gs-name')){var i=+el.getAttribute('data-gs-name');if(teams[i]){teams[i].name=el.value.trim()||defName(i);rememberNames();}}}
function onKey(e){if(!ROOT||ROOT.hidden)return;var mb=$('mm-modal-backdrop');if(mb){var cs=getComputedStyle(mb);if(cs.display!=='none'&&cs.visibility!=='hidden'&&+cs.opacity>0)return;}
  if(e.key==='Escape'){e.stopPropagation();e.preventDefault();var w=$('gs-modal');if(mode==='lobby'){if(w&&!w.hidden){closeModal();return;}close();return;}if(w&&!w.hidden){if(mode==='board'&&G&&G.cur&&G.phase==='reveal'){boardDone();return;}if(mode==='podium'||(mode==='live')){closeModal();return;}return;}confirmQuit(lobby);return;}
  var tg=e.target&&e.target.tagName;if(/INPUT|SELECT|TEXTAREA/.test(tg)){if(e.key==='Enter'&&e.target.id&&/^gs-gi-/.test(e.target.id)){e.preventDefault();gLock(+e.target.id.slice(6));}return;}
  if(G&&teams.length===1&&G.phase==='answer'&&G.items&&(mode==='rush'||mode==='tf'||mode==='who'||mode==='daily')){var m={a:0,b:1,c:2,d:3,'1':0,'2':1,'3':2,'4':3,t:0,f:1}[String(e.key).toLowerCase()];var n=G.items[G.i].opts.length;if(m!=null&&m<n){e.preventDefault();pick(0,m);}}}
function confirmQuit(then){var go=function(ok){if(ok)then();};try{if(typeof mmConfirm==='function'){mmConfirm('End this game?','Scores for this game will be lost.','End game','🎲').then(go);return;}}catch(e){}go(window.confirm('End this game?'));}

/* ---------- public ---------- */
var lastFocus=null,inerted=[];
function hostInert(on){if(on){inerted=[];[].forEach.call(document.body.children,function(e){if(e===ROOT||/^(mm-modal-backdrop|info-toast|mm-auth|autosave-toast)$/.test(e.id)||e.tagName==='SCRIPT'||e.tagName==='STYLE'||e.hasAttribute('inert'))return;e.setAttribute('inert','');inerted.push(e);});}else{inerted.forEach(function(e){e.removeAttribute('inert');});inerted=[];}}
function open(m,o){build();o=o||{};chosenGrade=o.grade||null;lastFocus=document.activeElement;initTeams();ROOT.hidden=false;hostInert(true);document.documentElement.classList.add('mm-gs-on');
  if(m&&(MODE_NAME[m])){launch(m);}else lobby();setTimeout(function(){try{$('gs-main').focus({preventScroll:true});}catch(e){}},30);}
function close(){if(!ROOT)return;runLeave();stopAll();closeModal();if(G&&G.savedTeams)teams=G.savedTeams;mode='lobby';G=null;ROOT.hidden=true;hostInert(false);document.documentElement.classList.remove('mm-gs-on');try{if(document.fullscreenElement)document.exitFullscreen();}catch(e){}if(lastFocus&&lastFocus.focus)try{lastFocus.focus();}catch(e){}}
window.MMGameShow={bank:bank,_:{$:$,esc:esc,money:money,shuffle:shuffle,grade:grade,band:band,gradeName:gradeName,pool:pool,toItem:toItem,quizItems:quizItems,pickFresh:pickFresh,sfx:sfx,main:main,progress:progress,modal:modal,closeModal:closeModal,startClock:startClock,stopClock:stopClock,confetti:confetti,opt:opt,fmtU:fmtU,lang:lang,isStaff:isStaff,sampleOn:sampleOn,root:function(){return ROOT;},build:build,setMode:function(m,name){mode=m;lastMode=m;MODE_NAME[m]=name||MODE_NAME[m]||m;bar();strip();},onLeave:function(f){leaveHooks.push(f);},recap:function(list){recap=list;},showRecap:showRecap,confirmQuit:confirmQuit,lobby:lobby,isOpen:function(){return !!ROOT&&!ROOT.hidden;}},open:open,close:close,modes:MODES.map(function(m){return {id:m.id,name:m.name,tag:m.tag,desc:m.desc};}),name:function(id){return MODE_NAME[id]||id;}};
})();
