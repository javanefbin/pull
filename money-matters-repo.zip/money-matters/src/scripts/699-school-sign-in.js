/* =====================================================================
   V22 · SIGN IN WITH CLEVER OR CLASSLINK  (window.MMSchoolSignIn)
   Hosted build only. Shown on the sign-in screen for students and adults
   once the site has Clever and/or ClassLink keys (see /api/config and
   functions/api/sso/).
   Flow
     1. "Clever" sends the person to /api/sso/clever?n=<nonce>. The nonce stays
        in this tab's sessionStorage.
     2. They come back to /#mm-sso=<signed result>. We remove it from the
        address bar at once, then /api/sso-verify checks it against the nonce.
     3. Adults: the account on this device with the same email (or already
        linked to this school account). On a brand-new device the first adult
        becomes its administrator, as with Google or Microsoft.
        Students: the student already linked to this school account, else the
        one student here with exactly the same name (then linked), else class
        sync (664-class-sync.js) finds them in their class. A student who isn't
        on this device and isn't in a synced class is asked to sign in once with
        their username and code; that links the two, so next time the school
        account is enough on every device of the class.
     4. When the district or email is licensed, the device also gets a device
        token and reloads with the full program.
   Portal launches (Clever Portal, Instant Login, ClassLink LaunchPad) arrive as
   /#mm-sso-start=<provider> and start step 1 automatically.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var ACC=MM.accounts,GATE=MM.gate,A=MM.auth,U=MM.util;
var HOSTED=!!window.MM_PUBLIC_BUILD&&/^https?:$/.test(location.protocol);
var NAMES={clever:'Clever',classlink:'ClassLink'};
var KEY='mmSso_v1',PENDING='mmSsoPending_v1',list=[],busy=false;
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function say(m,cls){try{GATE.message(m,cls||'');}catch(e){try{U.toast(m,5000);}catch(x){}}}
function rand(n){var a=new Uint8Array(n||24);crypto.getRandomValues(a);return btoa(String.fromCharCode.apply(null,a)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function normName(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]+/g,' ').trim();}
function linkKey(res){return res.provider+':'+res.sub;}

var API=window.MMSchoolSignIn={enabled:function(){return list.length>0;},providers:function(){return list.slice();},start:start,_finish:finish,_setConfig:function(c){list=(c&&c.sso||[]).filter(function(p){return NAMES[p];});inject();},_linkPending:linkPending};

/* ---------- buttons on the sign-in screen (student and adult views, and first-run setup) ---------- */
function buttons(){return '<div class="mm-sso" role="group" aria-label="'+esc(T('Sign in with your school account'))+'"><div class="mm-social-or"><span>'+esc(T('or use your school account'))+'</span></div><div class="mm-social-row">'
  +list.map(function(p){return '<button type="button" class="mm-social-btn mm-sso-btn" data-sso="'+p+'"><span class="mm-social-mark mm-sso-'+p+'" aria-hidden="true">'+(p==='clever'?'C':'CL')+'</span>'+esc(NAMES[p])+'</button>';}).join('')+'</div></div>';}
function inject(){if(!list.length)return;var g=document.getElementById('mm-auth');if(!g||g.classList.contains('mm-hidden')||g.querySelector('.mm-sso'))return;
  var anchor=g.querySelector('[data-a=login]')||g.querySelector('[data-a=dosetup]');if(!anchor||!anchor.parentNode)return;
  var d=document.createElement('div');d.innerHTML=buttons();
  var social=anchor.parentNode.querySelector('.mm-social');(social||anchor).parentNode.insertBefore(d.firstChild,(social||anchor).nextSibling);}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-sso]');if(!b)return;e.preventDefault();e.stopPropagation();start(b.getAttribute('data-sso'));},true);

/* ---------- 1. leave for the provider ---------- */
function start(p){if(busy||!NAMES[p])return;busy=true;var n=rand(24);
  try{sessionStorage.setItem(KEY,JSON.stringify({p:p,n:n,at:Date.now()}));}catch(e){}
  say(T('Opening')+' '+NAMES[p]+'…','info');location.assign('/api/sso/'+p+'?n='+encodeURIComponent(n));}

/* ---------- 2. back from the provider ---------- */
function returning(){var h=location.hash||'',m;
  if((m=/^#mm-sso-start=(clever|classlink)$/.exec(h))){clean();if(A.get())try{GATE.signOut('school sign-in');}catch(e){}start(m[1]);return true;}
  if((m=/^#mm-sso-error=(.*)$/.exec(h))){clean();var msg='';try{msg=decodeURIComponent(m[1]);}catch(e){msg=m[1];}say(T('School sign-in did not finish')+': '+msg,'err');return true;}
  if(!(m=/^#mm-sso=(MMA1\.[A-Za-z0-9_\-.]+)$/.exec(h)))return false;
  clean();var st=null;try{st=JSON.parse(sessionStorage.getItem(KEY)||'null');sessionStorage.removeItem(KEY);}catch(e){}
  if(!st||!st.n){say(T('This sign-in was started in another browser or tab. Please sign in again here.'),'err');return true;}
  say(T('Finishing sign-in with')+' '+(NAMES[st.p]||'')+'…','info');
  fetch('/api/sso-verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({a:m[1],n:st.n})})
    .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j;});})
    .then(finish).catch(function(err){say(T('School sign-in did not finish')+': '+(err&&err.message||err),'err');});
  return true;}
function clean(){try{history.replaceState(null,'',location.pathname+location.search);}catch(e){}}

/* ---------- 3-4. sign in on this device ---------- */
function license(res){if(!res.token)return false;try{localStorage.setItem('mmAccess_v1',res.token);}catch(e){}return !window.__MM_FULL;}
function reloadSoon(){try{U.toast(T('Unlocking the full program…'),2500);}catch(e){}setTimeout(function(){location.reload();},900);}
function finish(res){
  if(!res||!res.sub){say(T('School sign-in did not say who you are.'),'err');return Promise.resolve(false);}
  var via=NAMES[res.provider]||res.provider,unlocked=license(res);
  if(res.role==='student')return student(res,via,unlocked);
  return adult(res,via,unlocked);}

function adult(res,via,unlocked){var key=linkKey(res),email=String(res.email||'').toLowerCase();
  var acc=ACC.list().filter(function(a){return a.role!=='student'&&(a.sso||[]).indexOf(key)>-1;})[0]
    ||(email?ACC.list().filter(function(a){return a.role!=='student'&&String(a.email||'').toLowerCase()===email;})[0]:null)||null;
  var make=Promise.resolve(acc);
  if(!acc&&!ACC.admins().length){
    make=ACC.add({username:ACC.uniqueUsername((email.split('@')[0]||normName(res.name).replace(/ /g,'.')||'admin').slice(0,20)),name:res.name||email||'Administrator',email:email,role:'admin',password:rand(18),by:'sign-in:'+res.provider})
      .then(function(r){if(r.error)throw new Error(r.error);try{localStorage.setItem('mmSetupDone','1');}catch(e){}ACC.log('user-add',r.account.u,'Administrator (signed in with '+via+')');return r.account;});}
  return make.then(function(a){
    if(!a){say(T('Signed in with')+' '+via+(res.name?' '+T('as')+' '+res.name:'')+'. '+T('This device has no Money Matters account for you. Ask your administrator to add your email in Admin Console → Users, then sign in again.')+(unlocked?' '+T('The full program is unlocked on this device.'):''),unlocked?'info':'err');if(unlocked)setTimeout(function(){location.reload();},2600);return false;}
    if(a.locked||a.pending){say(T('Your account on this device is locked or waiting for approval. Ask your administrator.'),'err');return false;}
    ACC.update(a.u,function(x){x.sso=(x.sso||[]).filter(function(k){return k!==linkKey(res);}).concat(linkKey(res));if(!x.email&&res.email)x.email=String(res.email).toLowerCase();});
    if(!GATE.signInAccount(ACC.get(a.u),{})){say(T('Could not sign in.'),'err');return false;}
    if(!res.licensed&&res.reason)setTimeout(function(){try{U.toast(T(res.reason)+' '+T('You are using the free edition (week 1 of every grade).'),6000);}catch(e){}},800);
    if(unlocked)reloadSoon();return true;
  }).catch(function(err){say(String(err&&err.message||err),'err');return false;});}

function student(res,via,unlocked){var key=linkKey(res);
  try{ACC.ensureStudents();}catch(e){}
  var store=loadStore(),studs=Object.keys(store.list||{}).map(function(id){return store.list[id];});
  var st=studs.filter(function(s){return (s.sso||[]).indexOf(key)>-1;})[0];
  if(!st&&res.name){var same=studs.filter(function(s){return normName(s.name)===normName(res.name)&&!(s.sso||[]).some(function(k){return k.indexOf(res.provider+':')===0;});});if(same.length===1)st=same[0];}
  var found=st?Promise.resolve(ACC.forStudent(st.id)):(window.MMSync&&MMSync.ssoSignIn?MMSync.ssoSignIn(res):Promise.resolve(null));
  return found.then(function(acc){
    if(!acc){
      /* remember for a few minutes: signing in with a username and code next links the two */
      try{sessionStorage.setItem(PENDING,JSON.stringify({key:key,name:res.name||'',provider:res.provider,sub:res.sub,until:Date.now()+10*60000}));}catch(e){}
      try{localStorage.setItem('mmLoginAs_v1','student');var b=document.querySelector('#mm-auth [data-a=as][data-v=student]');if(b&&b.getAttribute('aria-pressed')!=='true')b.click();}catch(e){}
      say(T('Signed in with')+' '+via+(res.name?' '+T('as')+' '+res.name:'')+'. '+T('Your class is not on this device yet. Sign in once with your username and code (your teacher has them). After that,')+' '+via+' '+T('is all you need.'),'info');
      if(unlocked)setTimeout(function(){location.reload();},4000);
      return false;}
    link(acc,res);
    if(!GATE.signInStudentAccount(ACC.get(acc.u)||acc)){say(T('Could not sign in.'),'err');return false;}
    if(unlocked)reloadSoon();return true;
  }).catch(function(err){say(String(err&&err.message||err),'err');return false;});}

/** store the link on the student record (so class sync carries it to every device of the class) */
function link(acc,res){var key=linkKey(res);try{var s=loadStore(),st=s.list[acc.studentId];if(st&&(st.sso||[]).indexOf(key)<0){st.sso=(st.sso||[]).filter(function(k){return k.indexOf(res.provider+':')!==0;}).concat(key);saveStore(s);}}catch(e){}
  try{ACC.update(acc.u,function(x){x.sso=[key];});}catch(e){}
  try{if(window.MMSync&&MMSync.linkSso)MMSync.linkSso(acc.studentId,res);}catch(e){}}
/** after a username + code sign-in: finish a link the student started with Clever/ClassLink */
function linkPending(){var p=null;try{p=JSON.parse(sessionStorage.getItem(PENDING)||'null');}catch(e){}if(!p||p.until<Date.now())return;
  var a=A.get();if(!a||a.role!=='student'||!a.id)return;var st=null;try{st=loadStore().list[a.id];}catch(e){}if(!st)return;
  if(p.name&&normName(p.name)!==normName(st.name))return;   /* only the same person */
  try{sessionStorage.removeItem(PENDING);}catch(e){}
  var acc=ACC.forStudent(st.id);if(acc)link(acc,{provider:p.provider,sub:p.sub,name:p.name});
  try{U.toast(T('Your school account is linked. Next time, just use')+' '+(NAMES[p.provider]||'')+'.',5000);}catch(e){}}

/* ---------- boot ---------- */
if(!HOSTED)return;
(window.MMConfig?MMConfig():Promise.resolve({})).then(function(c){list=(c&&c.sso||[]).filter(function(p){return NAMES[p];});
  var go=function(){var g=document.getElementById('mm-auth');if(g&&!g.__sso){g.__sso=1;new MutationObserver(inject).observe(g,{childList:true,subtree:true,attributes:true,attributeFilter:['class','aria-pressed']});}inject();returning();};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(go,450);});else setTimeout(go,450);
  window.addEventListener('hashchange',function(){if(/^#mm-sso/.test(location.hash))returning();});});
/* a student who just signed in with a username and code may be finishing a link */
var lastWho='';setInterval(function(){var a=null;try{a=A.get();}catch(e){}var w=a?(a.role+':'+(a.id||a.u||'')):'';if(w&&w!==lastWho){lastWho=w;linkPending();}else if(!w)lastWho='';},1500);
})();
