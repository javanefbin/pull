(function(){'use strict';
function role(){try{return String(loadRole()||'student').toLowerCase()}catch(e){return 'student'}}
function staff(){return ['teacher','guardian','parent','coteacher','admin','owner'].indexOf(role())>=0}
function panel(){var id='';try{id=String(currentDoc||'')}catch(e){}return id}
function intro(){var r=document.documentElement;r.classList.toggle('mm-staff-view',staff());if(!staff())return;
 var p=document.querySelector('#panel-lessons .panel-body');if(!p)return;
 var title=document.getElementById('lessonTitle');if(!title)return;
 var host=p.querySelector('.mm-educator-intro');if(!host){host=document.createElement('section');host.className='mm-educator-intro';host.setAttribute('aria-label','Teacher preparation overview');
 host.innerHTML='<div class="mm-educator-mark" aria-hidden="true">▤</div><div><h2>Teaching workspace</h2><p>Use this lesson to model the skill, guide supported practice, and check for independent understanding. Student-facing activities remain available below.</p><div class="mm-educator-meta"><span>PLAN · MODEL · PRACTICE</span><span>CHECK FOR UNDERSTANDING</span></div></div>';
 /* replaced by the teaching view */}
}
function testKey(){if(!staff())return;var f=document.getElementById('testForm');if(!f||!f.querySelector('.q-item')||f.querySelector('.mm-test-key-banner'))return;
 var t;try{t=typeof tests==='function'?tests()[currentTest]:null}catch(e){}if(!t||!Array.isArray(t.questions))return;
 var b=document.createElement('div');b.className='mm-key-banner mm-test-key-banner';b.textContent='Instructor preview · Correct answers and teaching explanations are visible here. Do not project this view during independent student testing.';f.insertBefore(b,f.firstChild);
 t.questions.forEach(function(q,i){var item=document.getElementById('ti-'+i);if(!item)return;item.classList.add('mm-key-item');var opt=document.getElementById('to-'+i+'-'+q.answer);if(opt)opt.classList.add('mm-key-correct');
 if(q.explain){var n=document.createElement('div');n.className='mm-key-note';n.textContent='Teaching note / rationale: '+q.explain;var fb=document.getElementById('tf-'+i);if(fb&&fb.parentNode)item.insertBefore(n,fb);else item.appendChild(n);}
 });var submit=document.querySelector('#testButtons [onclick*="submitTest"]');if(submit){submit.style.display='none';submit.setAttribute('aria-hidden','true')}
}
function sync(){intro();testKey()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync);else sync();
try{new MutationObserver(sync).observe(document.body,{childList:true,subtree:true})}catch(e){}
setInterval(sync,1400);
})();
