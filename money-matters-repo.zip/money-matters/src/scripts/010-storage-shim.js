(function(){function ok(){try{localStorage.setItem('__t','1');localStorage.removeItem('__t');sessionStorage.setItem('__t','1');sessionStorage.removeItem('__t');return true;}catch(e){return false;}}
if(ok())return;
function mk(){var d={},o={};['getItem','setItem','removeItem','clear','key'].forEach(function(n){Object.defineProperty(o,n,{enumerable:false,value:{getItem:function(k){return Object.prototype.hasOwnProperty.call(d,k)?d[k]:null;},setItem:function(k,v){d[k]=String(v);Object.defineProperty(o,k,{enumerable:true,configurable:true,get:function(){return d[k];}});},removeItem:function(k){delete d[k];delete o[k];},clear:function(){Object.keys(d).forEach(function(k){delete d[k];delete o[k];});},key:function(i){return Object.keys(d)[i]||null;}}[n]});});
Object.defineProperty(o,'length',{enumerable:false,get:function(){return Object.keys(d).length;}});return o;}
['localStorage','sessionStorage'].forEach(function(n){try{Object.defineProperty(window,n,{configurable:true,value:mk()});}catch(e){}});
window.MM_NO_STORAGE=true;
document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){try{infoToast('Preview mode: progress will not be saved. Open this file in your browser to save progress.',6000);}catch(e){}},1500);});
})();
