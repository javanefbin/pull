/* =====================================================================
   V19 · LICENSE LAYER  (window.MMLicense)
   Only active in the hosted public build (window.MM_PUBLIC_BUILD). The
   full build, used for local copies and tests, is always licensed.
   Free edition (no valid access code on this device):
     · week 1 of every grade is open, in English, Spanish and Portuguese
     · weeks 2-36, section tests, workshops, and the full-year workbook and
       teacher's guide open the unlock dialog instead
   Licensed: the content packs from /api/content replace the free parts
   before the app boots (see 020-v69-access-loader.js), and nothing is locked.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;
var PUBLIC=!!window.MM_PUBLIC_BUILD,FULL=!!window.__MM_FULL,LICENSED=!PUBLIC||FULL;
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function sampleOn(){try{return !!(MM&&MM.sample&&MM.sample.active());}catch(e){return false;}}
function prompt(what){try{MM.sample.subscribe(what);}catch(e){try{infoToast(T('Included with a subscription.'),3000);}catch(x){}}}
function isStaff(){try{return MM.auth.roleKey()!=='student';}catch(e){return false;}}
function locked(){return !LICENSED&&!sampleOn();}
var API={public:PUBLIC,licensed:LICENSED,label:window.__MM_LICENSE||'',expires:window.__MM_LICENSE_EXPIRES||'',
  has:function(){return LICENSED;},prompt:prompt,
  unlock:function(){try{MM.sample.enterCode();}catch(e){}},
  remove:function(){try{localStorage.removeItem('mmAccess_v1');}catch(e){}location.reload();}};
window.MMLicense=API;
if(LICENSED&&!PUBLIC)return;

/* ---------- locks (outermost wrappers; re-applied after later layers boot) ---------- */
function wrap(obj,name,fn){var o=obj&&obj[name];if(typeof o!=='function'||o.__lic)return;var w=function(){return fn(o,[].slice.call(arguments),this);};w.__lic=true;obj[name]=w;}
var BIG={workbook:'The full-year workbook',guide:'The full-year teacher’s guide'};
function install(){if(LICENSED)return;
  wrap(window,'weekUnlocked',function(o,a,t){if(locked()&&(a[0]|0)>0)return false;return o.apply(t,a);});
  wrap(window,'lockedMsg',function(o,a,t){if(locked()){prompt('Weeks 2 to 36');return;}return o.apply(t,a);});
  wrap(window,'gotoLesson',function(o,a,t){if(locked()&&(a[0]|0)>0){prompt('Weeks 2 to 36');return;}return o.apply(t,a);});
  /* loadLesson also runs at start-up with the last week viewed: fall back to week 1 quietly */
  wrap(window,'loadLesson',function(o,a,t){if(locked()&&(a[0]|0)>0){try{currentIndex=0;}catch(e){}return o.apply(t,[0].concat(a.slice(1)));}return o.apply(t,a);});
  wrap(window,'gotoWeek',function(o,a,t){if(locked()&&(a[1]|0)>0){prompt('Weeks 2 to 36');return;}return o.apply(t,a);});
  wrap(window,'openTestMenu',function(o,a,t){if(locked()){prompt('Section tests');return;}return o.apply(t,a);});
  wrap(window,'openDoc',function(o,a,t){if(locked()&&BIG[a[0]]){prompt(BIG[a[0]]);return;}return o.apply(t,a);});
  wrap(window,'downloadDoc',function(o,a,t){if(locked()&&BIG[a[0]]){prompt(BIG[a[0]]);return;}return o.apply(t,a);});
  if(window.MMPrint){wrap(MMPrint,'doc',function(o,a,t){if(locked()&&BIG[a[0]]){prompt(BIG[a[0]]);return;}return o.apply(t,a);});
    wrap(MMPrint,'wordDoc',function(o,a,t){if(locked()&&BIG[a[0]]){prompt(BIG[a[0]]);return;}return o.apply(t,a);});}
}
install();
document.addEventListener('DOMContentLoaded',function(){setTimeout(install,0);setTimeout(install,3800);});

/* ---------- top bar: unlock button for staff; status notices ---------- */
function bar(){var tb=document.getElementById('mm-topbar');if(!tb||tb.style.display==='none')return;var b=tb.querySelector('[data-lic=unlock]');
  if(LICENSED||sampleOn()||!isStaff()){if(b)b.remove();return;}
  if(b)return;b=document.createElement('button');b.type='button';b.className='tb lic-unlock';b.setAttribute('data-lic','unlock');
  b.innerHTML='<span aria-hidden="true">🔑</span> <span>'+esc(T('Unlock full program'))+'</span>';b.title=T('Free edition: week 1 of every grade. Enter a school access code to unlock the rest.');
  b.onclick=function(){prompt('');};var out=tb.querySelector('[data-a=out]');tb.insertBefore(b,out||null);}
if(MM&&MM.shell&&MM.shell.topbar&&!MM.shell.topbar.__lic){var ot=MM.shell.topbar;MM.shell.topbar=function(){var r=ot.apply(this,arguments);try{bar();}catch(e){}return r;};MM.shell.topbar.__lic=1;}
setTimeout(bar,1500);
function notices(){if(typeof window.mmNotify!=='function')return;var has='';try{has=localStorage.getItem('mmAccess_v1')||'';}catch(e){}
  if(has&&window.__MM_ACCESS_OFFLINE&&!FULL)mmNotify('lic-offline','The full program could not be loaded because the server was not reachable. Week 1 is available; the rest returns when you are back online.','location.reload()');
  if(FULL&&API.expires){var d=(Date.parse(API.expires)-Date.now())/864e5;if(d>=0&&d<30)mmNotify('lic-expiring','Your Money Matters access code expires in '+Math.ceil(d)+' days. Contact your provider to renew.','');}}
setTimeout(notices,2500);

/* ---------- Admin Console: license card at the top of Settings ---------- */
function card(){var st=LICENSED?'<b>'+esc(T('Full program'))+'</b>'+(API.label?' · '+esc(API.label):'')+(API.expires?' · '+esc(T('expires'))+' '+esc(new Date(API.expires).toLocaleDateString()):''):'<b>'+esc(T('Free edition'))+'</b> · '+esc(T('week 1 of every grade'));
  return '<div class="mm-card lic-card"><div class="mm-card-title">🔑 '+esc(T('License'))+'</div><p class="mm-card-sub">'+st+'</p><div class="mm-row">'
    +(LICENSED?'<button type="button" class="mm-btn ghost sm" onclick="MMLicense.remove()">'+esc(T('Remove access code from this device'))+'</button>':'<button type="button" class="mm-btn primary sm" onclick="MMLicense.unlock()">'+esc(T('Enter access code'))+'</button>')+'</div></div>';}
function adminHook(){var AD=MM&&MM.admin;if(!AD||!AD.VIEWS||!AD.VIEWS.settings||AD.VIEWS.settings.__lic){if(!AD||!AD.VIEWS)setTimeout(adminHook,800);return;}
  var o=AD.VIEWS.settings;AD.VIEWS.settings=function(){var h=o.apply(this,arguments);var i=h.indexOf('<div class="mm-card');return i<0?card()+h:h.slice(0,i)+card()+h.slice(i);};AD.VIEWS.settings.__lic=1;}
adminHook();
})();
