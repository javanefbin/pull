/* =====================================================================
   V22 · CLASS SYNC  (window.MMSync)
   Keeps a class's roster and every student's progress the same on all the
   class's devices. Hosted site with a school license only.

   Privacy design (the server is lib/mm-sync.mjs + functions/api/sync.js):
     · Everything is encrypted on the device (AES-256-GCM) before it is sent.
       The server never sees a name, a sign-in code, a score or a key.
     · The class key lives only on teacher devices (teacher link). From it come
       the class id, the teacher secret W, the student secret S and the roster key.
     · Each student record has its own random key. The roster (teacher-only)
       holds those keys. A student device gets a student's key only by proving
       the username + sign-in code (PBKDF2, 150,000 rounds) or a linked
       Clever/ClassLink account, so it can open that one record and no other.
     · Student links (#mm-join=<class id>.<S>) give no access by themselves:
       S only lets a device look up one sign-in entry by its exact id.
   What syncs per student: the profile and progress record, Financial Literacy
   Assessment attempts and reflection, and quiz reflections. Scores merge by
   keeping the best result; other fields follow the most recent change.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var ACC=MM.accounts,A=MM.auth,U=MM.util,D=MM.data;
var HOSTED=!!window.MM_PUBLIC_BUILD&&/^https?:$/.test(location.protocol);
var ST_KEY='mmSync_v1',JOIN_KEY='mmSyncJoin_v1',MINE_KEY='mmSyncMine_v1',PEND_KEY='mmSyncPending_v1';
var FA='mmFinancialAssessment_v1',FAR='mmFinancialAssessmentReflection_v1',QR='mmQuizReflection_v2|';
var ITER=150000,te=new TextEncoder(),td=new TextDecoder();
var cfg={},busy=false,last={at:0,error:'',pulled:0,pushed:0},lastStore='';
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function toast(m,ms){try{U.toast(m,ms||4000);}catch(e){}}
function jget(k,d){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?d:v;}catch(e){return d;}}
function jset(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}

/* ---------- crypto ---------- */
function b64u(buf){var a=new Uint8Array(buf),s='';for(var i=0;i<a.length;i+=8192)s+=String.fromCharCode.apply(null,a.subarray(i,i+8192));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function unb64u(s){s=String(s).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';var b=atob(s),a=new Uint8Array(b.length);for(var i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a;}
function rnd(n){var a=new Uint8Array(n);crypto.getRandomValues(a);return a;}
function hex(buf){return Array.from(new Uint8Array(buf)).map(function(b){return ('0'+b.toString(16)).slice(-2);}).join('');}
function sha(s){return crypto.subtle.digest('SHA-256',te.encode(s)).then(hex);}
function hkdf(keyBytes,info){return crypto.subtle.importKey('raw',keyBytes,'HKDF',false,['deriveBits']).then(function(k){return crypto.subtle.deriveBits({name:'HKDF',hash:'SHA-256',salt:te.encode('money-matters/class-sync'),info:te.encode(info)},k,256);}).then(function(b){return new Uint8Array(b);});}
function hmacId(keyBytes,msg){return crypto.subtle.importKey('raw',keyBytes,{name:'HMAC',hash:'SHA-256'},false,['sign']).then(function(k){return crypto.subtle.sign('HMAC',k,te.encode(msg));}).then(function(s){return b64u(s).slice(0,32);});}
function pbkdf(code,salt){return crypto.subtle.importKey('raw',te.encode(code),'PBKDF2',false,['deriveBits']).then(function(k){return crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:salt,iterations:ITER},k,256);}).then(function(b){return new Uint8Array(b);});}
function aes(keyBytes){return crypto.subtle.importKey('raw',keyBytes,'AES-GCM',false,['encrypt','decrypt']);}
function seal(keyBytes,obj,aad){var iv=rnd(12);return aes(keyBytes).then(function(k){return crypto.subtle.encrypt({name:'AES-GCM',iv:iv,additionalData:te.encode(aad)},k,te.encode(JSON.stringify(obj)));}).then(function(ct){return 'v1.'+b64u(iv)+'.'+b64u(ct);});}
function open(keyBytes,body,aad){var p=String(body||'').split('.');if(p[0]!=='v1'||p.length!==3)return Promise.reject(new Error('bad item'));
  return aes(keyBytes).then(function(k){return crypto.subtle.decrypt({name:'AES-GCM',iv:unb64u(p[1]),additionalData:te.encode(aad)},k,unb64u(p[2]));}).then(function(pt){return JSON.parse(td.decode(pt));});}
function normU(u){return String(u||'').trim().toLowerCase();}
function normCode(c){return String(c||'').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');}
var keyCache={};
function classKeys(K){if(keyCache[K])return keyCache[K];var kb=unb64u(K);
  return (keyCache[K]=Promise.all([sha('mm-room|'+K),hkdf(kb,'mm-write'),hkdf(kb,'mm-student'),hkdf(kb,'mm-roster')]).then(function(r){return {room:r[0],W:b64u(r[1]),S:b64u(r[2]),R:r[3]};}));}
function ownerProof(ks){return hkdf(unb64u(ks),'mm-owner').then(b64u);}
function loginId(S,u){return hmacId(unb64u(S),'login|'+normU(u));}
function ssoId(S,key){return hmacId(unb64u(S),'sso|'+key);}
function ssoKey(S,key){return hkdf(unb64u(S),'mm-sso|'+key);}

/* ---------- server ---------- */
function call(room,key,body,auth){var h={'Content-Type':'application/json','X-MM-Room':room,'X-MM-Key':key};if(auth)h.Authorization='Bearer '+auth;
  return fetch('/api/sync',{method:'POST',headers:h,body:JSON.stringify(body)}).then(function(r){return r.json().catch(function(){return {};}).then(function(j){j.__status=r.status;if(r.ok||r.status===409||r.status===404)return j;throw new Error(j.error||('HTTP '+r.status));});});}

/* ---------- state ---------- */
function state(){return jget(ST_KEY,null);}          /* teacher device: {K, since, map:{sid:{rid,ks,ver,h,t,lid,lh,lver}}, rv, roster:{removed}} */
function join(){return jget(JOIN_KEY,null);}         /* student device: {room,S} */
function mine(){return jget(MINE_KEY,{});}           /* student device: {sid:{rid,ks,ver,h,t,u}} */
function mode(){return state()?'teacher':join()?'student':'off';}
/* a short, readable class id so a teacher can check a link is for their own class */
function classId(room){return String(room||'').slice(0,8).toUpperCase().replace(/^(.{4})/,'$1-');}

/* ---------- one student's data ---------- */
function payloadOf(sid){var s=loadStore(),st=s.list&&s.list[sid];if(!st)return null;var qr={};
  try{Object.keys(localStorage).forEach(function(k){if(k.indexOf(QR+sid+'|')===0)qr[k.slice((QR+sid+'|').length)]=jget(k,null);});}catch(e){}
  return {rec:st,fa:(jget(FA,{})[sid])||null,far:(jget(FAR,{})[sid])||null,qr:qr};}
function hashOf(p){return sha(JSON.stringify(p));}
function stable(x){return JSON.stringify(x);}
/* by: 's' when a student device wrote this copy. Teacher devices then take only the student's own
   work from it (progress, assessments, reflections), never teacher-managed fields. */
var TEACHER_FIELDS=['name','grade','teacher','verifyCode','verificationCode','locked','notes','review','created','classId','section'];
function pickTeacher(rec){var f={};TEACHER_FIELDS.forEach(function(k){if(rec&&rec[k]!=null)f[k]=rec[k];});return f;}
function applyPayload(sid,p,newer,by,tf){if(!p||!p.rec)return false;var fromStudent=by==='s'&&mode()==='teacher';var s=loadStore();s.list=s.list||{};var cur=s.list[sid],before=stable(cur||null),existed=!!cur;
  if(!cur){cur=s.list[sid]=JSON.parse(JSON.stringify(p.rec));cur.id=sid;}
  else{var ip=p.rec.prog||{};cur.prog=cur.prog||{};Object.keys(ip).forEach(function(k){var a=cur.prog[k],b=ip[k];if(a==null||(typeof b==='number'&&typeof a==='number'&&b>a))cur.prog[k]=b;});
    Object.keys(p.rec).forEach(function(k){if(k==='prog'||k==='id'||k==='sso')return;if(fromStudent&&TEACHER_FIELDS.indexOf(k)>-1)return;if(newer||cur[k]==null)cur[k]=p.rec[k];});
    var ss=(cur.sso||[]).concat(p.rec.sso||[]).filter(function(v,i,a){return a.indexOf(v)===i;});if(ss.length)cur.sso=ss;}
  /* teacher-managed fields come from the teacher-only roster, never from a copy a student device wrote */
  if(fromStudent&&tf)TEACHER_FIELDS.forEach(function(k){if(tf[k]!=null)cur[k]=tf[k];else if(!existed)delete cur[k];});
  if(cur.teacher){s.teachers=s.teachers||[];if(s.teachers.indexOf(cur.teacher)<0)s.teachers.push(cur.teacher);}
  var changed=stable(cur)!==before;if(changed)saveStore(s);
  if(p.fa&&p.fa.attempts){var o=jget(FA,{}),la=(o[sid]&&o[sid].attempts)||[],seen={},all=[];la.concat(p.fa.attempts).forEach(function(a){var k=stable(a);if(!seen[k]){seen[k]=1;all.push(a);}});
    if(all.length!==la.length){o[sid]=Object.assign({},p.fa,o[sid]||{},{attempts:all});jset(FA,o);changed=true;}}
  if(p.far){var r=jget(FAR,{});if(!r[sid]||newer){if(stable(r[sid])!==stable(p.far)){r[sid]=p.far;jset(FAR,r);changed=true;}}}
  Object.keys(p.qr||{}).forEach(function(k){var key=QR+sid+'|'+k,has=localStorage.getItem(key);if(has==null||newer){if(has!==stable(p.qr[k])){jset(key,p.qr[k]);changed=true;}}});
  return changed;}
/** the synced username wins over the one this device made up */
function setUsername(sid,u){if(!u)return;try{ACC.ensureStudents();var o=ACC.load(),a=null;Object.keys(o.list).forEach(function(k){if(o.list[k].role==='student'&&o.list[k].studentId===sid)a=o.list[k];});
  if(!a||a.u===normU(u)||o.list[normU(u)])return;var nu=normU(u);o.list[nu]=Object.assign({},a,{u:nu});delete o.list[a.u];ACC.save(o);}catch(e){}}

/* ---------- login entries (wrapped student keys) ---------- */
/* A sign-in entry: the student's key, wrapped with a key from their code (PBKDF2). The server releases
   the entry only for the matching proof (also from the code; the server keeps its SHA-256) and locks it
   after 10 wrong proofs, so it can't be downloaded and guessed offline. */
function codeKeys(code,salt){return pbkdf(normCode(code),salt).then(function(k){return Promise.all([hkdf(k,'mm-login-wrap'),hkdf(k,'mm-login-verify')]);}).then(function(r){return {wrap:r[0],proof:b64u(r[1])};});}
function makeLogin(S,room,sid,ent,u,code,name){var salt=rnd(16);return Promise.all([loginId(S,u),codeKeys(code,salt)]).then(function(r){
  return Promise.all([seal(r[1].wrap,{sid:sid,rid:ent.rid,ks:ent.ks,u:normU(u),n:name},room+'|'+r[0]),sha(r[1].proof)]).then(function(x){return {id:r[0],owner_hash:x[1],body:b64u(te.encode(JSON.stringify({s:b64u(salt),c:x[0]})))};});});}

/* =====================================================================
   TEACHER DEVICES
   ===================================================================== */
function teacherTick(){var st=state();if(!st)return Promise.resolve();
  return classKeys(st.K).then(function(k){var room=k.room,W=k.W;st.room=room;st.map=st.map||{};st.roster=st.roster||{removed:{}};
    var pulled=0,pushed=0,rosterDirty=false;
    /* 1. pull what changed since last time */
    return call(room,W,{op:'list',since:st.since||0}).then(function(res){
      if(res.__status===404){last.error=T('This class is no longer synced on the server.');return;}
      var items=res.items||[],maxAt=st.since||0;items.forEach(function(i){if(i.at>maxAt)maxAt=i.at;});
      var want=items.filter(function(i){return i.id==='roster'||i.kind==='student';}).map(function(i){return i.id;});
      var getAll=function(ids){var out=[];var chunks=[];for(var i=0;i<ids.length;i+=100)chunks.push(ids.slice(i,i+100));
        return chunks.reduce(function(p,c){return p.then(function(){return call(room,W,{op:'get',ids:c}).then(function(r){out=out.concat(r.items||[]);});});},Promise.resolve()).then(function(){return out;});};
      return getAll(want).then(function(got){
        var ro=got.filter(function(i){return i.id==='roster';})[0];
        var p=Promise.resolve();
        if(ro)p=open(k.R,ro.body,room+'|roster').then(function(remote){st.rv=ro.ver;mergeRoster(st,remote);
          /* students we have never fetched */
          var missing=Object.keys(remote.students||{}).filter(function(sid){return !st.map[sid]||!st.map[sid].ver;}).map(function(sid){return remote.students[sid].rid;});
          var have={};got.forEach(function(i){have[i.id]=1;});missing=missing.filter(function(r){return !have[r];});
          return getAll(missing).then(function(more){got=got.concat(more);});});
        return p.then(function(){var byRid={};Object.keys(st.map).forEach(function(sid){byRid[st.map[sid].rid]=sid;});
          return got.filter(function(i){return i.kind==='student'&&byRid[i.id];}).reduce(function(q,i){return q.then(function(){var sid=byRid[i.id],ent=st.map[sid];
            if(ent.ver&&i.ver<=ent.ver)return;
            return open(unb64u(ent.ks),i.body,room+'|'+i.id).then(function(pl){var isNew=!(loadStore().list||{})[sid];applyPayload(sid,pl,(pl.t||0)>(ent.t||0),i.by,ent.f);if(isNew)dedupe(st,sid);if(ent.u)setUsername(sid,ent.u);ent.ver=i.ver;if((pl.t||0)>(ent.t||0))ent.t=pl.t;pulled++;
              return Promise.all([hashOf({rec:pl.rec,fa:pl.fa,far:pl.far,qr:pl.qr}),hashOf(payloadOf(sid))]).then(function(hh){if(hh[0]===hh[1])ent.h=hh[1];});});});},Promise.resolve());});
      }).then(function(){st.since=Math.max(0,maxAt-3000);});
    }).then(function(){
      /* 2. push local changes, new students, sign-in entries */
      try{ACC.ensureStudents();}catch(e){}
      var list=(loadStore().list)||{},puts=[],logins=[],removed=[];
      return Object.keys(list).reduce(function(q,sid){return q.then(function(){var ent=st.map[sid];
        if(!ent){ent=st.map[sid]={rid:b64u(rnd(18)),ks:b64u(rnd(32)),ver:0,t:Date.now()};rosterDirty=true;}
        var acc=ACC.forStudent(sid),u=acc&&acc.u;if(u&&ent.u!==u){ent.u=u;rosterDirty=true;}
        var tf=pickTeacher(list[sid]);if(stable(tf)!==stable(ent.f||null)){ent.f=tf;rosterDirty=true;}
        var pl=payloadOf(sid);return hashOf(pl).then(function(h){
          var work=[];
          if(h!==ent.h){if(ent.h)ent.t=Date.now();pl.t=ent.t||Date.now();
            work.push(Promise.all([seal(unb64u(ent.ks),pl,room+'|'+ent.rid),ownerProof(ent.ks).then(sha)]).then(function(r){puts.push({sid:sid,h:h,item:{id:ent.rid,kind:'student',body:r[0],ver:ent.ver||0,owner_hash:r[1]}});}));}
          var code=D.codeOf(list[sid]);
          if(u&&code)work.push(sha('v2|'+u+'|'+code).then(function(lh){if(lh===ent.lh)return;return makeLogin(k.S,room,sid,ent,u,code,list[sid].name).then(function(L){
            if(ent.lid&&ent.lid!==L.id)removed.push(ent.lid);logins.push({sid:sid,lh:lh,item:{id:L.id,kind:'login',body:L.body,owner_hash:L.owner_hash,ver:ent.lid===L.id?(ent.lver||0):0}});});}));
          return Promise.all(work);});});},Promise.resolve()).then(function(){
        /* students removed on this device */
        Object.keys(st.map).forEach(function(sid){if(!list[sid]&&!st.roster.removed[sid]){st.roster.removed[sid]=Date.now();removed.push(st.map[sid].rid);if(st.map[sid].lid)removed.push(st.map[sid].lid);delete st.map[sid];rosterDirty=true;}});
        var all=puts.concat(logins),chunks=[];for(var i=0;i<all.length;i+=50)chunks.push(all.slice(i,i+50));
        return chunks.reduce(function(q,c){return q.then(function(){return call(room,W,{op:'put',items:c.map(function(x){return x.item;})}).then(function(r){var waits=[];(r.results||[]).forEach(function(res,j){var x=c[j],ent=st.map[x.sid];if(!ent)return;
          if(res.ok){if(x.item.kind==='student'){ent.ver=res.ver;ent.h=x.h;pushed++;}else{ent.lid=x.item.id;ent.lver=res.ver;ent.lh=x.lh;}}
          else if(res.conflict&&x.item.kind==='student'){/* someone else changed it: merge theirs now, push ours next time */
            waits.push(open(unb64u(ent.ks),res.body,room+'|'+ent.rid).then(function(pl){applyPayload(x.sid,pl,(pl.t||0)>(ent.t||0),res.by,ent.f);ent.ver=res.ver;ent.h=null;}).catch(function(){}));}
          else if(res.conflict){ent.lid=x.item.id;ent.lver=res.ver;ent.lh=null;}});return Promise.all(waits);});});},Promise.resolve())
        .then(function(){return removed.length?call(room,W,{op:'del',ids:removed}):null;});
      });
    }).then(function(){
      /* 3. the roster */
      if(!rosterDirty)return;
      var ro={v:1,students:{},removed:st.roster.removed,teachers:(loadStore().teachers||[])};
      Object.keys(st.map).forEach(function(sid){var e=st.map[sid];ro.students[sid]={rid:e.rid,ks:e.ks,u:e.u||'',f:e.f||null};});
      return seal(k.R,ro,room+'|roster').then(function(body){return call(room,W,{op:'put',items:[{id:'roster',kind:'roster',body:body,ver:st.rv||0}]});}).then(function(r){var x=(r.results||[])[0]||{};
        if(x.ok)st.rv=x.ver;else if(x.conflict)return open(k.R,x.body,room+'|roster').then(function(remote){st.rv=x.ver;mergeRoster(st,remote);});});
    }).then(function(){var cur=state();if(cur&&cur.K===st.K)jset(ST_KEY,st);last={at:Date.now(),error:'',pulled:pulled,pushed:pushed};});
  });}
/* a student made on this device before it joined the class, who is already in the class: keep one */
function norm2(st){return String(st.name||'').trim().toLowerCase()+'|'+(st.grade||'K');}
function dedupe(st,sid){var s=loadStore(),cls=s.list[sid];if(!cls)return;var dup=Object.keys(s.list).filter(function(id){return id!==sid&&!st.map[id]&&norm2(s.list[id])===norm2(cls);})[0];if(!dup)return;
  var theirs=payloadOf(dup);delete s.list[dup];saveStore(s);applyPayload(sid,theirs,false);
  try{var ra=jget(FA,{});if(ra[dup]){delete ra[dup];jset(FA,ra);}var rr=jget(FAR,{});if(rr[dup]){delete rr[dup];jset(FAR,rr);}}catch(e){}
  try{ACC.ensureStudents();}catch(e){}}
function mergeRoster(st,remote){var s=loadStore(),changed=false;st.roster.removed=Object.assign({},remote.removed||{},st.roster.removed||{});
  Object.keys(remote.students||{}).forEach(function(sid){var r=remote.students[sid];if(st.roster.removed[sid])return;var e=st.map[sid];
    if(!e)st.map[sid]={rid:r.rid,ks:r.ks,ver:0,t:0,u:r.u,f:r.f||null};else{e.rid=r.rid;e.ks=r.ks;if(r.u)e.u=r.u;if(r.f)e.f=r.f;}});
  Object.keys(st.roster.removed).forEach(function(sid){if(s.list&&s.list[sid]){delete s.list[sid];changed=true;}delete st.map[sid];});
  (remote.teachers||[]).forEach(function(tn){s.teachers=s.teachers||[];if(s.teachers.indexOf(tn)<0){s.teachers.push(tn);changed=true;}});
  if(changed)saveStore(s);}

/* =====================================================================
   STUDENT DEVICES
   ===================================================================== */
function bring(room,S,cred){/* fetch, open and store one student's record on this device */
  return ownerProof(cred.ks).then(function(proof){return call(room,S,{op:'rec',id:cred.rid,proof:proof});}).then(function(r){
    if(r.__status===404||!r.body)throw new Error(T('Your record was not found in the class. Ask your teacher.'));
    return open(unb64u(cred.ks),r.body,room+'|'+cred.rid).then(function(pl){applyPayload(cred.sid,pl,true);setUsername(cred.sid,cred.u);
      var m=mine();m[cred.sid]={rid:cred.rid,ks:cred.ks,u:cred.u,ver:r.ver,t:pl.t||0,h:null};jset(MINE_KEY,m);
      try{ACC.ensureStudents();}catch(e){}return ACC.forStudent(cred.sid);});});}
function creds(){var j=join();if(j)return Promise.resolve({room:j.room,S:j.S});var st=state();if(st)return classKeys(st.K).then(function(k){return {room:k.room,S:k.S};});return Promise.resolve(null);}
function remoteSignIn(user,code){return creds().then(function(c){if(!c)return null;return loginId(c.S,user).then(function(id){
  return call(c.room,c.S,{op:'salt',id:id}).then(function(r){if(r.__status===429)throw new Error(r.error);if(!r.s)return null;
    return codeKeys(code,unb64u(r.s)).then(function(ck){return call(c.room,c.S,{op:'login',id:id,proof:ck.proof}).then(function(x){
      if(x.__status===429)throw new Error(x.error);if(!x.body)return null;
      var o=JSON.parse(td.decode(unb64u(x.body)));return open(ck.wrap,o.c,c.room+'|'+id).then(function(cred){return bring(c.room,c.S,cred);});});});});});});}
function ssoSignIn(res){return creds().then(function(c){if(!c)return null;var key=res.provider+':'+res.sub;return ssoId(c.S,key).then(function(id){return call(c.room,c.S,{op:'login',id:id}).then(function(r){if(!r.body)return null;
    return ssoKey(c.S,key).then(function(kb){return open(kb,r.body,c.room+'|'+id);}).then(function(cred){return bring(c.room,c.S,cred);});});});});}
function linkSso(sid,res){return creds().then(function(c){if(!c)return;var st=state(),m=mine(),ent=(st&&st.map&&st.map[sid])||m[sid];if(!ent)return;var key=res.provider+':'+res.sub;
  return Promise.all([ssoId(c.S,key),ssoKey(c.S,key)]).then(function(r){var acc=ACC.forStudent(sid);return seal(r[1],{sid:sid,rid:ent.rid,ks:ent.ks,u:(acc&&acc.u)||ent.u||''},c.room+'|'+r[0]).then(function(body){return call(c.room,c.S,{op:'ssoput',id:r[0],body:body});});});}).catch(function(){});}
function studentTick(){var j=join();if(!j)return Promise.resolve();var a=null;try{a=A.get();}catch(e){}if(!a||a.role!=='student'||!a.id)return Promise.resolve();
  var m=mine(),cred=m[a.id];if(!cred)return Promise.resolve();
  return ownerProof(cred.ks).then(function(proof){
    return call(j.room,j.S,{op:'rec',id:cred.rid,proof:proof}).then(function(r){if(!r.body)return;var p=Promise.resolve();
      if(r.ver>(cred.ver||0))p=open(unb64u(cred.ks),r.body,j.room+'|'+cred.rid).then(function(pl){applyPayload(a.id,pl,(pl.t||0)>(cred.t||0));cred.ver=r.ver;if((pl.t||0)>(cred.t||0))cred.t=pl.t;});
      return p.then(function(){var pl=payloadOf(a.id);return hashOf(pl).then(function(h){if(h===cred.h)return;if(cred.h)cred.t=Date.now();pl.t=cred.t||Date.now();
        return seal(unb64u(cred.ks),pl,j.room+'|'+cred.rid).then(function(body){return call(j.room,j.S,{op:'recput',id:cred.rid,proof:proof,ver:cred.ver||0,body:body});}).then(function(x){
          if(x.ok){cred.ver=x.ver;cred.h=h;}else if(x.conflict){return open(unb64u(cred.ks),x.body,j.room+'|'+cred.rid).then(function(pl2){applyPayload(a.id,pl2,(pl2.t||0)>(cred.t||0));cred.ver=x.ver;cred.h=null;});}});});});});
  }).then(function(){var m2=mine();m2[a.id]=cred;jset(MINE_KEY,m2);last={at:Date.now(),error:'',pulled:0,pushed:0};});}

/* =====================================================================
   RUNNING
   ===================================================================== */
/* one run at a time; asking while a run is going waits for it and then runs once more
   (so "Sync now" right after a change always includes the change) */
var running=null,queued=null;
function sync(){if(!HOSTED||mode()==='off'||!navigator.onLine)return Promise.resolve(false);
  if(running){if(!queued)queued=running.then(function(){queued=null;return sync();});return queued;}
  busy=true;var p=mode()==='teacher'?teacherTick():studentTick();
  running=p.then(function(){try{lastStore=localStorage.getItem('mmStudents_v2')||'';}catch(e){}return true;},function(e){last.error=String(e&&e.message||e);return false;})
    .then(function(ok){busy=false;running=null;render();return ok;});
  return running;}
/* push a change within seconds; otherwise look for others' changes every 5 minutes and when the app comes back into view
   (keeps a large school inside Cloudflare's free 100,000 function calls a day) */
setInterval(function(){if(document.hidden)return;var s='';try{s=localStorage.getItem('mmStudents_v2')||'';}catch(e){}if(s!==lastStore||Date.now()-last.at>300000)sync();},5000);
document.addEventListener('visibilitychange',function(){if(!document.hidden)sync();});
window.addEventListener('online',function(){sync();});

/* ---------- turning it on, links, joining ---------- */
function access(){try{return localStorage.getItem('mmAccess_v1')||'';}catch(e){return '';}}
function turnOn(){if(!A.isAdmin||!A.isAdmin()){toast(T('Only an administrator can turn on class sync.'));return Promise.resolve(false);}
  var K=b64u(rnd(32));return classKeys(K).then(function(k){return Promise.all([sha(k.W),sha(k.S)]).then(function(h){return call(k.room,k.W,{op:'create',w_hash:h[0],s_hash:h[1]},access());}).then(function(r){
    if(r.error)throw new Error(r.error);jset(ST_KEY,{K:K,room:k.room,since:0,map:{},rv:0,roster:{removed:{}},on:Date.now()});try{localStorage.removeItem(JOIN_KEY);}catch(e){}
    return sync().then(function(){toast(T('Class sync is on. Every student on this device is now in the class.'),5000);return true;});});}).catch(function(e){toast(String(e.message||e),6000);return false;});}
function links(){var st=state();if(!st)return Promise.resolve(null);var base=location.origin+location.pathname;
  return classKeys(st.K).then(function(k){return {teacher:base+'#mm-class='+st.K,student:base+'#mm-join='+k.room+'.'+k.S};});}
function turnOff(){try{localStorage.removeItem(ST_KEY);localStorage.removeItem(JOIN_KEY);localStorage.removeItem(MINE_KEY);}catch(e){}last={at:0,error:'',pulled:0,pushed:0};render();}
function dropServer(){var st=state();if(!st)return Promise.resolve();return classKeys(st.K).then(function(k){return call(k.room,k.W,{op:'drop'});}).then(function(){turnOff();toast(T('The class was deleted from the server. Everything stays on this device.'),5000);});}
function readLink(){var h=location.hash||'',m;
  if((m=/^#mm-class=([A-Za-z0-9_-]{43})$/.exec(h))){jset(PEND_KEY,{K:m[1],at:Date.now()});clean();}
  else if((m=/^#mm-join=([a-f0-9]{64})\.([A-Za-z0-9_-]{43})$/.exec(h))){clean();if(!state()){jset(JOIN_KEY,{room:m[1],S:m[2],at:Date.now()});try{localStorage.setItem('mmLoginAs_v1','student');}catch(e){}try{if(MM.gate.visible())MM.gate.show({view:'signin'});}catch(e){}setTimeout(function(){toast(T('This device is now connected to your class. Sign in with your username and code.'),6000);},1200);}}}
function clean(){try{history.replaceState(null,'',location.pathname+location.search);}catch(e){}}
/* a teacher link is applied only after a teacher or administrator signs in, and only if they say yes */
function applyPending(){var p=jget(PEND_KEY,null);if(!p)return;var a=null;try{a=A.get();}catch(e){}if(!a||a.role==='student'||MM.gate.visible())return;
  try{localStorage.removeItem(PEND_KEY);}catch(e){}
  if(Date.now()-p.at>3600000)return;var cur=state();if(cur&&cur.K===p.K){toast(T('This device is already in this class.'));return;}
  var room='';classKeys(p.K).then(function(k){room=k.room;return mmConfirm(T('Connect this device to the class?'),T('Class ID')+' '+classId(k.room)+'. '+T('Connect only if a colleague you trust sent you this link. The class roster and progress will be copied to this device and kept up to date. Students already on this device are added to the class.'),T('Connect'),'🔄');}).then(function(ok){if(!ok)return;
    jset(ST_KEY,{K:p.K,room:room,since:0,map:{},rv:0,roster:{removed:{}},on:Date.now()});try{localStorage.removeItem(JOIN_KEY);}catch(e){}
    sync().then(function(){toast(T('Connected. The class is on this device.'),5000);try{if(openPanelId==='admin')MM.admin.render();}catch(e){}});});}
setInterval(applyPending,1500);

/* ---------- Admin Console → Class sync ---------- */
var AD=MM.admin;
function ago(t){if(!t)return T('not yet');var s=Math.round((Date.now()-t)/1000);return s<60?T('just now'):s<3600?Math.round(s/60)+' '+T('min ago'):new Date(t).toLocaleString();}
function view(){var H=AD.h,m=mode(),st=state(),n=st?Object.keys(st.map||{}).length:0,h='';
  h+=H.head('🔄 '+esc(T('Class sync')),esc(T('Keep the roster and every student\'s progress the same on all of the class\'s devices.')));
  if(!HOSTED){return h+'<div class="mm-card"><p>'+esc(T('Class sync works on the website, not in a downloaded copy.'))+'</p></div>';}
  if(!cfg.sync){return h+'<div class="mm-card"><p>'+esc(T('Class sync is not set up on this site yet.'))+'</p></div>';}
  h+='<div class="mm-card mm-sync-why"><div class="mm-card-title">🔐 '+esc(T('How your students\' data is protected'))+'</div><ul class="mm-sync-list">'
    +'<li>'+esc(T('Everything is encrypted on this device before it is sent. The server never sees a name, a sign-in code or a score.'))+'</li>'
    +'<li>'+esc(T('Each student\'s record has its own key. A student device can open only the record of the student who signs in on it.'))+'</li>'
    +'<li>'+esc(T('Turn it off, or delete the class from the server, at any time. Everything stays on this device.'))+'</li></ul></div>';
  if(m==='off'){var lic=window.MMLicense&&MMLicense.has();
    return h+'<div class="mm-card"><div class="mm-card-title">'+esc(T('Class sync is off'))+'</div><p>'+esc(T('Turn it on here, then open the teacher link on your other teacher devices and share the student link with your class.'))+'</p>'
      +(lic?'<button class="mm-btn primary" data-act="syncOn">'+esc(T('Turn on class sync'))+'</button>':'<p class="mm-muted">'+esc(T('Class sync is part of the school license. Unlock the full program on this device first.'))+'</p>')+'</div>';}
  if(m==='student')return h+'<div class="mm-card"><p>'+esc(T('This device is connected to a class as a student device. Students sign in with their username and code, and their progress syncs.'))+'</p><button class="mm-btn sm ghost" data-act="syncOff">'+esc(T('Disconnect this device'))+'</button></div>';
  h+='<div class="mm-grid c2"><div class="mm-card"><div class="mm-card-title">'+esc(T('Status'))+'</div><div class="mm-stack"><div>'+esc(T('Class ID'))+': <b class="mm-sync-id">'+esc(st&&st.room?classId(st.room):'…')+'</b></div><div><b>'+n+'</b> '+esc(T('students in the class'))+'</div><div>'+esc(T('Last synced'))+': <b>'+esc(ago(last.at))+'</b></div>'
    +(last.error?'<div class="mm-sync-err" role="alert">'+esc(last.error)+'</div>':'')+'<div class="mm-row"><button class="mm-btn sm" data-act="syncNow">'+esc(T('Sync now'))+'</button></div></div></div>'
    +'<div class="mm-card"><div class="mm-card-title">'+esc(T('Student devices'))+'</div><p>'+esc(T('Students open this link once on each device. Then they sign in with their username and code as usual, and their progress follows them.'))+'</p>'
    +'<div class="mm-row"><button class="mm-btn sm primary" data-act="syncStudentLink">'+esc(T('Student link'))+'</button>'+(window.MMLinks?'<button class="mm-btn sm secondary" data-act="syncShare"><span class="mm-gc-mark" aria-hidden="true"></span> '+esc(T('Share to Google Classroom'))+'</button>':'')+'</div></div></div>'
    +'<div class="mm-grid c2"><div class="mm-card"><div class="mm-card-title">'+esc(T('Other teacher devices'))+'</div><p>'+esc(T('Open the teacher link on another teacher or administrator device to bring the whole class there. Keep it private: it opens every student\'s record.'))+'</p><button class="mm-btn sm" data-act="syncTeacherLink">'+esc(T('Teacher link'))+'</button></div>'
    +'<div class="mm-card"><div class="mm-card-title">'+esc(T('Stop syncing'))+'</div><p>'+esc(T('Disconnecting keeps everything on this device. Deleting removes the class from the server for every device.'))+'</p><div class="mm-row"><button class="mm-btn sm ghost" data-act="syncOff">'+esc(T('Disconnect this device'))+'</button><button class="mm-btn sm danger" data-act="syncDrop">'+esc(T('Delete the class from the server'))+'</button></div></div></div>';
  return h;}
function showLink(kind){links().then(function(L){if(!L)return;var url=kind==='teacher'?L.teacher:L.student;var qr='';try{if(typeof qrcode==='function'){var q=qrcode(0,'M');q.addData(url);q.make();var n=q.getModuleCount(),d='';for(var r=0;r<n;r++)for(var c=0;c<n;c++)if(q.isDark(r,c))d+='M'+c+' '+r+'h1v1h-1z';qr='<svg viewBox="-2 -2 '+(n+4)+' '+(n+4)+'" width="220" height="220" shape-rendering="crispEdges"><rect x="-2" y="-2" width="'+(n+4)+'" height="'+(n+4)+'" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>';}}catch(e){}
  _openModal(kind==='teacher'?'🔑':'🎒',kind==='teacher'?T('Teacher link'):T('Student link'),'',[{label:T('Copy link'),value:'copy'},{label:T('Close'),ghost:true,value:false}]).then(function(v){if(v==='copy'){try{navigator.clipboard.writeText(url);toast(T('Copied'));}catch(e){}}});
  setTimeout(function(){var b=document.getElementById('mm-modal-body');if(!b)return;b.innerHTML='<p class="mm-sync-note">'+esc(kind==='teacher'?T('Open this on another teacher or administrator device. Anyone with this link can open every student\'s record, so send it only to staff.'):T('Students open this once on their device. It does not show anyone\'s data by itself: each student still needs their own username and code.'))+'</p>'
    +(qr?'<div class="mm-sync-qr" aria-hidden="true">'+qr+'</div>':'')+'<input class="mm-sync-link" readonly aria-label="'+esc(T('Link'))+'" value="'+esc(url)+'">';},60);});}
if(AD&&AD.TABS){var iS=AD.TABS.findIndex(function(t){return t.id==='students';});AD.TABS.splice(iS+1,0,{id:'sync',ic:'🔄',l:'Class sync'});
  AD.VIEWS.sync=view;
  Object.assign(AD.acts,{
    syncOn:function(){turnOn().then(function(){AD.render();});},
    syncNow:function(){sync().then(function(){AD.render();toast(last.error||T('Synced.'));});},
    syncStudentLink:function(){showLink('student');},
    syncTeacherLink:function(){showLink('teacher');},
    syncShare:function(){links().then(function(L){if(L&&window.MMLinks)MMLinks.share(L.student);});},
    syncOff:function(){mmConfirm(T('Disconnect this device from the class?'),T('Everything stays on this device. It just stops syncing.'),T('Disconnect'),'🔄').then(function(ok){if(ok){turnOff();AD.render();}});},
    syncDrop:function(){mmConfirm(T('Delete the class from the server?'),T('Every device stops syncing. Each device keeps what it has. This cannot be undone.'),T('Delete'),'🗑').then(function(ok){if(ok)dropServer().then(function(){AD.render();});});}});}
function render(){try{if(typeof openPanelId!=='undefined'&&openPanelId==='admin'&&AD.state&&AD.state.tab==='sync')AD.render();}catch(e){}}

window.MMSync={mode:mode,canRemote:function(){return HOSTED&&!!(join()||state());},remoteSignIn:remoteSignIn,ssoSignIn:ssoSignIn,linkSso:linkSso,sync:sync,turnOn:turnOn,turnOff:turnOff,links:links,status:function(){return Object.assign({mode:mode()},last);},
  _classKeys:classKeys,_payloadOf:payloadOf,_applyPayload:applyPayload};
readLink();window.addEventListener('hashchange',readLink);
/* MMConfig is defined by 695-license.js, which loads later: wait for the page */
function boot(){(window.MMConfig?MMConfig():Promise.resolve({})).then(function(c){cfg=c||{};if(mode()!=='off')setTimeout(sync,1200);});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else setTimeout(boot,0);
})();
