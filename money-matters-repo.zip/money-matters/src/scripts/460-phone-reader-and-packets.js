/* =====================================================================
   V94 · 1 phone lesson reader · 2 touch targets & rotate hint · 3 install
         4 phone coach marks · 5 share class to another device
         6 per-student weekly packet · 7 accessibility pass · 8 smoke test
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91,U=MM.util,D=MM.data,A=MM.auth,S=MM.shell,AD=MM.admin,ACC=MM.accounts,$=U.$,E=U.E,H=AD.h;
function phone(){return innerWidth<=640;}

/* ---------- 1. phone lesson reader ---------- */
var READER=MM.reader={
  fold:function(){var p=$('panel-lessons');if(!p)return;var body=p.querySelector('.panel-body');if(!body||body.__folded)return;body.__folded=1;
    var kids=[].slice.call(body.children),i=0;
    /* keep progress, lexile bar, week strip, voice bar, and the lesson header block unfolded; fold from the first section-head */
    var start=kids.findIndex(function(k){return k.classList&&k.classList.contains('section-head');});if(start<0)return;
    var groups=[],cur=null;for(i=start;i<kids.length;i++){var k=kids[i];if(k.classList.contains('section-head')){cur={head:k,items:[]};groups.push(cur);}else if(cur)cur.items.push(k);}
    groups.forEach(function(g,gi){var det=document.createElement('details');det.className='mm-fold';if(gi<2)det.open=true;var sum=document.createElement('summary');sum.textContent=(g.head.textContent||'').replace(/\s+/g,' ').trim().split(' — ')[0];det.appendChild(sum);var inner=document.createElement('div');inner.className='mm-fold-body';body.insertBefore(det,g.head);inner.appendChild(g.head);g.items.forEach(function(x){inner.appendChild(x);});det.appendChild(inner);});
    if(!$('mm-lesson-sticky')){var bar=document.createElement('div');bar.id='mm-lesson-sticky';bar.innerHTML='<button class="mm-btn ghost" onclick="loadLesson(currentIndex-1,true)" aria-label="Previous week">‹</button><button class="mm-btn primary" onclick="lessonNext(\'worksheet\')">Next: Worksheet →</button><button class="mm-btn ghost" onclick="loadLesson(currentIndex+1,true)" aria-label="Next week">›</button>';p.appendChild(bar);}},
  unfold:function(){var p=$('panel-lessons');if(!p)return;var body=p.querySelector('.panel-body');if(!body||!body.__folded)return;body.querySelectorAll('details.mm-fold').forEach(function(det){var inner=det.querySelector('.mm-fold-body');while(inner&&inner.firstChild)body.insertBefore(inner.firstChild,det);det.remove();});body.__folded=0;var bar=$('mm-lesson-sticky');if(bar)bar.remove();},
  sync:function(){if(phone()&&document.documentElement.classList.contains('mm-tabs-on'))READER.fold();else READER.unfold();}
};
window.addEventListener('resize',U.debounce(READER.sync,200));
(function(){if(typeof openPanel==='function'){var o=openPanel;var w=function(id){var r=o.apply(this,arguments);if(id==='lessons')setTimeout(READER.sync,0);return r;};w.__v94=true;openPanel=w;}})();

/* ---------- 2. rotate hint for wide games ---------- */
(function(){var WIDE={market:1,budget:1,interest:1,tax:1,life:1};
  function hint(id){var gb=$('gamesBody');if(!gb||gb.querySelector('.mm-rotate'))return;try{if(sessionStorage.getItem('mmRotateDismiss'))return;}catch(e){}gb.insertAdjacentHTML('afterbegin','<div class="mm-rotate" role="note"><span class="ic" aria-hidden="true">📱</span><div><b>Rotate for the best view.</b> This game has more room in landscape.</div><button class="mm-btn sm ghost" onclick="this.closest(\'.mm-rotate\').remove();try{sessionStorage.setItem(\'mmRotateDismiss\',\'1\')}catch(e){}">Got it</button></div>');}
  if(typeof openGame==='function'&&!openGame.__v94){var o=openGame;var w=function(id){var r=o.apply(this,arguments);if(WIDE[id]&&phone()&&innerHeight>innerWidth)setTimeout(function(){hint(id);},60);return r;};w.__v94=true;openGame=w;}})();

/* ---------- 3. install prompt ---------- */
var INST=MM.install={
  available:function(){try{if(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)return false;}catch(e){}return !!(window._installPrompt)||/iphone|ipad|android/i.test(navigator.userAgent);},
  go:function(){try{triggerInstall();}catch(e){}},
  card:function(){if(!INST.available())return '';return '<div class="mm-install"><span class="ic" aria-hidden="true">📲</span><div><b>Install Money Matters</b> on this device for a full-screen, offline classroom.</div><button class="mm-btn sm primary" onclick="MM91.install.go()">Install</button></div>';}
};
/* on the phone sheet */
(function(){var o=S.openSheet;S.openSheet=function(){o.apply(this,arguments);var sh=$('mm-sheet');if(!sh)return;var body=sh.querySelector('.sh-body');if(!body||body.querySelector('.mm-install')||body.querySelector('[data-v94-tour]'))return;
  var extra=(INST.available()?'<div style="margin:10px 0 4px">'+INST.card()+'</div>':'')+'<div class="sh-g">Help</div><div class="sh-grid"><button type="button" data-v94-tour onclick="MM91.shell.closeSheet();MM91.coach.start(true)"><span class="ic" aria-hidden="true">🧭</span><span>Phone tour</span></button>'+(INST.available()?'<button type="button" onclick="MM91.shell.closeSheet();MM91.install.go()"><span class="ic" aria-hidden="true">📲</span><span>Install app</span></button>':'')+'</div>';
  body.insertAdjacentHTML('beforeend',extra);};})();
/* in Settings (all sizes) */
AD.afterRender.push(function(st,main){if(st.tab!=='settings')return;var box=main.querySelector('#adminSettingsExt');if(box&&INST.available()&&!box.querySelector('.mm-install'))box.insertAdjacentHTML('afterbegin','<div style="margin-top:12px">'+INST.card()+'</div>');});

/* ---------- 4. phone coach marks ---------- */
var COACH=MM.coach=(function(){var el=null,i=0,steps=[];
  function build(){if(el)return el;el=document.createElement('div');el.id='mm-coach';el.setAttribute('role','dialog');el.setAttribute('aria-label','Phone tour');el.innerHTML='<div class="spot"></div><div class="card"></div>';document.body.appendChild(el);el.addEventListener('click',function(e){var a=e.target.getAttribute&&e.target.getAttribute('data-c');if(a==='next')next();if(a==='skip')end();});return el;}
  function targets(){var rk=A.roleKey(),staff=rk==='admin'||rk==='teacher';return [
    {sel:'#mm-tabbar',k:'1 of 3',t:'Everything is in the tab bar',p:staff?'Home, the Teacher’s Guide, Lessons, Students, and More. More opens your Console, every section, your session, and sign-out.':'Home, Lessons, Quiz, Story, and More. More opens every other section, including your profile and sign-out.',pos:'above'},
    {sel:'#mm-topbar .gradepick',k:'2 of 3',t:'Your grade is up here',p:staff?'Tap the grade chip to teach a different grade. Students always see their own grade.':'This is the grade your teacher set for you. It unlocks new grades when you are promoted.',pos:'below'},
    {sel:'#mm-home',k:'3 of 3',t:'Today at a glance',p:staff?'Class size, students who need attention, this week’s lesson, and backup reminders, with one-tap actions.':'Your next step, progress, word of the day, and readiness. Tap a card to jump straight in.',pos:'above'}];}
  function place(){var s=steps[i];if(!s){end();return;}var t=document.querySelector(s.sel),spot=el.querySelector('.spot'),card=el.querySelector('.card');if(!t||t.offsetParent===null&&s.sel!=='#mm-tabbar'){i++;if(i>=steps.length){end();return;}place();return;}
    var r=t.getBoundingClientRect(),pad=6;spot.style.left=(r.left-pad)+'px';spot.style.top=(r.top-pad)+'px';spot.style.width=(r.width+pad*2)+'px';spot.style.height=(r.height+pad*2)+'px';
    card.innerHTML='<div class="k">'+E(s.k)+'</div><h3>'+E(s.t)+'</h3><p>'+E(s.p)+'</p><div class="row"><div class="dots">'+steps.map(function(_,j){return '<i class="'+(j===i?'on':'')+'"></i>';}).join('')+'</div><button class="mm-btn sm ghost" data-c="skip">Skip</button><button class="mm-btn sm primary" data-c="next">'+(i===steps.length-1?'Done':'Next')+'</button></div>';
    card.style.top='';card.style.bottom='';if(s.pos==='below'){card.style.top=Math.min(innerHeight-220,r.bottom+14)+'px';}else{card.style.bottom=Math.max(12,innerHeight-r.top+14)+'px';}}
  function start(force){if(!phone()||!A.get())return;try{if(!force&&localStorage.getItem('mmPhoneTourDone'))return;}catch(e){}try{closePanel(true);}catch(e){}steps=targets();i=0;build().classList.add('on');setTimeout(place,250);}
  function next(){i++;if(i>=steps.length)end();else place();}
  function end(){if(el)el.classList.remove('on');try{localStorage.setItem('mmPhoneTourDone','1');}catch(e){}}
  return {start:start,end:end};})();
(function(){var oh=MM.gate.hide;MM.gate.hide=function(){oh.apply(MM.gate,arguments);setTimeout(function(){try{COACH.start(false);}catch(e){}},1400);};})();

/* ---------- 5. share class to another device ---------- */
var SHARE=MM.share={
  KEYS:['mmStudents_v2','mmAccounts_v1','mmSchools_v1','mmSchoolName','mmRoleCaps_v1','mmTeacherPin','mmTeacherRecQ','mmTeacherRecA','mmAdmin_v1','mmGate','mmLang'],
  pack:function(){var d={};SHARE.KEYS.forEach(function(k){try{var v=localStorage.getItem(k);if(v!=null)d[k]=v;}catch(e){}});try{Object.keys(localStorage).forEach(function(k){if(/^mmAssign\|/.test(k))d[k]=localStorage.getItem(k);});}catch(e){}return {app:'MoneyMatters',kind:'class',v:1,at:new Date().toISOString(),school:H.schoolName(),students:D.listAll().length,data:d};},
  download:function(){var p=SHARE.pack();U.download('MoneyMatters-class-'+(p.school||'package').replace(/[^\w]+/g,'_')+'-'+new Date().toISOString().slice(0,10)+'.mmclass.json',JSON.stringify(p),'application/json');ACC.log('backup',A.get().u||'','class package exported',A.displayName());},
  code:function(){try{return btoa(unescape(encodeURIComponent(JSON.stringify(SHARE.pack()))));}catch(e){return '';}},
  decode:function(text){text=String(text||'').trim();try{return JSON.parse(text);}catch(e){}try{return JSON.parse(decodeURIComponent(escape(atob(text.replace(/\s+/g,'')))));}catch(e){}return null;},
  apply:function(p,mode){if(!p||p.app!=='MoneyMatters'||!p.data)return {error:'Not a Money Matters class package.'};var d=p.data,added=0,merged=0;
    if(mode==='replace'){Object.keys(d).forEach(function(k){try{localStorage.setItem(k,d[k]);}catch(e){}});return {replaced:Object.keys(d).length};}
    /* merge students by name+grade (keep higher scores), accounts by username (keep existing), schools union, settings only when missing */
    try{if(d.mmStudents_v2){var inc=JSON.parse(d.mmStudents_v2);var r=mergeRestore(inc);added+=r.added;merged+=r.merged;}}catch(e){}
    try{if(d.mmAccounts_v1){var ia=JSON.parse(d.mmAccounts_v1),o=ACC.load();Object.keys(ia.list||{}).forEach(function(k){if(!o.list[k]){o.list[k]=ia.list[k];added++;}});if(!o.policy||!Object.keys(o.policy).length)o.policy=ia.policy||{};ACC.save(o);ACC.ensureStudents();}}catch(e){}
    try{if(d.mmSchools_v1){var is=JSON.parse(d.mmSchools_v1)||[],cur=MM.schools.list();is.forEach(function(s){if(cur.indexOf(s)<0)cur.push(s);});MM.schools.save(cur);if(!MM.schools.current()&&d.mmSchoolName)MM.schools.setCurrent(d.mmSchoolName);}}catch(e){}
    ['mmRoleCaps_v1','mmTeacherPin','mmTeacherRecQ','mmTeacherRecA','mmAdmin_v1','mmGate','mmLang'].forEach(function(k){try{if(d[k]!=null&&localStorage.getItem(k)==null)localStorage.setItem(k,d[k]);}catch(e){}});
    Object.keys(d).forEach(function(k){if(/^mmAssign\|/.test(k)){try{if(localStorage.getItem(k)==null)localStorage.setItem(k,d[k]);}catch(e){}}});
    ACC.log('backup',A.get().u||'','class package imported ('+added+' added, '+merged+' merged)',A.displayName());return {added:added,merged:merged};},
  importFile:function(){var inp=document.createElement('input');inp.type='file';inp.accept='.json,application/json,.mmclass.json';inp.onchange=function(){var f=inp.files&&inp.files[0];if(!f)return;var r=new FileReader();r.onload=function(){SHARE.importText(String(r.result||''));};r.readAsText(f);};inp.click();},
  importText:function(text){var p=SHARE.decode(text);if(!p){U.toast('That is not a valid class package.',3000);return;}
    mmConfirm('Import class from '+(p.school||'another device')+'?','Students: '+(p.students||'?')+'. Merge adds new students and accounts and keeps your existing progress. Replace overwrites roster, accounts, schools, and settings on this device.','Merge','📦').then(function(ok){if(!ok)return;var r=SHARE.apply(p,'merge');if(r.error){U.toast(r.error,3000);return;}U.toast('✓ Imported: '+r.added+' added, '+r.merged+' merged.',3500);setTimeout(function(){try{buildGradeNav();AD.render();}catch(e){}},200);});}
};
AD.acts.shareDownload=function(){SHARE.download();};
AD.acts.shareImport=function(){SHARE.importFile();};
AD.acts.shareCode=function(){var ta=$('share-code');if(!ta)return;ta.value=SHARE.code();ta.select();try{navigator.clipboard.writeText(ta.value).then(function(){U.toast('Share code copied. Paste it on the other device.',3500);});}catch(e){}};
AD.acts.sharePaste=function(){var ta=$('share-paste');if(!ta||!ta.value.trim()){U.toast('Paste a share code or package text first.');return;}SHARE.importText(ta.value);};
AD.afterRender.push(function(st,main){if(st.tab!=='data')return;var box=main.querySelector('#adminDataExt');if(!box||box.querySelector('.mm-share'))return;
  box.insertAdjacentHTML('beforeend','<div class="mm-card mm-share" style="margin-top:14px"><div class="mm-card-title">📦 Share class to another device</div><div class="mm-card-sub">Move this class (students, accounts, schools, roles, settings) to a tablet or another computer. Progress and logs stay on this device; use Full backup for everything. On the other device: Admin Console → Data &amp; Backup → Import.</div><div class="mm-row" style="margin-top:10px"><button class="mm-btn primary" data-act="shareDownload">⬇ Export class package</button><button class="mm-btn secondary" data-act="shareImport">📥 Import package file</button></div><div class="mm-grid c2" style="margin-top:12px"><div><div class="mm-label" style="margin-bottom:6px">Share code (copy and send)</div><textarea class="mm-share-code" id="share-code" readonly placeholder="Press Generate to create a code you can paste into email or chat."></textarea><div class="mm-row" style="margin-top:6px"><button class="mm-btn sm secondary" data-act="shareCode">Generate &amp; copy</button></div></div><div><div class="mm-label" style="margin-bottom:6px">Receive a share code</div><textarea class="mm-share-code" id="share-paste" placeholder="Paste a share code or package text here."></textarea><div class="mm-row" style="margin-top:6px"><button class="mm-btn sm primary" data-act="sharePaste">Import</button></div></div></div></div>');});

/* ---------- 6. per-student weekly packet ---------- */
var PACKET=MM.packet={
  build:function(id,idx){var st=D.get(id);if(!st)return '';var g=st.grade||'K',ls=D.lessons(g);if(!ls.length)return '';if(idx==null){var aw=null;try{aw=assignedWeek(g);}catch(e){}if(aw!=null&&ls[aw])idx=aw;else{idx=0;for(var i=0;i<ls.length;i++){var v=(st.prog||{})['quiz|'+g+'|'+ls[i].week];if(!(v!=null&&v>=75)){idx=i;break;}}}}
    var l=ls[idx];if(!l)return '';var prevG=currentGrade,prevI=currentIndex,html='';try{currentGrade=g;currentIndex=idx;var cover='<div class="paper"><div class="doc-kicker">Money Matters · Weekly Packet</div><h1>'+E(st.name)+'</h1><div class="doc-meta">'+E(D.gradeLabel(g))+(st.teacher?' · '+E(st.teacher):'')+(H.schoolName()?' · '+E(H.schoolName()):'')+'</div><h2>Week '+l.week+' · '+E(l.title)+'</h2><p>'+E(l.sub||'')+'</p><p><b>Objective:</b> '+E(l.objective||'')+'</p><div class="callout"><b>This packet contains:</b> the student worksheet, the family guide, and (for staff) the lesson plan.</div><div class="doc-note">Prepared '+E(new Date().toLocaleDateString())+'</div></div>';
      var ws='';try{ws=docWorksheet(l);}catch(e){}var fam='';try{fam=docFamily(l);}catch(e){}var plan='';try{if(A.isTeacher())plan=docPlan(l);}catch(e){}
      html=cover+'<div class="page-break"></div>'+ws+(fam?'<div class="page-break"></div>'+fam:'')+(plan?'<div class="page-break"></div>'+plan:'');}finally{currentGrade=prevG;currentIndex=prevI;}
    return html;},
  print:function(id,idx){var body=PACKET.build(id,idx);if(!body){U.toast('No lesson available for this student.');return;}var css='';try{css=PAPER_CSS;}catch(e){}U.openHTML('Weekly packet',body,css+'.paper{box-shadow:none;max-width:780px;margin:0 auto 18px;background:#fff;border-radius:10px;padding:32px}@media print{.page-break{page-break-before:always}}');},
  select:function(id){var st=D.get(id);if(!st)return;var g=st.grade||'K',ls=D.lessons(g);_openModal('🖨️','Print weekly packet','',[{label:'Cancel',ghost:true,value:false},{label:'Print',value:true}]).then(function(ok){if(!ok)return;var sel=$('pk-week');PACKET.print(id,sel?parseInt(sel.value,10):null);});setTimeout(function(){var b=$('mm-modal-body');if(!b)return;var aw=null;try{aw=assignedWeek(g);}catch(e){}b.innerHTML='<div style="text-align:left;font-size:13px;margin-bottom:8px">Choose the week for <b>'+E(st.name)+'</b>. The packet includes the worksheet, the family guide'+(A.isTeacher()?', and the lesson plan':'')+'.</div><select class="mm-select" id="pk-week">'+ls.map(function(l,i){return '<option value="'+i+'"'+(aw===i?' selected':'')+'>Week '+l.week+' · '+E(l.title)+'</option>';}).join('')+'</select>';},40);}
};
AD.acts.packet=function(el,o){PACKET.select(o.id);};
AD.afterRender.push(function(st,main){if(!(st.tab==='students'&&st.view==='student'))return;var acts=main.querySelector('.mm-profile-head .acts');if(acts&&!acts.querySelector('[data-act="packet"]'))acts.insertAdjacentHTML('afterbegin','<button class="mm-btn secondary" data-act="packet" data-id="'+E(st.sid)+'">🖨️ Weekly packet</button>');});

/* ---------- 7. accessibility pass ---------- */
var A11Y=MM.a11y={
  pass:function(root){root=root||document;try{
    root.querySelectorAll('.mm-table, .mm-roles, .st-table').forEach(function(t){if(!t.querySelector('caption')){var cap=document.createElement('caption');cap.className='mm-vh';var h=t.closest('.mm-card, .mm-table-wrap, .panel-body');var title=(h&&h.querySelector('.mm-card-title, h2, .mm-section h3'))?(h.querySelector('.mm-card-title, h2, .mm-section h3').textContent.trim()):'Data table';cap.textContent=title;t.insertBefore(cap,t.firstChild);}
      t.querySelectorAll('thead th').forEach(function(th){if(!th.getAttribute('scope'))th.setAttribute('scope','col');});t.querySelectorAll('tbody tr').forEach(function(tr){var td=tr.querySelector('td');if(td&&!td.getAttribute('scope')&&(td.classList.contains('name')||t.classList.contains('mm-roles'))){td.setAttribute('scope','row');}});});
    root.querySelectorAll('.mm-switch input').forEach(function(i){i.setAttribute('role','switch');i.setAttribute('aria-checked',String(i.checked));i.addEventListener('change',function(){i.setAttribute('aria-checked',String(i.checked));});});
    root.querySelectorAll('.cap-box').forEach(function(i){i.setAttribute('aria-checked',String(i.checked));i.addEventListener('change',function(){i.setAttribute('aria-checked',String(i.checked));});});
    root.querySelectorAll('.mm-tabs button[role=tab]').forEach(function(b){b.setAttribute('aria-selected',String(b.classList.contains('on')));});
    root.querySelectorAll('#mm-tabbar button').forEach(function(b){if(b.classList.contains('on'))b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
    root.querySelectorAll('.mm-prog[role=progressbar]').forEach(function(p){if(!p.getAttribute('aria-label'))p.setAttribute('aria-label','Progress');});
    root.querySelectorAll('.mm-user').forEach(function(c){if(!c.getAttribute('role')){c.setAttribute('role','group');var nm=c.querySelector('.hd .nm');if(nm)c.setAttribute('aria-label',nm.textContent.trim());}});
    root.querySelectorAll('button:not([aria-label])').forEach(function(b){var t=(b.textContent||'').trim();if(!t&&b.title)b.setAttribute('aria-label',b.title);});
  }catch(e){}},
  live:function(msg){var l=$('mm-live');if(!l){l=document.createElement('div');l.id='mm-live';l.className='mm-vh';l.setAttribute('aria-live','polite');document.body.appendChild(l);}l.textContent='';setTimeout(function(){l.textContent=msg;},30);}
};
AD.afterRender.push(function(st,main){A11Y.pass(main);A11Y.pass($('adminSide'));var h2=main.querySelector('h2');if(h2)A11Y.live(h2.textContent.trim()+' loaded');});
(function(){var ot=S.topbar;S.topbar=function(){ot.apply(this,arguments);try{A11Y.pass($('mm-tabbar'));}catch(e){}};})();
/* sheet: focus management and focus return */
(function(){var last=null;var oo=S.openSheet;S.openSheet=function(){last=document.activeElement;oo.apply(this,arguments);var sh=$('mm-sheet');if(sh){sh.querySelector('.sh-card').setAttribute('tabindex','-1');setTimeout(function(){var b=sh.querySelector('.sh-grid button');if(b)b.focus();},60);}};var oc=S.closeSheet;S.closeSheet=function(){oc.apply(this,arguments);if(last&&last.focus)try{last.focus();}catch(e){}};})();
/* the inactivity sign-out reason is announced */
(function(){var oShow=MM.gate.show;MM.gate.show=function(opts){oShow.call(MM.gate,opts);if(opts&&opts.message)A11Y.live(opts.message);};})();
document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){A11Y.pass(document);},1500);});

/* ---------- 8. smoke test ---------- */
var SMOKE=MM.smoke={
  PANELS:{student:['dashboard','lessons','path','quiz','test','glossary','story','games','certificate','assessment','help','a11y','legal','feedback','login'],staff:['admin','dashboard','lessons','path','quiz','test','glossary','story','games','certificate','assessment','help','a11y','legal','feedback','login','doc','overview']},
  TABS:['overview','me','users','students','teachers','classes','curriculum','reports','roles','security','authlog','data','settings','system'],
  run:function(opts){opts=opts||{};var results=[],errors=[],t0=Date.now();var onErr=function(e){errors.push(String(e&&(e.message||e.reason&&e.reason.message||e.reason)||e));};window.addEventListener('error',onErr);window.addEventListener('unhandledrejection',onErr);var ce=console.error;console.error=function(){errors.push([].slice.call(arguments).map(String).join(' '));ce.apply(console,arguments);};
    var startAdmin=A.isAdmin(),stashBefore=!!A.stash();
    function step(label,fn){return new Promise(function(res){var e0=errors.length,s=Date.now();var r={label:label,ok:true,ms:0,err:''};try{var ret=fn();Promise.resolve(ret).then(function(){setTimeout(function(){r.ms=Date.now()-s;if(errors.length>e0){r.ok=false;r.err=errors.slice(e0).join(' | ').slice(0,200);}results.push(r);if(opts.onStep)opts.onStep(r,results);res();},opts.delay||120);}).catch(function(x){r.ok=false;r.err=String(x).slice(0,200);r.ms=Date.now()-s;results.push(r);res();});}catch(x){r.ok=false;r.err=String(x).slice(0,200);r.ms=Date.now()-s;results.push(r);if(opts.onStep)opts.onStep(r,results);res();}});}
    function panelSteps(role){var list=SMOKE.PANELS[role==='student'?'student':'staff'];return list.reduce(function(p,id){return p.then(function(){return step((role)+' · panel: '+id,function(){openPanel(id);try{_quizInProgress=false;}catch(e){}var el=$('panel-'+id);if(!el||!el.classList.contains('open')){if(role==='student'&&MM.assessFirst&&MM.assessFirst.needs()&&$('panel-assessment').classList.contains('open'))return;throw new Error('panel did not open');}var body=el.querySelector('.panel-body');if(body&&!body.innerHTML.trim())throw new Error('empty panel body');});});},Promise.resolve());}
    function tabSteps(){return SMOKE.TABS.reduce(function(p,t){return p.then(function(){return step('admin · console: '+t,function(){AD.open(t);var m=$('adminMain');if(!m||m.innerHTML.length<200)throw new Error('console section empty');if(m.querySelector('.mm-alert.bad'))throw new Error(m.querySelector('.mm-alert.bad').textContent.slice(0,120));});});},Promise.resolve());}
    var chain=Promise.resolve();
    if(startAdmin){chain=chain.then(function(){return step('admin · sign-in state',function(){if(!A.get())throw new Error('no session');});}).then(tabSteps).then(function(){return panelSteps('admin');});
      var st=D.listAll()[0],tch=ACC.staff().filter(function(a){return a.role!=='admin'&&!a.pending&&!a.locked;})[0];
      if(tch)chain=chain.then(function(){return step('switch → teacher '+tch.u,function(){A.impersonateStaff(tch.u);if(A.isAdmin())throw new Error('still admin');});}).then(function(){return panelSteps('teacher');}).then(function(){return step('return to admin',function(){A.returnToAdmin();if(!A.isAdmin())throw new Error('not restored');});});
      if(st)chain=chain.then(function(){return step('switch → student '+st.name,function(){A.impersonate(st.id);if(A.roleKey()!=='student')throw new Error('not student');});}).then(function(){return panelSteps('student');}).then(function(){return step('return to admin',function(){A.returnToAdmin();if(!A.isAdmin())throw new Error('not restored');});});}
    else{chain=chain.then(function(){return panelSteps(A.roleKey());});}
    return chain.then(function(){try{_quizInProgress=false;}catch(e){}try{_closeModal(false);}catch(e){}try{closePanel(true);}catch(e){}window.removeEventListener('error',onErr);window.removeEventListener('unhandledrejection',onErr);console.error=ce;var rep={at:new Date().toISOString(),ms:Date.now()-t0,total:results.length,passed:results.filter(function(r){return r.ok;}).length,results:results};window.__MM_SMOKE=rep;try{localStorage.setItem('mmSmokeLast',JSON.stringify({at:rep.at,total:rep.total,passed:rep.passed,ms:rep.ms}));}catch(e){}try{console.table(results.map(function(r){return {step:r.label,ok:r.ok,ms:r.ms,error:r.err};}));}catch(e){}return rep;});}
};
AD.acts.smokeRun=function(){if(!A.isAdmin()){U.toast('Run the smoke test as an administrator.');return;}var box=$('smoke-out');if(box)box.innerHTML='<div class="mm-smoke"><progress id="smoke-prog" max="60" value="0"></progress><div id="smoke-live" class="mm-muted" style="margin-top:6px">Starting…</div></div>';
  SMOKE.run({delay:150,onStep:function(r,all){var l=$('smoke-live'),p=$('smoke-prog');if(l)l.textContent=(r.ok?'✓ ':'✕ ')+r.label;if(p)p.value=all.length;}}).then(function(rep){AD.open('system');setTimeout(function(){var b=$('smoke-out');if(!b)return;b.innerHTML='<div class="mm-smoke"><div class="mm-grid c3" style="margin-bottom:10px">'+H.stat(rep.passed+' / '+rep.total,'Steps passed',rep.passed===rep.total?'ok':'bad')+H.stat((rep.ms/1000).toFixed(1)+'s','Duration')+H.stat(E(U.fmtDateTime(rep.at)),'Run at','','',null)+'</div><div class="mm-table-wrap"><table class="mm-table"><thead><tr><th>Step</th><th>Result</th><th class="num">ms</th><th>Detail</th></tr></thead><tbody>'+rep.results.map(function(r){return '<tr><td>'+E(r.label)+'</td><td><span class="'+(r.ok?'ok':'bad')+'">'+(r.ok?'✓ pass':'✕ fail')+'</span></td><td class="num">'+r.ms+'</td><td class="muted">'+E(r.err)+'</td></tr>';}).join('')+'</tbody></table></div><div class="mm-muted" style="margin-top:8px">Results are also in the browser console (<code>console.table</code>) and in <code>window.__MM_SMOKE</code>. Open the app with <code>#smoke</code> in the address bar to run automatically after an administrator signs in.</div></div>';A11Y.pass(b);},200);});};
AD.afterRender.push(function(st,main){if(st.tab!=='system')return;var h=main.querySelector('.mm-admin-head');if(!h||main.querySelector('#smoke-out'))return;var last='';try{var l=JSON.parse(localStorage.getItem('mmSmokeLast')||'null');if(l)last='Last run '+U.fmtDateTime(l.at)+': '+l.passed+' of '+l.total+' passed in '+(l.ms/1000).toFixed(1)+'s.';}catch(e){}
  h.insertAdjacentHTML('afterend','<div class="mm-card accent" style="margin-bottom:14px"><div class="mm-card-title">🧪 Automated smoke test <span class="spacer"></span><button class="mm-btn primary" data-act="smokeRun">▶ Run smoke test</button></div><div class="mm-card-sub">Opens every console section and every panel as administrator, then as a teacher and as a student (via profile switching), and checks for runtime errors and empty views. Takes about a minute. '+E(last)+'</div><div id="smoke-out" style="margin-top:10px"></div></div>');});
if(location.hash==='#smoke'){var tries=0;(function auto(){if(A.isAdmin()&&!MM.gate.visible()){SMOKE.run({delay:120});return;}if(tries++<600)setTimeout(auto,500);})();}

/* ---------- release notes ---------- */
try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'October 2026',items:['Phone lesson reader: single column, large type, collapsible sections, a snap-scrolling week strip, and a sticky Next: Worksheet bar.','Touch targets of at least 44 px across games, quizzes, tests, and the story; a rotate hint for wide games on phones.','Install prompt in the phone sheet and in Settings; a three-step phone tour (tab bar, grade chip, Today cards) that also replays from More.','Share class to another device: export/import a class package or paste a share code; merge keeps existing progress.','Print a weekly packet (worksheet, family guide, lesson plan) for one student from the student profile.','Accessibility pass: table captions and scopes, switch roles, announced section changes, focus management for sheets.','Automated smoke test in System: every section and panel as administrator, teacher, and student, with a results table and #smoke auto-run.']});}}catch(e){}
})();
