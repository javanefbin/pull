/* =====================================================================
   V22 · ANONYMOUS USAGE COUNTS  (window.MMUsage)
   Hosted site only, when /api/config says usage is on. Counts how often things
   are opened (a lesson week, a quiz, a workshop's Run mode, the Game Show, a
   panel), adds them up in memory, and sends the day's totals when the page is
   hidden or closed. No user, device, school or IP is sent or kept: only
   "lesson:4:3 was opened 2 times today". An administrator can turn it off for
   this device in Admin Console → Settings. Read the totals with npm run usage.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var HOSTED=!!window.MM_PUBLIC_BUILD&&/^https?:$/.test(location.protocol);
var OFF='mmUsageOff',EV=/^[a-z][a-z0-9-]{0,23}(:[A-Za-z0-9_-]{1,24}){0,3}$/;
var on=false,counts={},n=0,prev={panel:'',lesson:'',gs:false,lp:false,run:false,who:''};
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function off(){try{return localStorage.getItem(OFF)==='1';}catch(e){return false;}}
function day(){return new Date().toISOString().slice(0,10);}
var API=window.MMUsage={count:count,flush:flush,enabled:function(){return on&&!off();},setOff:function(v){try{if(v)localStorage.setItem(OFF,'1');else localStorage.removeItem(OFF);}catch(e){}if(v)counts={};},_peek:function(){return Object.assign({},counts);}};
function count(ev){if(!on||off()||!EV.test(ev))return;counts[ev]=(counts[ev]||0)+1;n++;if(n>=200)flush();}
function flush(){var keys=Object.keys(counts);if(!keys.length)return;var body=JSON.stringify({d:day(),e:counts});counts={};n=0;
  try{if(navigator.sendBeacon&&navigator.sendBeacon('/api/usage',new Blob([body],{type:'application/json'})))return;}catch(e){}
  try{fetch('/api/usage',{method:'POST',headers:{'Content-Type':'application/json'},body:body,keepalive:true}).catch(function(){});}catch(e){}}

/* what is being used: watched every 1.5 s (no wrappers around app functions) */
function tick(){var c=document.documentElement.classList;
  var who='';try{var a=MM.auth.get();who=a?(a.role==='student'?'student':MM.auth.roleKey()):'';}catch(e){}
  if(who&&who!==prev.who)count('session:'+who);prev.who=who;
  var panel=(typeof openPanelId!=='undefined'&&openPanelId)||'';
  if(panel&&panel!==prev.panel)count('panel:'+panel);prev.panel=panel;
  var lesson='';try{if(panel==='lessons'||panel==='quiz')lesson=(panel==='quiz'?'quiz:':'lesson:')+currentGrade+':'+(currentIndex+1);}catch(e){}
  if(lesson&&lesson!==prev.lesson)count(lesson);prev.lesson=lesson;
  var gs=c.contains('mm-gs-on');if(gs&&!prev.gs)count('gameshow');prev.gs=gs;
  var lp=c.contains('mm-lp-on');if(lp&&!prev.lp)count('live-player');prev.lp=lp;
  var run=false;try{run=!!(window.MMWorkshopRun&&MMWorkshopRun.isOpen());}catch(e){}if(run&&!prev.run){try{count('workshop-run:'+currentGrade);}catch(e){count('workshop-run');}}prev.run=run;}

/* Admin Console → Settings: the switch */
var AD=MM.admin;
if(AD&&AD.afterRender)AD.afterRender.push(function(st,main){if(st.tab!=='settings'||!HOSTED||!on||!main||main.querySelector('#mm-usage-card'))return;
  var d=document.createElement('div');d.className='mm-card';d.id='mm-usage-card';
  d.innerHTML='<div class="mm-card-title">📊 '+T('Anonymous usage counts')+'</div><p>'+T('This device adds to daily totals of which lessons, quizzes, workshops and games are opened. Nothing identifies a person, a device or your school.')+'</p><label class="mm-switch"><input type="checkbox" id="mm-usage-on"'+(off()?'':' checked')+'><span>'+T('Share anonymous usage counts from this device')+'</span></label>';
  main.appendChild(d);d.querySelector('#mm-usage-on').addEventListener('change',function(e){API.setOff(!e.target.checked);});});

if(!HOSTED)return;
(function boot(){if(!window.MMConfig){setTimeout(boot,200);return;}MMConfig().then(function(c){on=!!(c&&c.usage);if(!on)return;
  count('edition:'+(window.MMLicense&&MMLicense.licensed?'licensed':'free'));
  try{var lg=localStorage.getItem('mmLang')||'en';if(lg!=='en')count('lang:'+lg);}catch(e){}
  count('device:'+(innerWidth<=640?'phone':innerWidth<=1024?'tablet':'desktop'));
  setInterval(tick,1500);setInterval(flush,10*60000);
  document.addEventListener('visibilitychange',function(){if(document.hidden)flush();});
  window.addEventListener('pagehide',flush);});})();
})();
