/* =====================================================================
   V22 · SHARE TO GOOGLE CLASSROOM, AND LINKS THAT OPEN A LESSON  (window.MMLinks)
   Hosted site only (a file:// copy has no address to share).
   · Links:  https://<site>/?open=lesson&grade=4&week=3   (also open=quiz, story,
     games, glossary, path). The page remembers the link, removes it from the
     address bar, and opens it once someone is signed in. A student opens it
     only in their own grade. Week locks and the free edition still apply.
   · Share:  Google's documented share link,
     https://classroom.google.com/share?url=<link>, in a small window. The
     teacher picks the class and posts it as an assignment, material or
     announcement. Nothing is sent to Google until they post.
   · Buttons: the lesson's teacher view (lesson, quiz), the live Game Show
     lobby (the join link), and class sync's student link (664 ↔ 665).
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var A=MM.auth,U=MM.util;
var HOSTED=/^https?:$/.test(location.protocol);
var KINDS=['lesson','quiz','story','games','glossary','path'],PEND='mmOpenLink_v1';
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function toast(m,ms){try{U.toast(m,ms||4000);}catch(e){try{infoToast(m,ms||4000);}catch(x){}}}
function base(){return location.origin+location.pathname;}

var API=window.MMLinks={
  url:function(kind,grade,week){var q=new URLSearchParams();q.set('open',kind);if(grade!=null)q.set('grade',String(grade));if(week)q.set('week',String(week));return base()+'?'+q.toString();},
  classroom:function(url){return 'https://classroom.google.com/share?url='+encodeURIComponent(url);},
  share:function(url){if(!HOSTED){toast(T('Sharing to Google Classroom works on the website, not in a downloaded copy.'));return false;}
    var w=window.open(API.classroom(url),'mmClassroomShare','width=660,height=720,noopener');if(!w){location.assign(API.classroom(url));}return true;},
  button:function(url,label){return '<button type="button" class="mm-btn sm secondary mm-share-btn" data-share-url="'+esc(url)+'"><span class="mm-gc-mark" aria-hidden="true"></span>'+esc(label||T('Share to Google Classroom'))+'</button>';},
  _apply:apply,_pending:function(){try{return JSON.parse(sessionStorage.getItem(PEND)||'null');}catch(e){return null;}}};
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-share-url]');if(!b)return;e.preventDefault();API.share(b.getAttribute('data-share-url'));},true);

/* ---------- 1. read a link once, then clean the address bar ---------- */
(function read(){var q=new URLSearchParams(location.search),k=q.get('open');if(!k||KINDS.indexOf(k)<0)return;
  var g=String(q.get('grade')||''),w=parseInt(q.get('week'),10)||0;
  if(g&&!/^(K|[1-8])$/.test(g))g='';if(w<0||w>36)w=0;
  try{sessionStorage.setItem(PEND,JSON.stringify({k:k,g:g,w:w,at:Date.now()}));}catch(e){}
  ['open','grade','week'].forEach(function(x){q.delete(x);});
  try{history.replaceState(null,'',location.pathname+(q.toString()?'?'+q.toString():'')+location.hash);}catch(e){}})();

/* ---------- 2. open it once someone is signed in ---------- */
/* signed in, and the app's own start-up routing (e.g. a new student's first assessment) has had its turn */
var since=0;
function ready(){var ok=false;try{var a=A.get();ok=!!a&&!MM.gate.visible()&&!document.querySelector('.mmrt-ov')&&(a.role!=='student'||(typeof activeStudent==='function'&&!!activeStudent()));}catch(e){}if(!ok){since=0;return false;}if(!since)since=Date.now();return Date.now()-since>1600;}
function apply(){var p=API._pending();if(!p)return false;if(Date.now()-p.at>6*3600000){try{sessionStorage.removeItem(PEND);}catch(e){}return false;}
  if(!ready())return false;
  /* students who must take the Financial Literacy Assessment first: the link waits until it is done */
  try{if(MM.assessFirst&&MM.assessFirst.needs()){if(!p.told){p.told=1;sessionStorage.setItem(PEND,JSON.stringify(p));toast(T('Your teacher\'s link opens right after the Financial Literacy Assessment.'),5000);}return false;}}catch(e){}
  try{sessionStorage.removeItem(PEND);}catch(e){}
  var who=A.get(),student=who.role==='student';
  if(p.g){if(student){var st=null;try{st=loadStore().list[who.id];}catch(e){}
      if(st&&st.grade&&String(st.grade)!==p.g){toast(T('That link is for')+' '+(p.g==='K'?T('Kindergarten'):T('Grade')+' '+p.g)+'. '+T('Opening your own grade.'),5000);p.g='';}}
    if(p.g&&!student)try{setGrade(p.g);}catch(e){}}
  try{closePanel(true);}catch(e){}
  setTimeout(function(){try{
    if(p.k==='lesson'){if(p.w)gotoLesson(p.w-1);else openPanel('lessons');}
    else if(p.k==='quiz'){if(p.w){currentIndex=p.w-1;}openQuiz();}
    else openPanel(p.k);
  }catch(e){}},120);
  return true;}
var iv=setInterval(function(){if(!API._pending()){clearInterval(iv);return;}apply();},1000);

/* ---------- 3. buttons ---------- */
function staff(){try{return A.roleKey()!=='student';}catch(e){return false;}}
function teachView(){if(!HOSTED||!staff())return;var top=document.querySelector('#panel-lessons .mmtv-top, #panel-doc .mmtv-top');if(!top||top.querySelector('.mm-share'))return;
  var l=null;try{l=L();}catch(e){}if(!l)return;var w=l.week||(currentIndex+1);
  var d=document.createElement('div');d.className='mm-share';
  d.innerHTML='<span class="mm-share-lbl">'+esc(T('Share to Google Classroom'))+':</span>'+API.button(API.url('lesson',currentGrade,w),T('Lesson')+' '+w)+API.button(API.url('quiz',currentGrade,w),T('Quiz')+' '+w);
  top.appendChild(d);}
function lobby(){if(!HOSTED)return;var inp=document.querySelector('#mm-gs .gl-link');if(!inp||!/^https:/.test(inp.value)||!/[?&]sb=/.test(inp.value))return;   /* phones join through the school's live server; a this-device link is no use to share */var row=inp.parentNode;if(!row||row.querySelector('.mm-share-btn'))return;
  var d=document.createElement('span');d.innerHTML=API.button(inp.value,T('Share to Classroom'));row.appendChild(d.firstChild);}
var t=0;function scan(){clearTimeout(t);t=setTimeout(function(){teachView();lobby();},80);}
function boot(){['panel-lessons','panel-doc','mm-gs'].forEach(function(id){var el=document.getElementById(id);if(el&&!el.__share){el.__share=1;new MutationObserver(scan).observe(el,{childList:true,subtree:true});}});
  /* #mm-gs is created on first use */
  if(!document.getElementById('mm-gs')&&!boot.__w){boot.__w=new MutationObserver(function(){if(document.getElementById('mm-gs')){boot.__w.disconnect();boot();}});boot.__w.observe(document.body,{childList:true});}scan();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
