/* =====================================================================
   V21 · MATERIALS CENTER  (window.MMMaterials · panel "materials")
   Where to get every material a lesson or workshop day asks for:
     🖨 Print it here    play money, coins, price tags, pay stubs, checks,
                        registers, receipts, budget sheets, job cards, need
                        and want cards, goal trackers, jar labels, ten frames,
                        scenario cards, points boards and more, sized for the
                        grade band (K–2, 3–5, 6–8)
     📄 In the app       worksheets, quizzes and lesson slides that the lesson
                        or workshop already provides
     🔗 Free source      official free materials (IRS Form W-4, U.S. Currency
                        Education Program play money and lesson plans, U.S. Mint,
                        FDIC Money Smart, Federal Reserve Education)
     🏫 Supply           ordinary classroom supplies, with where-to-get tips
                        and a family supply-request letter
   Play money is an original design marked "Play money · not real money",
   printed one-sided and under three-quarters the size of real bills, in line
   with the rules for currency illustrations (31 CFR 411).
   Staff only. Opened from the dock (Documents → Materials), a lesson's
   Prepare list, a workshop day's materials checklist, or the Resource Guide.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91||{};
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function grade(){try{return currentGrade||'K';}catch(e){return 'K';}}
function band(g){g=g||grade();return g==='K'||g==='1'||g==='2'?'K-2':(+g<=5?'3-5':'6-8');}
function gname(g){try{if(typeof GRADE_LABEL!=='undefined'&&GRADE_LABEL[g])return GRADE_LABEL[g];}catch(e){}return g==='K'?'Kindergarten':'Grade '+g;}
function isStaff(){try{return MM.auth.roleKey()!=='student'&&!!MM.auth.get();}catch(e){return false;}}
function school(){try{return (typeof getSchoolName==='function'&&getSchoolName())||localStorage.getItem('mmSchoolName')||'';}catch(e){return '';}}
function money(n){return '$'+(Math.round(n*100)/100).toFixed(n%1?2:0);}
function cents(n){return n<1?Math.round(n*100)+'¢':money(n);}

/* ---------- 1. official free sources (links checked 2026-10-27) ---------- */
var SOURCES={
  w4:{t:'IRS Form W-4 (current year)',u:'https://www.irs.gov/forms-pubs/about-form-w-4',d:'The real Employee’s Withholding Certificate. Print a blank copy for practice; students never enter real personal information.'},
  uscurrency:{t:'U.S. Currency Education Program: lesson plans and printable play money',u:'https://www.uscurrency.gov/educational-materials/classrooms/lesson-plans',d:'Free lesson plans for grades 2–5 with a printable play money file, plus the free book Carnival Thrills and Dollar Bills (English and Spanish).'},
  mint:{t:'U.S. Mint Coin Classroom',u:'https://kids.usmint.gov',d:'Coin facts, games and classroom ideas for younger grades.'},
  fdic:{t:'FDIC Money Smart for Young People',u:'https://www.fdic.gov/consumer-resource-center/money-smart-young-people',d:'Free Pre-K–12 lessons with teacher guides, student activities and family guides.'},
  fed:{t:'Federal Reserve Education teaching resources',u:'https://www.federalreserveeducation.org/teaching-resources',d:'Free lessons, activities and classroom materials searchable by grade and topic.'},
  cfpb:{t:'CFPB youth financial education activities',u:'https://www.consumerfinance.gov/consumer-tools/educator-tools/youth-financial-education/teach/activities/',d:'Free activities for K–12, searchable by grade and topic.'},
  credit:{t:'AnnualCreditReport.com (official site)',u:'https://www.annualcreditreport.com',d:'For teaching only: the one official site for free credit reports. Use the printable sample report here with students.'}
};

/* ---------- 2. classify a material ---------- */
/* [pattern, type, key]  type: print | app | source | supply */
var RULES=[
  [/w-?4/i,'source','w4'],
  [/credit report/i,'print','creditreport'],
  [/check register|checkbook register|ledgers?\b|balance books?|(final |)registers\b|bank statements?|monthly statements?/i,'print','register'],
  [/deposit slip/i,'print','deposit'],
  [/\bchecks?\b|blank check/i,'print','checks'],
  [/pay ?stub|paycheck|pay check|pay slip/i,'print','paystub'],
  [/receipt/i,'print','receipt'],
  [/play (money|bills?|dollars?|\$)|money bills|bills and coins|coins and bills|play cash|cash box|dollar bills?|\$1 bill|fake money/i,'print','money'],
  [/coin|penn(y|ies)|nickels?|dimes?|quarters?/i,'print','coins'],
  [/price tags?|price cards?|price labels?|item cards?|store items|menu|catalog|price list|product cards?/i,'print','items'],
  [/shopping list/i,'print','shopping'],
  [/budget/i,'print','budget'],
  [/job|career|chore/i,'print','jobs'],
  [/needs?.{0,12}wants?|wants?.{0,12}needs?/i,'print','needwant'],
  [/goal|savings tracker|thermometer|growth chart|tracker/i,'print','goal'],
  [/jars?\b|save.{0,6}spend|piggy/i,'print','jars'],
  [/ten[- ]frame|hundreds? (chart|grid)|10 ?x ?10|ten by ten|counting mat|number line/i,'print','grid'],
  [/sorting mats?|sort mats?|compare mats?/i,'print','sortmat'],
  [/points? board|score ?board|score sheet|team chart/i,'print','points'],
  [/tally|recording sheet|record sheet|data sheet|log sheet/i,'print','tally'],
  [/name (tag|tent|card)|badge|lanyard/i,'print','names'],
  [/cards?\b|deck|prompts?|scenarios?|station/i,'print','cards'],
  [/slides?\b|lesson video|projector|mockups?|audio|recorded/i,'app','slides'],
  [/worksheet|handout|quiz|packet|practice sheet|answer key|test|review page|activity page|plan sheet|planning sheet|template|form/i,'app','docs'],
  [/calculat/i,'supply','calculators'],
  [/timer|stopwatch|bell/i,'supply','timer'],
  [/whiteboard|dry[- ]erase/i,'supply','whiteboards'],
  [/pencil|crayon|marker|highlighter|pen\b|pens\b|colored/i,'supply','writing'],
  [/paper|notebook|index card|sticky|post-it|poster|graph|journal|envelope|folder|cardstock/i,'supply','paper'],
  [/glue|tape|scissors|stapler|hole punch|string|yarn|clip/i,'supply','craft'],
  [/sticker|stamp|medal|prize|ribbon|award/i,'supply','rewards'],
  [/counter|cube|dice|die\b|spinner|ruler|scale|magnif|bag|box|basket|cup|container|tray|apron|hoop|cone|ball|lock/i,'supply','manipulatives'],
  [/snack|food|candy|fruit|water/i,'supply','food'],
  [/rubric|checklist|check list/i,'print','checklist'],
  [/certificate/i,'app','certs'],
  [/labels?\b|strips?\b|slips?\b/i,'print','cards'],
  [/(charts?|tables?|boards?|calendars?|signs?|plans?|banks?|bubbles?|maps?|frames?|lists?|pages?|guides?)\b|sheets?\b|mats?\b|chips?\b|bins?\b/i,'print','chart'],
  [/picture|photo|image|drawing of/i,'supply','pictures'],
  [/toy|pretend|wallet|cart|phone|cash register|pointer|stage|noisemaker|costume|prop/i,'supply','props']
];
var SUPPLY={
  calculators:{i:'🧮',t:'Calculators',d:'Basic four-function calculators. No set? Students can use the calculator on a school device, or pair up and share.'},
  timer:{i:'⏱',t:'Timer',d:'Use Run mode in Workshops: it has a full-screen countdown and a time’s-up chime.'},
  whiteboards:{i:'🧽',t:'Whiteboards and dry-erase markers',d:'Sheet protectors around white paper work as cheap individual whiteboards.'},
  writing:{i:'✏️',t:'Pencils, markers and crayons',d:'Standard classroom stock; ask families with the supply letter.'},
  paper:{i:'📄',t:'Paper, notebooks and cards',d:'Chart paper, index cards and sticky notes from the school supply room.'},
  craft:{i:'✂️',t:'Glue, tape and scissors',d:'Standard classroom stock.'},
  rewards:{i:'⭐',t:'Stickers and small rewards',d:'Optional. Certificates and team points from the app work as rewards too.'},
  manipulatives:{i:'🧺',t:'Manipulatives and props',d:'Counters, dice, containers and props. Substitute anything similar you already have.'},
  pictures:{i:'🖼',t:'Pictures',d:'Draw them, show the lesson slide on the projector, or use the item cards in the Printables library.'},
  props:{i:'🧸',t:'Pretend props',d:'Toy wallets, carts, phones and signs. Anything similar works, or make one from paper and a box.'},
  food:{i:'🍎',t:'Food or snacks',d:'Optional. Check allergies and school policy first; picture cards work instead.'},
  other:{i:'📦',t:'Other items',d:'Use what you have or a printed picture card; nothing here needs to be bought new.'}
};
var memo={};
function classify(m){var k=String(m||'').trim().toLowerCase();if(memo[k])return memo[k];var r=null;for(var i=0;i<RULES.length;i++)if(RULES[i][0].test(k)){r={type:RULES[i][1],key:RULES[i][2]};break;}return (memo[k]=r||{type:'supply',key:'other'});}

/* ---------- 3. printables ---------- */
var CSS='.mtl-h{margin:0 0 4px;font:700 20px Georgia,serif}.mtl-note{margin:0 0 10px;font:11px system-ui,sans-serif;color:#555}'
 +'.cut{display:grid;gap:0;border-top:1px dashed #999;border-left:1px dashed #999}.cut>*{border-right:1px dashed #999;border-bottom:1px dashed #999;break-inside:avoid;page-break-inside:avoid}'
 +'.bill{height:1.25in;padding:.06in;display:flex}.bill>div{flex:1;border:2px solid var(--c);border-radius:6px;background:var(--bg);display:grid;grid-template-columns:auto 1fr auto;align-items:center;padding:0 .1in;position:relative;overflow:hidden}'
 +'.bill b{font:800 24px Georgia,serif;color:var(--c)}.bill .mid{text-align:center;font:700 9px system-ui,sans-serif;letter-spacing:.12em;color:var(--c);line-height:1.4}.bill .mid i{display:block;font:italic 700 15px Georgia,serif;letter-spacing:0}.bill .mid small{display:block;font-size:7px;letter-spacing:.06em;font-weight:600;color:#444}'
 +'.coins{display:flex;flex-wrap:wrap;gap:.12in;justify-content:flex-start}.coin{border-radius:50%;border:2px dashed #777;display:flex;flex-direction:column;align-items:center;justify-content:center;background:var(--bg);text-align:center;font:800 13px system-ui,sans-serif;color:#222}.coin small{font-size:7px;font-weight:700;letter-spacing:.05em}'
 +'.card{padding:.12in;min-height:1.1in;display:flex;flex-direction:column;gap:3px;font:12px/1.35 system-ui,sans-serif}.card .ic{font-size:26px;line-height:1}.card b{font:700 14px Georgia,serif}.card .pr{margin-top:auto;font:800 18px system-ui,sans-serif}'
 +'.tag{padding:.1in;text-align:center;font:12px system-ui,sans-serif;min-height:.9in;display:flex;flex-direction:column;justify-content:center}.tag b{font:800 22px system-ui,sans-serif}'
 +'.doc{border:1.5px solid #333;border-radius:6px;padding:.12in .16in;margin:0 0 .18in;font:12px/1.5 system-ui,sans-serif;break-inside:avoid;page-break-inside:avoid}.doc h4{margin:0 0 4px;font:700 14px Georgia,serif;display:flex;justify-content:space-between}'
 +'.ln{display:flex;gap:8px;align-items:flex-end;margin:6px 0}.ln span{white-space:nowrap}.ln i{flex:1;border-bottom:1px solid #333;min-height:16px}.box{border:1.5px solid #333;min-width:1.1in;height:24px;display:inline-block;vertical-align:middle}'
 +'table.g{width:100%;border-collapse:collapse;font:12px system-ui,sans-serif}table.g th,table.g td{border:1px solid #444;padding:5px 6px;text-align:left;height:22px}table.g th{background:#eee;font-size:11px;text-transform:uppercase;letter-spacing:.05em}'
 +'.big{font:800 40px Georgia,serif;text-align:center;padding:.3in 0}.mat2{display:grid;grid-template-columns:1fr 1fr;gap:.2in;height:8.4in}.mat2>div{border:3px solid #333;border-radius:14px;padding:.15in;text-align:center;font:800 30px Georgia,serif}'
 +'.tf{display:grid;grid-template-columns:repeat(5,.7in);border:2px solid #333;width:max-content;margin:.12in 0}.tf i{height:.7in;border:1px solid #333}.hg{display:grid;grid-template-columns:repeat(10,.62in);border:2px solid #333;width:max-content}.hg i{height:.62in;border:1px solid #555;font:10px system-ui,sans-serif;font-style:normal;padding:2px}'
 +'.therm{display:grid;grid-template-columns:1.2in 1fr;gap:.3in;align-items:stretch;height:8in}.therm .t{border:3px solid #333;border-radius:.6in .6in .6in .6in;position:relative}.therm ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column-reverse;justify-content:space-between;height:100%;font:700 14px system-ui,sans-serif}.therm li{border-top:1px solid #999;padding-top:2px}'
 +'.jar{border:3px solid #333;border-radius:16px;text-align:center;padding:.25in;margin:0 0 .2in;break-inside:avoid}.jar b{display:block;font:800 54px Georgia,serif;letter-spacing:.06em}.jar span{font:16px system-ui,sans-serif}'
 +'.tent{height:2.2in;display:flex;flex-direction:column}.tent>div{flex:1;display:flex;align-items:center;justify-content:center;font:700 26px Georgia,serif}.tent>div:first-child{transform:rotate(180deg);border-bottom:1px dashed #999;font-size:13px;color:#555}'
 +'.letter p{font:13px/1.6 system-ui,sans-serif;margin:0 0 10px}.letter ul{columns:2;font:13px/1.8 system-ui,sans-serif}.slip{border-top:2px dashed #555;margin-top:.3in;padding-top:.15in}';
var C={1:['#2e6b3f','#eef6ef'],5:['#2b5d8a','#eef3f9'],10:['#8a5a12','#fbf3e2'],20:['#6b2f7a','#f5eef8'],50:['#9a3b2b','#fbefec'],100:['#235a55','#eaf5f3']};
function bills(g){var dens=band(g)==='K-2'?[1,5,10]:[1,5,10,20,50,100];
  return dens.map(function(d,i){var c=C[d];var one='<div class="bill" style="--c:'+c[0]+';--bg:'+c[1]+'"><div><b>'+d+'</b><div class="mid">PLAY MONEY<i>'+money(d)+'</i><small>NOT REAL MONEY · MONEY MATTERS</small></div><b>'+d+'</b></div></div>';
    return '<section'+(i?' style="break-before:page"':'')+'><h2 class="mtl-h">'+money(d)+' '+T('play bills')+' · 10</h2><p class="mtl-note">'+T('Original classroom design, printed on one side only and well under three-quarters the size of a real bill. Cut on the dashed lines.')+'</p><div class="cut" style="grid-template-columns:1fr 1fr">'+Array.from({length:10},function(){return one;}).join('')+'</div></section>';}).join('');}
function coins(g){var set=[['1¢','PENNY',.78,'#f6e1cf'],['5¢','NICKEL',.88,'#eceff1'],['10¢','DIME',.72,'#eceff1'],['25¢','QUARTER',.98,'#eceff1']];if(band(g)!=='K-2')set.push(['$1','DOLLAR COIN',1.05,'#f5ebc8']);
  return '<h2 class="mtl-h">'+T('Play coins')+'</h2><p class="mtl-note">'+T('Cut out on the dashed circles. Glue to cardstock for sturdier coins. The U.S. stopped making new pennies in 2025, but pennies are still money.')+'</p>'
   +set.map(function(c){return '<h3 style="font:700 13px system-ui,sans-serif;margin:10px 0 6px">'+c[1]+' · '+c[0]+'</h3><div class="coins">'+Array.from({length:c[1]==='DOLLAR COIN'?10:16},function(){return '<div class="coin" style="width:'+c[2]+'in;height:'+c[2]+'in;--bg:'+c[3]+'">'+c[0]+'<small>'+c[1]+'</small></div>';}).join('')+'</div>';}).join('');}
var ITEMS={'K-2':[['🍎','Apple',.25],['✏️','Pencil',.10],['🍪','Cookie',.15],['🎈','Balloon',.50],['🧃','Juice box',.35],['📒','Notebook',1],['🧸','Teddy bear',5],['⚽','Ball',3],['🖍','Crayons',2],['🍌','Banana',.20],['🎨','Paint set',4],['📚','Book',6]],
  '3-5':[['👟','Sneakers',45],['🎧','Headphones',25],['📚','Chapter book',8],['🍕','Pizza slice',3.5],['🎮','Video game',40],['🧢','Cap',15],['🎒','Backpack',32],['🖍','Art kit',12],['🍦','Ice cream',4.25],['🚲','Bike helmet',28],['📱','Phone case',18],['🪴','Plant',9]],
  '6-8':[['📱','Smartphone',450],['🎧','Wireless earbuds',129],['👟','Running shoes',89],['🧥','Winter coat',75],['🎮','Game console',399],['🚲','Bicycle',260],['💻','Laptop',650],['🎟','Concert ticket',65],['🍔','Dinner out',18.5],['🛒','Weekly groceries',95],['⛽','Tank of gas',48],['🎁','Gift card',25]]};
function items(g){var b=band(g),L=ITEMS[b];return '<h2 class="mtl-h">'+T('Store item cards')+' · '+b+'</h2><p class="mtl-note">'+T('Pretend prices for classroom stores. The last row is blank for your own items.')+'</p><div class="cut" style="grid-template-columns:repeat(4,1fr)">'
  +L.map(function(x){return '<div class="card"><span class="ic">'+x[0]+'</span><b>'+esc(T(x[1]))+'</b><span class="pr">'+(b==='K-2'?cents(x[2]):money(x[2]))+'</span></div>';}).join('')
  +Array.from({length:4},function(){return '<div class="card"><span class="ic">☐</span><b>______________</b><span class="pr">$______</span></div>';}).join('')+'</div>'
  +'<h2 class="mtl-h" style="margin-top:.25in">'+T('Price tags')+'</h2><div class="cut" style="grid-template-columns:repeat(5,1fr)">'+Array.from({length:20},function(){return '<div class="tag">'+T('Price')+'<b>$_____</b></div>';}).join('')+'</div>';}
function paystub(g){var b=band(g),simple=b!=='6-8';function one(fill){return '<div class="doc"><h4><span>'+T('Pay stub')+'</span><span style="font:11px system-ui">'+T('Money Matters Practice Co.')+' · '+T('PRACTICE ONLY')+'</span></h4>'
    +'<div class="ln"><span>'+T('Employee')+'</span><i>'+(fill?'Jordan Rivera':'')+'</i><span>'+T('Pay period')+'</span><i>'+(fill?'Oct 1–15':'')+'</i></div>'
    +'<table class="g"><tr><th>'+T('Hours')+'</th><th>'+T('Rate')+'</th><th>'+T('Gross pay')+'</th></tr><tr><td>'+(fill?'40':'')+'</td><td>'+(fill?'$15.00':'')+'</td><td>'+(fill?'$600.00':'')+'</td></tr></table>'
    +'<table class="g" style="margin-top:6px"><tr><th>'+T('Deductions')+'</th><th>'+T('Amount')+'</th></tr>'+(simple?[[T('Taxes (simplified 10%)'),'$60.00']]:[[T('Federal income tax'),'$48.00'],[T('Social Security (6.2%)'),'$37.20'],[T('Medicare (1.45%)'),'$8.70'],[T('State income tax'),'$18.00']]).map(function(r){return '<tr><td>'+r[0]+'</td><td>'+(fill?r[1]:'')+'</td></tr>';}).join('')+'</table>'
    +'<div class="ln" style="margin-top:8px"><b>'+T('Net pay (take-home)')+'</b><i>'+(fill?(simple?'$540.00':'$488.10'):'')+'</i></div></div>';}
  return '<h2 class="mtl-h">'+T('Pay stubs')+'</h2><p class="mtl-note">'+T('One filled-in example, then blank stubs. All names and amounts are pretend.')+'</p>'+one(true)+one(false)+one(false);}
function checks(){function one(){return '<div class="doc" style="min-height:2.3in"><h4><span>Money Matters '+T('Practice Bank')+'</span><span>No. ____</span></h4><div class="ln"><span style="margin-left:auto">'+T('Date')+'</span><i style="flex:0 0 1.6in"></i></div>'
    +'<div class="ln"><span>'+T('Pay to the order of')+'</span><i></i><span>$</span><span class="box"></span></div><div class="ln"><i></i><span>'+T('dollars')+'</span></div><div class="ln"><span>'+T('Memo')+'</span><i style="flex:0 0 2.2in"></i><span style="margin-left:auto">'+T('Signature')+'</span><i style="flex:0 0 2.2in"></i></div>'
    +'<p style="margin:6px 0 0;font:700 9px system-ui;letter-spacing:.12em;color:#666;text-align:center">'+T('PRACTICE CHECK · NOT VALID · NO ACCOUNT NUMBER')+'</p></div>';}
  return '<h2 class="mtl-h">'+T('Practice checks')+'</h2>'+one()+one()+one();}
function register(){return '<h2 class="mtl-h">'+T('Check register')+'</h2><p class="mtl-note">'+T('Record every payment and deposit, then the new balance.')+'</p><table class="g"><tr><th>'+T('Date')+'</th><th>'+T('No.')+'</th><th style="width:38%">'+T('Description')+'</th><th>'+T('Payment')+' (−)</th><th>'+T('Deposit')+' (+)</th><th>'+T('Balance')+'</th></tr><tr><td></td><td></td><td><b>'+T('Starting balance')+'</b></td><td></td><td></td><td></td></tr>'+Array.from({length:22},function(){return '<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>';}).join('')+'</table>';}
function deposit(){function one(){return '<div class="doc"><h4><span>'+T('Deposit slip')+'</span><span style="font:11px system-ui">Money Matters '+T('Practice Bank')+'</span></h4><div class="ln"><span>'+T('Name')+'</span><i></i><span>'+T('Date')+'</span><i style="flex:0 0 1.4in"></i></div><table class="g"><tr><th>'+T('Cash')+'</th><td></td></tr><tr><th>'+T('Checks')+'</th><td></td></tr><tr><th>'+T('Total deposit')+'</th><td></td></tr></table></div>';}return '<h2 class="mtl-h">'+T('Deposit slips')+'</h2>'+one()+one()+one();}
function receipt(g){function one(){return '<div class="doc"><h4><span>'+T('Receipt')+'</span><span>________________ '+T('Store')+'</span></h4><table class="g"><tr><th style="width:60%">'+T('Item')+'</th><th>'+T('Price')+'</th></tr>'+Array.from({length:5},function(){return '<tr><td></td><td></td></tr>';}).join('')+'<tr><td>'+T('Subtotal')+'</td><td></td></tr>'+(band(g)==='K-2'?'':'<tr><td>'+T('Sales tax')+'</td><td></td></tr>')+'<tr><td><b>'+T('Total')+'</b></td><td></td></tr><tr><td>'+T('Paid')+'</td><td></td></tr><tr><td>'+T('Change')+'</td><td></td></tr></table></div>';}return '<h2 class="mtl-h">'+T('Receipts')+'</h2><div style="display:grid;grid-template-columns:1fr 1fr;gap:.15in">'+one()+one()+one()+one()+'</div>';}
function budget(g){var b=band(g);
  if(b==='K-2')return '<h2 class="mtl-h">'+T('My money plan')+'</h2><p class="mtl-note">'+T('Draw or write how you will use your money.')+'</p><div class="ln" style="font-size:16px"><span>'+T('I have')+'</span><i></i></div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.15in;margin-top:.2in">'+['🐷 SAVE','🛍 SPEND','💝 SHARE'].map(function(x){return '<div class="jar" style="min-height:4.5in"><b style="font-size:30px">'+x+'</b><span>$______</span></div>';}).join('')+'</div>';
  var rows=b==='3-5'?[[T('Needs'),T('Food, home, clothes')],[T('Wants'),T('Fun, treats, games')],[T('Savings'),T('Goals and emergencies')],[T('Giving'),T('Helping others')]]:[[T('Housing'),T('Need')],[T('Food and groceries'),T('Need')],[T('Transportation'),T('Need')],[T('Phone and internet'),T('Need')],[T('Insurance'),T('Need')],[T('Entertainment'),T('Want')],[T('Eating out'),T('Want')],[T('Clothes and shopping'),T('Want')],[T('Emergency fund'),T('Savings')],[T('Long-term savings or investing'),T('Savings')],[T('Giving'),T('Want')]];
  return '<h2 class="mtl-h">'+T(b==='3-5'?'Budget sheet':'Monthly budget')+'</h2><div class="ln"><span>'+T('Name')+'</span><i></i><span>'+T('Month')+'</span><i style="flex:0 0 1.5in"></i></div><div class="ln" style="font-size:15px"><b>'+T('Income this month')+'</b><i></i></div>'
   +'<table class="g" style="margin-top:8px"><tr><th style="width:36%">'+T('Category')+'</th><th>'+T(b==='3-5'?'For':'Type')+'</th><th>'+T('Planned')+'</th><th>'+T('Actual')+'</th><th>'+T('Difference')+'</th></tr>'+rows.map(function(r){return '<tr><td>'+r[0]+'</td><td>'+r[1]+'</td><td></td><td></td><td></td></tr>';}).join('')+'<tr><td><b>'+T('Total')+'</b></td><td></td><td></td><td></td><td></td></tr></table>'
   +(b==='6-8'?'<p class="mtl-note" style="margin-top:10px">'+T('Check: a common guideline is about 50% needs, 30% wants and 20% savings. Needs ____% · Wants ____% · Savings ____%')+'</p>':'');}
function shopping(g){function one(){return '<div class="doc"><h4><span>'+T('Shopping list')+'</span><span>'+T('Budget')+': $______</span></h4><table class="g"><tr><th style="width:55%">'+T('Item')+'</th><th>'+T('Price')+'</th><th>'+T('Running total')+'</th></tr>'+Array.from({length:7},function(){return '<tr><td></td><td></td><td></td></tr>';}).join('')+'</table><div class="ln"><span>'+T('Money left')+'</span><i></i></div></div>';}return '<h2 class="mtl-h">'+T('Shopping lists')+'</h2><div style="display:grid;grid-template-columns:1fr 1fr;gap:.15in">'+one()+one()+one()+one()+'</div>';}
var JOBS={'K-2':[['🧹','Classroom helper','3 play dollars a week'],['🌱','Plant waterer','2 play dollars a week'],['📚','Librarian','3 play dollars a week'],['🍎','Snack helper','2 play dollars a week'],['🐟','Pet feeder','2 play dollars a week'],['🚪','Line leader','2 play dollars a week'],['📬','Mail carrier','3 play dollars a week'],['🧽','Board cleaner','2 play dollars a week']],
  '3-5':[['👩‍🏫','Teacher','$30 an hour'],['🧑‍🍳','Cook','$17 an hour'],['🚒','Firefighter','$28 an hour'],['👩‍⚕️','Nurse','$40 an hour'],['🧑‍🔧','Mechanic','$24 an hour'],['🧑‍🌾','Farmer','$20 an hour'],['📦','Delivery driver','$21 an hour'],['🎨','Artist','$22 an hour']],
  '6-8':[['💻','Software developer','$110,000 a year'],['🩺','Registered nurse','$85,000 a year'],['⚡','Electrician','$60,000 a year'],['🧑‍🏫','Teacher','$62,000 a year'],['🛒','Retail manager','$48,000 a year'],['🚛','Truck driver','$55,000 a year'],['🧾','Accountant','$78,000 a year'],['💇','Hair stylist','$36,000 a year']]};
function jobs(g){var b=band(g);return '<h2 class="mtl-h">'+T('Job cards')+' · '+b+'</h2><p class="mtl-note">'+T('Pretend pay, rounded for classroom math. Real pay depends on the place and experience. The last row is blank for your own jobs.')+'</p><div class="cut" style="grid-template-columns:repeat(4,1fr)">'
  +JOBS[b].map(function(j){return '<div class="card"><span class="ic">'+j[0]+'</span><b>'+esc(T(j[1]))+'</b><span class="pr" style="font-size:14px">'+esc(T(j[2]))+'</span></div>';}).join('')+Array.from({length:4},function(){return '<div class="card"><span class="ic">☐</span><b>______________</b><span class="pr" style="font-size:14px">______</span></div>';}).join('')+'</div>';}
var NW=[['🍞','Food','need'],['🏠','Home','need'],['🧥','Warm coat','need'],['💧','Water','need'],['💊','Medicine','need'],['👟','Shoes','need'],['🎮','Video game','want'],['🍭','Candy','want'],['🧸','New toy','want'],['🎢','Theme park','want'],['📱','Newest phone','want'],['🍦','Ice cream','want']];
function needwant(){return '<h2 class="mtl-h">'+T('Need and want cards')+'</h2><p class="mtl-note">'+T('Cut out and sort on the mat. Some cards can start a good debate, and that is part of the lesson.')+'</p><div class="cut" style="grid-template-columns:repeat(4,1fr)">'+NW.map(function(x){return '<div class="card" style="align-items:center;text-align:center"><span class="ic" style="font-size:34px">'+x[0]+'</span><b>'+esc(T(x[1]))+'</b></div>';}).join('')+'</div>'+sortmat(T('NEEDS'),T('WANTS'));}
function sortmat(a,b){return '<section style="break-before:page"><div class="mat2"><div>'+(a||T('NEEDS'))+'</div><div>'+(b||T('WANTS'))+'</div></div></section>';}
function goal(){return '<h2 class="mtl-h">'+T('Savings goal tracker')+'</h2><div class="ln" style="font-size:15px"><span>'+T('My goal')+'</span><i></i><span>'+T('Cost')+'</span><i style="flex:0 0 1.3in"></i></div><div class="therm" style="margin-top:.2in"><div class="t"></div><ol>'+Array.from({length:11},function(_,i){return '<li>'+(i===10?T('GOAL'):i*10+'%')+' $______</li>';}).join('')+'</ol></div>';}
function jars(g){var L=[['SAVE','🐷',T('Money for later and goals')],['SPEND','🛍',T('Money for things I need and want now')],['SHARE','💝',T('Money to help others')]];if(band(g)==='6-8')L.push(['INVEST','📈',T('Money set aside to grow over time')]);return L.map(function(x,i){return '<div class="jar"'+(i&&i%2===0?' style="break-before:page"':'')+'><div style="font-size:60px">'+x[1]+'</div><b>'+T(x[0])+'</b><span>'+x[2]+'</span></div>';}).join('');}
function grid(){return '<h2 class="mtl-h">'+T('Ten frames')+'</h2>'+Array.from({length:4},function(){return '<div class="tf">'+Array(10).join('<i></i>')+'<i></i></div>';}).join('')+'<h2 class="mtl-h" style="break-before:page">'+T('Hundred grid')+'</h2><div class="hg">'+Array.from({length:100},function(_,i){return '<i>'+(i+1)+'</i>';}).join('')+'</div>';}
function cards(){return '<h2 class="mtl-h">'+T('Blank scenario and choice cards')+'</h2><p class="mtl-note">'+T('Write a money situation on the front and the choices underneath. Use them for stations, debates or review games.')+'</p><div class="cut" style="grid-template-columns:1fr 1fr">'+Array.from({length:8},function(_,i){return '<div class="card" style="min-height:2in"><b>'+T('Card')+' '+(i+1)+'</b><div class="ln"><i></i></div><div class="ln"><i></i></div><div class="ln"><span>A</span><i></i></div><div class="ln"><span>B</span><i></i></div></div>';}).join('')+'</div>';}
function points(){return '<h2 class="mtl-h">'+T('Team points board')+'</h2><table class="g" style="font-size:14px"><tr><th style="width:24%">'+T('Team')+'</th>'+Array.from({length:8},function(_,i){return '<th>'+T('Round')+' '+(i+1)+'</th>';}).join('')+'<th>'+T('Total')+'</th></tr>'+Array.from({length:8},function(){return '<tr style="height:.6in">'+Array(11).join('<td></td>')+'</tr>';}).join('')+'</table>';}
function tally(){return '<h2 class="mtl-h">'+T('Recording sheet')+'</h2><div class="ln"><span>'+T('Name')+'</span><i></i><span>'+T('Date')+'</span><i style="flex:0 0 1.5in"></i></div><table class="g" style="margin-top:8px"><tr><th style="width:8%">#</th><th style="width:42%">'+T('What I counted or decided')+'</th><th>'+T('Tally')+'</th><th>'+T('Total')+'</th></tr>'+Array.from({length:18},function(_,i){return '<tr><td>'+(i+1)+'</td><td></td><td></td><td></td></tr>';}).join('')+'</table>';}
function chart(){return '<h2 class="mtl-h">'+T('Blank class chart')+'</h2><div class="ln" style="font-size:16px"><span>'+T('Title')+'</span><i></i></div><table class="g" style="margin-top:10px;font-size:14px"><tr>'+Array.from({length:4},function(){return '<th style="height:.45in"></th>';}).join('')+'</tr>'+Array.from({length:12},function(){return '<tr style="height:.55in">'+Array(5).join('<td></td>')+'</tr>';}).join('')+'</table>';}
function checklist(){return '<h2 class="mtl-h">'+T('Checklist and scoring rubric')+'</h2><div class="ln"><span>'+T('Name or team')+'</span><i></i><span>'+T('Project')+'</span><i></i></div><table class="g" style="margin-top:10px"><tr><th style="width:5%">✓</th><th style="width:43%">'+T('What to include')+'</th><th>1 · '+T('Beginning')+'</th><th>2 · '+T('Getting there')+'</th><th>3 · '+T('Got it')+'</th><th>4 · '+T('Wow')+'</th></tr>'+Array.from({length:8},function(){return '<tr style="height:.5in"><td>☐</td><td></td><td></td><td></td><td></td><td></td></tr>';}).join('')+'<tr><td></td><td><b>'+T('Total')+'</b></td><td colspan="4"></td></tr></table>';}
function names(){return '<h2 class="mtl-h">'+T('Name tents')+'</h2><p class="mtl-note">'+T('Fold on the dashed line so the name faces out.')+'</p><div class="cut" style="grid-template-columns:1fr 1fr">'+Array.from({length:6},function(){return '<div class="tent"><div>Money Matters</div><div>__________________</div></div>';}).join('')+'</div>';}
function creditreport(){return '<h2 class="mtl-h">'+T('Sample credit report')+' <span style="font:700 11px system-ui;color:#a33;letter-spacing:.1em">'+T('FICTIONAL · FOR CLASSROOM USE')+'</span></h2><p class="mtl-note">'+T('Every name, number and account here is made up. Real reports are free at AnnualCreditReport.com.')+'</p>'
  +'<div class="doc"><h4><span>'+T('Personal information')+'</span></h4>'+T('Name')+': Alex Sample · '+T('Address')+': 123 Practice Lane, Anytown · '+T('Employer')+': Anytown Library</div>'
  +'<div class="doc"><h4><span>'+T('Accounts')+'</span></h4><table class="g"><tr><th>'+T('Account')+'</th><th>'+T('Type')+'</th><th>'+T('Opened')+'</th><th>'+T('Limit / loan')+'</th><th>'+T('Balance')+'</th><th>'+T('Status')+'</th></tr>'
  +[['Practice Card A','Credit card','2021','$2,000','$450','Current'],['Practice Card B','Credit card','2023','$1,000','$980','30 days late (Mar)'],['Practice Auto Loan','Installment','2022','$12,000','$7,300','Current'],['Practice Student Loan','Installment','2019','$18,000','$14,200','Current']].map(function(r){return '<tr>'+r.map(function(c){return '<td>'+esc(c)+'</td>';}).join('')+'</tr>';}).join('')+'</table></div>'
  +'<div class="doc"><h4><span>'+T('Recent inquiries')+'</span></h4>Practice Bank (Jan) · Practice Phone Co. (Jun)</div>'
  +'<div class="doc"><h4><span>'+T('Questions')+'</span></h4><ol style="margin:0;padding-left:18px"><li>'+T('What is the credit utilization on Card B, and why could it hurt the score?')+'</li><li>'+T('Which account shows a late payment? What should Alex do next?')+'</li><li>'+T('Find one thing that helps this report and one thing that hurts it.')+'</li></ol></div>';}
var GEN={money:[T('Play money'),'💵',bills,'Bills for every grade band'],coins:[T('Play coins'),'🪙',coins,'Penny, nickel, dime, quarter, dollar coin'],items:[T('Store items and price tags'),'🏷',items,'Item cards with pretend prices and blank tags'],shopping:[T('Shopping lists'),'📝',shopping,'With a budget line and running total'],
  receipt:[T('Receipts'),'🧾',receipt,'Subtotal, tax, total, change'],paystub:[T('Pay stubs'),'💼',paystub,'A worked example plus blanks'],checks:[T('Practice checks'),'✍️',checks,'Clearly marked practice only'],register:[T('Check register'),'📒',register,'Payments, deposits, balance'],deposit:[T('Deposit slips'),'🏦',deposit,'Cash and checks'],
  budget:[T('Budget sheets'),'📊',budget,'Save/spend/share for K–2, budgets for 3–8'],jobs:[T('Job cards'),'👷',jobs,'Jobs with pretend pay by grade band'],needwant:[T('Need and want cards'),'⚖️',needwant,'Cards and a sorting mat'],goal:[T('Savings goal tracker'),'🎯',goal,'Thermometer chart'],jars:[T('Save, spend, share labels'),'🫙',jars,'Jar labels (plus invest for 6–8)'],
  grid:[T('Ten frames and hundred grid'),'🔟',grid,'Counting and percent practice'],sortmat:[T('Sorting mat'),'🗂',function(){return sortmat('','');},'Two-column mat'],cards:[T('Blank scenario cards'),'🃏',cards,'Write-your-own situations and choices'],points:[T('Team points board'),'🏆',points,'Up to 8 teams, 8 rounds'],
  tally:[T('Recording sheet'),'📋',tally,'Tally and totals'],chart:[T('Blank class chart'),'📈',chart,'Charts, tables, boards and plans'],checklist:[T('Checklist and rubric'),'✅',checklist,'Projects and presentations'],names:[T('Name tents'),'🪧',names,'Fold-and-stand names'],creditreport:[T('Sample credit report'),'📈',creditreport,'Fictional report with questions (6–8)']};
function printOne(key,g){var G=GEN[key];if(!G||!window.MMPrint)return;g=g||grade();MMPrint.open(G[0]+' · '+gname(g),G[2](g),{headerLeft:'Money Matters · '+G[0],css:CSS});}
function printMany(keys,g,title){if(!window.MMPrint)return;g=g||grade();var body=keys.filter(function(k){return GEN[k];}).map(function(k,i){return '<section'+(i?' style="break-before:page"':'')+'>'+GEN[k][2](g)+'</section>';}).join('');if(!body)return;MMPrint.open(title||T('Printable materials'),body,{headerLeft:'Money Matters · '+(title||T('Materials')),css:CSS});}
function supplyLetter(list,what){var sch=school();var body='<div class="letter"><h2 class="mtl-h">'+T('Classroom supply request')+'</h2><p>'+T('Dear families,')+'</p><p>'+esc(what?T('Our class is getting ready for')+' '+what+'. ':'')+T('We are learning about money with hands-on activities. If you are able to, please send any of the items below. Every donation is optional and helps the whole class.')+'</p><ul>'+list.map(function(x){return '<li>☐ '+esc(x)+'</li>';}).join('')+'</ul><p>'+T('Thank you for supporting our young money learners!')+'</p><p>'+esc(sch||'')+'</p>'
  +'<div class="slip"><b>'+T('Return slip')+'</b><div class="ln"><span>'+T('Student name')+'</span><i></i></div><div class="ln"><span>'+T('I am sending')+'</span><i></i></div><div class="ln"><span>'+T('Family signature (optional)')+'</span><i></i></div></div></div>';
  if(window.MMPrint)MMPrint.open(T('Supply request letter'),body,{headerLeft:'Money Matters · '+T('Family letter'),css:CSS});}

/* ---------- 4. materials for a lesson or a workshop day ---------- */
function lessonMats(g,i){try{var L=(typeof LESSONS!=='undefined'&&LESSONS[g])||[];var l=L[i];return l&&!l.locked?{title:gname(g)+' · '+T('Week')+' '+l.week+': '+l.title,list:(l.materials||[]).slice()}:null;}catch(e){return null;}}
function workshopMats(g,f,d){try{var X=window.MMWorkshops&&MMWorkshops._;if(!X)return null;var w=X.W(g);if(!w||w.locked)return null;var D=X.day(g,f,d),m={};D.blocks.forEach(function(b){(b.materials||[]).forEach(function(x){m[x]=1;});});return {title:w.title+' · '+T('Day')+' '+(d+1)+' '+T('of')+' '+f,list:Object.keys(m)};}catch(e){return null;}}
function plan(list){var out={print:{},app:[],source:{},supply:{}};list.forEach(function(m){var c=classify(m);if(c.type==='print'){(out.print[c.key]=out.print[c.key]||[]).push(m);}else if(c.type==='app')out.app.push(m);else if(c.type==='source'){(out.source[c.key]=out.source[c.key]||[]).push(m);}else{(out.supply[c.key]=out.supply[c.key]||[]).push(m);}});return out;}
function planHTML(set,ctxKind){if(!set)return '<p class="mtc-empty">'+esc(T('Nothing to show here yet.'))+'</p>';var p=plan(set.list),pk=Object.keys(p.print),h='<div class="mtc-plan">';
  h+='<div class="mtc-planhead"><div><div class="mtc-k">'+esc(T(ctxKind==='ws'?'Workshop day':'Lesson'))+'</div><h3>'+esc(set.title)+'</h3><p>'+set.list.length+' '+esc(T('materials'))+' · '+pk.length+' '+esc(T('printable'))+' · '+Object.keys(p.supply).length+' '+esc(T('supply groups'))+'</p></div>'
    +'<div class="mtc-acts">'+(pk.length?'<button type="button" class="mtc-btn" data-mt="printall" data-keys="'+esc(pk.join(','))+'" data-title="'+esc(set.title)+'">🖨 '+esc(T('Print all printables'))+'</button>':'')+(Object.keys(p.supply).length?'<button type="button" class="mtc-btn ghost" data-mt="letter" data-list="'+esc(JSON.stringify([].concat.apply([],Object.keys(p.supply).map(function(k){return p.supply[k];}))))+'" data-title="'+esc(set.title)+'">✉️ '+esc(T('Family supply letter'))+'</button>':'')+'</div></div>';
  if(pk.length)h+='<div class="mtc-sec"><h4>🖨 '+esc(T('Print it here'))+'</h4><ul class="mtc-list">'+pk.map(function(k){return '<li><span class="mtc-ic" aria-hidden="true">'+GEN[k][1]+'</span><div><b>'+esc(GEN[k][0])+'</b><small>'+esc(T('For'))+': '+esc(p.print[k].join('; '))+'</small></div><button type="button" class="mtc-btn sm" data-mt="print" data-k="'+k+'">'+esc(T('Print'))+'</button></li>';}).join('')+'</ul></div>';
  if(p.app.length)h+='<div class="mtc-sec"><h4>📄 '+esc(T('Already in the app'))+'</h4><ul class="mtc-list">'+p.app.map(function(m){return '<li><span class="mtc-ic" aria-hidden="true">📄</span><div><b>'+esc(m)+'</b><small>'+esc(ctxKind==='ws'?T('Print it from the workshop: facilitator guide, student passport, or check-in sheets.'):T('Open the lesson’s Documents: worksheet, quiz, weekly packet or lesson plan.'))+'</small></div>'+(ctxKind==='ws'||/certificate/i.test(m)?'':'<button type="button" class="mtc-btn sm ghost" data-mt="docs">'+esc(T('Open'))+'</button>')+'</li>';}).join('')+'</ul></div>';
  if(Object.keys(p.source).length)h+='<div class="mtc-sec"><h4>🔗 '+esc(T('Free official source'))+'</h4><ul class="mtc-list">'+Object.keys(p.source).map(function(k){var s=SOURCES[k];return '<li><span class="mtc-ic" aria-hidden="true">🔗</span><div><b>'+esc(T(s.t))+'</b><small>'+esc(T(s.d))+'</small></div><a class="mtc-btn sm ghost" href="'+esc(s.u)+'" target="_blank" rel="noopener noreferrer">'+esc(T('Open'))+' ↗</a></li>';}).join('')+'</ul></div>';
  if(Object.keys(p.supply).length)h+='<div class="mtc-sec"><h4>🏫 '+esc(T('Classroom supplies'))+'</h4><ul class="mtc-list">'+Object.keys(p.supply).map(function(k){var s=SUPPLY[k];return '<li><span class="mtc-ic" aria-hidden="true">'+s.i+'</span><div><b>'+esc(T(s.t))+'</b><small>'+esc(p.supply[k].join('; '))+' — '+esc(T(s.d))+'</small></div></li>';}).join('')+'</ul></div>';
  return h+'</div>';}

/* ---------- 5. panel ---------- */
var view={tab:'lesson',ctx:null};
function ensurePanel(){if(document.getElementById('panel-materials'))return;var p=document.createElement('div');p.className='panel';p.id='panel-materials';p.setAttribute('role','dialog');p.setAttribute('aria-modal','true');p.setAttribute('aria-label',T('Materials Center'));
  p.innerHTML='<div class="panel-header"><div class="panel-icon" style="background:linear-gradient(135deg,#8a5e10,#c4912e)">🧰</div><div class="panel-meta"><div class="panel-kicker">Money Matters · '+esc(T('Materials'))+'</div><div class="panel-title">'+esc(T('Materials Center'))+'</div><div class="panel-sub">'+esc(T('Everything a lesson or workshop needs: print it here, find a free official source, or see what to gather.'))+'</div></div><button class="close-btn" onclick="closePanel()" aria-label="'+esc(T('Close'))+'">✕</button></div><div class="panel-body" id="materialsBody"></div>';
  var ref=document.getElementById('panel-resources');(ref&&ref.parentNode?ref.parentNode:document.body).insertBefore(p,ref?ref.nextSibling:null);}
function render(){var el=document.getElementById('materialsBody');if(!el)return;var g=grade();
  if(!isStaff()){el.innerHTML='<p class="mtc-empty">'+esc(T('The Materials Center is for teachers, parents and administrators.'))+'</p>';return;}
  var tabs=[['lesson',T('This lesson')],['ws',T('Workshop day')],['library',T('Printables library')],['sources',T('Supplies and free sources')]];
  var h='<div class="mtc"><div class="mtc-tabs" role="tablist">'+tabs.map(function(t){return '<button type="button" role="tab" data-mt="tab" data-t="'+t[0]+'" aria-selected="'+(view.tab===t[0])+'">'+esc(t[1])+'</button>';}).join('')+'</div>';
  if(view.tab==='lesson'){var L=(typeof LESSONS!=='undefined'&&LESSONS[g])||[],ci=(typeof currentIndex!=='undefined'?currentIndex:0)||0;if(view.ctx&&view.ctx.kind==='lesson')ci=view.ctx.i;
    h+='<label class="mtc-pick">'+esc(T('Week'))+' <select data-mt-ch="week">'+L.map(function(l,i){return '<option value="'+i+'"'+(i===ci?' selected':'')+(l.locked?' disabled':'')+'>'+esc(T('Week')+' '+l.week+': '+l.title)+(l.locked?' 🔒':'')+'</option>';}).join('')+'</select></label>'+planHTML(lessonMats(g,ci),'lesson');}
  else if(view.tab==='ws'){var X=window.MMWorkshops&&MMWorkshops._,f=X?X.fmtOf(g):3,d=view.ctx&&view.ctx.kind==='ws'?view.ctx.d:(X?X.view.day:0);if(view.ctx&&view.ctx.kind==='ws')f=view.ctx.f;
    var wm=workshopMats(g,f,d);h+='<label class="mtc-pick">'+esc(T('Day'))+' <select data-mt-ch="wsday">'+Array.from({length:f},function(_,i){return '<option value="'+i+'"'+(i===d?' selected':'')+'>'+esc(T('Day')+' '+(i+1)+' '+T('of')+' '+f)+'</option>';}).join('')+'</select> <span class="mtc-note">'+esc(gname(g))+' · '+esc(T('format set in Workshops'))+'</span></label>'+(wm?planHTML(wm,'ws'):'<p class="mtc-empty">'+esc(T('Workshops are included with a subscription.'))+'</p>');}
  else if(view.tab==='library'){h+='<p class="mtc-note">'+esc(T('Sized for'))+' <b>'+esc(gname(g))+'</b> ('+band(g)+'). '+esc(T('Change the grade from the top bar to get another grade band.'))+'</p><div class="mtc-lib">'+Object.keys(GEN).map(function(k){var G=GEN[k];return '<button type="button" class="mtc-item" data-mt="print" data-k="'+k+'"><span class="mtc-ic" aria-hidden="true">'+G[1]+'</span><b>'+esc(G[0])+'</b><small>'+esc(T(G[3]))+'</small><em>🖨 '+esc(T('Print'))+'</em></button>';}).join('')+'</div>';}
  else{h+='<div class="mtc-sec"><h4>🔗 '+esc(T('Free official materials'))+'</h4><ul class="mtc-list">'+Object.keys(SOURCES).map(function(k){var s=SOURCES[k];return '<li><span class="mtc-ic" aria-hidden="true">🔗</span><div><b>'+esc(T(s.t))+'</b><small>'+esc(T(s.d))+'</small></div><a class="mtc-btn sm ghost" href="'+esc(s.u)+'" target="_blank" rel="noopener noreferrer">'+esc(T('Open'))+' ↗</a></li>';}).join('')+'</ul></div>'
    +'<div class="mtc-sec"><h4>🏫 '+esc(T('Where to get classroom supplies'))+'</h4><ul class="mtc-list">'+Object.keys(SUPPLY).map(function(k){var s=SUPPLY[k];return '<li><span class="mtc-ic" aria-hidden="true">'+s.i+'</span><div><b>'+esc(T(s.t))+'</b><small>'+esc(T(s.d))+'</small></div></li>';}).join('')+'</ul>'
    +'<p class="mtc-note">'+esc(T('Other free ways to get supplies: your school or district supply room, your PTA or parent group, community donations, and teacher crowdfunding through nonprofits such as DonorsChoose.'))+'</p><div class="mtc-acts"><button type="button" class="mtc-btn ghost" data-mt="letter" data-list="'+esc(JSON.stringify([T('Pencils'),T('Glue sticks'),T('Crayons or markers'),T('Index cards'),T('Calculators'),T('Plastic sandwich bags (for play money)'),T('Small jars or cups (for save, spend, share)')]))+'" data-title="">✉️ '+esc(T('Family supply letter'))+'</button></div></div>';}
  el.innerHTML=h+'</div>';}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-mt]');if(!b)return;var a=b.getAttribute('data-mt');
  if(a==='tab'){view.tab=b.getAttribute('data-t');render();var t=document.querySelector('#materialsBody [data-mt=tab][aria-selected=true]');if(t)t.focus();return;}
  if(a==='print')return printOne(b.getAttribute('data-k'));
  if(a==='printall')return printMany(b.getAttribute('data-keys').split(','),grade(),b.getAttribute('data-title'));
  if(a==='letter'){var l=[];try{l=JSON.parse(b.getAttribute('data-list')||'[]');}catch(x){}return supplyLetter(l,b.getAttribute('data-title'));}
  if(a==='docs'){try{closePanel(true);openDoc('worksheet');}catch(x){}return;}
  if(a==='open'){e.preventDefault();open(JSON.parse(b.getAttribute('data-ctx')||'null'));}});
document.addEventListener('change',function(e){var el=e.target;if(!el.closest||!el.closest('#materialsBody'))return;var k=el.getAttribute('data-mt-ch');
  if(k==='week'){view.ctx={kind:'lesson',i:+el.value};render();}if(k==='wsday'){var X=window.MMWorkshops&&MMWorkshops._;view.ctx={kind:'ws',f:X?X.fmtOf(grade()):3,d:+el.value};render();}});
function open(ctx){ensurePanel();view.ctx=ctx||null;view.tab=ctx&&ctx.kind==='ws'?'ws':ctx&&ctx.tab?ctx.tab:'lesson';try{openPanel('materials');}catch(e){}render();}
try{if(typeof _panelRenderers!=='undefined')_panelRenderers.materials=render;}catch(e){}

/* ---------- 6. links from lessons, workshops, the dock and the Resource Guide ---------- */
function lessonHook(){var tv=document.getElementById('mm-teach-view');if(!tv||!isStaff())return;tv.querySelectorAll('.mmtv-check').forEach(function(ul){if(ul.nextSibling&&ul.nextSibling.classList&&ul.nextSibling.classList.contains('mtc-hook'))return;
  var lbl=ul.previousElementSibling;if(!lbl||!/material/i.test(lbl.textContent))return;var ci=(typeof currentIndex!=='undefined'?currentIndex:0)||0;
  var d=document.createElement('div');d.className='mtc-hook';d.innerHTML='<button type="button" class="mtc-btn sm" data-mt="open" data-ctx="'+esc(JSON.stringify({kind:'lesson',i:ci}))+'">🧰 '+esc(T('Get these materials'))+'</button><span>'+esc(T('Printables, free sources and a supply list'))+'</span>';ul.parentNode.insertBefore(d,ul.nextSibling);});}
function wsHook(){var body=document.getElementById('workshopsBody');if(!body||!isStaff())return;body.querySelectorAll('.ws-check').forEach(function(ul){var card=ul.closest('.ws-card');if(!card||card.querySelector('.mtc-hook'))return;var X=window.MMWorkshops&&MMWorkshops._;if(!X)return;var g=grade();
  var d=document.createElement('div');d.className='mtc-hook';d.innerHTML='<button type="button" class="mtc-btn sm" data-mt="open" data-ctx="'+esc(JSON.stringify({kind:'ws',f:X.fmtOf(g),d:X.view.day}))+'">🧰 '+esc(T('Get these materials'))+'</button>';card.appendChild(d);});}
function resHook(){var body=document.getElementById('resourcesBody');if(!body||!isStaff()||body.querySelector('.mtc-reslink'))return;var hero=body.querySelector('.rg-hero');if(!hero)return;
  var d=document.createElement('div');d.className='mtc-reslink';d.innerHTML='<span aria-hidden="true">🧰</span><div><b>'+esc(T('Need materials for a lesson or workshop?'))+'</b><small>'+esc(T('Printable play money, coins, price tags, pay stubs, checks and more, plus free official sources.'))+'</small></div><button type="button" class="mtc-btn sm" data-mt="open" data-ctx="'+esc(JSON.stringify({tab:'library'}))+'">'+esc(T('Materials Center'))+'</button>';hero.parentNode.insertBefore(d,hero.nextSibling);}
function watch(id,fn){var el=document.getElementById(id);if(!el||el.__mtc)return;el.__mtc=1;var t=0;new MutationObserver(function(){clearTimeout(t);t=setTimeout(fn,60);}).observe(el,{childList:true,subtree:true});fn();}
function boot(){ensurePanel();watch('panel-lessons',lessonHook);watch('workshopsBody',wsHook);watch('resourcesBody',resHook);}
setInterval(boot,1500);if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
try{var S=MM.shell;if(S&&S.navGroups&&!S.navGroups.__mtc){var on=S.navGroups;S.navGroups=function(){var gs=on.apply(this,arguments);try{if(isStaff()){var docs=gs.filter(function(x){return /doc/i.test(x.label||x.l||x.name||'');})[0]||gs[gs.length-1];if(docs&&docs.items&&!docs.items.some(function(x){return /materials/.test(x[2]);}))docs.items.push(['🧰',T('Materials'),"MMMaterials.open()",1]);}}catch(e){}return gs;};S.navGroups.__mtc=1;}
  if(S&&S.moreItems&&!S.moreItems.__mtc){var om=S.moreItems;S.moreItems=function(){var it=om.apply(this,arguments);try{if(isStaff()&&!it.some(function(x){return Array.isArray(x)&&/MMMaterials/.test(x[2]);}))it.push(['🧰',T('Materials Center'),"MMMaterials.open()"]);}catch(e){}return it;};S.moreItems.__mtc=1;}}catch(e){}

window.MMMaterials={open:open,render:render,classify:classify,plan:plan,printOne:printOne,printMany:printMany,GEN:GEN,SOURCES:SOURCES,_lessonMats:lessonMats,_workshopMats:workshopMats};
})();
