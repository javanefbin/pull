(function(){
  'use strict';
  var OWNER_KEY='mmOwnerMode_v1';
  function esc(s){try{return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]});}catch(e){return ''}}
  function ownerEnabled(){try{var a=JSON.parse(sessionStorage.getItem('mmAuth_v1')||'null');return !!(a&&a.role==='teacher'&&a.id==='admin');}catch(e){return false;}}
  function setOwner(v){try{if(v)localStorage.setItem(OWNER_KEY,'1');else localStorage.removeItem(OWNER_KEY);}catch(e){}}
  function makeCode(){
    var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789', used={};
    try{var s=loadStore();Object.keys(s.list||{}).forEach(function(k){var c=s.list[k]&&s.list[k].verifyCode;if(c)used[String(c).toUpperCase()]=1;});}catch(e){}
    var c=''; do{c='';for(var i=0;i<6;i++)c+=chars[Math.floor(Math.random()*chars.length)];}while(used[c]); return c;
  }
  function createStudentFixed(){
    var n=document.getElementById('mm56-new-name'), g=document.getElementById('mm56-new-grade'), t=document.getElementById('mm56-new-teacher');
    var name=((n&&n.value)||'').trim().slice(0,40), grade=((g&&g.value)||'K'), teacher=((t&&t.value)||'').trim().slice(0,60);
    var err=document.getElementById('mm56-new-error'); if(err)err.textContent='';
    if(!name){if(err)err.textContent='Enter the student name.';return;}
    try{
      var s=loadStore(); if(!s.list)s.list={};
      var id=(typeof newId==='function')?newId():'s_'+Date.now().toString(36)+Math.random().toString(36).slice(2,9);
      var rec={id:id,name:name,grade:grade,prog:{},verifyCode:makeCode()};
      if(teacher){rec.teacher=teacher;if(!s.teachers)s.teachers=[];if(s.teachers.indexOf(teacher)<0)s.teachers.push(teacher);}
      s.list[id]=rec;s.active=id;saveStore(s);setTabActive(id);
      try{sessionStorage.setItem('mmRole','student');sessionStorage.setItem('mmLoginRole','student');}catch(e){}
      if(typeof setAuth==='function')setAuth('student',name,id);
      if(typeof refreshStudentUI==='function')refreshStudentUI();
      if(typeof setGrade==='function')setGrade(grade);
      if(typeof applyRole==='function')applyRole();
      if(typeof buildGradeNav==='function')buildGradeNav();
      if(typeof updateIndicator==='function')updateIndicator();
      if(typeof mmV56HideGate==='function')mmV56HideGate();
      if(typeof openPanel==='function')openPanel('dashboard');
      if(typeof infoToast==='function')infoToast('✓ Student profile created. Verification code: '+rec.verifyCode,4500); else alert('Student created. Verification code: '+rec.verifyCode);
    }catch(e){if(err)err.textContent='Could not create the profile. Please try again.';console.error(e);}
  }
  function showCreate(){
    var gate=document.getElementById('mm-login-gate'); if(!gate)return;
    gate.classList.remove('mm-hidden');
    var grades=(typeof GRADE_LABEL!=='undefined'?Object.keys(GRADE_LABEL):['K','1','2','3','4','5','6','7','8']);
    var opts=grades.map(function(g){var lab=(typeof GRADE_LABEL!=='undefined'&&GRADE_LABEL[g])?GRADE_LABEL[g]:(g==='K'?'Kindergarten':'Grade '+g);return '<option value="'+esc(g)+'">'+esc(lab)+'</option>';}).join('');
    var teachers=[];try{teachers=teacherList()||[]}catch(e){}
    gate.innerHTML='<div class="mm-login-shell"><div class="mm-login-brand"><div class="logo">🎒</div><h1>Money Matters</h1><p>Create Student Profile</p></div><div class="mm-login-title">New Student Profile</div><div class="mm-login-field"><span class="field-icon">👤</span><input id="mm56-new-name" autocomplete="name" placeholder="Student name" aria-label="Student name"></div><div class="mm-login-field"><span class="field-icon">🎓</span><select id="mm56-new-grade" aria-label="Grade">'+opts+'</select></div><div class="mm-login-field"><span class="field-icon">🏫</span><input id="mm56-new-teacher" list="mm56-teachers" placeholder="Class or teacher (optional)" aria-label="Class or teacher name, optional"><datalist id="mm56-teachers">'+teachers.map(function(x){return '<option value="'+esc(x)+'">';}).join('')+'</datalist></div><div id="mm56-new-error" class="mm-login-error" role="alert"></div><button class="mm-login-submit" onclick="window.mmV56CreateStudent()">CREATE PROFILE</button><button class="mm-login-back" onclick="window.mmV55Show ? window.mmV55Show() : location.reload()">← Back to login</button><div class="mm-login-note">A unique 6-character verification code will be created for this student.</div></div>';
    setTimeout(function(){var x=document.getElementById('mm56-new-name');if(x)x.focus();},60);
  }
  function ownerScreen(){
    if(ownerEnabled())return true;
    return false;
  }
  function activateOwner(){
    setOwner(true);
    try{sessionStorage.setItem('mmRole','teacher');sessionStorage.setItem('mmLoginRole','teacher');}catch(e){}
    if(typeof setAuth==='function')setAuth('owner','Owner','owner');
    if(typeof applyRole==='function')applyRole();
    if(typeof updateIndicator==='function')updateIndicator();
    var gate=document.getElementById('mm-login-gate');if(gate)gate.classList.add('mm-hidden');
    if(typeof infoToast==='function')infoToast('✓ Owner/Admin mode enabled on this device',3000);
  }
  function signOutFixed(){
    try{sessionStorage.removeItem('mmRole');sessionStorage.removeItem('mmLoginRole');sessionStorage.removeItem('mmAuth_v1');sessionStorage.removeItem('mmAuth');}catch(e){}
    try{if(typeof clearAuth==='function')clearAuth();}catch(e){}
    try{if(typeof setTabActive==='function')setTabActive(null);}catch(e){}
    if(typeof applyRole==='function')applyRole();
    if(typeof updateIndicator==='function')updateIndicator();
    if(typeof mmV55Show==='function')mmV55Show(); else location.reload();
  }
  function hideGate(){var g=document.getElementById('mm-login-gate');if(g)g.classList.add('mm-hidden');}
  window.mmV56CreateStudent=createStudentFixed;
  window.mmV56NewStudent=showCreate;
  window.mmV56Owner=activateOwner;
  window.mmV56SignOut=signOutFixed;
  window.mmV56HideGate=hideGate;
  window.mmV56OwnerEnabled=ownerEnabled;
  function patchLogin(){
    try{
      if(typeof window.mmV55NewStudent==='function')window.mmV55NewStudent=showCreate;
      if(typeof window.signOut==='function'&&!window.signOut.__v56){window.signOut.__v56=true;}
      var b=document.createElement('style');b.textContent='#mm56-new-grade{font-family:system-ui,sans-serif;color:#2b2118}.mm-owner-bar{display:flex;justify-content:center;margin-top:10px}.mm-owner-btn{border:0;background:transparent;color:#8b6a3d;text-decoration:underline;cursor:pointer;font:600 12px system-ui}.mm-session-signout{margin-left:8px;border:0;border-radius:10px;padding:7px 10px;background:#efe2cc;color:#3b2b1d;font-weight:800;cursor:pointer}';document.head.appendChild(b);
      // If owner mode has been enabled on this device, bypass the role/login gate.
      if(ownerScreen()){
        try{sessionStorage.setItem('mmRole','teacher');}catch(e){}
        if(typeof setAuth==='function')setAuth('owner','Owner','owner');
        if(typeof applyRole==='function')applyRole();
        hideGate();
      }
    }catch(e){console.warn('V56 login patch',e)}
  }
  function addSignOut(){
    var ind=document.getElementById('mm-session-indicator');if(!ind||document.getElementById('mm56-signout'))return;
    var btn=document.createElement('button');btn.id='mm56-signout';btn.className='mm-session-signout';btn.textContent='Sign out';btn.onclick=function(e){e.stopPropagation();signOutFixed();};
    ind.insertAdjacentElement('afterend',btn);
  }
  // Replace the login gate after V55 has initialized.
  document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){patchLogin();addSignOut();},120);});
  setTimeout(function(){patchLogin();addSignOut();},700);
})();
