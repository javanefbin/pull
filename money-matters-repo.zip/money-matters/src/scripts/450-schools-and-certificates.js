/* =====================================================================
   V93 · Schools · administrator switching into teacher profiles ·
         certificate redesign · one-time password dialog · quiz polish
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91,U=MM.util,D=MM.data,A=MM.auth,S=MM.shell,AD=MM.admin,ACC=MM.accounts,$=U.$,E=U.E,H=AD.h;

/* ---------- MM.schools ---------- */
var SK='mmSchools_v1';
var SCH=MM.schools={
  list:function(){var l=[];try{l=JSON.parse(localStorage.getItem(SK)||'[]')||[];}catch(e){}var cur=SCH.current();if(cur&&l.indexOf(cur)<0)l.unshift(cur);return l;},
  save:function(l){try{localStorage.setItem(SK,JSON.stringify(l.filter(function(x,i,a){return x&&a.indexOf(x)===i;})));}catch(e){}},
  current:function(){try{return localStorage.getItem('mmSchoolName')||'';}catch(e){return '';}},
  setCurrent:function(name){name=String(name||'').trim().slice(0,80);try{if(name)localStorage.setItem('mmSchoolName',name);else localStorage.removeItem('mmSchoolName');}catch(e){}if(name){var l=SCH.list();if(l.indexOf(name)<0){l.push(name);SCH.save(l);}}var ce=$('certSchool');if(ce)ce.value=name;try{S.topbar();}catch(e){}},
  add:function(name){name=String(name||'').trim().slice(0,80);if(!name)return false;var l=SCH.list();if(l.indexOf(name)<0){l.push(name);SCH.save(l);}if(!SCH.current())SCH.setCurrent(name);return true;},
  rename:function(oldN,newN){newN=String(newN||'').trim().slice(0,80);if(!newN||newN===oldN)return;SCH.save(SCH.list().map(function(x){return x===oldN?newN:x;}));if(SCH.current()===oldN)SCH.setCurrent(newN);var o=ACC.load();Object.keys(o.list).forEach(function(k){if(o.list[k].school===oldN)o.list[k].school=newN;});ACC.save(o);},
  remove:function(name){SCH.save(SCH.list().filter(function(x){return x!==name;}));if(SCH.current()===name){var l=SCH.list();SCH.setCurrent(l[0]||'');}}
};
/* tag new accounts with the active school */
(function(){var oa=ACC.add;ACC.add=function(opts){return oa.call(ACC,opts).then(function(r){if(r&&r.account&&!r.account.school){var sc=SCH.current();if(sc)ACC.update(r.account.u,function(a){a.school=sc;});}return r;});};})();

/* ---------- sign-in: school selector + account/school check ---------- */
(function(){var oShow=MM.gate.show;
  /* V18: a searchable field instead of a drop-down, so any number of schools fits */
  function schoolBlock(){var list=SCH.list(),cur=SCH.current();return '<label class="lbl" for="a-school">School</label><div class="fld"><input id="a-school" type="text" list="a-school-list" autocomplete="organization" spellcheck="false" placeholder="'+(list.length?'Start typing your school':'School name (optional)')+'" value="'+E(cur)+'"></div><datalist id="a-school-list">'+list.map(function(s){return '<option value="'+E(s)+'"></option>';}).join('')+'</datalist>';}
  function inject(){var el=$('mm-auth');if(!el||el.classList.contains('mm-hidden'))return;var lbl=el.querySelector('.mm-who')||el.querySelector('label.lbl[for="mm55-user"]');if(!lbl||el.querySelector('#a-school'))return;lbl.insertAdjacentHTML('beforebegin',schoolBlock());
    var sel=$('a-school');if(sel){sel.addEventListener('change',function(){var v=sel.value.trim();if(!v)return;SCH.setCurrent(v);var h1=el.querySelector('.mm-login-brand h1');if(h1)h1.textContent=v;var lg=el.querySelector('.mm-login-brand .logo');if(lg)lg.textContent=v.charAt(0).toUpperCase();});}}
  MM.gate.show=function(opts){oShow.call(MM.gate,opts);setTimeout(inject,0);};
  /* keep the school in sync when the sign-in screen re-renders itself */
  new MutationObserver(function(){inject();}).observe(document.documentElement,{childList:true,subtree:true});
  /* accounts bound to another school cannot sign in under a different one */
  var ov=ACC.verify;ACC.verify=function(u,pw){return ov.call(ACC,u,pw).then(function(acc){if(acc&&acc.school&&SCH.current()&&acc.school!==SCH.current()&&acc.role!=='admin'){var e=$('mm55-error');if(e)e.textContent='This account belongs to '+acc.school+'. Choose that school to sign in.';return null;}return acc;});};
})();

/* ---------- administrator → teacher profile switching ---------- */
A.impersonateStaff=function(u){var acc=ACC.get(u);if(!acc||acc.role==='student')return false;if(!A.canSwitch()){U.toast('Only an administrator can switch profiles.',3000);return false;}
  if(!A.stash()){try{sessionStorage.setItem('mmAdminStash_v1',sessionStorage.getItem('mmAuth_v1')||'');}catch(e){}}
  try{sessionStorage.setItem('mmRole','teacher');}catch(e){}
  A.set({role:'teacher',name:acc.name,id:acc.role==='admin'?'admin':'teacher',u:acc.u,scope:acc.scope||'all',acctRole:acc.role,viewing:true});
  try{setTabActive(null);closePanel(true);applyRole();buildNav();openPanel('admin');}catch(e){}U.toast('Viewing as '+acc.name+' ('+ACC.ROLES[acc.role]+'). Use "Return to Admin" when done.',3500);return true;};
/* session panel: teachers appear under Switch profile */
(function(){var o=S.renderSession;S.renderSession=function(){o.apply(this,arguments);var el=$('loginBody');if(!el||!A.canSwitch())return;var card=el.querySelector('.mm-card.accent');if(!card)return;
  var staff=ACC.staff().filter(function(a){return a.role!=='admin'&&!a.pending;}).sort(function(x,y){return x.name.localeCompare(y.name);});var me=A.get();
  var h='<div class="mm-divider"></div><div class="mm-label" style="margin-bottom:6px">Teacher profiles</div>'+(staff.length?'<div class="mm-row">'+staff.map(function(a){return '<button class="mm-btn sm '+(me&&me.u===a.u?'primary':'secondary')+'" onclick="MM91.auth.impersonateStaff(\''+E(a.u)+'\')">'+U.avatar(a.name,'sm teacher')+' '+E(a.name)+' <span style="opacity:.6">· '+E(ACC.ROLES[a.role])+(a.scope&&a.scope!=='all'?' · '+E(ACC.scopeLabel(a)):'')+'</span></button>';}).join('')+'</div>':'<div class="mm-muted">No teacher accounts yet. Add one in Users, or let a teacher create a profile from the sign-in screen.</div>')+'<div class="mm-label" style="margin:12px 0 6px">Student profiles</div>';
  var row=card.querySelector('.mm-row, .mm-empty');if(row)row.insertAdjacentHTML('beforebegin',h);var sub=card.querySelector('.mm-card-sub');if(sub)sub.textContent='Administrator only. Open the app exactly as a teacher or a student sees it. You return to this session with one click.';};})();

/* ---------- certificate ---------- */
var CERT_CSS93='body{margin:0;padding:24px;background:#fff;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}.cert{position:relative;background:#fffdf7;border:4px double #c4912e;border-radius:6px;max-width:820px;margin:0 auto;text-align:center;overflow:hidden}.cert::before{content:"";position:absolute;inset:14px;border:1px solid rgba(196,145,46,.6)}.cert-in{position:relative;padding:40px 48px 34px}.c-ribbon{position:absolute;top:0;left:0;right:0;height:10px;background:linear-gradient(90deg,#1e3d5c,#c4912e,#2a6b4a)}.c-school{font-weight:800;font-size:12px;letter-spacing:.24em;text-transform:uppercase;color:#8a5e10;margin-bottom:6px}.c-program{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#6b5137}.c-title{font-family:Georgia,serif;font-size:38px;font-weight:700;color:#1a1208;margin:18px 0 4px}.c-sub{font-family:Georgia,serif;font-style:italic;font-size:15px;color:#6b5137}.c-presented{font-size:13px;letter-spacing:.18em;text-transform:uppercase;color:#6b5137;margin:22px 0 6px}.c-name{font-family:Georgia,serif;font-size:40px;font-weight:700;color:#2a6b4a;display:inline-block;padding:4px 28px 8px;border-bottom:2px solid #c4912e;min-width:280px}.c-line{font-size:15px;line-height:1.6;color:#3d2c18;max-width:560px;margin:18px auto 0}.c-seal{width:96px;height:96px;border-radius:50%;margin:22px auto 6px;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(circle at 35% 30%,#f3d98b,#c4912e 70%,#9a6d14);color:#3a2a0a;box-shadow:inset 0 0 0 4px rgba(255,255,255,.35)}.c-seal .ic{font-size:30px;line-height:1}.c-seal .lv{font-weight:800;font-size:10px;letter-spacing:.1em;text-transform:uppercase;margin-top:2px}.c-stats{display:flex;justify-content:center;gap:10px;flex-wrap:wrap;margin-top:10px}.c-stats span{font-weight:700;font-size:12px;padding:5px 11px;border-radius:999px;background:#f7e8c4;color:#6e4b0b;border:1px solid rgba(196,145,46,.35)}.c-sign{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin:30px auto 0;max-width:560px}.c-sign div{border-top:1px solid #6b5137;padding-top:6px;font-size:12px;color:#6b5137}.c-sign b{display:block;font-size:13px;color:#1a1208}.c-foot{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-top:26px;font:11px ui-monospace,Menlo,Consolas,monospace;letter-spacing:.06em;color:#9a7a4a}@media print{body{padding:0}}';
function certHTML93(){var nameEl=$('certName'),name=(nameEl&&nameEl.value)||'',schoolEl=$('certSchool'),school=(schoolEl&&schoolEl.value)||SCH.current();var s,lv,gc;try{s=progStats();lv=certLevel();gc=gradeCompletion();}catch(e){s={stars:0};lv=['⭐','Participant'];gc={complete:false,weeks:0,totalWeeks:36,tests:0,totalTests:6};}
  var date='';try{date=new Date().toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'});}catch(e){}
  var heading=gc.complete?U.t('Certificate of Completion'):U.t('Certificate of Achievement'),gl=D.gradeLabel(currentGrade),st=null;try{st=activeStudent();}catch(e){}var teach=(st&&st.teacher)||'';
  var line=gc.complete?'has successfully completed <b>'+E(gl)+'</b> of the Money Matters financial literacy program: every weekly lesson and all checkpoint tests.':'is recognized for outstanding progress in <b>'+E(gl)+'</b>: earning, saving, budgeting, and making smart money decisions.';
  var aid='anon';try{aid=_activeId()||'anon';}catch(e){}try{_certCode(aid,currentGrade,gc.weeks).then(function(code){var el=$('certVerifyCode');if(el)el.textContent='Verification '+code;});}catch(e){}
  return '<div class="cert"><div class="c-ribbon"></div><div class="cert-in">'+(school?'<div class="c-school">'+E(school)+'</div>':'')+'<div class="c-program">Money Matters · K–8 Financial Literacy Program</div>'
    +'<div class="c-title">'+E(heading)+'</div><div class="c-sub">'+(gc.complete?'Grade complete':'Presented in recognition of achievement')+'</div>'
    +'<div class="c-presented">This certifies that</div><div class="c-name">'+E(name||U.t('Your Name'))+'</div>'
    +'<div class="c-line">'+line+'</div>'
    +'<div class="c-seal"><span class="ic">'+lv[0]+'</span><span class="lv">'+E(lv[1])+'</span></div>'
    +'<div class="c-stats"><span>Lessons '+gc.weeks+'/'+gc.totalWeeks+'</span><span>Checkpoints '+gc.tests+'/'+gc.totalTests+'</span><span>Stars '+(s.stars||0)+'</span></div>'
    +'<div class="c-sign"><div><b>'+E(teach||'Instructor')+'</b>'+(teach?'Instructor':'Signature')+'</div><div><b>'+E(date)+'</b>Date</div></div>'
    +'<div class="c-foot"><span id="certVerifyCode">Verification —</span><span>'+E(school||'Money Matters')+'</span></div></div></div>';}
function certDoc(){return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Certificate</title><style>'+CERT_CSS93+'</style></head><body>'+certHTML93()+'</body></html>';}
window.certHTML=certHTML93;
window.printCert=function(){try{var b=new Blob([certDoc()],{type:'text/html'}),u=URL.createObjectURL(b),w=window.open(u,'_blank');if(!w){window.print();URL.revokeObjectURL(u);return;}w.addEventListener('load',function(){try{w.print();}catch(e){}URL.revokeObjectURL(u);},{once:true});setTimeout(function(){URL.revokeObjectURL(u);},30000);}catch(e){window.print();}};
window.downloadCert=function(){var html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Certificate</title><style>'+CERT_CSS93+'</style></head><body>'+certHTML93()+'</body></html>';U.download('MoneyMatters_Certificate.doc','﻿'+html,'application/msword');};
/* certificate panel: tidy the name/school tools */
(function(){var p=$('panel-certificate');if(!p)return;var pills=p.querySelector('.panel-body > .meta-pills');if(pills&&!pills.classList.contains('cert-tools')){pills.classList.add('cert-tools');pills.querySelectorAll('input').forEach(function(inp){var w=document.createElement('div');w.className='mm-field';var l=document.createElement('label');l.textContent=inp.id==='certName'?'Name on the certificate':'School';l.setAttribute('for',inp.id);inp.classList.add('mm-input');inp.style.maxWidth='none';inp.style.marginTop='0';inp.parentNode.insertBefore(w,inp);w.appendChild(l);w.appendChild(inp);});}})();

/* ---------- one-time password dialog: clean layout ---------- */
(function(){var mo=new MutationObserver(function(){var b=$('mm-modal-body');if(!b)return;var pw=b.querySelector('.mm-temp-pw');if(pw&&!b.querySelector('.mm-once')){var wrap=document.createElement('div');wrap.className='mm-once';while(b.firstChild)wrap.appendChild(b.firstChild);b.appendChild(wrap);wrap.querySelectorAll('div[style*="text-align:left"]').forEach(function(d){d.style.textAlign='center';});}});var body=$('mm-modal-body');if(body)mo.observe(body,{childList:true});})();

/* ---------- Settings: schools (administrator) ---------- */
AD.acts.schoolAdd=function(){var v=(($('sc-new')||{}).value||'').trim();if(!v){U.toast('Enter the school name.');return;}SCH.add(v);if(SCH.list().length===1)SCH.setCurrent(v);AD.render();U.toast('✓ School added.');};
AD.acts.schoolUse=function(el,o){SCH.setCurrent(o.v);AD.render();U.toast('✓ '+o.v+' is now the active school.');};
AD.acts.schoolRename=function(el,o){mmInput('Rename school','',{icon:'🏫',okLabel:'Save'}).then(function(v){if(v&&v.trim()){SCH.rename(o.v,v.trim());AD.render();}});};
AD.acts.schoolRemove=function(el,o){mmConfirm('Remove '+o.v+'?','Accounts keep working; they are simply no longer bound to this school.','Remove','🏫').then(function(ok){if(!ok)return;SCH.remove(o.v);var a=ACC.load();Object.keys(a.list).forEach(function(k){if(a.list[k].school===o.v)delete a.list[k].school;});ACC.save(a);AD.render();});};
AD.afterRender.push(function(st,main){if(st.tab!=='settings'||!A.isAdmin())return;var box=main.querySelector('#adminSettingsExt');if(!box)return;var list=SCH.list(),cur=SCH.current();
  box.insertAdjacentHTML('afterbegin','<div class="mm-card accent" style="margin-top:12px"><div class="mm-card-title">🏫 Schools <span class="spacer"></span><span class="mm-chip">'+list.length+'</span></div><div class="mm-card-sub">The active school appears on the sign-in screen, certificates, reports, and the family letter. Sign-in offers every school listed here; new accounts are bound to the active school.</div><div class="mm-school-list" style="margin-top:10px">'+(list.length?list.map(function(s){return '<div class="mm-school-row '+(s===cur?'active':'')+'"><span class="n">'+E(s)+(s===cur?' <span class="mm-chip gold" style="margin-left:6px">active</span>':'')+'</span>'+(s===cur?'':'<button class="mm-btn sm secondary" data-act="schoolUse" data-v="'+E(s)+'">Make active</button>')+'<button class="mm-btn sm ghost" data-act="schoolRename" data-v="'+E(s)+'">Rename</button><button class="mm-btn sm ghost" data-act="schoolRemove" data-v="'+E(s)+'">Remove</button></div>';}).join(''):'<div class="mm-muted">No school yet. Add the first school below.</div>')+'</div><div class="mm-row" style="margin-top:10px"><input class="mm-input" id="sc-new" placeholder="School name" maxlength="80" style="flex:1 1 220px"><button class="mm-btn primary" data-act="schoolAdd">＋ Add school</button></div></div>');});
/* Users: school chip when more than one school exists */
AD.afterRender.push(function(st,main){if(st.tab!=='users')return;if(SCH.list().length<2)return;main.querySelectorAll('.mm-user').forEach(function(card){var u=card.getAttribute('data-u'),a=ACC.get(u);if(!a)return;var hd=card.querySelector('.hd .id');if(hd&&!card.querySelector('.sc-chip'))hd.insertAdjacentHTML('afterend','<span class="mm-chip sc-chip" style="margin-top:4px;align-self:flex-start">🏫 '+E(a.school||'Any school')+'</span>');});});

/* ---------- phone navigation: bottom tab bar + slide-up sheet ---------- */
(function(){
  function tabs(){var rk=A.roleKey();if(rk==='admin'||rk==='teacher')return [['🏠','Home',"MM91.shell.home()"],['🧑‍🏫','Teacher’s Guide',"openDoc('guide')"],['📚','Lessons',"openPanel('lessons')"],['👥','Students',"MM91.admin.open('students')"],['⋯','More',"MM91.shell.openSheet()"]];
    return [['🏠','Home',"openPanel('dashboard')"],['📚','Lessons',"openPanel('lessons')"],['📝','Quiz',"openQuiz()"],['🎭','Story',"openPanel('story')"],['⋯','More',"MM91.shell.openSheet()"]];}
  function build(){var el=$('mm-tabbar');if(!el){el=document.createElement('nav');el.id='mm-tabbar';el.setAttribute('aria-label','Quick navigation');document.body.appendChild(el);}
    if(!A.get()||MM.gate.visible()){el.style.display='none';document.documentElement.classList.remove('mm-tabs-on');return;}el.style.display='';document.documentElement.classList.add('mm-tabs-on');
    var cur=openPanelId;el.innerHTML=tabs().map(function(t){var on=(t[1]==='Home'&&!cur)||(cur&&t[2].indexOf("'"+cur+"'")>-1)||(t[1]==='Quiz'&&cur==='quiz')||(t[2].indexOf('openDoc')>-1&&cur==='doc'&&typeof currentDoc!=='undefined'&&currentDoc==='guide');return '<button type="button" class="'+(on?'on':'')+'" onclick="'+t[2]+'"'+''+'><span class="ic" aria-hidden="true">'+t[0]+'</span><span>'+E(t[1])+'</span></button>';}).join('');}
  S.openSheet=function(){var sh=$('mm-sheet');if(!sh){sh=document.createElement('div');sh.id='mm-sheet';sh.setAttribute('role','dialog');sh.setAttribute('aria-label','All sections');sh.innerHTML='<div class="sh-bd" onclick="MM91.shell.closeSheet()"></div><div class="sh-card"><div class="sh-handle"></div><div class="sh-body"></div></div>';document.body.appendChild(sh);}
    var body=sh.querySelector('.sh-body'),h='',staff=A.isTeacher();
    /* V23: the Console lives here (the tab bar has the Teacher's Guide in its place) */
    if(staff)h+='<div class="sh-g">'+E('Console')+'</div><div class="sh-grid"><button type="button" class="sh-console" onclick="MM91.shell.closeSheet();openPanel(\'admin\')"><span class="ic" aria-hidden="true">🛠️</span><span>'+E(A.roleKey()==='admin'?'Admin Console':'Console')+'</span></button></div>';
    S.navGroups().forEach(function(g){if(g.cls&&g.cls.indexOf('teacher-only')>-1&&!staff)return;var items=g.items.filter(function(d){return (!d[3]||staff)&&!(staff&&/openPanel\('admin'\)/.test(d[2]));});   /* the Console is first in the sheet */if(!items.length)return;h+='<div class="sh-g">'+E(g.label)+'</div><div class="sh-grid">'+items.map(function(d){return '<button type="button" onclick="MM91.shell.closeSheet();'+d[2]+'"><span class="ic" aria-hidden="true">'+d[0]+'</span><span>'+E(d[1])+'</span></button>';}).join('')+'</div>';});
    h+='<div class="sh-g">More</div><div class="sh-grid">'+S.moreItems().filter(function(x){return x!=='sep';}).map(function(it){return '<button type="button" onclick="MM91.shell.closeSheet();'+it[2]+'"><span class="ic" aria-hidden="true">'+it[0]+'</span><span>'+E(it[1])+'</span></button>';}).join('')+'</div>';
    body.innerHTML=h;try{MM.i18n&&MM.i18n.apply(body);}catch(e){}sh.classList.add('open');};
  S.closeSheet=function(){var sh=$('mm-sheet');if(sh)sh.classList.remove('open');};
  document.addEventListener('keydown',function(e){if(e.key==='Escape')S.closeSheet();});
  var ot=S.topbar;S.topbar=function(){ot.apply(this,arguments);try{build();}catch(e){}};
  window.addEventListener('resize',U.debounce(build,150));
  document.addEventListener('DOMContentLoaded',function(){setTimeout(build,700);setTimeout(build,1600);});
})();

/* ---------- editable roles & capabilities (administrator) ---------- */
var CAPK='mmRoleCaps_v1';
var CAPDEFS=[['lessons','Lessons, worksheets, quizzes, games, story'],['profiles','View student profiles & reports'],['guides','Teacher guide & answer keys'],['manage','Add / edit students, assign weeks, import roster'],['notes','Private notes on students'],['exports','Gradebook & class exports'],['backups','Backups & restore'],['users','Add users, lock / unlock, set passwords'],['security','Security policy & sign-in log'],['switch','Switch into a student or teacher profile'],['erase','Erase device data']];
var CAPDEF={admin:CAPDEFS.map(function(c){return c[0];}),teacher:['lessons','profiles','guides','manage','notes','exports','backups'],coteacher:['lessons','profiles','guides','notes'],guardian:['lessons','profiles'],student:['lessons']};
var FIXED={admin:true,student:true};var ADMIN_ONLY=['users','security','switch','erase'];
var CAPS=MM.caps={
  load:function(){var o={};try{o=JSON.parse(localStorage.getItem(CAPK)||'{}')||{};}catch(e){}var out={};Object.keys(CAPDEF).forEach(function(r){out[r]=FIXED[r]?CAPDEF[r].slice():(Array.isArray(o[r])?o[r].filter(function(c){return ADMIN_ONLY.indexOf(c)<0;}):CAPDEF[r].slice());if(out[r].indexOf('lessons')<0)out[r].push('lessons');});return out;},
  save:function(m){var o={};Object.keys(m).forEach(function(r){if(!FIXED[r])o[r]=m[r];});try{localStorage.setItem(CAPK,JSON.stringify(o));}catch(e){}},
  reset:function(){try{localStorage.removeItem(CAPK);}catch(e){}},
  has:function(role,cap){var m=CAPS.load();return (m[role]||[]).indexOf(cap)>-1;},
  can:function(cap){var a=A.get();if(!a)return false;if(A.isAdmin())return true;var role=a.role==='student'?'student':(a.acctRole||'teacher');return CAPS.has(role,cap);},
  label:function(role){var m=CAPS.load()[role]||[];return CAPDEFS.filter(function(c){return m.indexOf(c[0])>-1;}).map(function(c){return c[1].toLowerCase();}).join(', ');}
};
A.can=CAPS.can;
/* enforcement: console tabs, actions, teacher guide */
(function(){var T=AD.TABS;T.forEach(function(t){if(t.id==='data')t.cap='backups';if(t.id==='reports')t.cap='profiles';});
  var oRender=AD.render;AD.render=function(){var st=AD.state;if(!A.isAdmin()){var cur=T.filter(function(t){return t.id===st.tab;})[0];if(cur&&cur.cap&&!CAPS.can(cur.cap)){st.tab='overview';st.view=null;}}oRender.apply(this,arguments);
    if(A.isAdmin())return;var main=$('adminMain'),side=$('adminSide');if(side)side.querySelectorAll('.mm-side-btn').forEach(function(b){var id=b.getAttribute('data-id'),t=T.filter(function(x){return x.id===id;})[0];if(t&&t.cap&&!CAPS.can(t.cap))b.remove();});
    if(!main)return;
    if(!CAPS.can('manage'))main.querySelectorAll('[data-act="addToggle"],[data-act="addSave"],[data-act="saveEdit"],[data-act="promote"],[data-act="reset"],[data-act="remove"],[data-act="regen"],[data-act="assignWeek"],[data-act="assignWeekSel"],[data-act="assignWeekQuick"],[data-act="importPaste"],[data-act="teacherAddToggle"],[data-act="assignStudent"],[data-act="ptab"][data-id="manage"]').forEach(function(b){b.remove();});
    if(!CAPS.can('notes'))main.querySelectorAll('[data-act="ptab"][data-id="notes"],[data-act="noteAdd"]').forEach(function(b){b.remove();});
    if(!CAPS.can('exports'))main.querySelectorAll('[data-act="exportRoster"],[data-act="gradebook"],[data-act="xlsx"],[data-act="classCsv"],[data-act="classCsvSel"],[data-act="logCsv"]').forEach(function(b){b.remove();});
    if(!CAPS.can('profiles'))main.querySelectorAll('[data-act="report"],[data-act="export"],[data-act="student"]').forEach(function(b){if(b.tagName==='TR'){b.removeAttribute('data-act');b.classList.remove('clickable');}else b.remove();});
    if(!CAPS.can('backups'))main.querySelectorAll('[data-act="backup"],[data-act="fullBackup"],[data-act="restore"],[data-act="fullRestore"]').forEach(function(b){b.remove();});};
  if(typeof openDoc==='function'&&!openDoc.__v93){var od=openDoc;var wd=function(kind){if(kind==='guide'&&!CAPS.can('guides')){U.toast('The teacher guide is not enabled for your role.',3000);kind='plan';}return od.apply(this,arguments.length?[kind].concat([].slice.call(arguments,1)):[kind]);};wd.__v93=true;openDoc=wd;}
})();
/* editable matrix view */
AD.VIEWS.roles=function(){var m=CAPS.load(),order=['admin','teacher','coteacher','guardian','student'],isAdmin=A.isAdmin();
  var h=H.head('Roles &amp; capabilities','What each role may do. Administrators can switch capabilities on or off for teachers, co-teachers, and guardians; the changes apply immediately to the console, documents, and actions.',isAdmin?'<button class="mm-btn ghost" data-act="capReset">Reset to defaults</button>':'');
  h+='<div class="mm-grid c4" style="margin-bottom:14px">'+order.filter(function(r){return r!=='coteacher';}).map(function(r){var n=ACC.list().filter(function(a){return a.role===r;}).length;return H.stat(n,ACC.ROLES[r],'',{admin:'🛡️',teacher:'👩‍🏫',guardian:'👪',student:'🎒'}[r]);}).join('')+'</div>';
  h+='<div class="mm-table-wrap"><table class="mm-roles"><thead><tr><th>Capability</th>'+order.map(function(r){return '<th>'+E(ACC.ROLES[r])+(FIXED[r]?'<div class="mm-muted" style="font-weight:600;text-transform:none;letter-spacing:0">fixed</div>':'')+'</th>';}).join('')+'</tr></thead><tbody>'+CAPDEFS.map(function(c){return '<tr><td>'+E(c[1])+(ADMIN_ONLY.indexOf(c[0])>-1?' <span class="mm-chip bad" style="padding:1px 7px;font-size:10px">admin only</span>':'')+'</td>'+order.map(function(r){var on=(m[r]||[]).indexOf(c[0])>-1,editable=isAdmin&&!FIXED[r]&&ADMIN_ONLY.indexOf(c[0])<0&&c[0]!=='lessons';return '<td>'+(editable?'<input type="checkbox" class="cap-box" data-role="'+r+'" data-cap="'+c[0]+'" '+(on?'checked':'')+' aria-label="'+E(ACC.ROLES[r]+': '+c[1])+'">':(on?'<span class="y">✓</span>':'<span class="n">—</span>'))+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';
  h+='<div class="mm-alert info" style="margin-top:12px"><span class="ic">ℹ️</span><div>Lessons are available to every role. Account management, security policy, profile switching, and erasing data are always administrator-only. Scope (all grades or specific grades) further narrows which students a staff account sees.</div></div>';return h;};
AD.acts.capReset=function(){if(!A.isAdmin())return;mmConfirm('Reset roles to defaults?','Teacher, co-teacher, and guardian capabilities return to the standard set.','Reset','🛡️').then(function(ok){if(ok){CAPS.reset();ACC.log('policy',A.get().u||'','roles reset',A.displayName());AD.render();}});};
document.addEventListener('change',function(e){var b=e.target;if(!b.classList||!b.classList.contains('cap-box')||!A.isAdmin())return;var m=CAPS.load(),r=b.getAttribute('data-role'),c=b.getAttribute('data-cap');m[r]=(m[r]||[]).filter(function(x){return x!==c;});if(b.checked)m[r].push(c);CAPS.save(m);ACC.log('policy',A.get().u||'',ACC.ROLES[r]+': '+(b.checked?'+':'−')+c,A.displayName());U.toast('✓ '+ACC.ROLES[r]+' capabilities updated.',1500);});
/* capability text in Users and My profile follows the matrix */
(function(){var o=AD.VIEWS.users;AD.VIEWS.users=function(){var h=o.apply(this,arguments);return h;};})();

/* ---------- assessment first: students complete the Financial Literacy Assessment before lessons ---------- */
(function(){
  var GATED=['lessons','quiz','path','test','doc','story','games','certificate'];
  function on(){var p=ACC.policy();return p.assessFirst!==false;}
  function needs(){if(!on())return false;var a=A.get();if(!a||a.role!=='student')return false;var st=null;try{st=activeStudent();}catch(e){}if(!st)return false;return !D.fa(st.id).latest;}
  MM.assessFirst={needs:needs,on:on};
  function toAssessment(){try{if(typeof openFinancialAssessment==='function'&&activeStudent())openFinancialAssessment(activeStudent().id);else openPanel('assessment');}catch(e){}U.toast('Complete the Financial Literacy Assessment first. Your lessons unlock right after.',3500);}
  function install(){if(typeof openPanel==='function'&&!openPanel.__v93a){var o=openPanel;var w=function(id){if(GATED.indexOf(id)>-1&&needs()){toAssessment();return;}return o.apply(this,arguments);};w.__v93a=true;openPanel=w;}
    if(typeof weekUnlocked==='function'&&!weekUnlocked.__v93a){var ow=weekUnlocked;var ww=function(i){if(needs())return false;return ow.apply(this,arguments);};ww.__v93a=true;weekUnlocked=ww;}
    if(typeof lockedMsg==='function'&&!lockedMsg.__v93a){var ol=lockedMsg;var wl=function(i){if(needs()){toAssessment();return;}return ol.apply(this,arguments);};wl.__v93a=true;lockedMsg=wl;}
    if(typeof gotoLesson==='function'&&!gotoLesson.__v93a){var og=gotoLesson;var wg=function(i){if(needs()){toAssessment();return;}return og.apply(this,arguments);};wg.__v93a=true;gotoLesson=wg;}
    if(typeof continuePath==='function'&&!continuePath.__v93a){var oc=continuePath;var wc=function(){if(needs()){toAssessment();return;}return oc.apply(this,arguments);};wc.__v93a=true;continuePath=wc;}
    if(typeof openQuiz==='function'&&!openQuiz.__v93a){var oq=openQuiz;var wq=function(){if(needs()){toAssessment();return;}return oq.apply(this,arguments);};wq.__v93a=true;openQuiz=wq;}
    if(typeof openTestMenu==='function'&&!openTestMenu.__v93a){var otm=openTestMenu;var wtm=function(){if(needs()){toAssessment();return;}return otm.apply(this,arguments);};wtm.__v93a=true;openTestMenu=wtm;}}
  /* Today strip: the Continue card becomes the assessment call to action */
  if(S.homeCards&&!S.homeCards.__v93a){var oh=S.homeCards;var wh=function(){var cards=oh.apply(this,arguments);try{if(needs()&&cards.length){cards[0]={cls:'hi',k:'📊 Start here',v:'Financial Literacy Assessment',s:'A short grade-level check that personalizes your learning path. Lessons unlock as soon as it is finished.',a:'<button class="mm-btn sm primary" onclick="openPanel(\'assessment\')">Start assessment</button>'};}}catch(e){}return cards;};wh.__v93a=true;S.homeCards=wh;}
  /* dashboard notice */
  if(typeof renderDashboard==='function'&&!renderDashboard.__v93a){var ord=renderDashboard;var wrd=function(){ord.apply(this,arguments);try{if(needs()){var el=$('dashBody');if(el)el.insertAdjacentHTML('afterbegin','<div class="mm-alert warn" style="margin-bottom:12px"><span class="ic">📊</span><div><b>First step: the Financial Literacy Assessment.</b> It takes a few minutes and unlocks your lessons, quizzes, games, and story. <button class="mm-btn sm primary" onclick="openPanel(\'assessment\')">Start now</button></div></div>');}}catch(e){}};wrd.__v93a=true;renderDashboard=wrd;if(typeof _panelRenderers!=='undefined')_panelRenderers.dashboard=function(){renderDashboard();};}
  /* after the assessment is submitted, refresh locks */
  if(typeof window.faSubmit==='function'&&!window.faSubmit.__v93a){var ofs=window.faSubmit;var wfs=function(){var r=ofs.apply(this,arguments);setTimeout(function(){try{buildNav();S.topbar();if(!needs())U.toast('Assessment complete — your lessons are unlocked.',3500);}catch(e){}},300);return r;};wfs.__v93a=true;window.faSubmit=wfs;}
  /* security policy switch */
  AD.afterRender.push(function(st,main){if(st.tab!=='security')return;var card=main.querySelector('#pol-name');if(!card)return;var p=ACC.policy();card.closest('.mm-stack').insertAdjacentHTML('beforeend','<label class="mm-switch"><input type="checkbox" id="pol-assess" '+(p.assessFirst!==false?'checked':'')+(A.isAdmin()?'':' disabled')+'> Students must complete the Financial Literacy Assessment before lessons open</label>');});
  var oSave=AD.acts.polSave;AD.acts.polSave=function(){var cb=$('pol-assess');if(cb)ACC.setPolicy({assessFirst:cb.checked});return oSave.apply(this,arguments);};
  document.addEventListener('DOMContentLoaded',function(){setTimeout(install,350);setTimeout(install,1500);setTimeout(install,3000);});
})();

/* ---------- the instructor's welcome bubble stays closed until the instructor is clicked ---------- */
(function(){function hideWelcome(){var w=$('welcome-panel');if(w&&!w.classList.contains('hidden')){w.classList.add('hidden');try{welcomeVisible=false;}catch(e){}}}
  var oh=MM.gate.hide;MM.gate.hide=function(){oh.apply(MM.gate,arguments);hideWelcome();};
  document.addEventListener('DOMContentLoaded',function(){setTimeout(hideWelcome,900);setTimeout(hideWelcome,2200);});})();

/* ---------- phone grade picker: a top-bar chip + sheet replaces the nine-button grade row ---------- */
(function(){
  /* V23: the grade chip shows wherever the bottom tab bar replaces the grade row (phones, tablets, staff) */
  function phone(){return innerWidth<=640||document.documentElement.classList.contains('mm-tabs-all');}
  function unlocked(g){try{return gradeUnlocked(g);}catch(e){return true;}}
  function chip(){var tb=$('mm-topbar');if(!tb||tb.style.display==='none')return;var ctx=tb.querySelector('.ctx');if(!ctx)return;var old=ctx.querySelector('.gradepick');if(!phone()){if(old)old.remove();return;}
    var g=currentGrade||'K',canPick=D.GRADES.some(function(x){return x!==g&&unlocked(x);}),label=D.gradeLabel(g);
    var html='<button type="button" class="tb gradepick'+(canPick?'':' fixed')+'" data-a="grade" aria-haspopup="dialog" title="'+E(label)+'">🎓 <span>'+E(label)+'</span>'+(canPick?' ▾':'')+'</button>';
    if(old)old.outerHTML=html;else ctx.insertAdjacentHTML('afterbegin',html);}
  S.openGradeSheet=function(){var sh=$('mm-sheet');if(!sh){S.openSheet();S.closeSheet();sh=$('mm-sheet');}if(!sh)return;var body=sh.querySelector('.sh-body'),g=currentGrade||'K';
    body.innerHTML='<div class="sh-g">Choose a grade</div><div class="sh-grid grades">'+D.GRADES.map(function(x){var ok=unlocked(x),on=x===g;var th='';try{th=GRADE_THEME[x]||'';}catch(e){}return '<button type="button" class="'+(on?'on':'')+(ok?'':' locked')+'" '+(ok?'onclick="MM91.shell.closeSheet();pickGrade(\''+x+'\')"':'disabled')+'><span class="ic">'+(ok?E(x==='K'?'K':x):'🔒')+'</span><span>'+E(D.gradeLabel(x))+'</span></button>';}).join('')+'</div><div class="mm-muted" style="margin:10px 2px 0">'+(A.roleKey()==='student'?'Your grade is set by your teacher. Locked grades open when you are promoted.':'Teachers and administrators can teach any grade. Students see their own grade only.')+'</div>';
    sh.classList.add('open');};
  document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#mm-topbar .gradepick');if(!b)return;e.preventDefault();e.stopPropagation();if(!b.classList.contains('fixed'))S.openGradeSheet();},true);
  var ot=S.topbar;S.topbar=function(){ot.apply(this,arguments);try{chip();}catch(e){}};
  if(typeof setGrade==='function'&&!setGrade.__v93g){var og=setGrade;var wg=function(g){og.apply(this,arguments);try{chip();}catch(e){}};wg.__v93g=true;setGrade=wg;}
  window.addEventListener('resize',U.debounce(function(){chip();try{S.placeHome();}catch(e){}},150));
  document.addEventListener('DOMContentLoaded',function(){setTimeout(chip,800);setTimeout(chip,1800);});
})();

/* ---------- Today strip placement that understands the phone tab bar ---------- */
S.placeHome=function(){var el=$('mm-home'),room=document.querySelector('#scene .room'),chalk=document.querySelector('.chalkboard'),row=document.querySelector('.station-row');if(!el||!room||!chalk||!row)return;
  var R=room.getBoundingClientRect(),C=chalk.getBoundingClientRect(),S1=row.getBoundingClientRect(),limit=innerHeight;
  ['nav','mm-tabbar'].forEach(function(id){var n=$(id);if(!n)return;var cs=getComputedStyle(n);if(cs.display==='none'||cs.visibility==='hidden')return;var r=n.getBoundingClientRect();if(r.height>0&&r.top<limit)limit=r.top;});
  var wall={top:C.bottom+20,bottom:S1.top-8},floor={top:S1.bottom+12,bottom:limit-8},pick=(floor.bottom-floor.top)>=(wall.bottom-wall.top)?floor:wall,h=pick.bottom-pick.top;
  if(h<76){el.classList.add('hidden');return;}el.classList.remove('hidden');
  el.style.top=(pick.top-R.top)+'px';el.style.height=h+'px';
  var narrow=innerWidth<=1024,max=narrow?(h<250?2:4):4;
  el.classList.toggle('compact',h<150||(narrow&&max===4&&h<300));
  var grid=el.querySelector('.mm-home-grid');if(grid){grid.style.maxHeight=h+'px';grid.style.gridAutoRows='minmax(0,1fr)';}
  el.querySelectorAll('.mm-home-card').forEach(function(c,i){c.style.display=i>=max?'none':'';});};
document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){try{S.placeHome();}catch(e){}},1000);setTimeout(function(){try{S.placeHome();}catch(e){}},2000);});

/* ---------- release notes ---------- */
try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'October 2026',items:['School selector on the sign-in screen; schools are managed by the administrator in Settings and new accounts are bound to the active school.','Administrators can switch into teacher profiles as well as student profiles, and return with one click.','Redesigned certificate with school, seal, signature and date lines, and verification code; quizzes and section tests use lettered answer cards with clearer feedback.','Cleaner classroom: compact Today cards, navigation that fits on laptops, and a solid one-time password dialog.']});}}catch(e){}
})();
