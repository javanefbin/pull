/* =====================================================================
   V95 · SAMPLE MODE  (MM.sample)
     Anyone can try one grade from the sign-in screen, as a student or
     as a teacher, with no account: Lesson 1 (lesson, worksheet, quiz),
     Story Mode, and the Games are open. Everything else is locked and
     opens a subscription prompt. The sample runs against a sandboxed
     roster kept in this tab only, so the device's real students,
     accounts, and progress are never shown or changed.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var U=MM.util,D=MM.data,A=MM.auth,S=MM.shell,ACC=MM.accounts,GATE=MM.gate,$=U.$,E=U.E;
var KEY='mmSample_v1',BOX='mmSampleStore_v1',SID='sample_student',IDS=[SID,'sample_student_2','sample_student_3'];
var LOCKED={test:'Section tests',certificate:'Certificates',assessment:'The Financial Literacy Assessment',admin:'The Teacher and Admin Consoles',teacher:'Class setup',students:'Class setup'};
var cache=null;
/* Set either of these before this script runs to route the Subscribe button. */
window.MM_SUBSCRIBE_URL=window.MM_SUBSCRIBE_URL||'';
window.MM_SUPPORT_EMAIL=window.MM_SUPPORT_EMAIL||'';

function get(){try{return JSON.parse(sessionStorage.getItem(KEY)||'null');}catch(e){return null;}}
function active(){var s=get();return !!(s&&s.grade);}
function grade(){var s=get();return s&&s.grade?s.grade:'K';}
function role(){var s=get();return s&&s.role==='teacher'?'teacher':'student';}

/* ---------- sandboxed roster (this tab only) ---------- */
function freshBox(g,r){var now=new Date().toISOString(),list={};
  list[SID]={id:SID,name:'Sample Student',grade:g,prog:{},verifyCode:'SAMPLE',teacher:'Sample Class',created:now,sample:1};
  if(r==='teacher'){
    list[IDS[1]]={id:IDS[1],name:'Avery Sample',grade:g,prog:{},verifyCode:'SAMPL2',teacher:'Sample Class',created:now,sample:1};
    list[IDS[2]]={id:IDS[2],name:'Jordan Sample',grade:g,prog:{},verifyCode:'SAMPL3',teacher:'Sample Class',created:now,sample:1};}
  return {list:list,teachers:['Sample Class'],active:r==='student'?SID:null};}
function readBox(){if(cache)return cache;try{cache=JSON.parse(sessionStorage.getItem(BOX)||'null');}catch(e){cache=null;}if(!cache||!cache.list)cache=freshBox(grade(),role());return cache;}
function writeBox(o){cache=o;try{sessionStorage.setItem(BOX,JSON.stringify(o));}catch(e){}}
function hasSample(o){try{return !!(o&&o.list&&IDS.some(function(id){return !!o.list[id];}));}catch(e){return false;}}
/* remove any per-student side data the sample wrote to this browser */
function scrub(){
  try{var raw=localStorage.getItem('mmStudents_v2');if(raw){var st=JSON.parse(raw),hit=false;IDS.forEach(function(id){if(st.list&&st.list[id]){delete st.list[id];hit=true;}});if(st.active&&IDS.indexOf(st.active)>-1){st.active=null;hit=true;}if(hit)localStorage.setItem('mmStudents_v2',JSON.stringify(st));}}catch(e){}
  try{var ao=ACC.load(),ah=false;Object.keys(ao.list||{}).forEach(function(u){var a=ao.list[u];if(a&&a.role==='student'&&IDS.indexOf(a.studentId)>-1){delete ao.list[u];ah=true;}});if(ah)ACC.save(ao);}catch(e){}
  try{var keys=[];for(var i=0;i<localStorage.length;i++)keys.push(localStorage.key(i));
  keys.forEach(function(k){if(!k||k.indexOf('mm')!==0)return;
    if(k.indexOf(SID)>-1){localStorage.removeItem(k);return;}
    var v=localStorage.getItem(k);if(!v||v.charAt(0)!=='{')return;
    try{var o=JSON.parse(v),hit=false;IDS.forEach(function(id){if(Object.prototype.hasOwnProperty.call(o,id)){delete o[id];hit=true;}});if(hit)localStorage.setItem(k,JSON.stringify(o));}catch(e){}});}catch(e){}}

/* ---------- store + policy wrappers (installed before the app boots) ---------- */
function installStore(){
  if(typeof loadStore==='function'&&!loadStore.__v95){var ol=loadStore;var wl=function(){if(active())return readBox();return ol.apply(this,arguments);};wl.__v95=true;loadStore=wl;}
  if(typeof saveStore==='function'&&!saveStore.__v95){var os=saveStore;var ws=function(o){if(active()){writeBox(o);try{S.homeLater();}catch(e){}return;}if(hasSample(o))return;return os.apply(this,arguments);};ws.__v95=true;saveStore=ws;}
  if(ACC&&ACC.ensureStudents&&!ACC.ensureStudents.__v95){var oe=ACC.ensureStudents;var we=function(){if(active())return;return oe.apply(this,arguments);};we.__v95=true;ACC.ensureStudents=we;}
  if(ACC&&ACC.policy&&!ACC.policy.__v95){var op=ACC.policy;var wp=function(){var p=op.apply(this,arguments);if(active())p=Object.assign({},p,{assessFirst:false,idleMins:0});return p;};wp.__v95=true;ACC.policy=wp;}
  if(MM.trend&&MM.trend.snap&&!MM.trend.snap.__v95){var ot=MM.trend.snap;var wt=function(){if(active())return;return ot.apply(this,arguments);};wt.__v95=true;MM.trend.snap=wt;}
  if(GATE&&GATE.signOut&&!GATE.signOut.__v95){var og=GATE.signOut;var wg=function(){if(active()){end();return;}return og.apply(this,arguments);};wg.__v95=true;GATE.signOut=wg;}
}

/* ---------- locks: one grade, Lesson 1, Story Mode, Games ---------- */
function wrap(name,fn){var o=window[name];if(typeof o!=='function'||o.__v95)return;var w=function(){return fn(o,[].slice.call(arguments),this);};w.__v95=true;window[name]=w;}
function installLocks(){
  wrap('gradeUnlocked',function(o,a){if(active())return a[0]===grade();return o.apply(null,a);});
  wrap('pickGrade',function(o,a){if(active()&&a[0]!==grade()){subscribe('Other grades');return;}return o.apply(null,a);});
  wrap('weekUnlocked',function(o,a){if(active())return (a[0]|0)===0;return o.apply(null,a);});
  wrap('lockedMsg',function(o,a){if(active()){subscribe('Weeks 2 to 36');return;}return o.apply(null,a);});
  wrap('gotoLesson',function(o,a){if(active()&&(a[0]|0)!==0){subscribe('Weeks 2 to 36');return;}return o.apply(null,a);});
  wrap('gotoWeek',function(o,a){if(active()&&(a[0]!==grade()||(a[1]|0)!==0)){subscribe(a[0]!==grade()?'Other grades':'Weeks 2 to 36');return;}return o.apply(null,a);});
  wrap('openTestMenu',function(o,a){if(active()){subscribe('Section tests');return;}return o.apply(null,a);});
  wrap('openDoc',function(o,a){if(active()&&a[0]==='workbook'){subscribe('The full-year workbook');return;}return o.apply(null,a);});
  wrap('openPanel',function(o,a){if(active()&&LOCKED[a[0]]){subscribe(LOCKED[a[0]]);return;}return o.apply(null,a);});
  wrap('startTour',function(o,a){if(active())return;return o.apply(null,a);});
  if(MM.coach&&MM.coach.start&&!MM.coach.start.__v95){var oc=MM.coach.start;var wc=function(){if(active())return;return oc.apply(this,arguments);};wc.__v95=true;MM.coach.start=wc;}
  wrap('signOut',function(o,a){if(active()){end();return;}return o.apply(null,a);});
  if(S.moreItems&&!S.moreItems.__v95){var om=S.moreItems;var wm=function(){var items=om.apply(this,arguments);if(!active())return items;
    return items.filter(function(it){return !(Array.isArray(it)&&/^(Sign out|My session|Session & switch profile)$/.test(it[1]));}).concat(['sep',['⭐','Subscribe',"MM91.sample.subscribe()"],['⎋','Exit sample',"MM91.sample.end()"]]);};wm.__v95=true;S.moreItems=wm;}
  if(S.topbar&&!S.topbar.__v95){var otb=S.topbar;var wtb=function(){otb.apply(this,arguments);try{chip();}catch(e){}};wtb.__v95=true;S.topbar=wtb;}
}
/* top-bar chip + Subscribe / Exit sample buttons */
function chip(){var el=$('mm-topbar');if(!el||!active()||el.style.display==='none'||el.querySelector('.smp'))return;
  var g=D.gradeLabel(grade()),c=document.createElement('span');c.className='smp';c.title='Sample mode · '+g+' · Lesson 1, Story Mode, and Games are open';c.innerHTML='🔎 <span class="lbl">Sample ·</span> '+E(D.gradeShort(grade()));
  var sub=document.createElement('button');sub.type='button';sub.className='tb smp-sub';sub.title='See what a subscription unlocks';sub.innerHTML='⭐ <span>Subscribe</span>';sub.onclick=function(){subscribe();};
  var ex=document.createElement('button');ex.type='button';ex.className='tb';ex.title='Leave the sample and return to sign in';ex.innerHTML='⎋ <span>Exit sample</span>';ex.onclick=function(){end();};
  el.querySelectorAll('[data-a="out"]').forEach(function(b){b.remove();});
  var ctx=el.querySelector('.ctx');if(ctx&&ctx.nextSibling)el.insertBefore(c,ctx.nextSibling);else el.appendChild(c);el.appendChild(sub);el.appendChild(ex);}

/* ---------- subscription prompt ---------- */
function subscribe(what){var el=$('mm-subscribe');
  if(!el){el=document.createElement('div');el.id='mm-subscribe';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label','Subscribe to Money Matters');document.body.appendChild(el);
    el.addEventListener('click',function(e){if(e.target===el){close();return;}var b=e.target.closest?e.target.closest('[data-s]'):null;if(!b)return;var a=b.getAttribute('data-s');
      if(a==='close')close();else if(a==='sub')goSubscribe();else if(a==='code')enterCode();else if(a==='signin'){close();end();}});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&el.classList.contains('open'))close();});}
  if(!active()){free(el,what);el.classList.add('open');setTimeout(function(){var b=el.querySelector('[data-s]');if(b)try{b.focus({preventScroll:true});}catch(e){}},40);return;}
  var g=D.gradeLabel(grade()),r=role()==='teacher'?'teacher':'student';
  el.innerHTML='<div class="card"><div class="k">Sample mode · '+E(g)+' · '+(r==='teacher'?'Teacher':'Student')+' view</div>'
    +'<h2>Unlock the full program</h2>'+(what?'<div class="lockline">🔒 Locked in the sample: <b>'+E(what)+'</b></div>':'')
    +'<p>You are sampling Lesson 1, Story Mode, and the Games for '+E(g)+'. A subscription opens the complete K–8 program on this device:</p>'
    +'<ul><li>All 36 weeks for every grade, K–8</li><li>Quizzes, section tests, and certificates</li><li>Financial Literacy Assessment and learning profiles</li><li>Lesson plans, worksheets, workbooks, and answer keys</li><li>Teacher and Admin Consoles with class reports</li><li>Student accounts with saved progress</li></ul>'
    +'<div class="acts"><button type="button" class="mm-btn primary" data-s="sub">⭐ Subscribe</button><button type="button" class="mm-btn secondary" data-s="code">🔑 I have an access code</button><button type="button" class="mm-btn secondary" data-s="signin">👤 Sign in</button><button type="button" class="mm-btn ghost" data-s="close">Keep sampling</button></div>'
    +'<div class="note">'+(window.MM_SUBSCRIBE_URL?'Subscription details open in a new tab.':window.MM_SUPPORT_EMAIL?'Subscribe opens an email to '+E(window.MM_SUPPORT_EMAIL)+'.':'Ask your school or program administrator about a subscription, or enter an access code.')+'</div></div>';
  el.classList.add('open');setTimeout(function(){var b=el.querySelector('[data-s="sub"]');if(b)try{b.focus({preventScroll:true});}catch(e){}},40);}
/* free edition (hosted, no access code yet): week 1 of every grade is open */
function free(el,what){var T=function(x){try{return window.MMI18N?MMI18N.t(x):x;}catch(e){return x;}};var staff=false;try{staff=A.roleKey()!=='student';}catch(e){}
  el.innerHTML='<div class="card"><div class="k">'+E(T('Money Matters · Free edition'))+'</div><h2>'+E(T(staff?'Unlock the full program':'Ask your teacher'))+'</h2>'+(what?'<div class="lockline">🔒 '+E(T('Locked'))+': <b>'+E(T(what))+'</b></div>':'')
    +(staff?'<p>'+E(T('Week 1 of every grade is free. A school access code unlocks the complete K–8 program on this device:'))+'</p><ul><li>'+E(T('Weeks 2 to 36 for every grade, with worksheets and quizzes'))+'</li><li>'+E(T('Section tests and certificates'))+'</li><li>'+E(T('Spanish and Portuguese lessons'))+'</li><li>'+E(T('1- to 5-day workshops'))+'</li><li>'+E(T('The full-year workbook and teacher’s guide'))+'</li></ul>'
      +'<div class="acts"><button type="button" class="mm-btn primary" data-s="code">🔑 '+E(T('Enter access code'))+'</button><button type="button" class="mm-btn secondary" data-s="sub">⭐ '+E(T('Get a subscription'))+'</button><button type="button" class="mm-btn ghost" data-s="close">'+E(T('Not now'))+'</button></div>'
      +'<div class="note">'+E(T('Your access code is checked online once, then the lessons stay available on this device.'))+'</div>'
     :'<p>'+E(T('Week 1 is open for every grade. Your teacher can unlock the rest of the year with a school access code.'))+'</p><div class="acts"><button type="button" class="mm-btn primary" data-s="close">'+E(T('OK'))+'</button></div>')
    +'</div>';}
function close(){var el=$('mm-subscribe');if(el)el.classList.remove('open');}
function goSubscribe(){if(window.MM_SUBSCRIBE_URL){try{window.open(window.MM_SUBSCRIBE_URL,'_blank','noopener');}catch(e){location.href=window.MM_SUBSCRIBE_URL;}return;}
  if(window.MM_SUPPORT_EMAIL){location.href='mailto:'+window.MM_SUPPORT_EMAIL+'?subject='+encodeURIComponent('Money Matters subscription');return;}
  U.toast('Ask your school or program administrator about a subscription, or enter an access code.',4500);}
function enterCode(){close();var go=function(c){c=String(c||'').trim();if(!c)return;
    if(!/^https?:$/.test(location.protocol)){U.toast('Access codes are checked online. Open Money Matters from its web address to use one.',4500);return;}
    fetch('/api/content',{headers:{Authorization:'Bearer '+c}}).then(function(r){if(!r.ok)throw 0;try{localStorage.setItem('mmAccess_v1',c);}catch(e){}clearSample();location.reload();}).catch(function(){U.toast('That access code is not valid, has expired, or could not be checked. Check it and your internet connection.',4500);});};
  try{mmInput('Access code','',{icon:'🔑',okLabel:'Unlock',subtext:'Enter the access code that came with your subscription.'}).then(go);}catch(e){go(prompt('Access code'));}}

/* ---------- start / end ---------- */
function start(r,g){r=r==='teacher'?'teacher':'student';if(D.GRADES.indexOf(g)<0)g='K';
  try{sessionStorage.setItem(KEY,JSON.stringify({role:r,grade:g,at:Date.now()}));}catch(e){U.toast('Sample mode needs browser storage to be enabled.',4000);return false;}
  cache=null;writeBox(freshBox(g,r));
  try{sessionStorage.setItem('mmRole',r);sessionStorage.setItem('mmLoginRole',r);}catch(e){}
  if(r==='student'){A.set({role:'student',name:'Sample Student',id:SID,sample:1});try{setTabActive(SID);}catch(e){}}
  else{A.set({role:'teacher',name:'Sample Teacher',id:'teacher',sample:1,scope:[g],acctRole:'teacher'});try{setTabActive(null);}catch(e){}}
  GATE.hide();
  try{var tr=$('tour');if(tr)tr.classList.remove('on');}catch(e){}
  try{closePanel(true);}catch(e){}
  try{setGrade(g);}catch(e){}
  try{applyRole();buildNav();}catch(e){}
  try{S.topbar();S.renderHome();}catch(e){}
  setTimeout(function(){try{currentIndex=0;openPanel('lessons');renderChips();loadLesson(0,true);}catch(e){}},90);
  U.toast('Sample mode · '+D.gradeLabel(g)+' as '+(r==='teacher'?'a teacher':'a student')+'. Lesson 1, Story Mode, and Games are open.',4500);
  return true;}
function clearSample(){try{sessionStorage.removeItem(KEY);sessionStorage.removeItem(BOX);}catch(e){}cache=null;scrub();}
function end(){var was=active();close();clearSample();
  A.clear();try{setTabActive(null);}catch(e){}
  try{closePanel(true);}catch(e){}try{applyRole();buildNav();}catch(e){}
  GATE.show({view:'signin',message:was?'Thanks for trying the sample. Sign in or create a profile to continue.':'',messageClass:'info'});
  try{S.topbar();}catch(e){}}

MM.sample={start:start,end:end,active:active,grade:grade,role:role,subscribe:subscribe,enterCode:enterCode};

/* Spanish / Portuguese for the sample surfaces */
try{var es=MM.i18n.dict.es,pt=MM.i18n.dict.pt;function add(en,s,p){es[en]=s;pt[en]=p;}
  add('Try a free sample','Prueba una muestra gratis','Experimente uma amostra grátis');add('Just looking?','¿Solo mirando?','Só olhando?');add('Sample as','Probar como','Testar como');add('Start the sample','Comenzar la muestra','Começar a amostra');
  add('Subscribe','Suscribirse','Assinar');add('Exit sample','Salir de la muestra','Sair da amostra');add('Keep sampling','Seguir probando','Continuar testando');add('I have an access code','Tengo un código de acceso','Tenho um código de acesso');add('Unlock the full program','Desbloquea el programa completo','Desbloqueie o programa completo');}catch(e){}

function quietTour(){if(!active())return;try{var tr=$('tour');if(tr)tr.classList.remove('on');}catch(e){}}
installStore();installLocks();quietTour();
document.addEventListener('DOMContentLoaded',function(){
  setTimeout(installLocks,3600);quietTour();setTimeout(quietTour,1000);
  /* after a reload inside the sample, restore the sampled grade once the app has booted */
  setTimeout(function(){if(!active())return;quietTour();try{setGrade(grade());applyRole();buildNav();S.topbar();}catch(e){}},1700);
});
try{if(typeof CHANGELOG!=='undefined')CHANGELOG.unshift({date:'October 2026',items:['Free sample from the sign-in screen: try one grade as a student or a teacher with no account. Lesson 1 (lesson, worksheet, quiz), Story Mode, and the Games are open.','Everything else — other weeks and grades, section tests, certificates, the assessment, and the consoles — shows a subscription prompt with Subscribe, access-code, and sign-in options.','The sample runs on a sandboxed roster kept in the tab, so real students, accounts, and progress stay private and unchanged.']});}catch(e){}
})();
