(function(){
'use strict';
var root=document.documentElement;
/* V19: staff can switch a quiz to "practice as a student" (nothing is saved); the next quiz shows the key again */
var keyOff=false,keyOffFor=null;
function isKey(){if(keyOff&&typeof quizQs!=='undefined'&&quizQs===keyOffFor)return false;keyOff=false;try{return loadRole()==='teacher';}catch(e){return false;}}
function practice(on){var f=document.getElementById('quizForm');if(!f)return;keyOff=on;keyOffFor=on?quizQs:null;
  if(on){f.querySelectorAll('.mm-key-item').forEach(function(x){x.classList.remove('mm-key-item');});f.querySelectorAll('.mm-key-correct').forEach(function(x){x.classList.remove('mm-key-correct');});f.querySelectorAll('.mm-key-note').forEach(function(x){x.remove();});
    root.classList.remove('mm-key-view');var sb=document.querySelector('#quizButtons [onclick^="submitQuiz"]');if(sb)sb.style.display='';
    var b=f.querySelector('.mm-key-banner');if(b){b.innerHTML='';b.appendChild(document.createTextNode('Practice mode: you are answering as a student would. Nothing is saved. '));var k=document.createElement('button');k.type='button';k.className='mm-key-toggle';k.textContent='Show the answer key';k.onclick=function(){practice(false);};b.appendChild(k);try{f.querySelector('.mc-opt').focus();}catch(e){}}}
  else{var b2=f.querySelector('.mm-key-banner');if(b2)b2.remove();try{renderQuiz();}catch(e){}sync();}}
window.mmQuizPractice=practice;
/* practice answers never reach a student's record or the class's question statistics */
(function(){function wrapSubmit(){if(typeof submitQuiz!=='function'||submitQuiz.__practice)return;var o=submitQuiz;var w=function(){if(!(keyOff&&quizQs===keyOffFor))return o.apply(this,arguments);
  var rs=window.recordScore,ss=window.saveStore,ts=window.touchStreak;try{window.recordScore=function(){};window.saveStore=function(){};window.touchStreak=function(){};return o.apply(this,arguments);}finally{window.recordScore=rs;window.saveStore=ss;window.touchStreak=ts;}};w.__practice=true;window.submitQuiz=w;try{submitQuiz=w;}catch(e){}}
  wrapSubmit();document.addEventListener('DOMContentLoaded',function(){setTimeout(wrapSubmit,4000);});})();
function esc2(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function banner(txt){var b=document.createElement('div');b.className='mm-key-banner';b.textContent=txt;return b;}
function quiz(){var f=document.getElementById('quizForm');
 if(!f||!isKey()||f.querySelector('.mm-key-banner')||!f.querySelector('.q-item'))return;
 if(typeof quizQs==='undefined'||!quizQs||!quizQs.length)return;
 var bn=banner('Teacher / Parent view: questions and correct answers are highlighted. Students do not see this. ');var tb=document.createElement('button');tb.type='button';tb.className='mm-key-toggle';tb.textContent='Try this quiz as a student';tb.onclick=function(){practice(true);};bn.appendChild(tb);f.insertBefore(bn,f.firstChild);
 quizQs.forEach(function(q,i){var it=document.getElementById('qi-'+i);if(!it)return;it.classList.add('mm-key-item');
  var o=document.getElementById('qo-'+i+'-'+q.answer);if(o)o.classList.add('mm-key-correct');
  if(q.explain){var n=document.createElement('div');n.className='mm-key-note';n.textContent='Why: '+q.explain;it.appendChild(n);}});
 var sb=document.querySelector('#quizButtons [onclick^="submitQuiz"]');if(sb)sb.style.display='none';}
function ws(){var a=document.getElementById('printArea');
 if(!a||!isKey()||typeof currentDoc==='undefined'||currentDoc!=='worksheet'||a.querySelector('.mm-key-banner'))return;
 var l=L();if(!l||!l.worksheet||!l.worksheet.items)return;
 var d=a.querySelector('.ws-directions');if(d&&d.parentNode)d.parentNode.insertBefore(banner('Teacher / Parent view: answers are shown under each question.'),d);
 var items=a.querySelectorAll('.ws-item:not(.challenge-item)');
 items.forEach(function(el,i){var it=l.worksheet.items[i];if(!it||!it.answer)return;el.classList.add('mm-key-q');
  var x=document.createElement('div');x.className='mm-key-ans';x.innerHTML='<b>\u2713 Answer:</b> '+esc2(it.answer);el.appendChild(x);});}
function sync(){root.classList.toggle('mm-key-view',isKey());quiz();ws();}
function init(){
 [['quizForm'],['printArea']].forEach(function(p){var el=document.getElementById(p[0]);if(el){try{new MutationObserver(sync).observe(el,{childList:true});}catch(e){}}});
 sync();setInterval(sync,1000);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
