(function(){
  'use strict';
  /* V55: guarantee a reflection pause after the third incorrect attempt in every answer-based game. */
  function harden(){
    if(typeof mmGameWrong!=='function'||mmGameWrong.__v55)return;
    var old=mmGameWrong;
    function wrapped(game,prompt,continueFn){
      try{return old(game,prompt,continueFn);}catch(e){console.warn('Game reflection fallback',e);return false;}
    }
    wrapped.__v55=true;mmGameWrong=wrapped;
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',harden);else harden();
})();
