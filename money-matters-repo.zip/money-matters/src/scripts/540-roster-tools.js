(function(){
'use strict';
var CH='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',GR=['K','1','2','3','4','5','6','7','8'];
function $(i){return document.getElementById(i);}
function esc(x){return String(x==null?'':x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function say(m,ms){try{infoToast(m,ms||4500);}catch(e){alert(m);}}
function A(){var m=window.MM91||{};return m.accounts||m.acc||null;}
function DD(){return window.MM91&&MM91.data;}
function isAdmin(){try{return MM91.auth.isAdmin();}catch(e){return false;}}
function jget(k,d){try{return JSON.parse(localStorage.getItem(k)||'null')||d;}catch(e){return d;}}
function jset(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
var st=document.createElement('style');
st.textContent='.mmrt-ov{position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:14px}.mmrt-box{background:#fffaf0;color:#2b1d0e;border-radius:16px;max-width:520px;width:100%;max-height:88vh;overflow:auto;padding:18px;font:15px/1.45 system-ui,sans-serif;box-shadow:0 12px 40px rgba(0,0,0,.5)}.mmrt-box h2{margin:0 0 8px;font-size:20px}.mmrt-btns{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.mmrt-btns button{flex:1;padding:10px 12px;border-radius:10px;border:1px solid #2e7d57;background:#fff;color:#14472d;font-weight:700;font-size:15px}.mmrt-btns button.p{background:#2e7d57;color:#fff;border:0}.mmrt-box label{display:block;font-weight:600;font-size:13px;margin-top:8px}.mmrt-box input[type=text],.mmrt-box select{width:100%;padding:10px;border-radius:10px;border:1px solid #cdb98f;font-size:16px;margin:4px 0 6px;background:#fff;color:#2b1d0e;box-sizing:border-box}.mmrt-box table{border-collapse:collapse;width:100%;font-size:13px;margin:6px 0}.mmrt-box td,.mmrt-box th{padding:4px 6px;border-top:1px solid #e0d2b8;text-align:left}.mmrt-warn{background:#fff3cd;border:1px solid #c4912e;border-radius:10px;padding:8px 10px;margin:10px 0;font-size:13px}.mmrt-code{font:700 22px/1.2 ui-monospace,monospace;letter-spacing:.12em}.mmrt-row{border-top:1px solid #e0d2b8;padding:8px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap}.mmrt-row .n{flex:1 1 140px;font-weight:700}.mmrt-row button{padding:6px 10px;border-radius:8px;border:1px solid #2e7d57;background:#fff;color:#14472d;font-weight:700;font-size:13px}.mmrt-chk{display:flex!important;gap:8px;align-items:flex-start;font-weight:600}';
document.head.appendChild(st);
function dlg(title,body,btns){var o=document.createElement('div');o.className='mmrt-ov';
 o.innerHTML='<div class="mmrt-box" role="dialog" aria-modal="true"><h2>'+title+'</h2><div class="mmrt-body">'+body+'</div><div class="mmrt-btns">'+btns.map(function(b){return '<button type="button" data-id="'+b.id+'"'+(b.primary?' class="p"':'')+'>'+b.label+'</button>';}).join('')+'</div></div>';
 document.body.appendChild(o);var res,p=new Promise(function(r){res=r;});
 o.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-id]');if(b)res(b.getAttribute('data-id'));});
 var f=o.querySelector('input,select,button.p,button');if(f)try{f.focus();}catch(e){}
 return {el:o,promise:p,close:function(){o.remove();}};}
window.mmDlg=dlg;
function refreshAll(){try{refreshStudentUI();buildGradeNav();}catch(e){}try{var ad=MM91.admin;if(openPanelId==='admin'){ad.scheduleRender?ad.scheduleRender():ad.render();}}catch(e){}}
/* ---------- undo import ---------- */
async function undoImport(){var li=jget('mmLastImport',null);if(!li){say('There is no import to undo.');return;}
 var d=dlg('\u21A9 Undo last import','<p>This removes the <b>'+(li.students||[]).length+'</b> students and <b>'+(li.accounts||[]).length+'</b> teacher profiles that import created, and restores teacher assignments.</p><div class="mmrt-warn">Anything you changed on those students since the import is lost.</div>',[{id:'x',label:'Keep them'},{id:'go',label:'Undo import',primary:true}]);
 var id=await d.promise;d.close();if(id!=='go')return;
 var u=window.mmUndoLastImport();say(u?('\u21A9 Removed '+u.students+' students and '+u.teachers+' teacher profiles'):'Nothing to undo.',5000);refreshAll();}
/* ---------- year-end rollover ---------- */
function nextG(g){return g==='K'?'1':g==='8'?null:String(parseInt(g,10)+1);}
async function rollover(){
 var D=DD(),list=D.list();if(!list.length){say('There are no students to roll over.');return;}
 var cnt={};list.forEach(function(s){var g=s.grade||'K';cnt[g]=(cnt[g]||0)+1;});
 var rows=GR.filter(function(g){return cnt[g];}).map(function(g){return '<tr><td>'+(g==='K'?'Kindergarten':'Grade '+g)+'</td><td>'+cnt[g]+'</td><td>'+(g==='8'?'Archived (finished K\u20138)':'Grade '+nextG(g))+'</td></tr>';}).join('');
 var body='<p>Moves every student up one grade. Grade 8 students are archived, not deleted. Progress is kept.</p><table><tr><th>Now</th><th>Students</th><th>Becomes</th></tr>'+rows+'</table><label class="mmrt-chk"><input type="checkbox" id="rt-clear" checked> Clear teacher assignments so classes can be reassigned</label><label class="mmrt-chk"><input type="checkbox" id="rt-bk" checked> Download a backup first</label><div class="mmrt-warn">You can undo the rollover from Roster tools until you run another one.</div>';
 var d=dlg('\uD83D\uDCC5 Year-end rollover',body,[{id:'x',label:'Cancel'},{id:'go',label:'Roll over '+list.length+' students',primary:true}]);
 var id=await d.promise,clear=d.el.querySelector('#rt-clear').checked,bk=d.el.querySelector('#rt-bk').checked;d.close();if(id!=='go')return;
 if(bk){try{backupData();}catch(e){}}
 var s=loadStore(),ac=A(),scopes={};ac.list().forEach(function(a){scopes[a.u]=a.scope;});
 jset('mmLastRollover',{t:Date.now(),list:JSON.parse(JSON.stringify(s.list)),archived:(s.archived||[]).length,teachers:(s.teachers||[]).slice(),scopes:scopes});
 var now=new Date(),yr=now.getFullYear()-(now.getMonth()<6?1:0),label=yr+'\u2013'+String(yr+1).slice(2),moved=0,arch=0;
 s.archived=s.archived||[];
 Object.keys(s.list).forEach(function(k){var x=s.list[k],g=x.grade||'K';
  if(g==='8'){x.archivedOn=now.toISOString();x.archivedYear=label;s.archived.push(x);delete s.list[k];arch++;}
  else{x.grade=nextG(g);moved++;if(clear)delete x.teacher;}});
 saveStore(s);ac.ensureStudents();
 ac.list().forEach(function(a){
  if(a.role==='student'){var x=s.list[a.studentId];if(x)ac.update(a.u,function(z){z.scope=x.grade||'K';});}
  else if(Array.isArray(a.scope)){var ns=a.scope.map(nextG).filter(Boolean).filter(function(v,i,r){return r.indexOf(v)===i;});ac.update(a.u,function(z){z.scope=ns.length?ns:'all';});}});
 refreshAll();say('\uD83D\uDCC5 '+moved+' students moved up, '+arch+' archived ('+label+')',6000);}
function unroll(){var sn=jget('mmLastRollover',null);if(!sn){say('There is no rollover to undo.');return;}
 var s=loadStore();s.list=sn.list;s.archived=(s.archived||[]).slice(0,sn.archived);s.teachers=sn.teachers;saveStore(s);
 var ac=A();ac.ensureStudents();
 ac.list().forEach(function(a){if(a.role==='student'){var x=s.list[a.studentId];if(x)ac.update(a.u,function(z){z.scope=x.grade||'K';});}else if(sn.scopes&&sn.scopes[a.u]!==undefined)ac.update(a.u,function(z){z.scope=sn.scopes[a.u];});});
 try{localStorage.removeItem('mmLastRollover');}catch(e){}refreshAll();say('Rollover undone.');}
/* ---------- class join codes ---------- */
function codes(){return jget('mmClassCodes',{});}
function newCode(o){var c;do{c='';for(var i=0;i<6;i++)c+=CH[Math.floor(Math.random()*CH.length)];}while(Object.keys(o).some(function(k){return o[k].code===c;}));return c;}
function myTeachers(){if(isAdmin()){try{return DD().teachers();}catch(e){return [];}}try{var n=MM91.auth.displayName();return n?[n]:[];}catch(e){return [];}}
function codeRows(){var o=codes(),ts=myTeachers();if(!ts.length)return '<p>No teachers yet. Import a roster with a Teacher column or add teachers under Users.</p>';
 return ts.map(function(t,i){var r=o[t];return '<div class="mmrt-row"><span class="n">'+esc(t)+'</span>'+(r?'<span class="mmrt-code">'+esc(r.code)+'</span><button data-ca="tog" data-i="'+i+'">'+(r.open?'Open':'Closed')+'</button><button data-ca="new" data-i="'+i+'">New</button><button data-ca="copy" data-i="'+i+'">Copy</button>':'<button data-ca="new" data-i="'+i+'">Create code</button>')+'</div>';}).join('');}
function codesDialog(){
 var d=dlg('\uD83D\uDD11 Class join codes','<p style="margin:0 0 6px">Students tap <b>Join a class</b> on the sign-in screen and enter the code. Share it only with that class. Close it when everyone has joined.</p><div id="mmrt-codes">'+codeRows()+'</div><div class="mmrt-warn">Codes work on this device only, because all data stays on this device.</div>',[{id:'ok',label:'Done',primary:true}]);
 d.promise.then(d.close);
 d.el.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-ca]');if(!b)return;
  var o=codes(),ts=myTeachers(),t=ts[+b.getAttribute('data-i')],a=b.getAttribute('data-ca');if(!t)return;
  if(a==='new'){o[t]={code:newCode(o),open:true,joins:0};}
  else if(a==='tog'&&o[t]){o[t].open=!o[t].open;}
  else if(a==='copy'&&o[t]){try{navigator.clipboard.writeText(o[t].code);say('Code copied.');}catch(x){say('Code: '+o[t].code);}return;}
  jset('mmClassCodes',o);d.el.querySelector('#mmrt-codes').innerHTML=codeRows();});}
var bad=0,until=0;
function findCode(c){c=String(c||'').toUpperCase().replace(/[^A-Z0-9]/g,'');var o=codes(),k=Object.keys(o);for(var i=0;i<k.length;i++)if(o[k[i]].code===c)return {t:k[i],o:o,r:o[k[i]]};return null;}
function joinDialog(){
 var opts=GR.map(function(g){return '<option value="'+g+'">'+(g==='K'?'Kindergarten':'Grade '+g)+'</option>';}).join('');
 var d=dlg('\uD83C\uDF92 Join a class','<label for="jc-code">Class code from your teacher</label><input type="text" id="jc-code" maxlength="8" autocapitalize="characters" autocomplete="off"><label for="jc-name">Your name</label><input type="text" id="jc-name" maxlength="40" autocomplete="off" placeholder="First and last name"><label for="jc-grade">Grade</label><select id="jc-grade">'+opts+'</select><div class="mmrt-warn" id="jc-msg" style="display:none"></div>',[{id:'x',label:'Cancel'},{id:'join',label:'Join class',primary:true}]);
 var el=d.el;function msg(m){var b=el.querySelector('#jc-msg');b.textContent=m;b.style.display='block';}
 d.promise.then(function(id){if(id==='x')d.close();});
 el.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-id="join"]');if(!b)return;
  if(Date.now()<until){msg('Too many wrong codes. Please wait a minute and try again.');return;}
  var f=findCode(el.querySelector('#jc-code').value);
  if(!f||!f.r.open){bad++;if(bad>=5){until=Date.now()+60000;bad=0;}msg('That class code is not valid, or joining is closed. Ask your teacher.');return;}
  var name=el.querySelector('#jc-name').value.replace(/[^\p{L}\p{N} .'\-]/gu,'').replace(/\s+/g,' ').trim().slice(0,40),g=el.querySelector('#jc-grade').value;
  if(name.length<2){msg('Please enter your name.');return;}
  var D=DD();if(D.list().some(function(s){return s.name.toLowerCase()===name.toLowerCase()&&(s.grade||'K')===g;})){msg('A student named '+name+' is already in that grade. Ask your teacher for your sign-in code.');return;}
  var rec=D.createStudent(name,g,f.t);if(!rec){msg('Could not create your profile. Try again.');return;}
  var ac=A(),acct=null;try{ac.ensureStudents();acct=ac.forStudent(rec.id);}catch(x){}
  f.r.joins=(f.r.joins||0)+1;jset('mmClassCodes',f.o);refreshAll();
  el.querySelector('.mmrt-body').innerHTML='<p style="font-size:17px">\uD83C\uDF89 Welcome, <b>'+esc(name)+'</b>! You joined '+esc(f.t)+'\u2019s class.</p><p>Your sign-in code:</p><div class="mmrt-code">'+esc(rec.verifyCode||'')+'</div>'+(acct?'<p style="margin-top:8px">Username: <b>'+esc(acct.u)+'</b></p>':'')+'<div class="mmrt-warn">Write these down or take a photo. You will need them to sign in.</div>';
  el.querySelector('.mmrt-btns').innerHTML='<button type="button" class="p" data-id="done">Done</button>';
  el.querySelector('button[data-id="done"]').onclick=function(){d.close();};});}
/* ---------- end a leftover free-sample session once a real account is signed in ---------- */
function fixStaleSample(){
 try{if(!sessionStorage.getItem('mmSample_v1'))return false;
  var a=MM91.auth.get();if(!a||a.sample)return false;
  sessionStorage.removeItem('mmSample_v1');sessionStorage.removeItem('mmSampleStore_v1');
  refreshAll();try{MM91.shell.topbar();}catch(e){}return true;}catch(e){return false;}}
window.mmFixStaleSample=fixStaleSample;
/* ---------- remove sample records that leaked into the real student list (they block every save) ---------- */
var SIDS=['sample_student','sample_student_2','sample_student_3'];
function purgeSample(){
 try{if(window.MM91&&MM91.sample&&MM91.sample.active())return false;
  var hit=false,raw=localStorage.getItem('mmStudents_v2');
  if(raw){var st=JSON.parse(raw);
   Object.keys(st.list||{}).forEach(function(id){var x=st.list[id];if(SIDS.indexOf(id)>-1||(x&&x.sample)){delete st.list[id];hit=true;}});
   if(st.active&&SIDS.indexOf(st.active)>-1){st.active=null;hit=true;}
   if(Array.isArray(st.teachers)){var used={};Object.keys(st.list||{}).forEach(function(id){if(st.list[id]&&st.list[id].teacher)used[st.list[id].teacher]=1;});
    var nt=st.teachers.filter(function(n){return n!=='Sample Class'||used[n];});if(nt.length!==st.teachers.length){st.teachers=nt;hit=true;}}
   if(hit)localStorage.setItem('mmStudents_v2',JSON.stringify(st));}
  var ac=A();if(ac&&ac.list){ac.list().forEach(function(a){if(a.role==='student'&&SIDS.indexOf(a.studentId)>-1){try{ac.remove(a.u);hit=true;}catch(e){}}});}
  if(hit)refreshAll();return hit;}catch(e){return false;}}
window.mmPurgeSample=purgeSample;
/* ---------- School tab: every teacher, staff member and student ---------- */
function avatar(n){return '<span style="width:38px;height:38px;border-radius:50%;background:#2e7d57;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:700;flex:none">'+esc(String(n||'?').trim().charAt(0).toUpperCase())+'</span>';}
function vSchool(){
 var D=DD(),ac=A(),me=(MM91.auth.get()||{}).u,list=D.list().slice().sort(function(a,b){return a.name.localeCompare(b.name);}),
  staff=ac.list().filter(function(a){return a.role!=='student';}),have={};
 staff.forEach(function(a){have[String(a.name||'').toLowerCase()]=1;});
 var bare=D.teachers().filter(function(n){return !have[String(n).toLowerCase()];});
 var cnt=function(n){return list.filter(function(s){return s.teacher===n;}).length;};
 function row(q,r,inner){return '<div class="mm-card mmsc-row" data-q="'+esc(q.toLowerCase())+'" data-r="'+r+'" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:8px;padding:10px 12px">'+inner+'</div>';}
 var h='<div class="mm-admin-head"><div><h2>School</h2><p>Every teacher, staff member and student on this device. Open any profile, or sign in as that person.</p></div></div>';
 h+='<div class="mm-row" style="gap:8px;flex-wrap:wrap;margin-bottom:12px"><button type="button" class="mm-btn sm secondary" data-sh="print">\uD83D\uDDA8 Print sign-in cards</button><button type="button" class="mm-btn sm secondary" data-sh="bulk">\uD83E\uDDF0 Bulk tools</button><button type="button" class="mm-btn sm secondary" data-sh="archive">\uD83D\uDDC4\uFE0F Archive</button></div>';
 h+='<div class="mm-card" style="margin-bottom:12px"><div class="mm-row" style="gap:8px;flex-wrap:wrap"><input class="mm-input" id="mmsc-q" placeholder="Search people" style="flex:1 1 180px"><select class="mm-select" id="mmsc-r" aria-label="Show"><option value="">Everyone</option><option value="staff">Teachers &amp; staff</option><option value="student">Students</option></select></div></div>';
 h+='<div class="mm-label" style="margin:6px 0">Teachers &amp; staff ('+(staff.length+bare.length)+')</div>';
 staff.forEach(function(a){h+=row(a.name+' '+a.u+' '+a.role,'staff',avatar(a.name)+'<div style="flex:1 1 150px"><b>'+esc(a.name)+'</b><div class="mm-muted" style="font-size:13px">'+esc((ac.ROLES&&ac.ROLES[a.role])||a.role)+' \u00B7 '+esc(a.u)+(cnt(a.name)?' \u00B7 '+cnt(a.name)+' students':'')+(a.locked?' \u00B7 locked':'')+'</div></div>'+(a.u===me?'<span class="mm-chip">You</span>':'<button type="button" class="mm-btn sm primary" data-sw="'+esc(a.u)+'">Open as</button><button type="button" class="mm-btn sm secondary" data-rs="'+esc(a.u)+'">Reset password</button>')+'<button type="button" class="mm-btn sm secondary" data-act="tab" data-id="users">Manage</button>');});
 bare.forEach(function(n){h+=row(n+' teacher','staff',avatar(n)+'<div style="flex:1 1 150px"><b>'+esc(n)+'</b><div class="mm-muted" style="font-size:13px">No sign-in profile yet'+(cnt(n)?' \u00B7 '+cnt(n)+' students':'')+'</div></div><button type="button" class="mm-btn sm primary" data-mk="'+esc(n)+'">Create profile</button>');});
 if(!staff.length&&!bare.length)h+='<div class="mm-empty"><b>No teachers yet</b>Import a roster with a Teacher column, or add teachers under Users.</div>';
 h+='<div class="mm-label" style="margin:14px 0 6px">Students ('+list.length+')</div>';
 list.forEach(function(s){var code='',sa=null;try{code=D.codeOf(s);}catch(e){}try{sa=ac.forStudent(s.id);}catch(e){}
  h+=row(s.name+' '+(s.teacher||'')+' grade '+(s.grade||'K'),'student',avatar(s.name)+'<div style="flex:1 1 150px"><b>'+esc(s.name)+'</b><div class="mm-muted" style="font-size:13px">'+esc(D.gradeShort?D.gradeShort(s.grade||'K'):s.grade)+(s.teacher?' \u00B7 '+esc(s.teacher):'')+(code?' \u00B7 code '+esc(code):'')+'</div></div><button type="button" class="mm-btn sm primary" data-ss="'+esc(s.id)+'">Open as</button><button type="button" class="mm-btn sm secondary" data-sp="'+esc(s.id)+'">Profile</button>'+(sa?'<button type="button" class="mm-btn sm secondary" data-rs="'+esc(sa.u)+'">New code</button>':''));});
 if(!list.length)h+='<div class="mm-empty"><b>No students yet</b>Import a roster from Data &amp; Backup, or add users.</div>';
 return h;}
function installSchoolTab(){var ad=window.MM91&&MM91.admin;if(!ad||!ad.TABS||!ad.VIEWS||ad.VIEWS.school)return;
 var T=ad.TABS,i=-1;for(var k=0;k<T.length;k++)if(T[k].id==='teachers')i=k;
 T.splice(i+1,0,{id:'school',ic:'\uD83C\uDFDB\uFE0F',l:'School',adminOnly:true,cnt:function(){try{return DD().list().length+A().list().filter(function(a){return a.role!=='student';}).length;}catch(e){return null;}}});
 ad.VIEWS.school=vSchool;}
async function mkTeacher(name){var ac=A(),gs={};DD().list().forEach(function(s){if(s.teacher===name)gs[s.grade||'K']=1;});
 var g=Object.keys(gs).sort(function(a,b){return (a==='K'?0:+a)-(b==='K'?0:+b);});
 var r=await ac.add({name:name,role:'teacher',scope:g.length?g:'all',mustChange:true,by:'school tab'});
 if(r&&r.account){var d=dlg('Teacher profile created','<p><b>'+esc(name)+'</b></p><p>Username: <b>'+esc(r.account.u)+'</b><br>Temporary password: <code>'+esc(r.password)+'</code></p><div class="mmrt-warn">Shown only now. They must change it at first sign-in.</div>',[{id:'ok',label:'Done',primary:true}]);d.promise.then(d.close);refreshAll();}
 else say((r&&r.error)||'Could not create that profile.');}
document.addEventListener('input',function(e){if(e.target&&(e.target.id==='mmsc-q'||e.target.id==='mmsc-r'))filterSchool();},true);
document.addEventListener('change',function(e){if(e.target&&e.target.id==='mmsc-r')filterSchool();},true);
function filterSchool(){var q=(($('mmsc-q')||{}).value||'').toLowerCase().trim(),r=($('mmsc-r')||{}).value||'';
 [].forEach.call(document.querySelectorAll('.mmsc-row'),function(x){var ok=(!q||x.getAttribute('data-q').indexOf(q)>-1)&&(!r||x.getAttribute('data-r')===r);x.style.display=ok?'':'none';});}
/* ---------- Add user chooser (create a user or import a roster) ---------- */
var ROSTER_ACCEPT='.csv,.txt,.tsv,.json,.docx,text/csv,text/plain,application/json,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
function pickRoster(){var i=document.createElement('input');i.type='file';i.accept=ROSTER_ACCEPT;i.style.display='none';document.body.appendChild(i);
 i.onchange=function(){Promise.resolve(window.importRosterFile({target:i})).then(function(){i.remove();});};i.click();}
async function addUserChooser(){
 var d=dlg('\u2795 Add user','<p style="margin:0 0 6px">What would you like to do?</p><div class="mmrt-warn" style="margin-top:6px">Import accepts CSV, Word (.docx), JSON or plain text. Students and teachers are both created from the file.</div>',
  [{id:'x',label:'Cancel'},{id:'tpl',label:'\u2B07 Template'},{id:'imp',label:'\uD83D\uDCE5 Import a roster'},{id:'new',label:'\u2795 Create a new user',primary:true}]);
 var id=await d.promise;d.close();
 if(id==='new'){try{MM91.admin.open('users',{add:true});}catch(e){}setTimeout(function(){var f=document.querySelector('#adminMain [id^="nu-"]');if(f){try{f.scrollIntoView({block:'center'});f.focus();}catch(e){}}},350);}
 else if(id==='imp')pickRoster();
 else if(id==='tpl'){try{downloadRosterTemplate();}catch(e){say('Template is in Data & Backup.');}}}
/* ---------- Teachers tab: filters, sorting, sign-in buttons ---------- */
function enhanceTeachers(){
 var main=$('adminMain'),st=MM91.admin.state||{};if(!main||st.tab!=='teachers'||st.view||main.querySelector('#mmt-bar'))return;
 var grid=main.querySelector('.mm-grid.auto');if(!grid)return;
 var cards=[].slice.call(grid.querySelectorAll('[data-act="teacher"]'));if(!cards.length)return;
 var D=DD(),ac=A(),accs={},gset={};ac.list().forEach(function(a){if(a.role!=='student')accs[String(a.name||'').toLowerCase()]=a;});
 var all=D.list();
 cards.forEach(function(c,ix){var n=c.getAttribute('data-v'),ss=all.filter(function(s){return s.teacher===n;}),gs=[];
  ss.forEach(function(s){var g=s.grade||'K';if(gs.indexOf(g)<0)gs.push(g);gset[g]=1;});
  var cs={};try{cs=D.classStats(ss)||{};}catch(e){}var bs=cs.byStatus||{},attn=(bs.support||0)+(bs.inactive||0),a=accs[String(n).toLowerCase()];
  var w=document.createElement('div');w.className='mmt-wrap';w.style.cssText='display:flex;flex-direction:column;gap:6px;min-width:0';
  w.setAttribute('data-n',String(n).toLowerCase());w.setAttribute('data-cnt',ss.length);w.setAttribute('data-gr',','+gs.join(',')+',');w.setAttribute('data-attn',attn);w.setAttribute('data-acct',a?(a.locked?'locked':'yes'):'no');w.setAttribute('data-ix',ix);
  w.setAttribute('data-csv',[n,(a&&((ac.ROLES&&ac.ROLES[a.role])||a.role))||'Teacher',ss.length,gs.join(' '),a?a.u:'',a?(a.locked?'Locked':'Has sign-in'):'No sign-in'].map(function(x){return '"'+String(x).replace(/"/g,'""')+'"';}).join(','));
  c.parentNode.insertBefore(w,c);w.appendChild(c);c.style.flex='1';
  var r=document.createElement('div');r.style.cssText='display:flex;gap:8px;flex-wrap:wrap;align-items:center';
  r.innerHTML=a?'<button type="button" class="mm-btn sm primary" data-sw="'+esc(a.u)+'">\uD83D\uDD11 Sign in as</button>'+(a.locked?'<span class="mm-chip">Locked</span>':''):'<button type="button" class="mm-btn sm primary" data-mk="'+esc(n)+'">\uFF0B Create sign-in</button>';
  w.appendChild(r);});
 var gs=Object.keys(gset).sort(function(a,b){return (a==='K'?0:+a)-(b==='K'?0:+b);});
 var bar=document.createElement('div');bar.id='mmt-bar';bar.className='mm-card';bar.style.marginBottom='12px';
 bar.innerHTML='<div class="mm-grid c4" style="gap:8px"><div class="mm-field"><label for="mmt-q">Search</label><input class="mm-input" id="mmt-q" placeholder="Teacher name"></div>'
  +'<div class="mm-field"><label for="mmt-g">Grade taught</label><select class="mm-select" id="mmt-g"><option value="">All grades</option>'+gs.map(function(g){return '<option value="'+g+'">'+(g==='K'?'Kindergarten':'Grade '+g)+'</option>';}).join('')+'</select></div>'
  +'<div class="mm-field"><label for="mmt-s">Status</label><select class="mm-select" id="mmt-s"><option value="">All teachers</option><option value="yes">Has sign-in</option><option value="no">No sign-in yet</option><option value="locked">Locked</option><option value="attn">Needs attention</option><option value="empty">No students</option></select></div>'
  +'<div class="mm-field"><label for="mmt-o">Sort by</label><select class="mm-select" id="mmt-o"><option value="az">Name A\u2013Z</option><option value="za">Name Z\u2013A</option><option value="most">Most students</option><option value="least">Fewest students</option><option value="attn">Needs attention first</option></select></div></div>'
  +'<div class="mm-row" style="margin-top:8px;gap:8px;align-items:center;flex-wrap:wrap"><span id="mmt-count" class="mm-muted"></span><span class="spacer" style="flex:1"></span><button type="button" class="mm-btn sm ghost" id="mmt-reset">Reset</button><button type="button" class="mm-btn sm secondary" id="mmt-csv">\u2B07 Export CSV</button></div>';
 grid.parentNode.insertBefore(bar,grid);applyTeachers();}
function applyTeachers(){var q=(($('mmt-q')||{}).value||'').toLowerCase().trim(),g=($('mmt-g')||{}).value||'',s=($('mmt-s')||{}).value||'',o=($('mmt-o')||{}).value||'az';
 var ws=[].slice.call(document.querySelectorAll('.mmt-wrap')),shown=0;
 var key={az:function(w){return w.getAttribute('data-n');},za:function(w){return w.getAttribute('data-n');}};
 var sorted=ws.slice().sort(function(a,b){var an=a.getAttribute('data-n'),bn=b.getAttribute('data-n'),ac=+a.getAttribute('data-cnt'),bc=+b.getAttribute('data-cnt'),aa=+a.getAttribute('data-attn'),ba=+b.getAttribute('data-attn');
  if(o==='za')return bn<an?-1:bn>an?1:0;if(o==='most')return bc-ac||(an<bn?-1:1);if(o==='least')return ac-bc||(an<bn?-1:1);if(o==='attn')return ba-aa||(an<bn?-1:1);return an<bn?-1:an>bn?1:0;});
 sorted.forEach(function(w,i){w.style.order=i;});
 ws.forEach(function(w){var ok=(!q||w.getAttribute('data-n').indexOf(q)>-1)&&(!g||w.getAttribute('data-gr').indexOf(','+g+',')>-1);
  if(ok&&s){var ac=w.getAttribute('data-acct');if(s==='yes')ok=ac==='yes';else if(s==='no')ok=ac==='no';else if(s==='locked')ok=ac==='locked';else if(s==='attn')ok=+w.getAttribute('data-attn')>0;else if(s==='empty')ok=+w.getAttribute('data-cnt')===0;}
  w.style.display=ok?'':'none';if(ok)shown++;});
 var c=$('mmt-count');if(c)c.textContent='Showing '+shown+' of '+ws.length+' teachers';}
document.addEventListener('input',function(e){if(e.target&&e.target.id==='mmt-q')applyTeachers();},true);
document.addEventListener('change',function(e){if(e.target&&/^mmt-[gso]$/.test(e.target.id||''))applyTeachers();},true);
/* ---------- Teacher profile: sign in as ---------- */
function enhanceTeacherProfile(){var st=MM91.admin.state||{};if(st.tab!=='teachers'||st.view!=='teacher')return;
 var acts=document.querySelector('#adminMain .mm-profile-head .acts');if(!acts||acts.querySelector('[data-tsi]'))return;
 var n=st.tname,a=null;A().list().forEach(function(x){if(x.role!=='student'&&String(x.name||'').toLowerCase()===String(n||'').toLowerCase())a=x;});
 var b=document.createElement('button');b.type='button';b.className='mm-btn primary';b.setAttribute('data-tsi','1');
 if(a){b.setAttribute('data-sw',a.u);b.textContent='\uD83D\uDD11 Sign in as teacher';}else{b.setAttribute('data-mk',n);b.textContent='\uFF0B Create sign-in profile';}
 acts.insertBefore(b,acts.firstChild);}
/* ---------- Professional home for staff (replaces the student classroom scene) ---------- */
var shst=document.createElement('style');
shst.textContent='#mm-staff-home{position:fixed;left:0;right:0;z-index:12;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:16px 14px 28px;box-sizing:border-box;display:none}#mm-staff-home.on{display:block}html.mm-staff-home-on .room{visibility:hidden}.mmsh-wrap{max-width:1100px;margin:0 auto}.mmsh-head{margin-bottom:6px}.mmsh-head h1{margin:0;font:700 25px/1.2 Georgia,serif}.mmsh-sub{opacity:.75;font-size:14px;margin-top:2px}.mmsh-sec{font-weight:800;font-size:12px;letter-spacing:.1em;text-transform:uppercase;opacity:.7;margin:20px 0 8px}.mmsh-grid{display:grid;gap:12px;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:1fr}@media(min-width:760px){.mmsh-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}.mmsh-tile{display:flex;flex-direction:column;gap:4px;min-height:196px;padding:14px;box-sizing:border-box;margin:0}.mmsh-k{font-weight:700;font-size:12px;letter-spacing:.06em;text-transform:uppercase;opacity:.75}.mmsh-big{font:700 32px/1.1 Georgia,serif}.mmsh-v{font-weight:700;font-size:16px;line-height:1.25}.mmsh-s{font-size:13px;opacity:.75;flex:1}.mmsh-a{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.mmsh-act{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:92px;border-radius:14px;cursor:pointer;font:700 14px/1.2 system-ui,sans-serif;text-align:center;padding:10px;border:1px solid var(--mm-line,rgba(0,0,0,.18));background:var(--mm-paper,#fff);color:inherit}.mmsh-act .ic{font-size:26px}';
document.head.appendChild(shst);
var shEl=null,shSig='';
function staffNow(){try{var a=MM91.auth.get();return !!(a&&!a.sample&&MM91.auth.roleKey()!=='student'&&MM91.auth.isAdmin());}catch(e){return false;}}/* administrators only: teachers use the classroom home */
function shHtml(){var D=DD(),ac=A(),ad=isAdmin(),list=D.list(),cs={};try{cs=D.classStats(list)||{};}catch(e){}
 var staff=ac.list().filter(function(a){return a.role!=='student';}).length,gs={};list.forEach(function(s){gs[s.grade||'K']=1;});
 var hr=new Date().getHours(),gr=hr<12?'Good morning':hr<18?'Good afternoon':'Good evening',nm='';try{nm=MM91.auth.displayName();}catch(e){}
 var sch='';try{sch=schoolName();}catch(e){}
 function tile(k,big,s,a){return '<div class="mm-card mmsh-tile"><div class="mmsh-k">'+k+'</div><div class="mmsh-big">'+big+'</div><div class="mmsh-s">'+s+'</div>'+(a?'<div class="mmsh-a">'+a+'</div>':'')+'</div>';}
 var h='<div class="mmsh-wrap"><div class="mmsh-head"><h1>'+gr+(nm?', '+esc(nm):'')+'.</h1><div class="mmsh-sub">'+new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric',year:'numeric'})+(sch?' \u00B7 '+esc(sch):'')+'</div></div>';
 var cl=null,si=null;try{if(window.mmCloud&&window.mmCloud.configured){cl=window.mmCloud.summary();si=window.mmCloud.seatInfo();}}catch(e){}
 if(cl&&si)h+='<div class="mm-card" style="padding:14px;margin:10px 0 0;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div style="flex:1 1 200px"><div class="mmsh-k">\u2601 Plan</div><div class="mmsh-v">'+(cl.licensed?'Subscribed \u00B7 '+si.limit+' seats':'Free sample')+'</div><div class="mmsh-s">'+(cl.signedIn?esc(cl.email||'')+' \u00B7 ':'Not signed in \u00B7 ')+si.used+' of '+si.limit+' seats used</div></div><button type="button" class="mm-btn sm primary" data-sh="cloud">'+(cl.licensed?'Manage plan':'Subscribe or sign in')+'</button></div>';
 h+='<div class="mmsh-sec">At a glance</div><div class="mmsh-grid">';
 h+=tile('\uD83D\uDC65 Students',list.length,list.length?Object.keys(gs).length+' grade level'+(Object.keys(gs).length===1?'':'s')+' in use':'No students yet','<button type="button" class="mm-btn sm secondary" data-sh="students">View</button>');
 h+=ad?tile('\uD83D\uDC69\u200D\uD83C\uDFEB Teachers &amp; staff',staff,staff?'With sign-in profiles':'No teacher profiles yet','<button type="button" class="mm-btn sm secondary" data-sh="teachers">View</button>'):tile('\uD83D\uDCDA Grades',Object.keys(gs).length,'Grade levels in your classes','');
 h+=tile('\u26A1 Active this week',cs.active7||0,list.length?Math.round((cs.active7||0)/list.length*100)+'% of your roster':'Appears once students join','');
 h+=tile('\uD83D\uDCCA Average mastery',(cs.avgPct||0)+'%','Across all lessons so far','');
 h+='</div><div class="mmsh-sec">Today</div><div class="mmsh-grid">';
 var cards=[];try{cards=MM91.shell.homeCards()||[];}catch(e){}
 cards.forEach(function(c){h+='<div class="mm-card mmsh-tile"><div class="mmsh-k">'+c.k+'</div>'+(c.big!=null?'<div class="mmsh-big">'+c.big+'</div>':'<div class="mmsh-v">'+c.v+'</div>')+'<div class="mmsh-s">'+(c.s||'')+'</div>'+(c.a?'<div class="mmsh-a">'+c.a+'</div>':'')+'</div>';});
 h+='</div><div class="mmsh-sec">Quick actions</div><div class="mmsh-grid">';
 function act(id,ic,l){return '<button type="button" class="mmsh-act" data-sh="'+id+'"><span class="ic">'+ic+'</span>'+l+'</button>';}
 h+=act('students','\uD83D\uDC65','Students')+act('lessons','\uD83D\uDCDA','Lessons')+act('reports','\uD83D\uDCC4','Reports')+act('print','\uD83D\uDDA8\uFE0F','Print sign-in cards')+act('switch','\u21C4','Switch profile')+act('install','\uD83D\uDCF2','Install app')+act('feedback','\uD83D\uDCAC','Send feedback')+act('a11y','\u267F','Accessibility');
 if(ad)h+='</div><div class="mmsh-sec">Administration</div><div class="mmsh-grid">'+act('adduser','\u2795','Add user')+act('import','\uD83D\uDCE5','Import roster')+act('school','\uD83C\uDFDB\uFE0F','School')+act('teachers','\uD83D\uDC69\u200D\uD83C\uDFEB','Teachers')+act('bulk','\uD83E\uDDF0','Bulk tools')+act('archive','\uD83D\uDDC4\uFE0F','Archive')+act('setup','\uD83D\uDE80','Setup wizard')+act('support','\u2709\uFE0F','Support email');
 var hl=null;try{hl=window.mmHealth?window.mmHealth():null;}catch(e){}
 if(hl){var em=window.MM_SUPPORT_EMAIL||'',inst=!!(window.mmInstalled&&window.mmInstalled());
  h+='</div><div class="mmsh-sec">Device health</div><div class="mmsh-grid">'
   +tile('\uD83D\uDCBD Storage',hl.pct+'%',(hl.bytes/1048576).toFixed(1)+' MB of about 5 MB used'+(hl.pct>=75?'. Download a backup soon.':''),'<div style="height:8px;border-radius:6px;background:rgba(128,128,128,.28);width:100%;overflow:hidden"><div style="height:100%;width:'+hl.pct+'%;background:'+(hl.pct>=75?'#c0392b':'#2e7d57')+'"></div></div>')
   +tile('\uD83D\uDEE1\uFE0F Data protection','<span style="font-size:24px">'+(hl.persisted?'On':'Off')+'</span>',hl.persisted?'The browser will not clear this data automatically.':'The browser may clear data if the device runs low on space.',hl.persisted?'':'<button type="button" class="mm-btn sm secondary" data-sh="persist">Turn on</button>')
   +tile('\uD83D\uDCF2 App','<span style="font-size:24px">'+(inst?'Installed':'In browser')+'</span>',inst?'Running as an installed app.':'Install for a home screen icon and offline use.',inst?'':'<button type="button" class="mm-btn sm secondary" data-sh="install">Install</button>')
   +tile('\u2709\uFE0F Support email','<span style="font-size:24px">'+(em?'Set':'Not set')+'</span>',em?esc(em):'Needed so feedback can be emailed to you.',ad?'<button type="button" class="mm-btn sm secondary" data-sh="support">'+(em?'Edit':'Set up')+'</button>':'');}
 return h+'</div></div>';}
function shPlace(){if(!shEl)return;var tb=$('mm-topbar'),tab=$('mm-tabbar'),nav=document.querySelector('nav#nav'),top=tb?Math.round(tb.getBoundingClientRect().bottom):0,bot=0;
 if(tab&&getComputedStyle(tab).display!=='none')bot=Math.max(0,innerHeight-tab.getBoundingClientRect().top);
 else if(nav&&getComputedStyle(nav).display!=='none')bot=Math.max(0,innerHeight-nav.getBoundingClientRect().top);
 shEl.style.top=top+'px';shEl.style.bottom=bot+'px';}
function shUpdate(){try{
 var gated=document.documentElement.classList.contains('mm-gated'),on=staffNow()&&!gated&&!openPanelId;
 if(!shEl){shEl=document.createElement('div');shEl.id='mm-staff-home';document.body.appendChild(shEl);}
 if(!on){shEl.classList.remove('on');document.documentElement.classList.remove('mm-staff-home-on');return;}
 var pn=$('panel-admin');if(pn){var cs=getComputedStyle(pn);shEl.style.background=cs.backgroundColor;shEl.style.color=cs.color;}
 var sig;try{sig=shHtml();}catch(e){return;}
 if(sig!==shSig){shSig=sig;var keep=shEl.scrollTop;shEl.innerHTML=sig;shEl.scrollTop=keep;}
 shPlace();shEl.classList.add('on');document.documentElement.classList.add('mm-staff-home-on');}catch(e){}}
window.addEventListener('resize',function(){shPlace();});
window.mmPickRoster=pickRoster;window.mmAddUserChooser=addUserChooser;
function shGo(a){var ad=MM91.admin;
 if(a==='cloud'){if(window.mmCloud)window.mmCloud.open();return;}
 if(a==='adduser')return addUserChooser();if(a==='import')return pickRoster();
 if(a==='lessons'){try{openPanel('lessons');}catch(e){}return;}if(a==='switch'){try{openPanel('login');}catch(e){}return;}
 if(a==='feedback'){try{openPanel('feedback');}catch(e){}return;}if(a==='a11y'){try{openPanel('a11y');}catch(e){}return;}
 if(a==='print'){if(window.mmPrintCards)window.mmPrintCards();return;}if(a==='bulk'){if(window.mmBulkTools)window.mmBulkTools();return;}
 if(a==='setup'){if(window.mmSetupWizard)window.mmSetupWizard();return;}if(a==='support'){if(window.mmSupportEmail)window.mmSupportEmail();return;}
 if(a==='install'){if(window.mmInstall)window.mmInstall();return;}if(a==='persist'){if(window.mmEnablePersist)window.mmEnablePersist();return;}
 var tab={school:'school',teachers:'teachers',students:'students',reports:'reports',archive:'archive'}[a];
 try{if(!isAdmin()&&(tab==='school'||tab==='archive'))tab='students';ad.open(tab);}catch(e){}}
/* ---------- roster tools card + join button ---------- */
function inject(){var main=$('adminMain');if(!main||$('mm-roster-tools'))return;
 var tab=(MM91.admin.state||{}).tab;if(tab!=='data'&&tab!=='students')return;
 var ad=isAdmin(),li=jget('mmLastImport',null),lr=jget('mmLastRollover',null);
 var b=document.createElement('div');b.className='mm-card';b.id='mm-roster-tools';b.style.marginTop='14px';
 var h='<div class="mm-card-title">\uD83E\uDDF0 Roster tools</div><div class="mm-card-sub">'+(ad?'Undo an import, move everyone up a grade at year end, and manage class join codes.':'Share your class join code so students can add themselves to your class.')+'</div><div class="mm-row" style="margin-top:10px;gap:8px;flex-wrap:wrap">';
 if(ad&&li)h+='<button class="mm-btn" data-rt="undo">\u21A9 Undo last import ('+(li.students||[]).length+' students)</button>';
 if(ad)h+='<button class="mm-btn" data-rt="roll">\uD83D\uDCC5 Year-end rollover</button>';
 if(ad&&lr)h+='<button class="mm-btn" data-rt="unroll">\u21A9 Undo last rollover</button>';
 h+='<button class="mm-btn" data-rt="codes">\uD83D\uDD11 Class join code'+(ad?'s':'')+'</button></div>';
 b.innerHTML=h;main.appendChild(b);}
function injectSwitch(){var el=$('loginBody');if(!el||el.querySelector('#mm-switch-staff'))return;
 var card=[].slice.call(el.querySelectorAll('.mm-card')).filter(function(c){return /Switch profile/.test(c.textContent)&&c.classList.contains('accent');})[0];
 if(!card)return;var ac=A();if(!ac)return;
 var staff=ac.list().filter(function(a){return a.role!=='student'&&a.role!=='admin';});
 var d=document.createElement('div');d.id='mm-switch-staff';d.style.marginTop='14px';
 d.innerHTML='<div class="mm-label" style="margin-bottom:6px">Teachers &amp; staff ('+staff.length+')</div>'+(staff.length?'<div style="display:flex;flex-wrap:wrap;gap:8px">'+staff.map(function(a){return '<button type="button" class="mm-btn sm" data-sw="'+esc(a.u)+'">\uD83D\uDC69\u200D\uD83C\uDFEB '+esc(a.name)+'</button>';}).join('')+'</div>':'<div class="mm-card-sub">No teacher profiles yet. Import a roster with a Teacher column, or add teachers under Users.</div>');
 card.appendChild(d);}
function injectJoin(){var a=$('mm-auth');if(!a||a.querySelector('[data-mmjoin]'))return;var l=a.querySelector('.links');if(!l)return;
 var b=document.createElement('button');b.type='button';b.setAttribute('data-mmjoin','1');b.textContent='\uD83C\uDF92 Join a class';l.appendChild(b);}
document.addEventListener('click',function(e){var ab=e.target.closest&&e.target.closest('#adminMain [data-act="tab"][data-id="users"][data-add="1"]');
 if(ab){e.preventDefault();e.stopPropagation();addUserChooser();return;}
 var sh=e.target.closest&&e.target.closest('[data-sh]');if(sh){e.preventDefault();e.stopPropagation();shGo(sh.getAttribute('data-sh'));return;}
 var tb=e.target.closest&&e.target.closest('#mmt-reset,#mmt-csv');
 if(tb){e.preventDefault();e.stopPropagation();if(tb.id==='mmt-reset'){['mmt-q','mmt-g','mmt-s'].forEach(function(i){var x=$(i);if(x)x.value='';});var o=$('mmt-o');if(o)o.value='az';applyTeachers();}
  else{var rows=[].slice.call(document.querySelectorAll('.mmt-wrap')).filter(function(w){return w.style.display!=='none';}).sort(function(a,b){return (+a.style.order)-(+b.style.order);}).map(function(w){return w.getAttribute('data-csv');});
   var blob=new Blob(['Teacher,Role,Students,Grades,Username,Sign-in status\n'+rows.join('\n')],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='teachers.csv';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},800);}return;}
 var t=e.target.closest&&e.target.closest('[data-rt],[data-mmjoin],[data-sw],[data-ss],[data-sp],[data-mk],[data-rs]');if(!t)return;
 if(t.hasAttribute('data-rs')){e.preventDefault();e.stopPropagation();try{MM91.admin.acts.uReset(null,{v:t.getAttribute('data-rs')});}catch(x){say('Could not reset that account.');}return;}
 if(t.hasAttribute('data-ss')){e.preventDefault();e.stopPropagation();try{MM91.auth.impersonate(t.getAttribute('data-ss'));}catch(x){say('Could not open that profile.');}return;}
 if(t.hasAttribute('data-sp')){e.preventDefault();e.stopPropagation();try{MM91.admin.student(t.getAttribute('data-sp'));}catch(x){}return;}
 if(t.hasAttribute('data-mk')){e.preventDefault();e.stopPropagation();mkTeacher(t.getAttribute('data-mk'));return;}
 if(t.hasAttribute('data-sw')){e.preventDefault();e.stopPropagation();try{MM91.auth.impersonateStaff(t.getAttribute('data-sw'));}catch(x){say('Could not open that profile.');}return;}
 if(t.hasAttribute('data-mmjoin')){e.preventDefault();e.stopPropagation();joinDialog();return;}
 var a=t.getAttribute('data-rt');if(a==='undo')undoImport();else if(a==='roll')rollover();else if(a==='unroll')unroll();else if(a==='codes')codesDialog();},true);
function init(){var tm;function go(){clearTimeout(tm);tm=setTimeout(function(){try{inject();injectJoin();injectSwitch();enhanceTeachers();enhanceTeacherProfile();}catch(e){}},60);}
 try{new MutationObserver(go).observe(document.body,{childList:true,subtree:true});}catch(e){}go();installSchoolTab();fixStaleSample();purgeSample();shUpdate();setInterval(shUpdate,600);setInterval(function(){if(fixStaleSample())purgeSample();},700);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
