/* =====================================================================
   V19 · RESOURCE GUIDE  (window.MMResources · panel "resources")
   Curated, free financial-literacy resources (government, Federal Reserve,
   nonprofit and university sources). Every link was opened and checked on
   the date in RESOURCES.checked; see review/resources.json for notes.
   Filters: audience, grade band, topic, language, search.
   Prints: full guide with a QR code per link, or a one-page family handout.
   ===================================================================== */
var RESOURCES=/*@include data/RESOURCES.json*/;
(function(){
'use strict';
var view={aud:'',band:'',topic:'',q:'',es:false};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function T(s){try{return window.MMI18N?window.MMI18N.t(s):s;}catch(e){return s;}}
function band(){try{var g=currentGrade||'K';return (g==='K'||g==='1'||g==='2')?'K-2':(g==='3'||g==='4'||g==='5')?'3-5':'6-8';}catch(e){return '';}}
function host(u){try{return new URL(u).hostname.replace(/^www\./,'');}catch(e){return u;}}
var AUD={teachers:'Teachers',families:'Families',students:'Students'},TOP={spending:'Spending',saving:'Saving',earning:'Earning',investing:'Investing',credit:'Credit',risk:'Risk',banking:'Banking',taxes:'Taxes',budgeting:'Budgeting','consumer-protection':'Consumer protection'};
function match(r){if(view.aud&&r.audience.indexOf(view.aud)<0)return false;if(view.band&&r.grades.indexOf(view.band)<0)return false;if(view.topic&&r.topics.indexOf(view.topic)<0)return false;if(view.es&&(r.lang||[]).indexOf('es')<0)return false;
  if(view.q){var q=view.q.toLowerCase();if((r.title+' '+r.org+' '+r.desc+' '+r.topics.join(' ')).toLowerCase().indexOf(q)<0)return false;}return true;}
function sel(id,label,opts,cur){return '<label class="rg-f">'+esc(T(label))+'<select data-rg="'+id+'"><option value="">'+esc(T('All'))+'</option>'+opts.map(function(o){return '<option value="'+esc(o[0])+'"'+(o[0]===cur?' selected':'')+'>'+esc(T(o[1]))+'</option>';}).join('')+'</select></label>';}
function render(){var el=document.getElementById('resourcesBody');if(!el)return;var R=RESOURCES,list=R.resources.filter(match);
  var h='<div class="rg"><section class="rg-hero"><div><div class="rg-k">'+esc(T('Resource Guide'))+'</div><h2>'+esc(T('Trusted money-learning resources'))+'</h2><p>'+esc(T('Free resources from government agencies, the Federal Reserve, nonprofits and universities. Every link was opened and checked on'))+' '+esc(new Date(R.checked+'T12:00:00').toLocaleDateString())+'.</p></div><div class="rg-act"><button type="button" class="rg-btn" data-rga="print">'+esc(T('Print the full guide'))+'</button><button type="button" class="rg-btn ghost" data-rga="family">'+esc(T('Print a family handout'))+'</button></div></section>';
  h+='<div class="rg-filters" role="search"><label class="rg-f rg-q">'+esc(T('Search'))+'<input type="search" data-rg="q" value="'+esc(view.q)+'" placeholder="'+esc(T('e.g. credit, coins, budget'))+'"></label>'
    +sel('aud','For',Object.keys(AUD).map(function(k){return [k,AUD[k]];}),view.aud)+sel('band','Grades',[['K-2','K–2'],['3-5','3–5'],['6-8','6–8']],view.band)+sel('topic','Topic',Object.keys(TOP).map(function(k){return [k,TOP[k]];}),view.topic)
    +'<label class="rg-chk"><input type="checkbox" data-rg="es"'+(view.es?' checked':'')+'> '+esc(T('Available in Spanish'))+'</label><button type="button" class="rg-btn ghost sm" data-rga="mine">'+esc(T('My grade'))+'</button><button type="button" class="rg-btn ghost sm" data-rga="clear">'+esc(T('Clear'))+'</button></div>';
  h+='<p class="rg-count" role="status">'+list.length+' '+esc(T(list.length===1?'resource':'resources'))+'</p>';
  R.sections.forEach(function(s){var items=list.filter(function(r){return r.section===s.id;});if(!items.length)return;
    h+='<section class="rg-sec" aria-labelledby="rg-'+s.id+'"><h3 id="rg-'+s.id+'">'+esc(T(s.title))+'</h3><p class="rg-intro">'+esc(T(s.intro||''))+'</p><div class="rg-grid">'+items.map(function(r){return '<article class="rg-card"><div class="rg-org">'+esc(r.org)+'</div><h4>'+esc(r.title)+'</h4><p>'+esc(r.desc)+'</p>'
      +'<div class="rg-tags">'+r.audience.map(function(a){return '<span>'+esc(T(AUD[a]||a))+'</span>';}).join('')+'<span>'+esc(r.grades.join(', '))+'</span>'+((r.lang||[]).indexOf('es')>-1?'<span>Español</span>':'')+'</div>'
      +(r.note?'<p class="rg-note">'+esc(r.note)+'</p>':'')+'<div class="rg-links"><a href="'+esc(r.url)+'" target="_blank" rel="noopener noreferrer">'+esc(T('Open'))+' '+esc(host(r.url))+' <span aria-hidden="true">↗</span><span class="gs-sr"> ('+esc(T('opens in a new tab'))+')</span></a><button type="button" class="rg-copy" data-rga="copy" data-u="'+esc(r.url)+'">'+esc(T('Copy link'))+'</button></div></article>';}).join('')+'</div></section>';});
  if(!list.length)h+='<p>'+esc(T('No resources match these filters.'))+'</p>';
  h+='<p class="rg-foot">'+esc(T('Links go to outside websites, which have their own privacy policies. Preview a site before sharing it with students.'))+'</p></div>';
  el.innerHTML=h;try{if(window.MMI18N)MMI18N.apply(el);}catch(e){}}
function qr(u){try{if(typeof qrcode!=='function')return '';var q=qrcode(0,'L');q.addData(u);q.make();var n=q.getModuleCount(),d='';for(var r=0;r<n;r++)for(var c=0;c<n;c++)if(q.isDark(r,c))d+='M'+c+' '+r+'h1v1h-1z';return '<svg viewBox="-1 -1 '+(n+2)+' '+(n+2)+'" shape-rendering="crispEdges"><rect x="-1" y="-1" width="'+(n+2)+'" height="'+(n+2)+'" fill="#fff"/><path d="'+d+'" fill="#111"/></svg>';}catch(e){return '';}}
function printGuide(familyOnly){var M=window.MMPrint;if(!M)return;var R=RESOURCES,E=M.esc,list=R.resources.filter(familyOnly?function(r){return r.audience.indexOf('families')>-1||r.audience.indexOf('students')>-1;}:match);
  var h='';if(!familyOnly)h+='<div class="cover first"><div><div class="k">Money Matters · K–8 Financial Literacy</div><h1>Resource Guide</h1><div class="sub">Free, trusted resources for teachers, families and students</div></div><div class="mark" aria-hidden="true">$</div><div class="small">'+list.length+' resources · links checked '+E(R.checked)+'<br>Scan a QR code with a phone camera to open a site.</div></div><div class="page">';
  h+=M.head(familyOnly?'Money Matters · For families':'Resource Guide',familyOnly?'Money learning at home':'Contents',familyOnly?'Free websites to explore money skills together. Scan a code with your phone camera.':'');
  if(!familyOnly)h+='<table class="t"><thead><tr><th>Section</th><th style="width:16%">Resources</th></tr></thead><tbody>'+R.sections.map(function(s){var n=list.filter(function(r){return r.section===s.id;}).length;return n?'<tr><td><b>'+E(s.title)+'</b><div class="small">'+E(s.intro||'')+'</div></td><td class="c">'+n+'</td></tr>':'';}).join('')+'</tbody></table><div class="call"><b>Using outside sites with students:</b> preview each site first, avoid sites that ask students for personal information, and follow your school’s technology policy.</div></div>';
  R.sections.forEach(function(s,si){var items=list.filter(function(r){return r.section===s.id;});if(!items.length)return;
    h+=(familyOnly?'':'<div class="page">'+M.head('Resource Guide · Section '+(si+1),s.title,s.intro||''))+(familyOnly?'<h3 style="margin-top:12px">'+E(s.title)+'</h3>':'')
      +items.map(function(r){return '<div class="res"><div class="qr">'+qr(r.url)+'</div><div><h4>'+E(r.title)+'</h4><div class="small">'+E(r.org)+' · '+E(r.audience.join(', '))+' · grades '+E(r.grades.join(', '))+((r.lang||[]).indexOf('es')>-1?' · English and Spanish':'')+'</div><p>'+E(r.desc)+'</p>'+(r.note?'<p class="small"><i>'+E(r.note)+'</i></p>':'')+'<div class="url">'+E(r.url)+'</div></div></div>';}).join('')+(familyOnly?'':'</div>');});
  M.open(familyOnly?'Money learning at home':'Money Matters Resource Guide',h,{headerLeft:'Money Matters · Resource Guide',cover:!familyOnly});}
document.addEventListener('input',function(e){var el=e.target;if(!el.closest||!el.closest('#resourcesBody'))return;if(el.getAttribute('data-rg')==='q'){view.q=el.value;clearTimeout(window.__rgT);window.__rgT=setTimeout(function(){var pos=el.selectionStart;render();var n=document.querySelector('#resourcesBody [data-rg=q]');if(n){n.focus();try{n.setSelectionRange(pos,pos);}catch(x){}}},180);}});
document.addEventListener('change',function(e){var el=e.target;if(!el.closest||!el.closest('#resourcesBody'))return;var k=el.getAttribute('data-rg');if(!k||k==='q')return;view[k]=k==='es'?el.checked:el.value;render();var n=document.querySelector('#resourcesBody [data-rg="'+k+'"]');if(n)n.focus();});
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#resourcesBody [data-rga]');if(!b)return;var a=b.getAttribute('data-rga');
  if(a==='print')return printGuide(false);if(a==='family')return printGuide(true);
  if(a==='mine'){view.band=band();render();return;}if(a==='clear'){view={aud:'',band:'',topic:'',q:'',es:false};render();return;}
  if(a==='copy'){var u=b.getAttribute('data-u');try{navigator.clipboard.writeText(u).then(function(){b.textContent=T('Copied');});}catch(x){}}});
window.MMResources={render:render,print:printGuide,data:RESOURCES};
try{if(typeof _panelRenderers!=='undefined')_panelRenderers.resources=render;}catch(e){}
/* dock: Resources next to Workshops; Games panel's old link list points here */
try{var S=MM91.shell;if(S&&S.navGroups&&!S.navGroups.__rg){var on=S.navGroups;S.navGroups=function(){var g=on.apply(this,arguments);try{var learn=g[0];if(learn&&!learn.items.some(function(x){return /resources/.test(x[2]);}))learn.items.push(['🧭','Resources',"openPanel('resources')"]);}catch(e){}return g;};S.navGroups.__rg=1;}}catch(e){}
})();
