(function(){'use strict';
var IDS={wsName:'Student name',wsDate:'Date',certName:'Name on the certificate',certSchool:'School name',glossarySearch:'Search the glossary'};
function lab(el){if(IDS[el.id])return IDS[el.id];if(el.placeholder)return el.placeholder;var p=el.previousElementSibling;if(p&&p.textContent&&p.textContent.trim())return p.textContent.trim().slice(0,90);
  var r=el.closest('.ws-item,.q-item,.card,li,p,div');if(r){var t=(r.textContent||'').trim().replace(/\s+/g,' ').slice(0,90);if(t)return t;}return 'Answer';}
function run(){try{
 document.querySelectorAll('input:not([type=hidden]),select,textarea').forEach(function(el){
  if(el.getAttribute('aria-label')||el.getAttribute('aria-labelledby')||el.title||el.closest('label')||(el.id&&document.querySelector('label[for="'+el.id+'"]')))return;
  el.setAttribute('aria-label',lab(el));});
 document.querySelectorAll('.vocab-tip,.flow-step').forEach(function(el){if(!el.getAttribute('role')){el.setAttribute('role','button');}if(el.tabIndex<0||!el.hasAttribute('tabindex'))el.setAttribute('tabindex','0');});
 var si=document.getElementById('mm-session-indicator');if(si&&!si.getAttribute('aria-label'))si.setAttribute('aria-label','Signed-in user. Open the sign-in screen.');
}catch(e){}}
var t;function later(){clearTimeout(t);t=setTimeout(run,120);}
document.addEventListener('keydown',function(e){var el=e.target;if((e.key==='Enter'||e.key===' ')&&el&&el.getAttribute&&el.getAttribute('role')==='button'&&el.tagName!=='BUTTON'){e.preventDefault();el.click();}});
new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true});
run();
})();
