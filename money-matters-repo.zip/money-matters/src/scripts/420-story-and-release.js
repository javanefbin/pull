/* =====================================================================
   V91 · STORY MODE "DECISION LAB" PRESENTATION LAYER + RELEASE NOTES
   The story engine (v80) is unchanged. This layer restructures what it
   draws into a professional learning-module layout: a toolbar, an act
   stepper, money status tiles, numbered choice cards, a debrief with
   stat tiles and a decision timeline. Every transform is idempotent.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91,U=MM.util,$=U.$,E=U.E;
var STORY=MM.story={};
function enhance(){var b=$('storyBody');if(!b)return;b.classList.add('st-pro');
  /* toolbar: kicker + listen button on one line */
  var listen=b.querySelector(':scope > .st-listen'),kick=b.querySelector(':scope > .st-kicker');
  if(listen&&!listen.closest('.st-toolbar')){var tb=document.createElement('div');tb.className='st-toolbar';b.insertBefore(tb,b.firstChild);if(kick)tb.appendChild(kick);else{var k=document.createElement('div');k.className='st-kicker';k.textContent='Story Mode · Decision Lab';tb.appendChild(k);}tb.appendChild(listen);}
  /* money status tiles: "👛 Wallet: $5" → label + value */
  b.querySelectorAll('.st-bar > span').forEach(function(sp){if(sp.dataset.label)return;var m=sp.textContent.match(/^\s*(\S+)\s+([^:]+):\s*(.+)$/);if(m){sp.dataset.label=m[2].trim();sp.textContent=m[3].trim();}});
  /* debrief stats: "Earned: $12" → small label + bold value */
  b.querySelectorAll('.st-stats > li').forEach(function(li){if(li.dataset.pro)return;li.dataset.pro='1';var t=li.textContent,i=t.indexOf(': ');if(i>0){var lab=t.slice(0,i),val=t.slice(i+2);li.innerHTML='<small>'+E(lab)+'</small><b>'+E(val)+'</b>';if(/goal|ended/i.test(lab))li.classList.add('wide');}});
  /* decision path → timeline chips */
  b.querySelectorAll('.card > p').forEach(function(p){if(p.dataset.pro)return;var bb=p.querySelector('b');if(bb&&/^Your path:/.test(bb.textContent)){p.dataset.pro='1';var parts=p.textContent.replace(/^Your path:\s*/,'').split(' → ');var d=document.createElement('div');d.className='st-path';d.innerHTML='<b style="font:800 11px var(--mm-ui);letter-spacing:.1em;text-transform:uppercase;color:var(--ink-light);margin-right:4px">Decision path</b>'+parts.map(function(x,i){return (i?'<i aria-hidden="true">→</i>':'')+'<span>'+E(x.trim())+'</span>';}).join('');p.replaceWith(d);}});
  /* keyboard hint */
  b.querySelectorAll('.st-tip').forEach(function(t){if(t.dataset.pro)return;t.dataset.pro='1';t.innerHTML='<span aria-hidden="true">⌨️</span> '+E(t.textContent.replace(/^Tip:\s*/,''));});
  /* checkpoint prompt: give it a small label */
  b.querySelectorAll('.story-question > .st-kicker').forEach(function(k){if(k.dataset.pro)return;k.dataset.pro='1';k.textContent=k.textContent.replace(/ asks$/,' asks you');});
}
function watch(){var b=$('storyBody');if(!b||b.__v91)return;b.__v91=1;new MutationObserver(function(){enhance();}).observe(b,{childList:true});enhance();}
function wrap(){if(typeof window.renderStory==='function'&&!window.renderStory.__v91){var o=window.renderStory;var w=function(){o.apply(this,arguments);watch();enhance();};w.__v91=true;window.renderStory=w;if(typeof _panelRenderers!=='undefined')_panelRenderers.story=function(){window.renderStory();};}watch();}
STORY.enhance=enhance;
document.addEventListener('DOMContentLoaded',function(){wrap();setTimeout(wrap,800);});

/* ---------- release notes ---------- */
try{if(typeof CHANGELOG!=='undefined'){CHANGELOG.unshift({date:'October 2026',items:[
  'Professional sign-in: a single sign-in screen with Student, Teacher, and Administrator tabs, floating-label fields, quick-pick names, remember-me, inline validation, first-time passcode setup with a recovery question, and a guided student-profile creation flow that shows the new sign-in code.',
  'New Administration Console (teacher and administrator access): Overview with KPIs, setup checklist, enrollment, learner status, attention list and recent activity; Students with search, filters, sorting and roster export; Teachers with class insights; Classes by grade; Curriculum browser and content tools; Reports hub; Data & Backup; Settings; System.',
  'Student Profile: summary, 36-week lesson grid, checkpoints and financial-literacy assessment history, games and Story Mode evidence, all reflections, private teacher notes, and management (edit, code, promote, reset, remove).',
  'Teacher Profile: roster, class insights (status, grade breakdown, weeks with the most retries), details and role, class CSV and printable class summary.',
  'Organized shell: persistent top bar with the signed-in user and role, grouped bottom navigation (Learn · Assess · Documents · Admin) with a More menu, smoother panel transitions and a consistent component system.',
  'Story Mode redesigned as a Decision Lab: act stepper, money status tiles, numbered choice cards with impact chips, cleaner checkpoints, and a debrief with stat tiles and a decision timeline.'
]});}}catch(e){}
})();
