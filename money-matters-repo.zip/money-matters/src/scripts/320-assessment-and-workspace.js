(function(){
'use strict';
var mmFAIndex=0;
function assessmentQuestions(){
  var qs=window.mmFAQuestions||[];
  if(!qs.length && typeof faQuestionsForGrade==='function' && typeof faGradeForStudent==='function'){
    try{qs=faQuestionsForGrade(faGradeForStudent(mmFAStudentId));window.mmFAQuestions=qs}catch(e){}
  }
  return qs;
}
function renderOneAssessment(){
  var el=document.getElementById('assessmentBody'); if(!el)return;
  var qs=assessmentQuestions(); if(!qs.length){ if(typeof faRenderIntro==='function')faRenderIntro(); return; }
  var g=typeof faGradeForStudent==='function'?faGradeForStudent(mmFAStudentId):'K';
  if(mmFAIndex<0)mmFAIndex=0; if(mmFAIndex>=qs.length)mmFAIndex=qs.length-1;
  var answered=Object.keys(mmFAAnswers||{}).length;
  var q=qs[mmFAIndex], selected=(mmFAAnswers&&mmFAAnswers[mmFAIndex]!=null)?mmFAAnswers[mmFAIndex]:null;
  var pct=Math.round((answered/qs.length)*100), name='Student';
  try{name=loadStore().list[mmFAStudentId].name||name}catch(e){}
  var h='<div class="mm-assess-shell">';
  h+='<div class="mm-assess-top"><div><div class="mm-assess-kicker">Financial Literacy Assessment</div><div style="font-size:14px;font-weight:800">'+esc(gradeLabel(g))+'</div></div><div class="mm-assess-count">Question '+(mmFAIndex+1)+' of '+qs.length+'</div></div>';
  h+='<div class="mm-assess-progress"><i style="width:'+Math.max(3,Math.round(((mmFAIndex+(selected!==null?1:0))/qs.length)*100))+'%"></i></div>';
  h+='<div class="mm-assess-one"><div class="num">'+esc(q.domain)+(q.application?' · Real-world application':'')+'</div><div class="prompt">'+esc(q.q)+'</div>';
  h+=q.options.map(function(o,j){return '<button type="button" class="mm-assess-option '+(selected===j?'sel':'')+'" onclick="faPick('+mmFAIndex+','+j+')"><span class="mm-assess-letter">'+String.fromCharCode(65+j)+'</span><span>'+esc(o)+'</span></button>'}).join('');
  h+='<div class="mm-assess-footer">';
  h+='<button type="button" class="btn-calc ghost" '+(mmFAIndex===0?'disabled':'')+' onclick="mmFABack()">Back</button>';
  if(mmFAIndex<qs.length-1) h+='<button type="button" class="btn-calc green" '+(selected===null?'disabled':'')+' onclick="mmFANext()">Next</button>';
  else h+='<button type="button" class="btn-calc green" '+(answered<qs.length?'disabled':'')+' onclick="faSubmit()">Finish Assessment</button>';
  h+='</div><div class="mm-assess-instruction">Choose one answer, then select Next. Your answer is saved automatically.</div></div>';
  h+='<div class="mm-small-note" style="text-align:center;margin-top:12px">'+answered+' of '+qs.length+' answered'+(name&&name!=='Student'?' · '+esc(name):'')+'</div></div>';
  el.innerHTML=h;
  var pb=el.closest('.panel-body');if(pb){pb.scrollTop=0;}
}
window.faPick=function(i,j){if(mmFASubmitted)return;mmFAAnswers[i]=j;mmFAIndex=i;renderOneAssessment();};
window.mmFANext=function(){var qs=assessmentQuestions();if(mmFAAnswers[mmFAIndex]==null)return;if(mmFAIndex<qs.length-1){mmFAIndex++;renderOneAssessment();}};
window.mmFABack=function(){if(mmFAIndex>0){mmFAIndex--;renderOneAssessment();}};
window.faStart=function(){mmFAQuestions=faQuestionsForGrade(faGradeForStudent(mmFAStudentId));mmFAAnswers={};mmFASubmitted=false;mmFAIndex=0;renderOneAssessment();};
function wrapAssessment(){
  if(typeof window.renderFinancialAssessment!=='function')return;
  if(window.renderFinancialAssessment.__v66)return;
  window.renderFinancialAssessment.__v66=true;
  var old=window.renderFinancialAssessment;
  window.renderFinancialAssessment=function(){
    try{
      if(mmFASubmitted && typeof faLatest==='function' && faLatest(mmFAStudentId)){old();return;}
      if(!mmFAQuestions.length){old();return;}
      renderOneAssessment();
    }catch(e){old();}
  };
}
function wrapTeacher(){
  if(typeof window.renderTeacher!=='function'||window.renderTeacher.__v66)return;
  var old=window.renderTeacher;
  function clean(){
    var el=document.getElementById('teacherBody');if(!el)return;
    el.classList.add('mm-clean-teacher');
    var oldQuick=document.getElementById('mm-teacher-quick');if(oldQuick)oldQuick.remove();
    var q=document.createElement('div');q.id='mm-teacher-quick';q.className='mm-teacher-quick';
    q.innerHTML='<button onclick="openPanel(\'students\')"><b>👥 Students</b><span>Manage learner profiles</span></button><button onclick="openFinancialAssessment(getTabActive()||loadStore().active)"><b>📊 Assessment</b><span>View a student profile</span></button><button onclick="teacherReport(getTabActive()||loadStore().active)"><b>📄 Reports</b><span>Open the active report</span></button><button onclick="openPanel(\'overview\')"><b>📚 Curriculum</b><span>View the learning program</span></button>';
    el.insertBefore(q,el.firstChild);
    /* Collapse the long setup/tool area into one quiet control. */
    var heads=Array.prototype.slice.call(el.children).filter(function(x){return x.classList&&x.classList.contains('section-head');});
    var roster=heads.find(function(x){return (x.textContent||'').trim().toLowerCase().indexOf('roster')===0;});
    if(!roster)return;
    var first=heads[0];
    if(first && first!==roster){
      var det=document.createElement('details');det.className='mm-teacher-tools';
      var sum=document.createElement('summary');sum.textContent='Teacher setup & tools';det.appendChild(sum);
      var inner=document.createElement('div');inner.className='mm-tools-inner';
      var n=first;while(n && n!==roster){var next=n.nextElementSibling;inner.appendChild(n);n=next;}
      det.appendChild(inner);el.insertBefore(det,roster);
    }
    /* Keep roster as the primary workspace and reduce button clutter. */
    var rosterHead=Array.prototype.slice.call(el.children).find(function(x){return x.classList&&x.classList.contains('section-head')&&(x.textContent||'').trim().toLowerCase().indexOf('roster')===0;});
    if(rosterHead){rosterHead.classList.add('mm-teacher-roster-head');}
  }
  function fn(){old();setTimeout(clean,0)}
  fn.__v66=true;window.renderTeacher=fn;
}
function cleanGlobal(){
  document.documentElement.classList.add('mm-v66-clean');
  wrapAssessment();wrapTeacher();
}
function boot(){cleanGlobal();setTimeout(cleanGlobal,700);setTimeout(cleanGlobal,1800)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
