/* =====================================================================
   V19 · QUALITY LAYER
   1. Notices: routine reminders (backups, storage, "what's new") go to
      a bell in the top bar instead of popping up. Toasts that arrive
      while the Game Show or a phone player screen is open are held and
      shown after it closes.
   2. Tour: the full tour runs once per device. After an update, a
      "What's new" notice appears in the bell instead of the tour.
   3. Accessibility fixes for the legacy shell (see review/a11y.md):
      sign-in and open panels make the classroom behind them inert,
      focus returns to the opener, Space activates role=button divs,
      and leading emoji in dock buttons are hidden from screen readers.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;var S=MM.shell,A=MM.auth;
function $(id){return document.getElementById(id);}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function T(s){try{return window.MMI18N?window.MMI18N.t(s):s;}catch(e){return s;}}

/* ---------- 1. notices ---------- */
var NKEY='mmNotices_v1';
function nLoad(){try{return JSON.parse(localStorage.getItem(NKEY)||'[]')||[];}catch(e){return [];}}
function nSave(l){try{localStorage.setItem(NKEY,JSON.stringify(l.slice(-20)));}catch(e){}}
function notify(key,msg,action){var l=nLoad().filter(function(n){return n.key!==key;});l.push({key:key,msg:msg,action:action||'',t:Date.now(),read:false});nSave(l);bell();}
function unread(){return nLoad().filter(function(n){return !n.read;}).length;}
window.mmNotify=notify;
var ROUTE=[[/backup is more than a week old/i,'backup',"openPanel('admin');setTimeout(function(){try{MM91.admin.open('data')}catch(e){}},80)"],[/^Storage is \d+% full/i,'storage',"openPanel('admin');setTimeout(function(){try{MM91.admin.open('data')}catch(e){}},80)"]];
var held=[];
function busy(){var c=document.documentElement.classList;return c.contains('mm-gs-on')||c.contains('mm-lp-on');}
function wrapToast(obj,name){var o=obj&&obj[name];if(typeof o!=='function'||o.__v19)return;var w=function(msg){var m=String(msg||'');for(var i=0;i<ROUTE.length;i++)if(ROUTE[i][0].test(m)){notify(ROUTE[i][1],m,ROUTE[i][2]);return;}
    if(busy()){held.push([o,this,arguments]);return;}return o.apply(this,arguments);};w.__v19=true;obj[name]=w;}
function flush(){if(busy()||!held.length)return;var h=held.splice(0,3);h.forEach(function(x,i){setTimeout(function(){try{x[0].apply(x[1],x[2]);}catch(e){}},i*1800);});held=[];}
setInterval(flush,1500);
function installToasts(){try{wrapToast(window,'infoToast');}catch(e){}try{if(MM.util)wrapToast(MM.util,'toast');}catch(e){}}
installToasts();
/* bell in the top bar */
function bell(){var tb=$('mm-topbar');if(!tb||tb.style.display==='none')return;var a=A.get();var b=tb.querySelector('[data-v19=bell]'),n=unread(),list=nLoad();
  if(!a||!list.length){if(b)b.remove();return;}
  if(!b){b=document.createElement('button');b.type='button';b.className='tb';b.setAttribute('data-v19','bell');var out=tb.querySelector('[data-a=out]');tb.insertBefore(b,out||null);}
  b.innerHTML='<span aria-hidden="true">🔔</span>'+(n?'<b class="v19-badge">'+n+'</b>':'');b.setAttribute('aria-label',T('Notices')+(n?' ('+n+' '+T('new')+')':''));b.title=T('Notices');}
function pop(){var p=$('v19-notices');if(p){p.remove();return;}var l=nLoad().slice().reverse();p=document.createElement('div');p.id='v19-notices';p.setAttribute('role','dialog');p.setAttribute('aria-label',T('Notices'));
  p.innerHTML='<div class="v19-nh"><b>'+esc(T('Notices'))+'</b><button type="button" data-v19="nclose" aria-label="'+esc(T('Close'))+'">×</button></div>'+(l.length?l.map(function(n){return '<div class="v19-n'+(n.read?'':' new')+'"><p>'+esc(T(n.msg))+'</p><div class="v19-na"><small>'+new Date(n.t).toLocaleDateString()+'</small>'+(n.action?'<button type="button" data-v19="ngo" data-k="'+esc(n.key)+'">'+esc(T('Open'))+'</button>':'')+'<button type="button" data-v19="ndel" data-k="'+esc(n.key)+'">'+esc(T('Dismiss'))+'</button></div></div>';}).join(''):'<p class="v19-empty">'+esc(T('No notices.'))+'</p>');
  document.body.appendChild(p);nSave(nLoad().map(function(n){n.read=true;return n;}));bell();var f=p.querySelector('button');if(f)f.focus();}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-v19]');if(!b)return;var a=b.getAttribute('data-v19'),k=b.getAttribute('data-k');
  if(a==='bell')return pop();if(a==='nclose'){var p=$('v19-notices');if(p)p.remove();return;}
  if(a==='ndel'){nSave(nLoad().filter(function(n){return n.key!==k;}));var p2=$('v19-notices');if(p2)p2.remove();pop();bell();return;}
  if(a==='ngo'){var n=nLoad().filter(function(x){return x.key===k;})[0];var p3=$('v19-notices');if(p3)p3.remove();if(n&&n.action){try{(new Function(n.action))();}catch(x){}}return;}});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&$('v19-notices')){$('v19-notices').remove();e.stopPropagation();}},true);
if(S&&S.topbar&&!S.topbar.__v19){var ot=S.topbar;S.topbar=function(){var r=ot.apply(this,arguments);try{bell();}catch(e){}return r;};S.topbar.__v19=1;}

/* ---------- 2. tour once; updates go to the bell ---------- */
window.maybeTour=function(){try{var done=localStorage.getItem('mmTourDone')||'',ver=localStorage.getItem('mmTourVersion')||'',cur=(typeof APP_VERSION!=='undefined'?APP_VERSION:'');
  if(!done){setTimeout(function(){try{startTour();}catch(e){}},1000);return;}
  if(ver!==cur){try{localStorage.setItem('mmTourVersion',cur);}catch(e){}notify('whatsnew','Money Matters was updated. See what’s new: Game Show live play, Workshops, and more.',"openPanel('whatsnew')");}}catch(e){}};

/* ---------- 3. accessibility ---------- */
/* background classroom becomes inert under the sign-in gate and under open panels */
var SCENE=['scene','main-content','mm-home','mm-staff-home'];
function setInert(on){SCENE.forEach(function(id){var e=$(id);if(e){if(on)e.setAttribute('inert','');else e.removeAttribute('inert');}});var sk=document.querySelector('.skip-link');if(sk){if(on)sk.setAttribute('inert','');else sk.removeAttribute('inert');}}
var lastOpener=null;
document.addEventListener('focusin',function(e){var t=e.target;if(t&&!t.closest('.panel')&&!t.closest('#mm-auth'))lastOpener=t;},true);
function sync(){var gate=$('mm-auth'),gated=!!(gate&&!gate.classList.contains('mm-hidden')),open=document.querySelector('.panel.open');
  setInert(gated||!!open);
  /* the sign-in gate also hides the top bar, dock and tab bar */
  ['mm-topbar','nav','mm-tabbar'].forEach(function(id){var e=$(id);if(!e)return;if(gated)e.setAttribute('inert','');else e.removeAttribute('inert');});}
var wasOpen=null;
function watch(){var mo=new MutationObserver(function(){var open=document.querySelector('.panel.open');sync();
    if(wasOpen&&!open&&lastOpener&&document.contains(lastOpener)&&!lastOpener.closest('[inert]')){try{lastOpener.focus({preventScroll:true});}catch(e){}}wasOpen=open;});
  document.querySelectorAll('.panel').forEach(function(p){mo.observe(p,{attributes:true,attributeFilter:['class']});});
  var g=$('mm-auth');if(g)mo.observe(g,{attributes:true,attributeFilter:['class']});else setTimeout(watch,800);sync();}
/* Space activates div-based buttons, like real buttons */
document.addEventListener('keydown',function(e){if(e.key!==' '&&e.key!=='Spacebar')return;var t=e.target;if(!t||t.tagName==='BUTTON'||t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT'||t.isContentEditable)return;if(t.getAttribute&&t.getAttribute('role')==='button'){e.preventDefault();t.click();}});
/* leading emoji in dock and tab-bar buttons are decoration */
var EMO=/^(\s*)([←-⯿☀-➿\uD83C-􏰀-\uDFFF️‍]+)\s*/;
function hideEmoji(root){(root||document).querySelectorAll('#nav .nav-btn,#mm-tabbar button,.station .top').forEach(function(b){if(b.__v19e)return;var n=b.firstChild;if(n&&n.nodeType===3){var m=EMO.exec(n.nodeValue);if(m){var s=document.createElement('span');s.setAttribute('aria-hidden','true');s.textContent=m[2];n.nodeValue=n.nodeValue.slice(m[0].length);b.insertBefore(s,n);b.insertBefore(document.createTextNode(' '),n);}}b.__v19e=1;});
  document.querySelectorAll('.station .top').forEach(function(t){t.setAttribute('aria-hidden','true');});}
function navWatch(){var nav=$('nav');if(!nav){setTimeout(navWatch,800);return;}hideEmoji();new MutationObserver(function(){hideEmoji();}).observe(nav,{childList:true,subtree:true});var tb=$('mm-tabbar');if(tb)new MutationObserver(function(){hideEmoji();}).observe(tb,{childList:true,subtree:true});}
/* returning users: an update since their last visit goes to the bell (an older layer
   re-stamps mmTourVersion at load, so compare against the value it saw first) */
function whatsNew(){try{var prev=window.__mmPrevTourVersion,cur=(typeof APP_VERSION!=='undefined'?APP_VERSION:'');if(prev&&cur&&prev!==cur&&localStorage.getItem('mmTourDone')){window.__mmPrevTourVersion=cur;notify('whatsnew','Money Matters was updated. See what’s new: Game Show live play, redesigned printouts, the Resource Guide, and more.',"openPanel('whatsnew')");}}catch(e){}}
function boot(){watch();navWatch();installToasts();whatsNew();bell();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(boot,1200);});else setTimeout(boot,300);
})();

/* ---------- native alert() → the app's own dialog ----------
   Browsers block alert() in embedded views and some installed-app windows, so a
   button that only shows an alert looked dead there. */
(function(){var na=window.alert;window.alert=function(m){try{if(typeof mmAlert==='function'){mmAlert(String(m==null?'':m));return;}}catch(e){}try{infoToast(String(m),6000);return;}catch(e){}try{na.call(window,m);}catch(e){}};})();

/* ---------- school-tool dialogs (.mmrt-ov: setup wizard, bulk tools, join codes, sign-in cards, rollover) ----------
   They sit above everything else, so: confirmations (toasts) are raised above them (CSS), Escape closes them,
   screen readers get their title, and focus returns to the button that opened them. */
(function(){var opener=null;
  document.addEventListener('focusin',function(e){var t=e.target;if(t&&!(t.closest&&t.closest('.mmrt-ov')))opener=t;},true);
  function label(o){var box=o.querySelector('.mmrt-box'),h=o.querySelector('h2');if(box&&h&&!box.getAttribute('aria-labelledby')){h.id=h.id||('mmrt-h-'+Math.random().toString(36).slice(2,8));box.setAttribute('aria-labelledby',h.id);}}
  new MutationObserver(function(list){list.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1&&n.classList&&n.classList.contains('mmrt-ov')){n.__opener=opener;label(n);}});
    m.removedNodes.forEach(function(n){if(n.nodeType===1&&n.classList&&n.classList.contains('mmrt-ov')&&n.__opener&&document.contains(n.__opener)&&!document.querySelector('.mmrt-ov')){try{n.__opener.focus({preventScroll:true});}catch(e){}}});});}).observe(document.body,{childList:true});
  document.addEventListener('keydown',function(e){if(e.key!=='Escape')return;var all=document.querySelectorAll('.mmrt-ov');if(!all.length)return;var o=all[all.length-1];
    var b=[].filter.call(o.querySelectorAll('.mmrt-btns button[data-id]'),function(x){return /^(x|close|cancel|done|ok|no)$/i.test(x.getAttribute('data-id'))||/^(close|cancel|done|got it|not now)$/i.test(x.textContent.trim());})[0];
    e.preventDefault();e.stopPropagation();if(b)b.click();else o.remove();},true);
})();

/* ---------- changelog: V19 (October 2026) ---------- */
try{if(typeof CHANGELOG!=='undefined')CHANGELOG.unshift({date:'October 26, 2026 · V19',items:[
 'Live Game Show on phones and tablets: students join with a game PIN or QR code and a nickname (no student accounts). Plays across devices through your school’s own Supabase project, or across windows on one computer for practice.',
 'Printouts redesigned: lesson plans with a minute-by-minute sequence, success criteria, differentiation and language support; worksheets with a name bar and self-rating; separate answer keys; one-page family letters with a reply slip; workbooks and teacher’s guides with covers, contents and unit dividers. Every page has running headers, footers and page numbers, and the app no longer prints over the page.',
 'Resource Guide: 60 free, trusted resources for students, teachers and families, filtered by grade, topic and audience, including Spanish resources. Prints as a full guide with a QR code for each link, or as a one-page family handout.',
 'Workshops are now measurable: a 10-word vocabulary check-in and check-out per workshop, paper scoring, class results with growth, CSV export, and a Workshops report in the Admin Console. Each workshop day shows its national standards areas.',
 'Spanish and Portuguese for the Game Show, live play, Workshops, Resource Guide, notices and all printouts.',
 'Sixteen content corrections, including 2025–26 tuition figures, weekly free credit reports, credit-card interest only on unpaid balances, NCUA insurance, the end of penny production, and 15-character passwords.',
 'Privacy Policy, Terms and FAQ rewritten for accounts and live play, plus a new Security page and notice in Admin Console → Security policy explaining what sign-in protects and what it does not.',
 'Fewer pop-ups: backup and storage reminders and “What’s new” go to a bell in the top bar, and nothing pops up during a game. The welcome tour runs once per device.',
 'Accessibility: the classroom behind sign-in and open panels is skipped by screen readers and the keyboard, focus returns to where you were, Space activates every button, game timers can be turned off, answer colors meet contrast rules, and correct answers are announced.',
 'Behind the scenes: the app is built from a readable source tree with an automated test suite that checks sign-in, every panel, every game mode, live play, workshops, printouts, translations and accessibility.']});}catch(e){}
try{if(typeof CHANGELOG!=='undefined')CHANGELOG.unshift({date:'October 26, 2026 · V20',items:[
 'Website edition: week 1 of every grade is free online. A school license unlocks the full program on the device, with an access code or by signing in with Google, Microsoft or Facebook when the license covers your email or your school’s email domain.',
 'Teachers, parents and administrators can sign in with Google, Microsoft or Facebook on the website edition. On a new device, the first person to sign in becomes the administrator. Students keep their sign-in codes.',
 'Optional sponsor cards in the free edition, shown only to signed-in adults: never to students, during games, in printouts, or to licensed schools. Each card can be hidden.',
 'Fixed buttons that did nothing: the Financial Literacy Assessment could not start; “Open report” with no quiz data was silent; confirmation messages were hidden behind school-tool dialogs.',
 'Teachers can now try a quiz as a student from the answer-key view (nothing is saved). School-tool dialogs close with Escape and return focus to the button that opened them.']});}catch(e){}
