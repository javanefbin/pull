(function(){
  "use strict";
  var V='50';
  function role(){try{return sessionStorage.getItem('mmRole')||'student'}catch(e){return 'student'}}
  function active(){try{return typeof activeStudent==='function'?activeStudent():null}catch(e){return null}}
  function currentLesson(){try{return typeof L==='function'?L():null}catch(e){return null}}
  function esc2(s){try{return typeof esc==='function'?esc(String(s||'')):String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}catch(e){return ''}}
  function objectiveForStudent(x){
    var s=String(x||'').trim();
    s=s.replace(/^Students will\s+/i,'You will ')
     .replace(/^Learners will\s+/i,'You will ')
     .replace(/^The student will\s+/i,'You will ')
     .replace(/^Students can\s+/i,'You can ')
     .replace(/^Learners can\s+/i,'You can ');
    if(!/^(You|Today|Try|Learn)/i.test(s)) s='Today you will '+s.charAt(0).toLowerCase()+s.slice(1);
    return s;
  }
  function minutes(s){var m=String(s||'').match(/(\d+)/);return m?parseInt(m[1],10):30}
  function worksheetDone(l){
    try{var st=active(); if(!st||!st.ws)return false; var k=typeof wsKey==='function'?wsKey(l.week):('week|'+l.week); var w=st.ws[k]; if(!w)return false; return Object.keys(w).some(function(x){return /^i\d+$/.test(x)&&String(w[x]||'').trim().length>0;});}catch(e){return false}
  }
  function quizScore(l){try{var p=typeof myProg==='function'?myProg():{}; var v=p['quiz|'+currentGrade+'|'+l.week]; return v==null?null:Number(v)}catch(e){return null}}
  function reflectionDone(l){
    try{
      var sid=typeof mmGameStudentId==='function'?mmGameStudentId():'default';
      var key='mmQuizReflection_v2|'+sid+'|'+currentGrade+'|'+(l?l.week:'');
      var v=JSON.parse(localStorage.getItem(key)||'null');
      return !!(v && (String(v.learned||'').trim() || String(v.realLife||'').trim() || String(v.confidence||'').trim()));
    }catch(e){return false;}
  }
  function renderSupport(){
    var box=document.getElementById('lessonObjectiveCard'), l=currentLesson(); if(!box||!l)return;
    var r=role(), q=quizScore(l), ws=worksheetDone(l), ref=reflectionDone(l), mins=minutes(l.duration);
    var mastered=q!=null&&q>=75;
    var status=mastered?(ref?'✓ Lesson complete':'✓ Quiz passed · Reflection next'):(q!=null?'↺ Quiz available again':'1. Learn · 2. Practice · 3. Quiz · 4. Reflection');
    var statusClass=mastered?'mm-status-good':'mm-status-next';
    var obj=r==='teacher'?String(l.objective||''):(objectiveForStudent(l.objective));
    var plan=r==='teacher'?'Plan: about '+Math.max(5,Math.round(mins*.2))+' min to start, '+Math.max(10,Math.round(mins*.45))+' min to teach/practice, '+Math.max(5,mins-Math.max(5,Math.round(mins*.2))-Math.max(10,Math.round(mins*.45)))+' min to check learning.':'Plan for about '+mins+' minutes. You can pause and come back anytime.';
    var steps=[
      {n:1,label:'Lesson',done:true},
      {n:2,label:'Worksheet',done:ws},
      {n:3,label:'Quiz',done:mastered},
      {n:4,label:'Reflection',done:ref}
    ];
    var flow=steps.map(function(s){
      return '<span class="mm-step '+(s.done?'done':'')+'"><b>'+s.n+'</b> '+s.label+(s.done?' ✓':'')+'</span>';
    }).join('<span class="mm-step-arrow">→</span>');
    box.innerHTML='<div class="card-title">🎯 '+(r==='teacher'?'Lesson Objective':'Today\'s Goal')+'</div>'+
      '<div class="card-body"><div>'+esc2(obj)+'</div><div class="mm-support-grid">'+
      '<div class="mm-support-mini"><b>⏱️ Time</b>'+esc2(plan)+'<div class="mm-timebar" aria-label="Estimated lesson time"><i></i></div></div>'+
      '<div class="mm-support-mini"><b>📍 Progress</b><div class="mm-step-flow" aria-label="Lesson progress">'+flow+'</div><span class="'+statusClass+'">'+esc2(status)+'</span><br><span style="font-size:12px">Worksheet: '+(ws?'complete':'ready')+(q!=null?' · Quiz: '+q+'%':'')+' · Reflection: '+(ref?'complete':'next')+'</span></div>'+
      '</div></div>';
  }
  function ensureStudentSafety(){
    if(role()!=='teacher'){
      var sec=document.getElementById('lessonMaterialsSection'); if(sec)sec.remove();
      document.querySelectorAll('#lessonMaterials,.materials-ready-check,.materials-checklist,.lesson-materials,.materials-list').forEach(function(e){if(e&&e.remove)e.remove()});
    }
  }
  function applyPromptsToWorksheet(l){
    if(!l||!l.worksheet)return [];
    var g=String(currentGrade);
    if(g==='K'||g==='1') return [
      'Point to or draw one example of today\'s money idea. What is it?',
      'Show one way you could use today\'s money skill at home or at school.'
    ];
    if(g==='2'||g==='3') return [
      'Make your own example using today\'s money skill. Show your work.',
      'You have to make a money choice today. What would you do, and why?'
    ];
    if(g==='4'||g==='5') return [
      'Create a new real-life example that uses today\'s money skill. Explain each step.',
      'Compare two choices related to today\'s lesson. Which is better for the situation, and why?'
    ];
    return [
      'Create a realistic scenario that requires today\'s money skill. Solve it and explain your reasoning.',
      'Evaluate two possible decisions related to today\'s lesson. Which would you recommend, and what evidence supports your choice?'
    ];
  }
  function wrapWorksheet(){
    if(typeof docWorksheetFillable==='function'&&!docWorksheetFillable.__v50){
      var old=docWorksheetFillable;
      var fn=function(l){
        var h=old(l), p=applyPromptsToWorksheet(l), body='<div class="mm-apply"><h3>⭐ Apply It</h3><p>These questions ask you to use the idea in a new situation. They are for thinking and explaining, not for a right-or-wrong score.</p>';
        p.forEach(function(q,i){body+='<p><b>'+(i+1)+'.</b> '+esc2(q)+'</p><textarea aria-label="Apply It response '+(i+1)+'" placeholder="Explain your thinking..."></textarea>';});
        body+='</div>';
        return h.replace('</div><div class="doc-note">Answers save automatically','</div>'+body+'<div class="doc-note">Answers save automatically');
      }; fn.__v50=true; docWorksheetFillable=fn;
    }
    if(typeof docWorksheet==='function'&&!docWorksheet.__v50){
      var old2=docWorksheet;
      var fn2=function(l){var h=old2(l),p=applyPromptsToWorksheet(l),body='<div class="mm-apply"><h3>⭐ Apply It</h3><p>Use today\'s idea in a new situation.</p>'+p.map(function(q,i){return '<p><b>'+(i+1)+'.</b> '+esc2(q)+'</p><div class="ws-box" style="min-height:65px"></div>';}).join('')+'</div>';return h.replace('<div class="doc-note">'+esc2(GRADE_LABEL[currentGrade])+' · Week '+l.week+'</div>',''+body+'<div class="doc-note">'+esc2(GRADE_LABEL[currentGrade])+' · Week '+l.week+'</div>');};
      fn2.__v50=true; docWorksheet=fn2;
    }
  }
  function improveReflection(){ return;
    var box=document.getElementById('v46-quiz-reflection'); if(box&&box.tagName==='SCRIPT')box=document.getElementById('quizReflection'); if(!box)return;
    var st=active(), id=(st&&st.id)||'anon', key='mm_reflection|'+currentGrade+'|'+(id||'anon')+'|'+(currentLesson()&&currentLesson().week||0);
    var qs=[
      'What is one thing you understand better after this quiz?',
      'Which question made you think the most, and why?',
      'How could you use today\'s money skill outside of school?',
      'What is one thing you would like to practice more?',
      'What is one money decision you could make differently because of what you learned?'
    ];
    var html='<h3 id="v50-reflection-title">Reflect on Your Learning</h3><p>Think about your learning. There are no right or wrong answers here.</p>';
    qs.forEach(function(q,i){html+='<label for="v50-r-'+i+'">'+esc2(q)+'<textarea id="v50-r-'+i+'" rows="3" placeholder="Write your reflection..."></textarea></label>';});
    html+='<button type="button" id="v50-save-r" class="btn-calc green">Save Reflection</button><span id="v50-r-status" role="status" aria-live="polite"></span>';
    box.innerHTML=html;
    var saved=[];try{saved=JSON.parse(localStorage.getItem(key)||'[]')}catch(e){}
    qs.forEach(function(_,i){var el=document.getElementById('v50-r-'+i);if(el&&saved[i])el.value=saved[i]});
    var svb=document.getElementById('v50-save-r'); if(svb)svb.onclick=function(){var vals=qs.map(function(_,i){return (document.getElementById('v50-r-'+i)||{}).value||''});try{localStorage.setItem(key,JSON.stringify(vals));}catch(e){}document.getElementById('v50-r-status').textContent=' Reflection saved.';};
  }
  function patchQuiz(){
    if(typeof submitQuiz==='function'&&!submitQuiz.__v50){
      var old=submitQuiz;
      var fn=function(){old();setTimeout(function(){improveReflection();renderSupport();},80)};fn.__v50=true;submitQuiz=fn;
    }
  }
  function improveAudit(){
    if(typeof runQualityAudit!=='function'||runQualityAudit.__v50)return;
    var old=runQualityAudit;
    var fn=function(){
      old();
      var el=document.getElementById('teacherBody');if(!el||role()!=='teacher')return;
      try{
        var grades=['K','1','2','3','4','5','6','7','8'], total=0,dups=0,short=0,bad=0,dist=[0,0,0,0],wsLow=0;
        grades.forEach(function(g){(LESSON_QUIZ[g]||[]).forEach(function(w){var seen={};var qs=w.questions||[];if(qs.length<4)short++;qs.forEach(function(q){total++;var k=String(q.q||'').trim().toLowerCase();if(seen[k])dups++;seen[k]=1;if(!Number.isInteger(q.answer)||q.answer<0||q.answer>=q.options.length)bad++;if(q.answer>=0&&q.answer<4)dist[q.answer]++;});});(LESSONS[g]||[]).forEach(function(l){if(!l.worksheet||!l.worksheet.items||l.worksheet.items.length<4)wsLow++;});});
        var totalD=dist.reduce(function(a,b){return a+b},0), max=Math.max.apply(null,dist),min=Math.min.apply(null,dist),balance=Math.round((1-(max-min)/Math.max(1,totalD))*100);
        var box=document.createElement('div');box.className='card';box.style.marginTop='12px';box.innerHTML='<div class="card-title">🔍 Instructional Quality Signals</div><div class="card-body"><b>'+total+'</b> quiz questions reviewed · <b>'+dups+'</b> repeated wordings detected · <b>'+short+'</b> quizzes below 4 questions · <b>'+bad+'</b> invalid answer indexes · <b>'+wsLow+'</b> worksheets below 4 items · answer-position balance <b>'+balance+'%</b>.</div><div class="card-body" style="font-size:12px;color:var(--ink-light)">These signals prioritize human review. Repetition is not automatically an error because reinforcement can be intentional.</div>';
        el.appendChild(box);
      }catch(e){}
    };fn.__v50=true;runQualityAudit=fn;
  }
  function refresh(){ensureStudentSafety();renderSupport();wrapWorksheet();patchQuiz();improveAudit();improveReflection();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refresh);else refresh();
  document.addEventListener('click',function(){setTimeout(refresh,120)},true);
  if(window.MutationObserver)new MutationObserver(function(){ensureStudentSafety()}).observe(document.documentElement,{childList:true,subtree:true});
})();
