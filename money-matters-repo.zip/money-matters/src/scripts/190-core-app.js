/* ===== DATA ===== */
const GRADE_LABEL={K:"Kindergarten","1":"Grade 1","2":"Grade 2","3":"Grade 3","4":"Grade 4","5":"Grade 5","6":"Grade 6","7":"Grade 7","8":"Grade 8"};
const GRADE_THEME={
  K:"Money is something we use to buy things; we can earn, save, and choose wisely.",
  "1":"Ways to pay, counting coins to a dollar, and the spend, save, share habit.",
  "2":"Earning income, adding money, making change, and setting saving goals.",
  "3":"Banks, interest, budgeting, comparing prices, and opportunity cost.",
  "4":"Percent money math: gross vs. net pay, discounts, tax, tips, and the 50/30/20 budget.",
  "5":"Assets, net worth, simple vs. compound interest, good vs. bad debt, and inflation.",
  "6":"Investing basics: stocks, bonds, diversification, index funds, and risk vs. return.",
  "7":"Credit scores, building credit, debit vs. credit, loans, and avoiding debt traps.",
  "8":"Taxes, entrepreneurship, retirement, insurance, financial independence, and a capstone."
};
const GRADE_ICON={K:"🪙","1":"🐷","2":"💵","3":"🏦","4":"%","5":"📊","6":"📈","7":"💳","8":"🎓"};

const LESSONS = /*@include data/LESSONS.json*/;

const SECTION_TESTS = /*@include data/SECTION_TESTS.json*/;

const LESSON_QUIZ = /*@include data/LESSON_QUIZ.json*/;

const LESSONS_L = /*@include data/LESSONS_L.json*/;

const SECTION_TESTS_L = /*@include data/SECTION_TESTS_L.json*/;

const LESSON_QUIZ_L = /*@include data/LESSON_QUIZ_L.json*/;

const FACTS = /*@include data/FACTS.json*/;

const MATERIAL_CARDS = /*@include data/MATERIAL_CARDS.json*/;

const PREVIEW=false; const PREVIEW_SAMPLE=2;

/* ===== STATE ===== */
let currentGrade="K",currentIndex=0,currentDoc="plan",welcomeVisible=false,openPanelId=null;
function lessons(){ const lg=loadLang(); if(lg!=='en'&&typeof LESSONS_L!=='undefined'&&LESSONS_L[lg]&&LESSONS_L[lg][currentGrade])return LESSONS_L[lg][currentGrade]; return LESSONS[currentGrade]||[]; }
function L(){return lessons()[currentIndex]}
function contentTranslated(){ const lg=loadLang(); return lg!=='en'&&typeof LESSONS_L!=='undefined'&&LESSONS_L[lg]&&!!LESSONS_L[lg][currentGrade]; }
/* esc / sanitise — one canonical HTML-escape function used everywhere.
   sanitise() is the primary name; esc() is an alias kept for compatibility
   with the large number of existing call sites. Both encode the five
   dangerous characters and strip any remaining < > to prevent injection. */
function sanitise(s){
  return (s==null?'':String(s))
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;')
    .replace(/`/g,'&#96;');
}
function esc(s){ return sanitise(s); }
function rewordSel(q){ return (q||'').replace(/\bcircle it\b/gi,'choose the correct answer').replace(/\bcircle\b/gi,'select').replace(/\bcolor\b/gi,'select'); }
function rewordWrite(q){ return (q||'').replace(/circle it/gi,'write your answer').replace(/^Circle or write/,'Write').replace(/^Circle/,'Choose').replace(/circle/gi,'choose').replace(/color/gi,'write').replace(/draw/gi,'describe'); }
function set(id,t){const e=document.getElementById(id);if(e)e.textContent=t}

/* ===== GRADE ===== */
function signedIn(){ const a=activeStudent(); return !!(a&&a.name&&a.name!=='Guest'); }
function gradeUnlocked(g){ if(loadRole()==='teacher')return true; if(previewOn())return true; if(!signedIn())return false; const a=activeStudent(); return a.grade===g; }
function pickGrade(g){ if(gradeUnlocked(g)){ setGrade(g); return; }
  if(loadRole()!=='teacher'&&!signedIn()){ alert(t('Please sign in first — open the Student desk to start your grade.')); openPanel('login'); }
  else { const a=activeStudent(); alert(t('You are enrolled in')+' '+gradeLabel(a?a.grade:currentGrade)+'.'); } }
function buildGradeNav(){
  document.getElementById('gradeNav').innerHTML=Object.keys(GRADE_LABEL).map(function(g){
    var locked=!gradeUnlocked(g);
    return '<button class="grade-btn'+(g===currentGrade?' active':'')+(locked?' locked':'')+'" data-g="'+g+'" onclick="pickGrade(\''+g+'\')" title="'+(locked?esc(t('Locked — sign in')):'')+'">'+(g==="K"?"K":g)+(locked?' 🔒':'')+'</button>';
  }).join('');
}
function refreshBoard(){
  set('boardCta',t('Now teaching')+' '+gradeLabel(currentGrade)+' · '+t('click the board for the full curriculum'));
  set('lessonsKicker',gradeLabel(currentGrade)+' · '+t('Lessons'));set('docKicker',gradeLabel(currentGrade));
}
function setGrade(g){
  currentGrade=g;currentIndex=0;
  try{document.body.classList.toggle('lower', g==='K'||g==='1'||g==='2');}catch(e){}
  buildGradeNav();
  refreshBoard();
  renderChips();loadLesson(0);populateDocSelect();
  if(openPanelId==='doc')renderDoc();
  if(openPanelId==='path')renderPath();
  if(openPanelId==='test')renderTestPanel();
  if(openPanelId==='overview')buildOverview();
  stopReading();
}

/* ===== LESSONS ===== */
function renderChips(){
  const box=document.getElementById('lessonChips');const ls=lessons();
  box.innerHTML=ls.map(function(l,i){ const lock=!weekUnlocked(i); const tag=lock?' 🔒':(isWeekDone(i)?' ✓':'');
    return '<button class="module-card'+(i===currentIndex?' active':'')+(lock?' locked':'')+'" onclick="'+(lock?('lockedMsg('+i+')'):('loadLesson('+i+',true)'))+'">'
    +'<div class="module-num">Week '+l.week+tag+'</div><div class="module-name">'+esc(l.title)+'</div>'
    +'<div class="module-desc"><span class="tag">'+esc(l.duration)+'</span><span class="tag">'+unitPhase(i)+'</span>'+esc(l.sub)+'</div></button>'; }).join('');
  renderLessonProgress();
  renderLexileBar();
}
function loadLesson(i,scroll){
  const ls=lessons();if(!ls.length)return;
  i=Math.max(0,Math.min(i,ls.length-1));
  if(!weekUnlocked(i)){ if(scroll)lockedMsg(i); return; }
  currentIndex=i;const l=ls[currentIndex];
  document.querySelectorAll('#lessonChips .module-card').forEach((c,idx)=>c.classList.toggle('active',idx===currentIndex));
  set('lessonKicker',GRADE_LABEL[currentGrade]+' › Unit '+(Math.floor(currentIndex/6)+1)+' › Week '+l.week);
  set('lessonTitle',l.title);set('lessonSub',l.sub);
  if(typeof renderSupport==='function'){}
  document.getElementById('lessonMeta').innerHTML='<span class="pill gold">'+esc(l.duration)+'</span><span class="pill">'+unitPhase(currentIndex)+'</span><span class="pill">Worksheet + quiz</span>';
  document.getElementById('lessonVocab').innerHTML=(l.vocab||[]).map(v=>'<div class="vocab-item"><div class="vocab-term">'+esc(v.term)+'</div><div class="vocab-def">'+esc(v.def)+'</div></div>').join('');var lm=document.getElementById('lessonMaterials');
  if(lm && loadRole()==='teacher'){
    var mats=l.materials||[];lm.innerHTML=(mats.length?'<div style="display:grid;gap:7px">'+mats.map(function(m,i){return '<label style="display:flex;gap:8px;align-items:flex-start;font-size:13px"><input type="checkbox" aria-label="Materials ready: '+esc(m)+'" onchange="this.parentElement.style.opacity=this.checked?.55:1"> <span>'+esc(m)+'</span></label>';}).join('')+'</div>':'<div style="color:#a33">No materials listed for this lesson. Add materials before teaching.</div>')+'<div style="margin-top:9px;font-size:11px;color:var(--ink-light)">Teacher preparation checklist.</div>';}
  const mel=document.getElementById('miniLesson'); if(mel)mel.innerHTML=annotateVocab(l.mini,l.vocab); set('warmUp',l.warmUp);set('independent',l.independent);
  document.getElementById('guidedList').innerHTML=(l.guidedPractice||[]).map(s=>'<li>'+esc(s)+'</li>').join('');
  document.getElementById('discussionList').innerHTML=(l.discussion||[]).map(s=>'<li>'+esc(s)+'</li>').join('');
  (function(){var qc=l.check||'';var ans=qc.match(/\s*\(\s*(?:Answer|Respuesta|Resposta)\s*:[^)]*\)/i);var clean=ans?qc.replace(ans[0],'').trim():qc;set('quickCheck',loadRole()==='teacher'?qc:clean);})();set('exitTicket',l.exit);
  const sel=document.getElementById('docLessonSel');if(sel)sel.value=String(currentIndex);
  if(window.speechSynthesis&&window.speechSynthesis.speaking)readVisibleLesson();
  if(scroll){recordView(currentGrade,l.week);touchStreak();const k=document.getElementById('lessonKicker');if(k)k.scrollIntoView({behavior:'smooth',block:'start'});}
}
function teacherNote(l){return "Objective: "+l.objective+" Open with the warm-up, teach the mini-lesson, then move through the guided steps before releasing students to independent practice. Use the quick check to confirm understanding before closing with the exit ticket.";}
function escRe(s){return (s||'').replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function annotateVocab(text,vocab){ let safe=esc(text||''); if(!vocab||!vocab.length)return safe;
  const byLen=vocab.map(function(v,i){return {i:i,term:v.term||''};}).filter(function(x){return x.term.length>1;}).sort(function(a,b){return b.term.length-a.term.length;});
  byLen.forEach(function(x){ try{ const re=new RegExp('(?<![\\w>])('+escRe(esc(x.term))+')(?![\\w<])','i'); safe=safe.replace(re,'<span class="vocab-tip" onclick="showTip(event,'+x.i+')">$1</span>'); }catch(e){} });
  return safe;
}
let tipVocab=null;
function showTip(ev,i){ ev.stopPropagation(); const l=L(); if(!l||!l.vocab||!l.vocab[i])return; tipVocab=l.vocab[i];
  let tip=document.getElementById('vocabTip'); if(!tip){ tip=document.createElement('div'); tip.id='vocabTip'; tip.className='vocab-pop'; document.body.appendChild(tip); tip.addEventListener('click',function(e){e.stopPropagation();}); }
  tip.innerHTML='<div class="vp-term">'+esc(tipVocab.term)+'<button class="vp-spk" onclick="speakTip()">🔊</button></div><div class="vp-def">'+esc(tipVocab.def)+'</div>';
  const x=Math.min((ev.clientX||100),window.innerWidth-244); const y=(ev.clientY||100)+14;
  tip.style.left=Math.max(8,x)+'px'; tip.style.top=Math.min(y,window.innerHeight-120)+'px'; tip.style.display='block';
}
function speakTip(){ if(tipVocab)speakText(tipVocab.term+'. '+tipVocab.def); }
document.addEventListener('click',function(){ const tp=document.getElementById('vocabTip'); if(tp)tp.style.display='none'; });

/* ===== VOICE ===== */
function voiceOK(){return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window}
function vstatus(m){set('voiceStatus',m)}
let _voices=[];
function loadVoices(){ if(voiceOK()){ try{_voices=window.speechSynthesis.getVoices()||[];}catch(e){_voices=[];} } }
if(voiceOK()){ loadVoices(); try{ window.speechSynthesis.onvoiceschanged=loadVoices; }catch(e){} }
function pickVoice(){ if(!_voices.length) loadVoices();
  return _voices.find(v=>/en[-_]US/i.test(v.lang))||_voices.find(v=>/^en/i.test(v.lang))||_voices[0]||null; }
function readVisibleLesson(){
  if(!voiceOK()){vstatus('Voice reading is not available on this device or browser. Try Chrome, Safari, or Edge.');return}
  try{window.speechSynthesis.cancel();}catch(e){}
  const l=L();if(!l)return;
  const lg=loadLang(); const code=lg==='es'?'es-ES':lg==='pt'?'pt-BR':'en-US';
  const script=[l.title,l.sub,t('Mini Lesson')+'. '+l.mini,t('Quick Check')+'. '+l.check].filter(Boolean).join('. ');
  const u=new SpeechSynthesisUtterance(script);u.rate=parseFloat(document.getElementById('voiceRate').value)||1;u.lang=code;
  if(!_voices.length)loadVoices(); const v=_voices.find(function(x){return x.lang&&x.lang.toLowerCase().indexOf(code.slice(0,2))===0;})||pickVoice(); if(v) u.voice=v;
  u.onend=()=>vstatus('Finished reading. Tap Read Aloud to hear it again.');
  u.onerror=()=>vstatus('Voice stopped. Some school or in-app browsers block speech; open in Chrome, Safari, or Edge.');
  try{ window.speechSynthesis.speak(u); vstatus('Reading the '+GRADE_LABEL[currentGrade]+' lesson aloud. Use Pause or Stop anytime.'); }
  catch(e){ vstatus('Could not start voice on this device.'); }
}
function pauseReading(){if(voiceOK()&&window.speechSynthesis.speaking&&!window.speechSynthesis.paused){window.speechSynthesis.pause();vstatus('Paused. Tap Resume to continue.')}}
function resumeReading(){if(voiceOK()&&window.speechSynthesis.paused){window.speechSynthesis.resume();vstatus('Resumed reading.')}}
function stopReading(){if(voiceOK()){try{window.speechSynthesis.cancel();}catch(e){}vstatus('Voice ready.')}}
function speakText(txt){ if(!voiceOK()||!txt)return; try{window.speechSynthesis.cancel();}catch(e){}
  const lg=loadLang(); const code=lg==='es'?'es-ES':lg==='pt'?'pt-BR':'en-US';
  const u=new SpeechSynthesisUtterance(txt); u.lang=code; u.rate=parseFloat((document.getElementById('voiceRate')||{}).value)||1;
  if(!_voices.length)loadVoices(); const v=_voices.find(function(x){return x.lang&&x.lang.toLowerCase().indexOf(code.slice(0,2))===0;}); if(v)u.voice=v;
  try{window.speechSynthesis.speak(u);}catch(e){} }

/* V46 accessibility interaction layer: focus management and keyboard-friendly dialogs. */
var _mmLastFocus=null;
function _mmFocusPanel(p){
  try{_mmLastFocus=document.activeElement;}catch(e){_mmLastFocus=null;}
  var f=p&&p.querySelector('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])');
  if(f)setTimeout(function(){try{f.focus();}catch(e){}},20);
}
function _mmRestoreFocus(){try{if(_mmLastFocus&&typeof _mmLastFocus.focus==='function')_mmLastFocus.focus();}catch(e){}}

/* ===== PANELS ===== */
function openPanel(id){
  if(id==='teacher'&&loadRole()!=='teacher')id='help';
  closePanel();const p=document.getElementById('panel-'+id);if(!p)return;
  p.classList.add('open');document.getElementById('backdrop').classList.add('open');openPanelId=id;_mmFocusPanel(p);
  document.querySelectorAll('#nav .nav-btn').forEach(b=>b.classList.remove('active'));
  /* special pre-render side-effects that aren't covered by the renderer itself */
  if(id==='lessons'&&activeStudent()){ const _l=lessons()[currentIndex]; if(_l)recordView(currentGrade,_l.week); }
  if(id==='certificate'){ const ci=document.getElementById('certName'); if(ci&&studentName())ci.value=studentName(); }
  if(id==='a11y')applyA11y();
  /* use registry for all panel renders — single source of truth */
  _runPanelRenderer(id);
  const pb=p.querySelector('.panel-body');if(pb)pb.scrollTop=0;
}
function closePanel(force){
  if(_quizInProgress&&!force&&openPanelId==='quiz'){
    mmConfirm('Leave the quiz?','Your answers will be lost if you close now. Come back to restart.','Leave quiz','⚠️').then(function(ok){ if(ok){_quizInProgress=false;closePanel(true);} });
    return;
  }
  _quizInProgress=false;
  document.querySelectorAll('.panel.open').forEach(p=>p.classList.remove('open'));
  document.getElementById('backdrop').classList.remove('open');openPanelId=null;stopReading();_mmRestoreFocus();
}
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){closePanel();return}
  if(openPanelId==='lessons'&&!/^(INPUT|SELECT|TEXTAREA)$/.test((e.target||{}).tagName||'')){
    if(e.key==='ArrowRight'){loadLesson(currentIndex+1)} if(e.key==='ArrowLeft'){loadLesson(currentIndex-1)}
  }
});
function toggleWelcome(){welcomeVisible=!welcomeVisible;document.getElementById('welcome-panel').classList.toggle('hidden',!welcomeVisible);}

/* ===== OVERVIEW ===== */
function buildOverview(){
  set('ovKicker','Money Matters · '+(GRADE_ICON[currentGrade]||'')+' '+GRADE_LABEL[currentGrade]);
  set('ovTitle',GRADE_LABEL[currentGrade]+' — '+t('Overview'));
  const ls=lessons(); const tCount=(typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[currentGrade])?SECTION_TESTS[currentGrade].length:0;
  set('ovSub',ls.length+' weekly lessons · '+tCount+' checkpoint tests · full 36-week year');
  set('ovGoalLabel','This Grade');
  set('ovGoal',GRADE_THEME[currentGrade]);
  let h='';
  for(let u=0;u<6;u++){ const block=ls.slice(u*6,u*6+6); if(!block.length)continue;
    const wk=(u*6+1)+'-'+Math.min(u*6+6,ls.length);
    h+='<div class="unit-card"><div class="unit-head"><div class="unit-title">Unit '+(u+1)+' · Weeks '+wk+'</div>'
      +'<button class="btn-calc" style="background:#7a1e4d" onclick="openTest('+u+')">🧪 Checkpoint '+(u+1)+'</button></div><div class="wk-row">'
      +block.map(function(l){const idx=ls.indexOf(l);return '<button class="wk-chip" onclick="gotoLesson('+idx+')">Wk '+l.week+': '+esc(l.title)+'</button>';}).join('')+'</div></div>';
  }
  if(!ls.length) h='<div class="who">Lessons for this grade are loading.</div>';
  document.getElementById('overviewGrades').innerHTML=previewBanner()+h;
}

/* ===== DOCUMENTS ===== */
function openDoc(kind){ if(kind==='guide'&&loadRole()!=='teacher')kind='plan'; currentDoc=kind;openPanel('doc');switchDoc(kind);}
function switchDoc(kind){
  if(kind==='guide'&&loadRole()!=='teacher')kind='plan';
  currentDoc=kind;
  ['plan','worksheet','workbook','family','guide'].forEach(k=>{const b=document.getElementById('db-'+k);
    if(b) b.classList.toggle('active',k===kind);});
  const titles={plan:"Lesson Plan",worksheet:"Student Worksheet",workbook:"Student Workbook",family:"Family Guide",guide:"Teacher's Guide"};
  set('docTitle',titles[kind]);set('docKicker',GRADE_LABEL[currentGrade]);
  const nx=document.getElementById('docNext');
  if(nx){ if(kind==='plan'){nx.style.display='';nx.textContent=t('Next: Worksheet →');nx.onclick=function(){openDoc('worksheet');};}
    else if(kind==='worksheet'){nx.style.display='';nx.textContent=t('Next: Quiz →');nx.onclick=function(){openQuiz();};}
    else {nx.style.display='none';} }
  populateDocSelect();renderDoc();
  const pb=document.querySelector('#panel-doc .panel-body');if(pb)pb.scrollTop=0;
}
function populateDocSelect(){
  const sel=document.getElementById('docLessonSel');if(!sel)return;
  const ls=lessons();
  if(!weekUnlocked(currentIndex)){ for(var n=0;n<ls.length;n++){ if(weekUnlocked(n)){currentIndex=n;break;} } }
  sel.innerHTML=ls.map(function(l,i){ return weekUnlocked(i)?('<option value="'+i+'">Week '+l.week+' — '+esc(l.title)+'</option>'):''; }).join('');
  sel.value=String(currentIndex);
  sel.style.display=(currentDoc==='plan'||currentDoc==='worksheet')?'':'none';
}
function onDocLessonChange(){currentIndex=parseInt(document.getElementById('docLessonSel').value)||0;renderDoc();}
function renderDoc(){
  const area=document.getElementById('printArea');if(!area)return;
  if(!lessons().length){area.innerHTML='<div class="paper"><h1>'+GRADE_LABEL[currentGrade]+'</h1><p>Content loading…</p></div>';return}
  if((currentDoc==='plan'||currentDoc==='worksheet')&&!weekUnlocked(currentIndex)){ area.innerHTML='<div class="paper"><h1>🔒 Locked</h1><p>Finish the earlier weeks first — pass each week\'s quiz (75 percent) to unlock this one.</p></div>'; return; }
  if(currentDoc==='plan')area.innerHTML=docPlan(L());
  else if(currentDoc==='worksheet')area.innerHTML=docWorksheetFillable(L());
  else if(currentDoc==='workbook')area.innerHTML=docWorkbook();
  else if(currentDoc==='family')area.innerHTML=docFamily(L());
  else if(currentDoc==='guide')area.innerHTML=docGuide();
}
function docFamily(l){
  var chk=(l.check||''),ans='',m=chk.match(/^(.*?)\s*\(Answer:\s*(.*?)\)\s*$/); if(m){chk=m[1];ans=m[2];}
  return '<div class="paper"><div class="doc-kicker">Money Matters \u00B7 '+GRADE_LABEL[currentGrade]+' \u00B7 Family Guide</div>'
   +'<h1>Week '+l.week+': '+esc(l.title)+'</h1>'
   +'<h2>What your child is learning</h2><p>'+esc(l.sub||'')+'</p><p>'+esc(l.objective||'')+'</p>'
   +'<h2>Words to know</h2><ul>'+(l.vocab||[]).map(function(v){return '<li><b>'+esc(v.term)+':</b> '+esc(v.def)+'</li>';}).join('')+'</ul>'
   +'<h2>Talk about it together</h2><ul>'+(l.discussion||[]).map(function(d){return '<li>'+esc(d)+'</li>';}).join('')+'</ul>'
   +(l.independent?'<h2>Try it at home</h2><p>'+esc(l.independent)+'</p>':'')
   +(chk?'<h2>Quick check</h2><p>'+esc(chk)+'</p>'+(ans?'<p class="doc-note"><i>For the adult: '+esc(ans)+'</i></p>':''):'')
   +'<h2>How to help</h2><ul><li>Read the lesson together, then let your child try the worksheet first.</li><li>Praise effort and ask, \u201CHow did you figure that out?\u201D</li><li>A quiz score of 75 percent unlocks the next week.</li><li>Progress is saved on this device only. Use the gear button to make a backup.</li></ul>'
   +'<div class="doc-note">'+GRADE_LABEL[currentGrade]+' \u00B7 Week '+l.week+'</div></div>';
}
function docPlan(l){
  return '<div class="paper"><div class="doc-kicker">Money Matters · '+GRADE_LABEL[currentGrade]+' · Lesson Plan</div>'
    +'<h1>Week '+l.week+': '+esc(l.title)+'</h1>'
    +'<div class="doc-meta"><b>Duration:</b> '+esc(l.duration)+'</div>'
    +'<div class="doc-meta"><b>Objective:</b> '+esc(l.objective)+'</div>'
    +'<h2>Standards</h2><ul>'+l.standards.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ul>'
    +'<h2>Vocabulary</h2><ul>'+l.vocab.map(v=>'<li><b>'+esc(v.term)+':</b> '+esc(v.def)+'</li>').join('')+'</ul>'
    +'<h2>Materials</h2><ul>'+l.materials.map(m=>'<li>'+esc(m)+'</li>').join('')+'</ul>'
    +(l.prep?('<h2>Preparation</h2><p>'+esc(l.prep)+'</p>'):'')
    +'<h2>Warm-Up</h2><p>'+esc(l.warmUp)+'</p>'
    +'<h2>Mini-Lesson</h2><p>'+esc(l.mini)+'</p>'
    +'<h2>Guided Practice</h2><ol>'+l.guidedPractice.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ol>'
    +'<h2>Independent Practice</h2><p>'+esc(l.independent)+'</p>'
    +'<h2>Discussion Questions</h2><ul>'+l.discussion.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ul>'
    +'<h2>Formative Assessment (Quick Check)</h2><div class="callout">'+esc(l.check)+'</div>'
    +'<h2>Differentiation</h2><div class="two"><div><h3>Support</h3><p>'+esc(l.differentiation.support)+'</p></div>'
      +'<div><h3>Challenge</h3><p>'+esc(l.differentiation.challenge)+'</p></div></div>'
    +'<h2>Home Extension</h2><p>'+esc(l.homeExtension)+'</p>'
    +'<h2>Exit Ticket</h2><div class="callout">'+esc(l.exit)+'</div>'
    +'<div class="doc-note">Money Matters — K–8 Financial Literacy Curriculum</div></div>';
}
function wsBody(l,showName){
  let h='<p class=\"ws-directions\"><b>Directions:</b> '+esc(rewordWrite(l.worksheet.intro))+'</p>'; if(showName)h+='<div class="doc-meta" style="margin:8px 0 4px"><b>Name:</b> _______________________  <b>Date:</b> ____________</div>';
  l.worksheet.items.forEach((it,i)=>{h+='<div class="ws-item"><div class="ws-q">'+(i+1)+'. '+esc(rewordWrite(it.q))+'</div>';
    if(/draw|describe/i.test(it.q))h+='<div class="ws-box"></div>';
    else{h+='<div class="ws-line"></div>';if((it.answer||'').length>40)h+='<div class="ws-line"></div>';} h+='</div>';});
  if(currentGrade!=='K'&&currentGrade!=='1'&&currentGrade!=='2'){ h+='<div class="ws-item challenge-item"><div class="ws-q">'+(l.worksheet.items.length+1)+'. Money Matters Challenge: Explain one real-life choice where you could use today’s lesson. What would you do, and why?</div><div class="ws-box" style="min-height:70px"></div></div>'; }
  return h;
}
function docWorksheetFillable(l){
  const saved=wsGet(l.week); const wk=l.week; const nmVal=(saved.name!=null?saved.name:studentName());
  let h='<div class="paper"><div class="doc-kicker">Money Matters · '+GRADE_LABEL[currentGrade]+' · Student Worksheet</div>'
    +'<h1>Week '+l.week+': '+esc(l.title)+'</h1>'
    +'<p class="ws-directions"><b>Directions:</b> '+esc(rewordWrite(l.worksheet.intro))+'</p>'
     +'<div class="doc-meta ws-namedate"><b>Name:</b> <input class="ws-fill" id="wsName" style="width:190px" value="'+esc(nmVal)+'" oninput="wsAutoSave('+wk+')"> &nbsp; <b>Date:</b> <input class="ws-fill" id="wsDate" style="width:120px" value="'+esc(saved.date||'')+'" oninput="wsAutoSave('+wk+')"></div>';
  l.worksheet.items.forEach(function(it,i){ const val=esc(saved['i'+i]||'');
    h+='<div class="ws-item"><div class="ws-q">'+(i+1)+'. '+esc(rewordWrite(it.q))+'</div>';
    if(/draw|color|describe/i.test(it.q)) h+='<textarea class="ws-fill" id="wf-'+i+'" rows="2" placeholder="Write or describe your answer" oninput="wsAutoSave('+wk+')">'+val+'</textarea>';
    else if(/^(yes|no|sí|si|sim|não|nao)$/i.test((it.answer||'').trim())){var _y=t('Yes'),_n=t('No');h+='<select class="ws-fill" id="wf-'+i+'" aria-label="Yes or no" onchange="wsAutoSave('+wk+')"><option value="">'+esc(t('Choose one'))+'</option><option'+(val===esc(_y)?' selected':'')+'>'+esc(_y)+'</option><option'+(val===esc(_n)?' selected':'')+'>'+esc(_n)+'</option></select>';} else h+='<input class="ws-fill" id="wf-'+i+'" type="text" style="width:100%" placeholder="Write your answer" value="'+val+'" oninput="wsAutoSave('+wk+')">';
    h+='<div class="q-fb" id="wfb-'+i+'"></div></div>';
  });
  if(currentGrade!=='K'&&currentGrade!=='1'&&currentGrade!=='2'){ h+='<div class="ws-item challenge-item"><div class="ws-q">'+(l.worksheet.items.length+1)+'. Money Matters Challenge: Explain one real-life choice where you could use today’s lesson. What would you do, and why?</div><textarea class="ws-fill" id="wf-challenge" rows="4" placeholder="Explain your thinking..."></textarea></div>'; }
  h+='<div class="meta-pills" style="margin-top:12px"><button class="btn-calc green" onclick="checkWorksheet()">'+esc(t('✅ Check my answers'))+'</button><button class="btn-calc" onclick="readWorksheetAloud()">'+esc(t('🔊 Read aloud'))+'</button><button class="btn-calc ghost" onclick="clearWorksheet('+wk+')">'+esc(t('↺ Clear'))+'</button></div>'
    +'<div class="doc-note">Answers save automatically for the signed-in student. Print or Download gives a blank copy.</div></div>';
  return h;
}
function clearWorksheet(week){ const s=loadStore(); if(s.active&&s.list[s.active]&&s.list[s.active].ws){ delete s.list[s.active].ws[wsKey(week)]; saveStore(s); } renderDoc(); }
function checkWorksheet(){ const l=L(); if(!l)return; l.worksheet.items.forEach(function(it,i){ const el=document.getElementById('wf-'+i); const ok=gradeAns(el?el.value:'',it.answer,it.q); const fb=document.getElementById('wfb-'+i); if(fb){ fb.className='q-fb '+(ok?'ok':'no'); fb.innerHTML=(ok?'Looks good! ':'Check this — Try the lesson example again and explain your thinking.'); } if(el){ el.style.borderColor=ok?'#2a6b4a':'#c86a4a'; } }); }
function docWorksheet(l){
  return '<div class="paper"><div class="doc-kicker">Money Matters · '+GRADE_LABEL[currentGrade]+' · Student Worksheet</div>'
    +'<h1>Week '+l.week+': '+esc(l.title)+'</h1>'+wsBody(l,true)
    +'<div class="doc-note">'+GRADE_LABEL[currentGrade]+' · Week '+l.week+'</div></div>';
}
function docWorkbook(){
  const lim=typeof window.mmSampleLimited==='function'&&window.mmSampleLimited();
  const all=lessons(); const ls=lim?all.slice(0,1):all.filter(function(l,i){return weekUnlocked(i);}); const hidden=lim?0:all.length-ls.length;
  let h='<div class="paper"><div class="doc-kicker">Money Matters · Student Workbook</div>'
    +'<h1>'+GRADE_LABEL[currentGrade]+' Workbook</h1><p class="doc-meta">'+esc(GRADE_THEME[currentGrade])+'</p>'
    +'<div class="doc-meta"><b>Name:</b> _______________________  <b>Class:</b> ____________</div>'
    +'<h2>Contents</h2><ol>'+ls.map(function(l){return '<li>Week '+l.week+' — '+esc(l.title)+'</li>';}).join('')+'</ol>'
    +(lim?'<div class="callout"><b>Sample edition</b> · This sample includes Lesson 1. The full program adds weeks 2–36.</div>':'')
    +(hidden>0?'<div class="callout">'+hidden+' later week(s) are locked and will appear here once the earlier weeks are completed.</div>':'')
    +'<div class="doc-note">Complete one worksheet each lesson. Keep this workbook all year.</div></div>';
  ls.forEach(function(l){h+='<div class="paper page-break"><div class="doc-kicker">'+GRADE_LABEL[currentGrade]+' Workbook · Week '+l.week+'</div>'
    +'<h1>'+esc(l.title)+'</h1><div class="callout"><b>Big idea:</b> '+esc(l.sub)+'</div>'+wsBody(l,true)+'</div>';});
  return h;
}
function docGuide(){
  const lim=typeof window.mmSampleLimited==='function'&&window.mmSampleLimited();
  const ls=lessons();
  let h='<div class="paper"><div class="doc-kicker">Money Matters · Teacher\'s Guide</div>'
    +'<h1>'+GRADE_LABEL[currentGrade]+' Teacher\'s Guide</h1><p>'+esc(GRADE_THEME[currentGrade])+'</p>'
    +'<div class="callout"><b>How to use this guide:</b> Each lesson is about one class period per week. Open with the warm-up, deliver the mini-lesson, work through guided practice together, then release students to the worksheet. Use the quick check and exit ticket to gauge understanding. Answer keys for every worksheet are below.</div>'
    +'<h2>Scope &amp; Sequence</h2><table><tr><th>Week</th><th>Lesson</th><th>Objective</th></tr>'
    +(lim?ls.slice(0,1):ls).map(l=>'<tr><td>'+l.week+'</td><td>'+esc(l.title)+'</td><td>'+esc(l.objective)+'</td></tr>').join('')+'</table>'
    +'<h2>Pacing (36-week year)</h2><ul><li><b>Weeks 1–12 — Foundations:</b> core vocabulary and concepts.</li>'
      +'<li><b>Weeks 13–24 — Skills &amp; applications:</b> practice and problem solving.</li>'
      +'<li><b>Weeks 25–36 — Decisions &amp; projects:</b> apply learning, review, capstone.</li></ul>'
    +(lim?'<div class="callout"><b>Sample edition</b> · This sample includes Lesson 1. The full program adds weeks 2–36.</div>':'')
    +'<div class="doc-note">Money Matters — K–8 Financial Literacy Curriculum</div></div>';
  (lim?ls.slice(0,1):ls).forEach(l=>{h+='<div class="paper page-break"><div class="doc-kicker">'+GRADE_LABEL[currentGrade]+' Teacher\'s Guide · Week '+l.week+'</div>'
    +'<h1>'+esc(l.title)+'</h1><div class="doc-meta"><b>Objective:</b> '+esc(l.objective)+'</div>'
    +'<div class="doc-meta"><b>Duration:</b> '+esc(l.duration)+'</div>'
    +'<h2>Materials &amp; Preparation</h2><ul>'+(l.materials||[]).map(m=>'<li>'+esc(m)+'</li>').join('')+'</ul>'+(l.prep?('<div class="callout"><b>Prep:</b> '+esc(l.prep)+'</div>'):'')
    +'<h2>Facilitation Notes</h2><p>'+esc(teacherNote(l))+'</p>'
    +'<h2>Differentiation</h2><div class="two"><div><h3>Support</h3><p>'+esc(l.differentiation.support)+'</p></div>'
      +'<div><h3>Challenge</h3><p>'+esc(l.differentiation.challenge)+'</p></div></div>'
    +'<h2>Worksheet Answer Key</h2><ol>'+l.worksheet.items.map(it=>'<li>'+esc(it.q)+'<br><span class="answer">'+esc(it.answer)+'</span></li>').join('')+'</ol>'
    +'<h2>Exit Ticket</h2><div class="callout">'+esc(l.exit)+'</div></div>';});
  return h;
}

/* ===== DOWNLOAD (.doc, client-side) ===== */
const PAPER_CSS="body{font-family:Georgia,serif;color:#111;margin:24px;line-height:1.5;} .paper{max-width:780px;margin:0 auto 18px;} h1{font-size:22px;margin:0 0 6px;} h2{font-size:14px;margin:16px 0 6px;padding-bottom:3px;border-bottom:2px solid #c4912e;text-transform:uppercase;letter-spacing:.06em;color:#7a5a1e;font-family:Arial,sans-serif;} h3{font-size:13px;margin:10px 0 4px;} .doc-kicker{font-family:Arial,sans-serif;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#8a5e10;font-weight:bold;margin-bottom:4px;} .doc-meta{font-family:Arial,sans-serif;font-size:12px;color:#555;margin:2px 0;} .callout{background:#f7edda;border:1px solid #e3c78f;border-left:4px solid #c4912e;padding:8px 10px;margin:8px 0;font-family:Arial,sans-serif;font-size:12.5px;} table{border-collapse:collapse;width:100%;margin:8px 0;} th,td{border:1px solid #ccc;padding:6px 8px;font-family:Arial,sans-serif;font-size:12px;text-align:left;vertical-align:top;} th{background:#f3e9d6;} .ws-line{border-bottom:1px solid #bbb;height:24px;margin:6px 0;} .ws-box{border:1px solid #bbb;height:80px;margin:6px 0;} .answer{color:#2a6b4a;font-weight:bold;} .answer:before{content:'Answer: ';color:#7a5a1e;} .page-break{page-break-before:always;} .doc-note{font-family:Arial,sans-serif;font-size:11px;color:#888;text-align:center;margin-top:8px;} ol,ul{padding-left:22px;} li{margin-bottom:5px;}";
function docHTMLFor(kind){
  if(kind==='plan')return docPlan(L());
  if(kind==='worksheet')return docWorksheet(L());
  if(kind==='workbook')return docWorkbook();
  if(kind==='family')return docFamily(L());
  if(kind==='guide')return docGuide();
  return '';
}
function docFilename(kind){
  const g=GRADE_LABEL[currentGrade].replace(/\s+/g,'');
  if(kind==='plan')return 'MoneyMatters_'+g+'_LessonPlan_Week'+L().week+'.doc';
  if(kind==='worksheet')return 'MoneyMatters_'+g+'_Worksheet_Week'+L().week+'.doc';
  if(kind==='workbook')return 'MoneyMatters_'+g+'_Workbook.doc';
  if(kind==='guide')return 'MoneyMatters_'+g+'_TeacherGuide.doc'; if(kind==='family')return 'MoneyMatters_'+g+'_FamilyGuide_Week'+L().week+'.doc';
  return 'MoneyMatters.doc';
}
function downloadPacket(){ const l=L(); if(!l)return; if(loadRole()!=='teacher'&&!lessonViewed(currentIndex)){ alert(t('Finish the lesson first to unlock this download.')); return; }
  const ak='<div class="paper"><div class="doc-kicker">'+esc(gradeLabel(currentGrade))+' · '+esc(t('Answer Key'))+'</div><h1>'+esc(t('Answer Key'))+' — '+esc(t('Week'))+' '+l.week+'</h1><ol>'+(l.worksheet.items||[]).map(function(it){return '<li>'+esc(it.q)+'<br><b>'+esc(it.answer)+'</b></li>';}).join('')+'</ol></div>';
  const body=docPlan(l)+'<div class="page-break"></div>'+docWorksheet(l)+'<div class="page-break"></div>'+ak;
  const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Packet</title><style>'+PAPER_CSS+'</style></head><body>'+body+'\n</body></html>';
  try{ const b=new Blob(['﻿'+html],{type:'application/msword'}); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='MoneyMatters_Packet_'+currentGrade+'_wk'+l.week+'.doc'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){ alert('Download not supported in this browser. Use Print / Save PDF instead.'); }
}
function downloadDoc(kind){
  kind=kind||currentDoc;
  if(!lessons().length)return;
  if(loadRole()!=='teacher'&&!lessonViewed(currentIndex)){ alert(t('Finish the lesson first to unlock this download.')); return; }
  const body=docHTMLFor(kind);
  const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Money Matters</title><style>'+PAPER_CSS+'</style></head><body>'+body+'\n</body></html>';
  try{
    const blob=new Blob(['﻿'+html],{type:'application/msword'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=docFilename(kind);
    document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);
  }catch(e){ alert('Download not supported in this browser. Use Print / Save PDF instead.'); }
}

/* ===== STUDENTS (local profiles) + PROGRESS ===== */
const SKEY='mmStudents_v2'; let _memS=null;
function _defStore(){ return {active:null,list:{}}; }

/* ===== MULTI-TAB SYNC ===== */
/* Each browser tab keeps its OWN active-student session via sessionStorage,
   so two tabs can display two different students at the same time on the
   same device. The shared student roster lives in localStorage; when any
   tab writes it, a BroadcastChannel message refreshes all sibling tabs
   instantly without a page reload. Falls back to the legacy storage event
   for browsers that don't support BroadcastChannel (old Safari / WebView). */
const _TAB_KEY='mmTabActive';
let _syncChannel=null;
(function _initSync(){
  try{
    _syncChannel=new BroadcastChannel('mm_sync');
    _syncChannel.onmessage=function(e){
      if(e.data&&e.data.type==='store_updated'){
        _memS=null;
        _onExternalStoreChange();
      }
    };
  }catch(err){
    window.addEventListener('storage',function(e){
      if(e.key===SKEY){ _memS=null; _onExternalStoreChange(); }
    });
  }
})();
function _broadcastStoreChange(){
  if(_syncChannel){ try{ _syncChannel.postMessage({type:'store_updated'}); }catch(e){} }
}
function _onExternalStoreChange(){
  try{ refreshStudentUI(); }catch(e){}
  const id=openPanelId;
  if(id==='teacher')try{renderTeacher();}catch(e){}
  else if(id==='login')try{renderLogin();}catch(e){}
  else if(id==='overview')try{buildOverview();}catch(e){}
  else if(id==='certificate')try{renderPrizeSummary();renderCert();}catch(e){}
  else if(id==='path')try{renderPath();}catch(e){}
}

/* Per-tab active student — isolated in sessionStorage */
function getTabActive(){ try{ return sessionStorage.getItem(_TAB_KEY)||null; }catch(e){ return null; } }
function setTabActive(id){ try{ if(id)sessionStorage.setItem(_TAB_KEY,id); else sessionStorage.removeItem(_TAB_KEY); }catch(e){} }

function loadStore(){ try{return JSON.parse(localStorage.getItem(SKEY)||'null')||_defStore();}catch(e){return _memS||(_memS=_defStore());} }
function saveStore(o){ _memS=o; try{localStorage.setItem(SKEY,JSON.stringify(o));}catch(e){} _broadcastStoreChange(); }
/* Augment saveStore immediately after definition so all callers benefit */
(function(){
  const _origSave=saveStore;
  let _lastSaveHash='';
  saveStore=function(o){
    _origSave(o);
    try{
      const id=getTabActive()||o.active;
      const h=JSON.stringify({a:id,p:id&&o.list[id]?o.list[id].prog:null});
      if(h!==_lastSaveHash){ _lastSaveHash=h; showSaveToast('✓ Progress saved'); }
    }catch(e){}
  };
})();

/* activeStudent always resolves to THIS tab's student first */
function activeStudent(){
  const s=loadStore();
  const id=getTabActive()||s.active;
  return (id&&s.list[id])?s.list[id]:null;
}
function _activeId(){ const s=loadStore(); return getTabActive()||s.active||null; }
function studentName(){ const a=activeStudent(); return a?a.name:''; }
function newId(){
  try{
    const arr=new Uint8Array(8); crypto.getRandomValues(arr);
    return 's_'+Array.from(arr).map(function(b){return b.toString(16).padStart(2,'0');}).join('');
  }catch(e){ return 's_'+Date.now().toString(36)+Math.random().toString(36).slice(2,10); }
}
function createStudent(name,grade,teacher){ name=(name||'').trim().slice(0,40); if(!name)return; const s=loadStore(); const id=newId(); s.list[id]={id:id,name:name,grade:grade||currentGrade,prog:{}}; if(teacher&&(''+teacher).trim()){ const tn=(''+teacher).trim().slice(0,60); s.list[id].teacher=tn; if(!s.teachers)s.teachers=[]; if(s.teachers.indexOf(tn)<0)s.teachers.push(tn); } s.active=id; setTabActive(id); saveStore(s); refreshStudentUI(); setGrade(s.list[id].grade); renderLogin(); openPanel('dashboard'); }
function createStudentFromForm(){ const n=document.getElementById('newStudentName'); const g=document.getElementById('newStudentGrade'); const tch=document.getElementById('newStudentTeacher'); createStudent(n?n.value:'', g?g.value:currentGrade, tch?tch.value:''); }
/* ===== TEACHERS + IMPORT ===== */
function teacherList(){ const s=loadStore(); return s.teachers||[]; }
function addTeacherName(name){ name=(''+name||'').trim().slice(0,60); if(!name)return false; const s=loadStore(); if(!s.teachers)s.teachers=[]; if(s.teachers.indexOf(name)<0){s.teachers.push(name);saveStore(s);return true;} return false; }
function addTeacherFromForm(){ const el=document.getElementById('newTeacherName'); if(!el||!el.value.trim()){return;} addTeacherName(el.value); if(openPanelId==='teacher')renderTeacher(); }
function normGrade(g){ g=(''+g).trim().toLowerCase(); if(!g)return 'K'; if(g==='k'||g.indexOf('kinder')>-1||g.indexOf('jard')>-1)return 'K'; const m=g.match(/[1-8]/); return m?m[0]:'K'; }
function importRosterText(text){ if(!text||!text.trim()){ alert(t('Paste a roster or choose a CSV file first.')); return; }
  const s=loadStore(); if(!s.teachers)s.teachers=[]; const lines=text.split(/\r?\n/); let aS=0,aT=0,sk=0,upd=0;
  function findExisting(name,grade){ var hit=null; Object.keys(s.list).forEach(function(id){ var st=s.list[id]; if(st.name&&st.name.toLowerCase()===name.toLowerCase()&&(st.grade||'K')===grade)hit=id; }); return hit; }
  lines.forEach(function(line,idx){ line=line.trim(); if(!line)return;
    if(/^teacher\s*[:,-]/i.test(line)){ const tn=line.replace(/^teacher\s*[:,-]\s*/i,'').split(/[,;\t]/)[0].trim().slice(0,60); if(tn&&s.teachers.indexOf(tn)<0){s.teachers.push(tn);aT++;} return; }
    const parts=line.split(/[,;\t]/).map(function(x){return x.trim();});
    if(idx===0 && /^(name|student|first)/i.test(parts[0])) return;
    const name=(parts[0]||'').slice(0,40); if(!name){sk++;return;}
    const grade=normGrade(parts[1]||''); const teacher=(parts[2]||'').slice(0,60);
    var exId=findExisting(name,grade);
    if(exId){ s.list[exId].grade=grade; if(teacher)s.list[exId].teacher=teacher; upd++; }
    else { const id=newId(); const rec={id:id,name:name,grade:grade,prog:{}}; if(teacher)rec.teacher=teacher; s.list[id]=rec; aS++; }
    if(teacher && s.teachers.indexOf(teacher)<0){ s.teachers.push(teacher); aT++; }
  });
  saveStore(s); refreshStudentUI(); buildGradeNav(); if(openPanelId==='teacher')renderTeacher();
  infoToast('✅ '+aS+' '+t('students imported')+(upd?(' · '+upd+' '+t('updated')):'')+' · '+aT+' '+t('teachers added')+(sk?(' · '+sk+' '+t('rows skipped')):'')); }
function importRosterFile(ev){ const f=ev.target&&ev.target.files&&ev.target.files[0]; if(!f)return; const r=new FileReader(); r.onload=function(){ importRosterText(String(r.result||'')); }; r.readAsText(f); try{ev.target.value='';}catch(e){} }
function importRosterPaste(){ const el=document.getElementById('rosterPaste'); importRosterText(el?el.value:''); }
var teacherFilter='';
var teacherGradeFilter='';
var teacherStudentFilter='';
function setTeacherFilter(v){ teacherFilter=v||''; teacherStudentFilter=''; if(openPanelId==='teacher')renderTeacher(); }
function setTeacherGradeFilter(v){ teacherGradeFilter=v||''; teacherStudentFilter=''; if(openPanelId==='teacher')renderTeacher(); }
function setTeacherStudentFilter(v){ teacherStudentFilter=v||''; if(openPanelId==='teacher')renderTeacher(); }
function itemAnalysisReport(){ const s=loadStore(); const st=s.stats||{}; var rows=[]; Object.keys(st).forEach(function(k){ var o=st[k]; if(!o||!o.seen)return; var p=k.split('|'); rows.push({g:p[0],wk:p[1],qi:parseInt(p[2]),seen:o.seen,miss:o.miss,rate:o.miss/o.seen}); });
  if(!rows.length){ alert(t('No quiz data yet — item analysis appears after students take quizzes.')); return; }
  rows.sort(function(a,b){return (b.rate-a.rate)||(b.miss-a.miss);});
  function qtext(g,wk,qi){ var arr=(typeof LESSON_QUIZ!=='undefined'&&LESSON_QUIZ[g])?LESSON_QUIZ[g]:[]; for(var n=0;n<arr.length;n++){ if(String(arr[n].week)===String(wk)){ var q=(arr[n].questions||[])[qi]; return q?q.q:''; } } return ''; }
  var top=rows.slice(0,25);
  var body='<h1 style="font-family:Arial;color:#7a1e4d">Money Matters — '+esc(t('Most-missed questions'))+'</h1><p style="font-family:Arial;font-size:12px;color:#555">'+esc(t('Ranked by percent of attempts answered incorrectly across all students on this device.'))+'</p><table border="1" cellpadding="6" style="border-collapse:collapse;font-family:Arial;font-size:12px"><tr style="background:#f3e9d6"><th>'+esc(t('Grade'))+'</th><th>'+esc(t('Week'))+'</th><th>'+esc(t('Question'))+'</th><th>'+esc(t('Missed'))+'</th><th>%</th></tr>'+top.map(function(r){return '<tr><td>'+esc(gradeLabel(r.g))+'</td><td>'+esc(r.wk)+'</td><td>'+esc(qtext(r.g,r.wk,r.qi))+'</td><td>'+r.miss+'/'+r.seen+'</td><td><b>'+Math.round(r.rate*100)+'%</b></td></tr>';}).join('')+'</table>';
  var _html='<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+esc(t('Most-missed questions'))+'</title><style>body{font-family:Arial,sans-serif;padding:24px;}</style></head><body style="padding:24px">'+body+'\n</body></html>';
  try{ var _b=new Blob([_html],{type:'text/html'}); var _u=URL.createObjectURL(_b); var _w=window.open(_u,'_blank'); if(!_w){alert(t('Allow pop-ups to view the report.'));URL.revokeObjectURL(_u);return;} setTimeout(function(){URL.revokeObjectURL(_u);},30000); }catch(e){ var _fw=window.open('','_blank'); if(_fw){_fw.document.write(_html);_fw.document.close();} } }
function downloadRosterTemplate(){ const csv='Student Name,Grade,Teacher\nAva Martin,3,Ms. Rivera\nLiam Chen,K,Mr. Park\n'; try{ const b=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='MoneyMatters_Roster_Template.csv'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){alert('Download not supported.');} }
function switchStudent(id){ if(!isValidId(id))return; trackStudentSession(id); const s=loadStore(); if(s.list[id]){ s.active=id; setTabActive(id); saveStore(s); } refreshStudentUI(); const st=activeStudent(); if(st&&st.grade)setGrade(st.grade); renderLogin(); openPanel('dashboard'); }
function signOut(){ const s=loadStore(); s.active=null; setTabActive(null); saveStore(s); refreshStudentUI(); buildGradeNav(); renderLogin(); }
function ensureStudent(){ const s=loadStore(); const tid=getTabActive(); if(tid&&s.list[tid])return; if(!s.active||!s.list[s.active]){ const id=newId(); s.list[id]={id:id,name:'Guest',prog:{}}; s.active=id; setTabActive(id); saveStore(s); refreshStudentUI(); } else { setTabActive(s.active); } }
function myProg(){ const a=activeStudent(); return a?a.prog:{}; }
function recordScore(kind,g,key,pct){ ensureStudent(); const s=loadStore(); const aid=_activeId(); if(!aid||!s.list[aid])return; const st=s.list[aid]; const k=kind+'|'+g+'|'+key; if(st.prog[k]==null||pct>st.prog[k])st.prog[k]=pct; st.lastActive=todayStr(); saveStore(s); }
function recordView(g,w){ const s=loadStore(); const aid=_activeId(); if(!aid||!s.list[aid])return; s.list[aid].prog['view|'+g+'|'+w]=1; s.list[aid].lastActive=todayStr(); saveStore(s); }
function progStatsFor(p){ p=p||{}; let taken=0,passed=0,stars=0,gold=0,tests=0,testsPassed=0,qsum=0;
  Object.keys(p).forEach(function(k){ const v=p[k];
    if(k.indexOf('quiz|')===0){ taken++; qsum+=v; if(v>=50)stars++; if(v>=75)passed++; if(v>=90)gold++; }
    else if(k.indexOf('test|')===0){ tests++; if(v>=75)testsPassed++; } });
  return {taken:taken,passed:passed,stars:stars,gold:gold,tests:tests,testsPassed:testsPassed,avg:(taken?Math.round(qsum/taken):0)}; }
function progStats(){ return progStatsFor(myProg()); }
function tier(pct){ if(pct>=90)return{emoji:'🏆',name:'Gold — Best Investor'}; if(pct>=75)return{emoji:'🥇',name:'Silver — Smart Saver'}; if(pct>=50)return{emoji:'🎖️',name:'Bronze — Budget Master'}; return{emoji:'⭐',name:'Keep Practicing'}; }
function refreshStudentUI(){ const a=activeStudent(),r=loadRole(); const btn=document.getElementById('studentNavBtn'); if(btn){var _au=null;try{_au=JSON.parse(sessionStorage.getItem('mmAuth_v1')||'null');}catch(e){}btn.textContent=(r==='teacher'?'👤 '+((_au&&_au.role==='teacher'&&_au.name)||t('Sign in')):'🎒 '+(a?a.name:t('Sign in')));} const rb=document.getElementById('roleBtn'); if(rb)rb.setAttribute('aria-label',r==='teacher'?'Teacher/Parent mode active':'Student mode active'); }

/* ===== QUIZ (multiple choice, submittable) ===== */
let quizMeta=[], quizSel={};
function openQuiz(){ openPanel('quiz'); }
function answerPool(){ const pool=[]; lessons().forEach(function(l){(l.worksheet.items||[]).forEach(function(it){ if(/draw|color/i.test(it.q))return; const a=(it.answer||'').trim(); if(a&&a.length<=34&&pool.indexOf(a)<0)pool.push(a); });}); return pool; }
function shuffleArr(a){ for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));const t=a[i];a[i]=a[j];a[j]=t;} return a; }
function pickQ(i,j){ quizSel[i]=j; for(let k=0;k<8;k++){const b=document.getElementById('qo-'+i+'-'+k);if(b)b.classList.toggle('sel',k===j);} updateQuizProgress(); }
function updateQuizProgress(){ const el=document.getElementById('quizProgress'); if(!el)return; const n=Object.keys(quizSel).length; el.textContent=n+' / '+quizQs.length+' '+t('answered'); el.style.color=(n>=quizQs.length&&quizQs.length)?'#2a6b4a':''; }
function norm(s){return (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();}
function gradeAns(student,key,q){
  const s=norm(student),k=norm(key);
  if(/draw|color/i.test(q)) return s.length>0;
  if(!s) return false; if(s===k) return true;
  const sn=(s.match(/\d+(?:\.\d+)?/g)||[]).join(','), kn=(k.match(/\d+(?:\.\d+)?/g)||[]).join(',');
  if(kn&&sn===kn) return true;
  if(k.length>=3&&(s.indexOf(k)>-1||k.indexOf(s)>-1)) return true;
  return false;
}
/* ===== V47 ASSESSMENT QUALITY LAYER =====
   Adds application/reasoning questions without exposing answer keys early.
   Questions are generated from the lesson's existing instructional objective,
   so the assessment remains tied to the lesson rather than becoming generic trivia. */
function _mmAssessmentChallenges(l){
  /* Do not invent application questions from unrelated worksheet answers.
     The former generator mixed definitions and numeric answers into a vague
     real-life prompt, which could mark a correct response as wrong. Until a
     scenario has its own validated stem, options, key, and explanation, use
     the authored lesson quiz bank only. */
  return [];
}
function lessonQuizQuestions(){ const l=L(); if(!l)return []; const lg=loadLang(); const arr=(lg!=='en'&&typeof LESSON_QUIZ_L!=='undefined'&&LESSON_QUIZ_L[lg]&&LESSON_QUIZ_L[lg][currentGrade])?LESSON_QUIZ_L[lg][currentGrade]:((typeof LESSON_QUIZ!=='undefined'&&LESSON_QUIZ[currentGrade])?LESSON_QUIZ[currentGrade]:[]); for(let n=0;n<arr.length;n++){ if(arr[n]&&arr[n].week===l.week){ var base=Array.isArray(arr[n].questions)?arr[n].questions.slice():[]; if(loadLang()==='en') base=base.concat(_mmAssessmentChallenges(l)); return base; } } return []; }
let quizQs=[];
function markLessonDone(w){ try{localStorage.setItem('mmDone|'+currentGrade+'|'+w,'1');}catch(e){} }
function lessonViewed(idx){ if(loadRole()==='teacher')return true; const l=lessons()[idx]; if(!l)return true; try{return localStorage.getItem('mmDone|'+currentGrade+'|'+l.week)==='1';}catch(e){return false;} }
function lessonNext(kind){ const l=L(); if(l)markLessonDone(l.week); if(kind==='quiz')openQuiz(); else openDoc('worksheet'); }
function completeLesson(){ const l=L(); if(!l)return; markLessonDone(l.week); try{renderChips();}catch(e){} infoToast('✓ Lesson marked complete — the quiz is now unlocked.'); }
let _quizInProgress=false;
function renderQuiz(){
  try{ _renderQuizInner(); }
  catch(e){
    console.error('renderQuiz error:',e);
    _quizInProgress=false;
    const form=document.getElementById('quizForm');
    if(form)form.innerHTML='<div class="fact"><div class="fact-icon">⚠️</div><div class="fact-text">Something went wrong loading this quiz. <button class="btn-calc" onclick="renderQuiz()" style="margin-top:8px">↺ Try again</button></div></div>';
    const btns=document.getElementById('quizButtons'); if(btns)btns.innerHTML='';
  }
}

function mmRenderQuizFlow(){
  var host=document.getElementById('quizFlowV53'); if(!host)return;
  host.innerHTML='<div class="mm-step-flow" aria-label="Lesson progress">'+
    '<span class="mm-step done"><b>1</b> Lesson ✓</span><span class="mm-step-arrow">→</span>'+
    '<span class="mm-step done"><b>2</b> Worksheet ✓</span><span class="mm-step-arrow">→</span>'+
    '<span class="mm-step"><b>3</b> Quiz</span><span class="mm-step-arrow">→</span>'+
    '<span class="mm-step"><b>4</b> Reflection</span></div>';
}

function _renderQuizInner(){
  const l=L(); if(!l)return; _quizInProgress=false; var qrh=document.getElementById('quizReflection');if(qrh)qrh.innerHTML='';
  set('quizKicker',gradeLabel(currentGrade)+' · '+t('Week')+' '+l.week);
  if(loadRole()!=='teacher'&&!previewOn()&&!signedIn()){
    set('quizTitle',l.title+' — '+t('Quiz'));
    document.getElementById('quizPrize').innerHTML='';
    document.getElementById('quizForm').innerHTML='<div class="fact"><div class="fact-icon">🔒</div><div class="fact-text">'+esc(t('Please sign in first — open the Student desk to start.'))+'</div></div>';
    document.getElementById('quizButtons').innerHTML='<button class="btn-calc green" onclick="openPanel(\'login\')">'+esc(t('👤 Sign in'))+'</button>';
    return;
  }
  if(!lessonViewed(currentIndex)){
    set('quizTitle',l.title+' — '+t('Quiz'));
    document.getElementById('quizPrize').innerHTML='';
    document.getElementById('quizForm').innerHTML='<div class="fact"><div class="fact-icon">🔒</div><div class="fact-text">'+esc(t('Read the lesson first, then the quiz unlocks.'))+'</div></div>';
    document.getElementById('quizButtons').innerHTML='<button class="btn-calc green" onclick="gotoLesson(currentIndex)">'+esc(t('📖 Open the lesson'))+'</button>';
    return;
  }
  set('quizTitle',l.title+' — Quiz');
  document.getElementById('quizPrize').innerHTML='';
  mmRenderQuizFlow();
  quizQs=lessonQuizQuestions().map(function(q){ var pairs=(q.options||[]).map(function(o,idx){return {o:o,c:idx===q.answer};}); shuffleArr(pairs); var na=0; for(var z=0;z<pairs.length;z++){if(pairs[z].c){na=z;break;}} return {q:q.q,options:pairs.map(function(p){return p.o;}),answer:na,explain:q.explain}; }); quizSel={};
  if(!quizQs.length){ document.getElementById('quizForm').innerHTML='<div class="fact"><div class="fact-icon">📝</div><div class="fact-text">This quiz is being prepared. Try the Section Test for a full checkpoint on this unit.</div></div>'; document.getElementById('quizButtons').innerHTML=''; return; }
  let h='<div class="who">'+quizQs.length+' '+t('questions. Choose one answer for each, then submit.')+' <b id="quizProgress"></b></div>';
  quizQs.forEach(function(q,i){ h+='<div class="q-item" id="qi-'+i+'"><div class="q-num">'+(i+1)+'. '+esc(rewordSel(q.q))+'</div>';
    (q.options||[]).forEach(function(o,j){ h+='<button class="mc-opt" id="qo-'+i+'-'+j+'" onclick="pickQ('+i+','+j+')">'+esc(o)+'</button>'; });
    h+='<div class="q-fb" id="qf-'+i+'"></div></div>'; });
  document.getElementById('quizForm').innerHTML=h;
  document.getElementById('quizButtons').innerHTML='<button class="btn-calc green" onclick="submitQuiz()">'+esc(t('✅ Submit answers'))+'</button><button class="btn-calc" onclick="readQuizAloud()">'+esc(t('🔊 Read aloud'))+'</button><button class="btn-calc ghost" onclick="renderQuiz()">'+esc(t('↺ Reset'))+'</button>';
  updateQuizProgress(); _quizInProgress=true;
} /* end _renderQuizInner */
function firstUnanswered(){ for(var i=0;i<quizQs.length;i++){ if(!(i in quizSel))return i; } return -1; }
function smartNextBtn(){ const ls=lessons(); const isUnitEnd=((currentIndex+1)%6===0)||(currentIndex===ls.length-1);
  if(isUnitEnd){ const unit=Math.floor(currentIndex/6); return '<button class="btn-calc" style="background:#7a1e4d" onclick="openTest('+unit+')">'+esc(t('🧪 Section Test →'))+'</button>'; }
  const nl=ls[currentIndex+1]; return '<button class="btn-calc" onclick="nextLessonFromQuiz()">'+esc(t('➡ Next')+': '+t('Week')+' '+nl.week)+'</button>'; }
function mmQuizReflectionKey(){
  var l=L(),sid=mmGameStudentId();
  return 'mmQuizReflection_v2|'+sid+'|'+currentGrade+'|'+(l?l.week:'');
}
function mmShowQuizReflection(){
  var host=document.getElementById('quizReflection'); if(!host)return;
  var l=L()||{},ti=esc(l.title||'this lesson'),young=(currentGrade==='K'||currentGrade==='1'||currentGrade==='2');
  var key=mmQuizReflectionKey(),saved=null; try{saved=JSON.parse(localStorage.getItem(key)||'null');}catch(e){}
  var qs=young?[['qref1','What is one new thing you learned about \u201C'+ti+'\u201D?','Tell it in your own words...'],['qref4','Which quiz question was tricky? What made it tricky?','Write or tell a grown-up...'],['qref2','Where could you use this at home or at a store?','Give an example...']]
   :[['qref1','What is the most important idea you learned about \u201C'+ti+'\u201D?','Explain it in your own words...'],['qref4','Which quiz question was hardest for you, and why?','Name the question and explain your thinking...'],['qref2','How could you use this money skill in real life this month?','Give a specific example...']];
  var h='<div class="card" style="margin-top:14px;border-left:4px solid var(--gold)"><div class="card-title">\uD83D\uDCAD Reflect on Your Learning</div><div class="card-body">Take a moment to think about this lesson. This is not graded.</div>';
  qs.forEach(function(q,n){h+='<label class="qref-item" for="'+q[0]+'"><span class="qref-q">'+(n+1)+'. '+q[1]+'</span><textarea id="'+q[0]+'" class="quiz-input" rows="3" maxlength="500" placeholder="'+q[2]+'"></textarea></label>';});
  h+='<label class="qref-item" for="qref3"><span class="qref-q">'+(qs.length+1)+'. How confident do you feel about this lesson?</span><select id="qref3" class="gloss-search" style="margin-top:6px;width:100%"><option value="">Choose one</option><option>\uD83D\uDE0A I understand it</option><option>\uD83D\uDE42 I mostly understand it</option><option>\uD83E\uDD14 I need more practice</option></select></label>';
  h+='<div class="meta-pills" style="margin-top:10px"><button class="btn-calc green" onclick="mmSaveQuizReflection()">Save Reflection</button></div><div id="qref-status" class="who" style="text-align:center;min-height:20px;margin-top:5px"></div></div>';
  host.innerHTML=h;
  if(saved){[['qref1','learned'],['qref4','hardest'],['qref2','realLife'],['qref3','confidence']].forEach(function(p){var e=document.getElementById(p[0]);if(e)e.value=saved[p[1]]||'';});}
}
function mmSaveQuizReflection(){
  var key=mmQuizReflectionKey(),g=function(i){return (document.getElementById(i)||{}).value||'';};
  var data={learned:g('qref1'),hardest:g('qref4'),realLife:g('qref2'),confidence:g('qref3'),date:new Date().toISOString()};
  try{localStorage.setItem(key,JSON.stringify(data));}catch(e){}
  var st=document.getElementById('qref-status');if(st)st.textContent='\u2713 Reflection saved.';
}
function submitQuiz(){
  if(!quizQs.length)return;
  const answered=Object.keys(quizSel).length;
  if(answered<quizQs.length){ const el=document.getElementById('quizProgress'); if(el){ el.textContent=(quizQs.length-answered)+' '+t('left — answer every question first'); el.style.color='#b03030'; }
    const fu=firstUnanswered(); if(fu>=0){ const q=document.getElementById('qi-'+fu); if(q)q.scrollIntoView({behavior:'smooth',block:'center'}); } return; }
  const l=L(); let correct=0;
  quizQs.forEach(function(q,i){ const sel=(i in quizSel)?quizSel[i]:-1; const ok=(sel===q.answer); if(ok)correct++;
    for(let j=0;j<8;j++){ const b=document.getElementById('qo-'+i+'-'+j); if(!b)continue; b.classList.remove('sel'); if(j===q.answer)b.classList.add('right'); else if(j===sel)b.classList.add('bad'); b.disabled=true; }
    const qi=document.getElementById('qi-'+i); qi.classList.remove('correct','wrong'); qi.classList.add(ok?'correct':'wrong');
    const fb=document.getElementById('qf-'+i); fb.className='q-fb '+(ok?'ok':'no'); fb.innerHTML=(ok?'Correct! ':'Not quite. ')+esc(q.explain||'');
  });
  const pct=Math.round(correct/quizQs.length*100);
  recordScore('quiz',currentGrade,l.week,pct);
  try{ const _s=loadStore(); if(!_s.stats)_s.stats={}; quizQs.forEach(function(q,i){ var sel=(i in quizSel)?quizSel[i]:-1; var k=currentGrade+'|'+l.week+'|'+i; var o=_s.stats[k]||{seen:0,miss:0}; o.seen++; if(sel!==q.answer)o.miss++; _s.stats[k]=o; }); saveStore(_s); }catch(e){}
  touchStreak(); if(pct>=75){celebrate();playChime();}
  const tr=tier(pct); const col=pct>=90?'#2a6b4a':pct>=75?'#1e6b6b':pct>=50?'#c4912e':'#7a3b1e';
  document.getElementById('quizPrize').innerHTML=
    '<div class="score-banner" style="background:'+col+'"><div class="pct">'+pct+'%</div><div class="lbl">You got '+correct+' of '+quizQs.length+' correct</div></div>'
    +'<div class="prize"><div class="emoji">'+tr.emoji+'</div><div class="txt"><b>'+esc(tr.name)+'</b><span>'+(pct>=75?'Great work — this quiz counts toward your certificate!':'Try again to reach 75 percent and earn a medal.')+'</span></div></div>';
  document.getElementById('quizButtons').innerHTML='<button class="btn-calc green" onclick="renderQuiz()">'+esc(t('↺ Try again'))+'</button><button class="btn-calc" onclick="gotoLesson(currentIndex)">'+esc(t('📖 Re-read lesson'))+'</button>'+smartNextBtn()+'<button class="btn-calc" onclick="openPanel(\'dashboard\')">'+esc(t('🏠 Dashboard'))+'</button><span class="who" style="width:100%;text-align:center;margin-top:6px">Next step: complete the reflection below.</span>';
  mmShowQuizReflection();
  setTimeout(function(){var rh=document.getElementById('quizReflection');if(rh)rh.scrollIntoView({behavior:'smooth',block:'start'});},120);
  _quizInProgress=false;
  const pb=document.querySelector('#panel-quiz .panel-body'); if(pb)pb.scrollTop=0;
}
function nextLessonFromQuiz(){
  const l=L(), score=l?myProg()['quiz|'+currentGrade+'|'+l.week]:null;
  if(score==null||Number(score)<75){
    alert('Finish this quiz with 75% or higher before moving to the next lesson.');
    return;
  }
  gotoLesson(Math.min(currentIndex+1,lessons().length-1));
}

/* ===== CERTIFICATE ===== */
function renderPrizeSummary(){
  const s=progStats();
  const medal=s.gold>=1?'🏆 Gold':s.passed>=1?'🥇 Silver':s.taken>=1?'🎖️ Bronze':'⭐ Getting started';
  document.getElementById('prizeSummary').innerHTML=
    '<div class="two-col"><div class="card"><div class="card-title">🏅 Prizes earned</div><div class="card-body">Quizzes taken: <b>'+s.taken+'</b><br>Quizzes passed (75%+): <b>'+s.passed+'</b><br>Stars (50%+): <b>'+s.stars+'</b><br>Gold quizzes (90%+): <b>'+s.gold+'</b></div></div>'
    +'<div class="card"><div class="card-title">🎖️ Current level</div><div class="card-body" style="font-size:20px;font-weight:700;color:var(--ink)">'+medal+'</div></div></div>';
}
function gradeCompletion(){ const ls=lessons(); const p=myProg(); let wk=0; ls.forEach(function(l){var v=p['quiz|'+currentGrade+'|'+l.week]; if(v!=null&&v>=75)wk++;});
  const tArr=(typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[currentGrade])?SECTION_TESTS[currentGrade]:[]; let tp=0; tArr.forEach(function(t,i){var v=p['test|'+currentGrade+'|u'+(i+1)]; if(v!=null&&v>=75)tp++;});
  return {weeks:wk,totalWeeks:ls.length,tests:tp,totalTests:tArr.length,complete:(ls.length>0&&wk>=ls.length&&tArr.length>0&&tp>=tArr.length)}; }
function certLevel(){ if(gradeCompletion().complete)return['🏆','Grade Complete']; const s=progStats(); return s.gold>=1?['🥇','Gold']:s.passed>=1?['🥈','Silver']:s.taken>=1?['🎖️','Bronze']:['⭐','Participant']; }

function _certCode(studentId, grade, weeks){
  /* Short verification code — sha256 of key fields, first 8 hex chars */
  const raw=(studentId||'anon')+'|'+(grade||'')+'|'+String(weeks);
  return _sha256(raw).then(function(h){ return (h||'00000000').slice(0,8).toUpperCase(); });
}
function certHTML(){
  const nameEl=document.getElementById('certName'); const name=(nameEl&&nameEl.value)||'';
  const schoolEl=document.getElementById('certSchool'); const school=(schoolEl&&schoolEl.value)||getSchoolName();
  const s=progStats(); const lv=certLevel(); const gc=gradeCompletion();
  var date; try{ date=new Date().toLocaleDateString(); }catch(e){ date=''; }
  const heading=gc.complete?t('Certificate of Completion'):t('Certificate of Achievement');
  const gl=gradeLabel(currentGrade);
  const line=gc.complete
    ? '<b>'+esc(gl)+'</b> — '+esc(t('completed the full grade: every weekly lesson and all checkpoint tests.'))
    : '<b>'+esc(gl)+'</b> — '+esc(t('making great progress in earning, saving, budgeting, and smart money decisions.'));
  const teach=(activeStudent()&&activeStudent().teacher)?activeStudent().teacher:'';
  const schoolLine=school?('<div style="font-family:system-ui,sans-serif;font-size:14px;font-weight:700;color:#8a5e10;margin:2px 0 6px;letter-spacing:.04em">'+esc(school)+'</div>'):'';
  const teachLine=teach?(' · '+t('Instructor')+': '+esc(teach)):'';
  const aid=_activeId()||'anon'; const gc2=gradeCompletion();
  _certCode(aid,currentGrade,gc2.weeks).then(function(code){
    const el=document.getElementById('certVerifyCode'); if(el)el.textContent='Verification code: '+code;
  });
  return '<div class="cert"><div class="cap">★ Money Matters ★</div>'
    +'<div style="font-family:system-ui,sans-serif;font-size:13px;color:#6b5137;margin-bottom:4px">'+esc(t('K–8 Financial Literacy Program'))+'</div>'
    +schoolLine
    +'<div class="h">'+esc(heading)+'</div>'
    +(gc.complete?'<div style="font-family:system-ui,sans-serif;font-weight:800;letter-spacing:.12em;color:#2a6b4a;margin:2px 0 4px">★ '+esc(t('GRADE COMPLETE'))+' ★</div>':'')
    +'<div class="body">'+esc(t('This certifies that'))+'</div>'
    +'<div class="nm">'+esc(name||t('Your Name'))+'</div>'
    +'<div class="body">'+line+'</div>'
    +'<div class="medal">'+lv[0]+'</div>'
    +'<div class="body"><b>'+esc(t('Level'))+': '+esc(lv[1])+'</b> · '+esc(t('Lessons'))+' '+gc.weeks+'/'+gc.totalWeeks+' · '+esc(t('Checkpoints'))+' '+gc.tests+'/'+gc.totalTests+' · '+esc(t('Stars'))+' '+s.stars+'</div>'
    +'<div class="body" style="margin-top:12px;font-size:12px;color:#6b5137">'+t('Date')+': '+esc(date)+teachLine+'</div>'
    +'<div id="certVerifyCode" style="font-size:10px;color:#9a7a4a;font-family:monospace;margin-top:8px;letter-spacing:.06em">Verification code: —</div></div>';
}
function renderCert(){
  populateSchoolField();
  const ci=document.getElementById('certName'); if(ci&&!ci.value&&studentName())ci.value=studentName();
  const a=document.getElementById('certArea'); if(a)a.innerHTML=certHTML();
}
const CERT_CSS="body{font-family:Georgia,serif;padding:30px;text-align:center}.cert{border:3px double #c4912e;border-radius:16px;padding:36px;background:#fdf6e4;max-width:640px;margin:0 auto}.cap{letter-spacing:.2em;text-transform:uppercase;color:#c4912e;font-weight:800;font-family:Arial,sans-serif}.h{font-size:28px;font-weight:800;margin:8px 0;color:#1a1208}.nm{font-size:32px;color:#2a6b4a;border-bottom:2px solid #c4912e;display:inline-block;padding:4px 24px;margin:12px 0}.body{font-family:Arial,sans-serif;font-size:14px;color:#333;line-height:1.6}.medal{font-size:48px;margin:10px 0}";
function printCert(){
  const html='<!DOCTYPE html><html><head><meta charset="utf-8"><title>Certificate</title><style>'+CERT_CSS+'</style></head><body>'+certHTML()+'\n</body></html>';
  try{
    const blob=new Blob([html],{type:'text/html'});
    const url=URL.createObjectURL(blob);
    const pw=window.open(url,'_blank');
    if(!pw){ window.print(); URL.revokeObjectURL(url); return; }
    pw.addEventListener('load',function(){ try{pw.print();}catch(e){} URL.revokeObjectURL(url); },{once:true});
    setTimeout(function(){ URL.revokeObjectURL(url); },30000);
  }catch(e){ window.print(); }
}
function downloadCert(){
  const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Certificate</title><style>'+CERT_CSS+'</style></head><body>'+certHTML()+'\n</body></html>';
  try{ const blob=new Blob(['﻿'+html],{type:'application/msword'}); const a=document.createElement('a');
    a.href=URL.createObjectURL(blob); a.download='MoneyMatters_Certificate.doc'; document.body.appendChild(a); a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);
  }catch(e){ alert('Download not supported in this browser. Use Print instead.'); }
}

/* ===== LOGIN PANEL ===== */
function mmRoleLabel(){return loadRole()==='teacher'?'Teacher':'Student';}
function mmRoleBadge(){
  const r=loadRole(), a=activeStudent();
  return '<div class="mm-session-badges">'
    +'<span class="mm-role-badge '+(r==='student'?'active':'')+'">🎒 Student '+(r==='student'?'· Active':'')+'</span>'
    +'<span class="mm-role-badge '+(r==='teacher'?'active':'')+'">👩‍🏫 Teacher '+(r==='teacher'?'· Active':'')+'</span>'
    +(a?'<span class="mm-role-badge active">👤 '+esc(a.name)+'</span>':'')
    +'</div>';
}
function openNewLearningSession(){
  try{ const w=window.open(location.href,'_blank','noopener,noreferrer'); if(!w)mmAlert('Allow pop-ups to open another learning session.','⚠️'); }
  catch(e){ mmAlert('This browser could not open another session. Open Money Matters in a new tab instead.','⚠️'); }
}
function renderLogin(){
  const s=loadStore(); const a=activeStudent(); const r=loadRole();
  let h=mmRoleBadge();
  h+='<div class="card" style="margin-bottom:14px"><div class="card-title">'+(r==='teacher'?'👩‍🏫 Teacher session':'🎒 Student session')+'</div><div class="card-body">'
    +(r==='teacher'
      ?'Teacher/Parent mode is active in this tab. You can keep a student session open in another tab at the same time.'
      :(a?'Signed in as <b>'+esc(a.name)+'</b>. Your progress is saved to this student.':'No student is signed in in this tab yet.') )
    +'</div><div class="meta-pills" style="margin-top:10px">'
    +'<button class="btn-calc" onclick="toggleRole()">'+(r==='teacher'?'🎒 Switch to Student':'👩‍🏫 Switch to Teacher/Parent')+'</button>'
    +'<button class="btn-calc ghost" onclick="openNewLearningSession()">＋ Open another session</button>'
    +'</div></div>';
  const ids=Object.keys(s.list||{});
  if(ids.length){
    h+='<div class="section-head">'+esc(t('Choose a student'))+'</div>';
    h+='<div class="who" style="margin-bottom:8px">Each tab can use a different student. The green dot marks the student active in this tab.</div>';
    h+='<div class="student-list">'+ids.map(function(id){
      var st=s.list[id], active=id===getTabActive(), gr=st.grade?(' · '+(st.grade==='K'?'K':'Gr '+st.grade)):'',
          teacher=st.teacher?(' · 👩‍🏫 '+esc(st.teacher)):'',
          code=st.verifyCode?(' · '+esc(st.verifyCode)) : '';
      return '<div class="mm-session-card"><div class="mm-session-meta"><div class="mm-session-name">'+(active?'<span class="mm-session-dot" aria-label="Active in this tab"></span>':'')+esc(st.name)+'</div><div class="mm-session-sub">'+esc(st.grade==='K'?'Kindergarten':'Grade '+(st.grade||''))+teacher+code+'</div></div><div class="meta-pills"><button class="student-pill'+(active?' active':'')+'" onclick="switchStudent(\''+id+'\')">'+(active?'✓ Active':'Sign in')+'</button><button class="btn-calc ghost" style="min-height:42px;padding:8px 11px" title="Remove student" onclick="removeStudent(\''+id+'\')">🗑</button></div></div>';
    }).join('')+'</div>';
  }
  const gopts=Object.keys(GRADE_LABEL).map(function(g){return '<option value="'+g+'"'+(g===currentGrade?' selected':'')+'>'+GRADE_LABEL[g]+'</option>';}).join('');
  h+='<div class="section-head">'+esc(t('Add a new student'))+'</div><div class="meta-pills">'
    +'<input class="quiz-input" id="newStudentName" style="max-width:190px;margin-top:0" maxlength="40" placeholder="Type a name" onkeydown="if(event.key===\'Enter\')createStudentFromForm()">'
    +'<select class="voice-select" id="newStudentGrade" aria-label="Grade">'+gopts+'</select>'
    +'<input class="quiz-input" id="newStudentTeacher" list="teacherOptions" style="max-width:170px;margin-top:0" maxlength="60" placeholder="'+esc(t('Teacher (optional)'))+'">'
    +'<button class="btn-calc green" onclick="createStudentFromForm()">'+esc(t('Create & sign in'))+'</button>'
    +(a&&r==='student'?'<button class="btn-calc ghost" onclick="signOut()">'+esc(t('Sign out'))+'</button>':'')+'</div>'
    +'<datalist id="teacherOptions">'+teacherList().map(function(tn){return '<option value="'+esc(tn)+'"></option>';}).join('')+'</datalist>'
    +'<div class="fact" style="margin-top:14px"><div class="fact-icon">🧑‍🏫</div><div class="fact-text"><b>Multiple users at once:</b> open Money Matters in separate browser tabs. Each tab can have its own Student or Teacher indicator and its own active student. Student progress is still stored separately by student profile.</div></div>';
  const el=document.getElementById('loginBody'); if(el)el.innerHTML=h;
}


/* ===== USAGE TRACKING ===== */
const USAGE_KEY='mmUsage_v1';
function loadUsage(){ try{return JSON.parse(localStorage.getItem(USAGE_KEY)||'{}');}catch(e){return {};} }
function saveUsage(u){ try{localStorage.setItem(USAGE_KEY,JSON.stringify(u));}catch(e){} }
function trackAppOpen(){
  const u=loadUsage();
  u.totalOpens=(u.totalOpens||0)+1;
  u.lastOpen=new Date().toISOString();
  if(!u.firstOpen)u.firstOpen=u.lastOpen;
  const today=new Date().toDateString();
  if(!u.dailyLog)u.dailyLog={};
  u.dailyLog[today]=(u.dailyLog[today]||0)+1;
  const keys=Object.keys(u.dailyLog);
  if(keys.length>90){ keys.sort(); keys.slice(0,keys.length-90).forEach(function(k){delete u.dailyLog[k];}); }
  u.uniqueDays=Object.keys(u.dailyLog).length;
  saveUsage(u);
}
function trackStudentSession(id){
  if(!id)return;
  const u=loadUsage();
  if(!u.students)u.students={};
  if(!u.students[id])u.students[id]={opens:0,firstSeen:new Date().toISOString()};
  u.students[id].opens=(u.students[id].opens||0)+1;
  u.students[id].lastSeen=new Date().toISOString();
  saveUsage(u);
}
function getUsageSummary(){
  const u=loadUsage();
  return {
    totalOpens:u.totalOpens||0,
    uniqueDays:u.uniqueDays||0,
    firstOpen:u.firstOpen?new Date(u.firstOpen).toLocaleDateString():'—',
    lastOpen:u.lastOpen?new Date(u.lastOpen).toLocaleDateString():'—',
  };
}

/* ===== GRADE PROMOTION ===== */
const GRADE_SEQ=['K','1','2','3','4','5','6','7','8'];
function nextGradeFor(g){ const i=GRADE_SEQ.indexOf(String(g)); return (i>=0&&i<GRADE_SEQ.length-1)?GRADE_SEQ[i+1]:null; }
function promoteStudent(id){
  if(!isValidId(id))return;
  const s=loadStore(); if(!s.list[id])return;
  const st=s.list[id]; const next=nextGradeFor(st.grade||'K');
  if(!next){ mmAlert(sanitise(st.name)+' is already in Grade 8 — the highest grade.','🎓'); return; }
  mmConfirm(
    'Promote '+sanitise(st.name)+' to '+GRADE_LABEL[next]+'?',
    'Their Grade '+(st.grade||'K')+' progress will be kept. They will start fresh in '+GRADE_LABEL[next]+'. This cannot be undone.',
    'Promote','🎓'
  ).then(function(ok){
    if(!ok)return;
    const s2=loadStore(); if(!s2.list[id])return;
    s2.list[id].prevGrades=s2.list[id].prevGrades||[];
    s2.list[id].prevGrades.push({grade:s2.list[id].grade||'K',promoted:new Date().toISOString()});
    s2.list[id].grade=next;
    saveStore(s2);
    if(_activeId()===id)setGrade(next);
    if(openPanelId==='teacher')renderTeacher();
    if(openPanelId==='students')renderStudents();
    if(openPanelId==='login')renderLogin();
    infoToast('✓ '+sanitise(st.name)+' promoted to '+GRADE_LABEL[next]+'.',3000);
  });
}


/* ===== V53 FINAL ROSTER VERIFICATION ===== */
function _mmCodeHash(str){
  var h=2166136261>>>0,s=String(str||'');
  for(var i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}
  return h>>>0;
}
function studentVerificationCode(id){
  var s=loadStore(),st=s.list[id];if(!st)return '';
  if(st.verificationCode&&/^[A-Z0-9]{6}$/.test(st.verificationCode))return st.verificationCode;
  var seed=_mmCodeHash(id+'|'+(st.name||'')+'|'+(st.grade||'K')+'|MoneyMatters');
  var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',out='';
  for(var i=0;i<6;i++){out+=chars.charAt(seed%chars.length);seed=Math.floor(seed/chars.length);if(!seed)seed=_mmCodeHash(id+'|'+i);}
  st.verificationCode=out;saveStore(s);return out;
}
function copyStudentVerificationCode(id){
  var c=studentVerificationCode(id);if(!c)return;
  try{navigator.clipboard.writeText(c).then(function(){infoToast('✓ Verification code copied: '+c,2500);}).catch(function(){mmAlert('Verification code: '+c,'🔐');});}
  catch(e){mmAlert('Verification code: '+c,'🔐');}
}
function verifyRosterCode(){
  var el=document.getElementById('v53RosterVerifyInput'),msg=document.getElementById('v53RosterVerifyMsg');
  var code=((el&&el.value)||'').trim().toUpperCase(),s=loadStore(),found=null;
  if(code)Object.keys(s.list).some(function(id){if(studentVerificationCode(id)===code){found=id;return true;}return false;});
  if(!msg)return;
  if(found){
    var st=s.list[found];setTeacherStudentFilter(found);
    msg.innerHTML='✓ <b>'+esc(st.name)+'</b> · '+esc(gradeLabel(st.grade||'K'));
    msg.style.color='var(--green)';
  }else{msg.textContent='No student matched that verification code.';msg.style.color='#a33';}
}
function regenerateStudentVerificationCode(id){
  if(!isValidId(id))return;var s=loadStore();if(!s.list[id])return;
  s.list[id].verificationCode='';saveStore(s);var c=studentVerificationCode(id);
  if(openPanelId==='teacher')renderTeacher();if(openPanelId==='students')renderStudents();
  infoToast('New roster verification code: '+c,3500);
}

/* ===== STUDENT ROSTER PANEL ===== */
function renderStudents(){
  const s=loadStore(); const ids=Object.keys(s.list); const el=document.getElementById('studentsBody'); if(!el)return;
  const u=loadUsage();
  let h='';
  if(!ids.length){
    h='<div class="fact"><div class="fact-icon">👤</div><div class="fact-text">No students yet — use the Student Desk to add the first one.</div></div>';
    el.innerHTML=h; return;
  }
  h+='<div class="card" style="margin-bottom:14px"><div class="card-title">📊 Roster summary</div>'
    +'<div class="card-body">Students: <b>'+ids.length+'</b>'
    +' · App opens: <b>'+(u.totalOpens||0)+'</b>'
    +' · Days used: <b>'+(u.uniqueDays||0)+'</b>'
    +' · First used: '+(u.firstOpen?new Date(u.firstOpen).toLocaleDateString():'—')
    +'</div></div>';
  const byGrade={};
  ids.forEach(function(id){ const g=s.list[id].grade||'K'; if(!byGrade[g])byGrade[g]=[]; byGrade[g].push(id); });
  const gradeSeq=['K','1','2','3','4','5','6','7','8'];
  gradeSeq.forEach(function(g){
    const gids=byGrade[g]; if(!gids||!gids.length)return;
    h+='<div class="section-head">'+esc(GRADE_LABEL[g]||('Grade '+g))+' — '+gids.length+' student'+(gids.length>1?'s':'')+'</div>';
    gids.forEach(function(id){
      const st=s.list[id]; const x=progStatsFor(st.prog||{});
      const ls_g=lessons_for_grade(g);
      const pct=ls_g.length?Math.round(x.passed/ls_g.length*100):0;
      const isActive=(id===getTabActive()||((!getTabActive())&&id===s.active));
      const medal=x.gold>=1?'🏆':x.passed>=1?'🥇':x.taken>=1?'🎖️':'⭐';
      const gc=gradeCompletionFor(id,g); const next=nextGradeFor(g);
      const stuOpens=(u.students&&u.students[id])?(u.students[id].opens||0):0;
      const prevBadge=st.prevGrades&&st.prevGrades.length
        ?'<span style="font-size:11px;background:#e8f5e9;color:#1e6b3a;border-radius:6px;padding:2px 7px;margin-left:6px">Was: '+st.prevGrades.map(function(p){return p.grade;}).join('→')+'</span>':'';
      h+='<div class="unit-card">'
        +'<div class="unit-head"><div class="unit-title">'+medal+' '+esc(st.name)+prevBadge
        +(isActive?' <span style="font-size:11px;background:var(--green-pale);color:var(--green);border-radius:6px;padding:2px 7px;margin-left:4px">● Active</span>':'')
        +(gc.complete?' <span style="font-size:11px;background:#fff3cd;color:#856404;border-radius:6px;padding:2px 7px;margin-left:4px">🎓 Grade complete!</span>':'')
        +'</div>'
        +'<div class="meta-pills">'
        +'<button class="btn-calc green" onclick="switchStudent(\''+id+'\');closePanel()">Sign in</button>'
        +(next&&gc.complete?'<button class="btn-calc" style="background:#7a5a10" onclick="promoteStudent(\''+id+'\')">🎓 Promote→Gr '+next+'</button>':'')
        +'<button class="btn-calc ghost" onclick="teacherReport(\''+id+'\')">📋 Report</button>'
        +'<button class="btn-calc ghost" onclick="teacherReset(\''+id+'\')">♻️ Reset</button>'
        +'<button class="btn-calc" style="background:#a33" onclick="removeStudent(\''+id+'\');renderStudents()">🗑</button>'
        +'</div></div>'
        +'<div class="card-body">'+esc(GRADE_LABEL[g]||g)+(st.teacher?' · 👩‍🏫 '+esc(st.teacher):'')+' · Lessons: <b>'+x.passed+'/'+ls_g.length+'</b> ('+pct+'%) · Quiz avg: <b>'+x.avg+'%</b> · 📖 Opens: '+stuOpens+' · Last: '+esc(st.lastActive||'—')+'</div>'
        +'<div style="padding:4px 16px 10px"><div style="background:rgba(140,90,30,0.1);border-radius:6px;height:8px;overflow:hidden"><div style="height:100%;background:var(--green-light);border-radius:6px;width:'+pct+'%"></div></div></div>'
        +'</div>';
    });
  });
  const frag=document.createRange().createContextualFragment(h);
  el.innerHTML=''; el.appendChild(frag);
}
function lessons_for_grade(g){ try{return (typeof LESSONS!=='undefined'&&LESSONS[g])?LESSONS[g]:[];}catch(e){return[];} }
function gradeCompletionFor(id,g){
  const s=loadStore(); if(!s.list[id])return{complete:false,weeks:0,totalWeeks:36};
  const prog=s.list[id].prog||{}; const ls=lessons_for_grade(g);
  let wk=0; ls.forEach(function(l){var v=prog['quiz|'+g+'|'+l.week];if(v!=null&&v>=75)wk++;});
  return{complete:wk>=ls.length&&ls.length>0,weeks:wk,totalWeeks:ls.length};
}

/* ===== LEARNING PATH ===== */
function gotoLesson(i){ currentIndex=i; openPanel('lessons'); setTimeout(function(){renderChips();loadLesson(i,true);},60); }
function continuePath(){ const ls=lessons(); const aw=assignedWeek(currentGrade); if(aw!=null&&aw>=0&&aw<ls.length&&weekUnlocked(aw)){ gotoLesson(aw); return; } let idx=-1; for(let n=0;n<ls.length;n++){ const v=myProg()['quiz|'+currentGrade+'|'+ls[n].week]; if(!(v!=null&&v>=75)){idx=n;break;} } if(idx<0)idx=0; gotoLesson(idx); }
function renderPath(){
  set('pathKicker',GRADE_LABEL[currentGrade]+' · Learning Path');
  const ls=lessons(); const a=activeStudent(); const p=myProg();
  const passed=ls.filter(function(l){var v=p['quiz|'+currentGrade+'|'+l.week];return v!=null&&v>=75;}).length;
  const viewed=ls.filter(function(l){return p['view|'+currentGrade+'|'+l.week];}).length;
  const pct=ls.length?Math.round(passed/ls.length*100):0;
  let h='<div class="who">'+(a?('Learner: <b>'+esc(a.name)+'</b>'):'Tip: open the <b>Student</b> desk to save your progress.')+'</div>';
  h+='<div class="pbar"><i style="width:'+pct+'%"></i></div>';
  h+='<div class="who">'+passed+' of '+ls.length+' lessons mastered · '+viewed+' opened</div>';
  h+='<div class="meta-pills" style="margin-bottom:14px"><button class="btn-calc green" onclick="continuePath()">'+esc(t('▶ Continue where I left off'))+'</button></div>';
  for(let u=0;u<6;u++){
    const block=ls.slice(u*6,u*6+6); if(!block.length)continue;
    const wk=(u*6+1)+'-'+Math.min(u*6+6,ls.length);
    const tp=p['test|'+currentGrade+'|u'+(u+1)];
    const tstat=(tp!=null)?(tp>=75?'✓ passed '+tp+'%':'best '+tp+'%'):'not taken';
    h+='<div class="unit-card"><div class="unit-head"><div class="unit-title">Unit '+(u+1)+' · Weeks '+wk+'</div>'
      +'<button class="btn-calc" style="background:#7a1e4d" onclick="openTest('+u+')">🧪 Checkpoint '+(u+1)+' ('+tstat+')</button></div><div class="wk-row">';
    block.forEach(function(l){ const idx=ls.indexOf(l); const lock=!weekUnlocked(idx); const v=p['quiz|'+currentGrade+'|'+l.week]; const vw=p['view|'+currentGrade+'|'+l.week];
      let cls=(v!=null&&v>=75)?'passed':(vw?'viewed':''); if(lock)cls+=' locked'; const dot=lock?'🔒':((v!=null&&v>=75)?'✓':(vw?'•':'○'));
      h+='<button class="wk-chip '+cls+'" onclick="'+(lock?('lockedMsg('+idx+')'):('gotoLesson('+idx+')'))+'"><span class="dot">'+dot+'</span> Wk '+l.week+': '+esc(l.title)+'</button>'; });
    h+='</div></div>';
  }
  const el=document.getElementById('pathBody'); if(el)el.innerHTML=h;
}

/* ===== SECTION TESTS (multiple choice) ===== */
let currentTest=null, testSel={};
function tests(){ const lg=loadLang(); if(lg!=='en'&&typeof SECTION_TESTS_L!=='undefined'&&SECTION_TESTS_L[lg]&&SECTION_TESTS_L[lg][currentGrade])return SECTION_TESTS_L[lg][currentGrade]; return (typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[currentGrade])?SECTION_TESTS[currentGrade]:[]; }
function openTestMenu(){ currentTest=null; openPanel('test'); }
function renderTestPanel(){ if(currentTest==='review')renderReview(); else if(currentTest==null)renderTestMenu(); else renderTest(); }
function renderTestMenu(){
  set('testKicker',GRADE_LABEL[currentGrade]+' · Section Tests'); set('testTitle','Checkpoint Tests');
  document.getElementById('testResult').innerHTML=''; document.getElementById('testButtons').innerHTML='';
  const tArr=tests(); const p=myProg();
  if(!tArr.length){ document.getElementById('testForm').innerHTML='<div class="fact"><div class="fact-icon">🧪</div><div class="fact-text">Section tests for this grade are being prepared.</div></div>'; return; }
  let h='<div class="who">Choose a checkpoint. Each is a comprehensive multiple-choice test for a block of weeks.</div>';
  const rl=reviewList(); if(rl.length) h+='<div class="meta-pills" style="margin-bottom:12px"><button class="btn-calc" style="background:#7a5a1e" onclick="openReview()">🔁 Review missed questions ('+rl.length+')</button></div>';
  h+='<div class="module-grid">';
  tArr.forEach(function(t,i){ const lock=!unitUnlocked(i); const tp=p['test|'+currentGrade+'|u'+(i+1)];
    const st=lock?('🔒 Locked — finish Unit '+(i+1)+' first'):((tp!=null)?(tp>=75?'✓ Passed · '+tp+'%':'Best '+tp+'%'):'Not taken');
    h+='<button class="module-card'+(lock?' locked':'')+'" onclick="openTest('+i+')"><div class="module-num">Weeks '+esc(t.weeks)+(lock?' 🔒':'')+'</div><div class="module-name">'+esc(t.title)+'</div><div class="module-desc">'+((t.questions||[]).length)+' questions · '+st+'</div></button>'; });
  h+='</div>';
  document.getElementById('testForm').innerHTML=h;
}
function openTest(i){ if(!unitUnlocked(i)){ alert('This section test is locked. Finish all of Unit '+(i+1)+'\'s weekly lessons first — pass each week\'s quiz (75 percent) to unlock the checkpoint.'); return; } currentTest=i; if(openPanelId!=='test')openPanel('test'); else renderTest(); }

function mmRenderTestFlow(){
  var host=document.getElementById('testFlowV53'); if(!host)return;
  host.innerHTML='<div class="mm-step-flow" aria-label="Checkpoint progress">'+
    '<span class="mm-step done"><b>1</b> Lessons ✓</span><span class="mm-step-arrow">→</span>'+
    '<span class="mm-step done"><b>2</b> Weekly Quizzes ✓</span><span class="mm-step-arrow">→</span>'+
    '<span class="mm-step"><b>3</b> Section Test</span><span class="mm-step-arrow">→</span>'+
    '<span class="mm-step"><b>4</b> Next Unit</span></div>';
}

function renderTest(){
  const t=tests()[currentTest]; if(!t){renderTestMenu();return;}
  set('testKicker',GRADE_LABEL[currentGrade]+' · Weeks '+t.weeks); set('testTitle',t.title);
  document.getElementById('testResult').innerHTML=''; testSel={}; mmRenderTestFlow();
  let h='';
  t.questions.forEach(function(q,i){ h+='<div class="q-item" id="ti-'+i+'"><div class="q-num">'+(i+1)+'. '+esc(rewordSel(q.q))+'</div>';
    q.options.forEach(function(o,j){ h+='<button class="mc-opt" id="to-'+i+'-'+j+'" onclick="pickOpt('+i+','+j+')">'+esc(o)+'</button>'; });
    h+='<div class="q-fb" id="tf-'+i+'"></div></div>'; });
  document.getElementById('testForm').innerHTML=h;
  document.getElementById('testButtons').innerHTML='<button class="btn-calc ghost" onclick="renderTestMenu()">← All checkpoints</button><button class="btn-calc green" onclick="submitTest()">✅ Submit test</button>';
}
function pickOpt(i,j){ testSel[i]=j; for(let k=0;k<8;k++){const b=document.getElementById('to-'+i+'-'+k); if(b)b.classList.toggle('sel',k===j);} }
function submitTest(){
  const t=tests()[currentTest]; if(!t)return; let correct=0;
  t.questions.forEach(function(q,i){ const sel=(i in testSel)?testSel[i]:-1; const ok=sel===q.answer; if(ok)correct++;
    const qi=document.getElementById('ti-'+i); qi.classList.remove('correct','wrong'); qi.classList.add(ok?'correct':'wrong');
    q.options.forEach(function(o,j){ const b=document.getElementById('to-'+i+'-'+j); if(!b)return; b.classList.remove('sel'); if(j===q.answer)b.classList.add('right'); else if(j===sel)b.classList.add('bad'); b.disabled=true; });
    const fb=document.getElementById('tf-'+i); fb.className='q-fb '+(ok?'ok':'no'); fb.innerHTML=(ok?'Correct! ':'Not quite. ')+esc(q.explain||''); });
  const pct=Math.round(correct/t.questions.length*100);
  recordScore('test',currentGrade,'u'+(currentTest+1),pct);
  addMissed(t.questions.filter(function(q,i){return testSel[i]!==q.answer;}));
  touchStreak(); if(pct>=75){celebrate();playChime();}
  const ti=tier(pct); const col=pct>=90?'#2a6b4a':pct>=75?'#1e6b6b':pct>=50?'#c4912e':'#7a3b1e';
  document.getElementById('testResult').innerHTML=
    '<div class="score-banner" style="background:'+col+'"><div class="pct">'+pct+'%</div><div class="lbl">'+correct+' of '+t.questions.length+' correct</div></div>'
    +'<div class="prize"><div class="emoji">'+ti.emoji+'</div><div class="txt"><b>'+esc(ti.name)+'</b><span>'+(pct>=75?'Checkpoint passed at 75% or higher! It counts toward your certificate.':'Review the lessons and try again to reach 75 percent.')+'</span></div></div>';
  document.getElementById('testButtons').innerHTML='<button class="btn-calc ghost" onclick="renderTestMenu()">← All checkpoints</button><button class="btn-calc green" onclick="renderTest()">↺ Try again</button><button class="btn-calc" onclick="openPanel(\'certificate\')">🏆 Prizes &amp; certificate</button>';
  const pb=document.querySelector('#panel-test .panel-body'); if(pb)pb.scrollTop=0;
}

/* ===== ACCESSIBILITY ===== */
function loadA11y(){ try{return JSON.parse(localStorage.getItem('mmA11y')||'{}');}catch(e){return {};} }
function applyA11y(){ const a=loadA11y(); const r=document.documentElement; r.classList.toggle('a11y-big',!!a.big); r.classList.toggle('a11y-easy',!!a.easy); r.classList.toggle('a11y-contrast',!!a.contrast);
  [['a11yBig','big'],['a11yEasy','easy'],['a11yContrast','contrast']].forEach(function(p){const el=document.getElementById(p[0]); if(el)el.checked=!!a[p[1]];});
  const sc=document.getElementById('soundChk'); if(sc)sc.checked=soundOn(); updateLangBtns(); }
function toggleA11y(k){ const a=loadA11y(); a[k]=!a[k]; try{localStorage.setItem('mmA11y',JSON.stringify(a));}catch(e){} applyA11y(); }

/* ===== GLOSSARY ===== */
function gradeGlossary(){ const map={}; lessons().forEach(function(l){(l.vocab||[]).forEach(function(v){ if(v&&v.term){ const key=v.term.toLowerCase(); if(!map[key])map[key]={term:v.term,def:v.def}; } });}); return Object.keys(map).sort().map(function(k){return map[k];}); }
let glossList=[];

/* ===== GLOSSARY CROSS-LINKS ===== */
const GLOSS_SEE_ALSO={
  'interest':['principal','savings','compound interest','bank'],
  'compound interest':['interest','principal','savings'],
  'principal':['interest','loan','debt'],
  'budget':['income','expense','savings','spending'],
  'income':['budget','earning','wage','salary'],
  'expense':['budget','spending','cost'],
  'savings':['interest','budget','bank','goal'],
  'investment':['risk','return','stock','interest'],
  'credit':['debt','loan','interest','credit score'],
  'debt':['loan','credit','interest','principal'],
  'tax':['income','government','deduction'],
  'inflation':['purchasing power','savings','cost'],
  'need':['want','spending','budget'],
  'want':['need','spending','budget'],
  'loan':['interest','principal','debt','credit'],
  'bank':['savings','interest','deposit','checking'],
  'stock':['investment','risk','return','dividend'],
  'entrepreneur':['income','profit','business','risk'],
  'profit':['revenue','expense','entrepreneur'],
  'wage':['income','salary','earning'],
};

function renderGlossary(){ set('glossaryKicker',gradeLabel(currentGrade)+' · '+t('Glossary')); const el=document.getElementById('glossaryList'); if(!el)return;
  const q=((document.getElementById('glossarySearch')||{}).value||'').toLowerCase().trim();
  glossList=gradeGlossary().filter(function(v){return !q||v.term.toLowerCase().indexOf(q)>-1||(v.def||'').toLowerCase().indexOf(q)>-1;});
  el.innerHTML='<div class="who">'+glossList.length+' '+t('terms')+(q?(' · "'+esc(q)+'"'):(' · '+gradeLabel(currentGrade)))+' · '+t('Tap a word to hear it')+'</div>'
    +'<div class="meta-pills" style="margin:2px 0 12px"><button class="btn-calc" onclick="downloadGlossary()">'+esc(t('🖨️ Print / Download glossary'))+'</button></div>'
    +'<div class="vocab-grid">'
    +glossList.map(function(v,i){
      const key=(v.term||'').toLowerCase();
      const related=(GLOSS_SEE_ALSO&&GLOSS_SEE_ALSO[key])||[];
      const seeLine=related.length
        ?'<div class="vocab-see" style="font-size:11px;color:var(--ink-light);margin-top:4px">See also: '+related.map(function(r){return '<a href="#" onclick="event.preventDefault();document.getElementById(\'glossarySearch\').value=\''+esc(r)+'\';renderGlossary();" style="color:var(--gold);text-decoration:none;font-weight:700">'+esc(r)+'</a>';}).join(', ')+'</div>':'';
      return '<div class="vocab-item gloss-click" role="button" tabindex="0" onclick="glossSpeak('+i+')" onkeydown="if(event.key===\'Enter\')glossSpeak('+i+')" title="'+esc(t('Tap to hear'))+'"><div class="vocab-term">🔊 '+esc(v.term)+'</div><div class="vocab-def">'+esc(v.def)+'</div>'+seeLine+'</div>';
    }).join('')+'</div>';
}
function glossSpeak(i){ const v=glossList[i]; if(v)speakText(v.term+'. '+v.def); }
let wordOfDay=null;
function speakWordOfDay(){ if(wordOfDay)speakText(wordOfDay.term+'. '+wordOfDay.def); }
function dayIndex(){ try{ const d=new Date(); return Math.floor((d-new Date(d.getFullYear(),0,0))/86400000); }catch(e){ return 0; } }
let factToday=null;
function factOfDay(){
  if(typeof FACTS==='undefined'||!FACTS.length)return null;
  /* Global rotation: combine FACTS arrays from all grades if DAILY_FACTS exists */
  let pool=FACTS;
  try{ if(typeof DAILY_FACTS!=='undefined'){ pool=Object.values(DAILY_FACTS).reduce(function(a,b){return a.concat(Array.isArray(b)?b:[]);},[]); if(!pool.length)pool=FACTS; } }catch(e){}
  const f=pool[dayIndex()%pool.length];
  const lg=loadLang(); return (f&&(f[lg]||f.en))||null;
}
function speakFact(){ if(factToday)speakText(factToday); }
function unitProgressHTML(){ const ls=lessons(); const p=myProg(); const units=Math.ceil(ls.length/6); let h=''; for(let u=0;u<units;u++){ const block=ls.slice(u*6,u*6+6); let done=0; block.forEach(function(l){var v=p['quiz|'+currentGrade+'|'+l.week]; if(v!=null&&v>=75)done++;}); const pctu=block.length?Math.round(done/block.length*100):0; h+='<div style="margin:6px 0"><div style="font-size:12px;color:var(--ink-mid);margin-bottom:2px">'+esc(t('Unit'))+' '+(u+1)+' · '+done+'/'+block.length+'</div><div class="pbar"><i style="width:'+pctu+'%"></i></div></div>'; } return h; }
function nextBadgeNudge(){ const st=progStats(); if(st.gold>=1)return ''; var msg=(st.passed<1)?t('Pass one quiz (75%+) to earn your first medal!'):t('Score 90%+ on a quiz to earn Gold!'); return '<div class="lang-note" style="background:rgba(196,145,46,.14);border-color:rgba(196,145,46,.4)">🎯 '+esc(msg)+'</div>'; }
function backupNudge(){ const s=loadStore(); if(!Object.keys(s.list).length)return ''; var last=0; try{last=parseInt(localStorage.getItem('mmLastBackup')||'0');}catch(e){} var days=last?((Date.now()-last)/86400000):999; if(days<7)return ''; return '<div class="lang-note" style="background:rgba(122,30,77,.10);border-color:rgba(122,30,77,.3)">💾 '+esc(t('Tip: back up class progress from the Teacher desk — data is saved only in this browser.'))+'</div>'; }
function downloadGlossary(){ const list=gradeGlossary(); if(!list.length)return;
  const rows=list.map(function(v){return '<tr><td style="font-weight:700;width:32%">'+esc(v.term)+'</td><td>'+esc(v.def)+'</td></tr>';}).join('');
  const body='<div class="paper"><h1>Money Matters — '+esc(gradeLabel(currentGrade))+'</h1><h2>'+esc(t('Money Words'))+'</h2><table border="1" cellspacing="0" cellpadding="6" style="border-collapse:collapse;width:100%">'+rows+'</table></div>';
  const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Glossary</title><style>'+PAPER_CSS+'</style></head><body>'+body+'\n</body></html>';
  try{ const blob=new Blob(['﻿'+html],{type:'application/msword'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='MoneyMatters_Glossary_'+currentGrade+'_'+loadLang()+'.doc'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){ alert('Download not supported in this browser. Use Print / Save PDF instead.'); }
}

/* ===== TEACHER VIEW + REPORTS ===== */
function saveSchoolNameFromTeacher(){
  const el=document.getElementById('teacherSchoolInput'); if(!el)return;
  const val=(el.value||'').trim().slice(0,80);
  try{ if(val)localStorage.setItem('mmSchoolName',val); else localStorage.removeItem('mmSchoolName'); }catch(e){}
  /* sync to cert panel field if open */
  const certEl=document.getElementById('certSchool'); if(certEl)certEl.value=val;
}
function getSchoolName(){ try{return localStorage.getItem('mmSchoolName')||'';}catch(e){return '';} }
function saveSchoolName(){
  const el=document.getElementById('certSchool'); if(!el)return;
  const val=(el.value||'').trim().slice(0,80);
  try{ if(val)localStorage.setItem('mmSchoolName',val); else localStorage.removeItem('mmSchoolName'); }catch(e){}
}
function populateSchoolField(){
  const el=document.getElementById('certSchool'); if(el&&!el.value)el.value=getSchoolName();
}

function renderTeacher(){ const s=loadStore(); const ids=Object.keys(s.list); const el=document.getElementById('teacherBody'); if(!el)return;
  let h='<div class="who">'+esc(t('All learner profiles saved on this device. Reports print or download as Word.'))+'</div>';
  /* School name setting */
  const schoolVal=esc(getSchoolName());
  h+='<div class="section-head">'+esc(t('School'))+'</div>';
  h+='<div class="meta-pills" style="margin-bottom:14px"><input class="quiz-input" id="teacherSchoolInput" style="max-width:320px;margin-top:0" maxlength="80" placeholder="'+esc(t('School name (shown on certificates and reports)'))+'" value="'+schoolVal+'" oninput="saveSchoolNameFromTeacher()"><button class="btn-calc" onclick="saveSchoolNameFromTeacher();infoToast(\'✓ School name saved.\',2000)">'+esc(t('Save'))+'</button></div>';
  h+='<div class="meta-pills" style="margin-bottom:8px"><button class="btn-calc" style="background:#1e6b6b" onclick="exportGradebook()">'+esc(t('⬇ Export gradebook (CSV)'))+'</button><button class="btn-calc" style="background:#217346" onclick="exportGradebookXLSX()">📊 Excel</button><button class="btn-calc" onclick="openPanel(\'students\')">👥 '+esc(t('All Students'))+'</button><button class="btn-calc" onclick="changePin()">'+esc(t('🔑 Change adult passcode'))+'</button><button class="btn-calc ghost" onclick="toggleGate()">'+esc(gateOn()?t('🔓 Turn OFF week locks'):t('🔒 Turn ON week locks'))+'</button></div>';
  h+='<div class="meta-pills" style="margin-bottom:8px"><button class="btn-calc" onclick="printFamily()">'+esc(t('🏠 Family letter (print)'))+'</button><button class="btn-calc" style="background:#1e6b6b" onclick="downloadFamily()">'+esc(t('⬇ Family letter (.doc)'))+'</button><button class="btn-calc" onclick="backupData()">'+esc(t('💾 Backup all progress'))+'</button><button class="btn-calc ghost" onclick="restoreData()">'+esc(t('↩ Restore from file'))+'</button></div>';
  h+='<div class="meta-pills" style="margin-bottom:14px"><button class="btn-calc" onclick="checkContent()">'+esc(t('🔎 Check content'))+'</button><button class="btn-calc" style="background:#7a1e4d" onclick="runQualityAudit()">⭐ 9+ Quality Audit</button><button class="btn-calc" style="background:#1e6b6b" onclick="itemAnalysisReport()">'+esc(t('📊 Most-missed questions'))+'</button><button class="btn-calc" style="background:#7a5a10" onclick="renderGameReports()">🎮 Game performance</button><button class="btn-calc" style="background:#a33" onclick="removeAllStudents()">'+esc(t('🗑 Remove ALL students'))+'</button></div>';
  h+='<div class="section-head">'+esc(t('Import teachers & students'))+'</div>';
  h+='<div class="who" style="margin-bottom:6px">'+esc(t('CSV: Student Name, Grade (K-8), Teacher — one per line. A line like "Teacher: Ms. Rivera" adds a teacher only.'))+'</div>';
  h+='<div class="meta-pills" style="margin-bottom:6px"><input type="file" id="rosterFile" accept=".csv,.txt,.tsv,.json,.docx,text/csv,text/plain,application/json,application/vnd.openxmlformats-officedocument.wordprocessingml.document" aria-label="'+esc(t('Choose roster CSV file'))+'" onchange="importRosterFile(event)" style="max-width:230px;font-size:12px"> <button class="btn-calc ghost" onclick="downloadRosterTemplate()">'+esc(t('⬇ CSV template'))+'</button></div>';
  h+='<textarea id="rosterPaste" aria-label="'+esc(t('Paste roster rows'))+'" style="width:100%;max-width:460px;height:76px;display:block;border:1px solid rgba(140,90,30,.28);border-radius:8px;padding:8px;font-family:system-ui,sans-serif;font-size:13px" placeholder="Ava Martin, 3, Ms. Rivera&#10;Liam Chen, K, Mr. Park"></textarea>';
  h+='<div class="meta-pills" style="margin:6px 0 14px"><button class="btn-calc" style="background:#1e6b6b" onclick="importRosterPaste()">'+esc(t('📥 Import roster'))+'</button></div>';
  h+='<div class="section-head">'+esc(t('Teachers'))+'</div><div class="meta-pills" style="margin-bottom:6px"><input class="quiz-input" id="newTeacherName" style="max-width:210px;margin-top:0" maxlength="60" placeholder="'+esc(t('Teacher name'))+'" onkeydown="if(event.key===\'Enter\')addTeacherFromForm()"><button class="btn-calc" onclick="addTeacherFromForm()">'+esc(t('➕ Add teacher or guardian'))+'</button></div>';
  h+='<div class="who" style="margin-bottom:14px">'+(teacherList().length
    ?teacherList().map(function(tn){
        var tgrds=ids.filter(function(id){return (s.list[id].teacher||'')===tn;})
          .map(function(id){return s.list[id].grade||'K';})
          .filter(function(v,i,a){return a.indexOf(v)===i;}).sort();
        return '👩‍🏫 '+esc(tn)+(tgrds.length?' <span style="font-size:11px;background:var(--gold-pale);border-radius:6px;padding:1px 7px">'+tgrds.join(', ')+'</span>':'');
      }).join(' &nbsp;·&nbsp; ')
    :esc(t('No teachers or guardians yet.')))+'</div>';
  h+='<div class="section-head">'+esc(t('Materials'))+' — '+esc(gradeLabel(currentGrade))+' ('+fullMaterialsEN(currentGrade).length+')</div><div class="meta-pills" style="margin-bottom:14px"><button class="btn-calc" style="background:#8a5e10" onclick="printMaterialsSheet()">'+esc(t('🃏 Print material cards'))+'</button><button class="btn-calc" style="background:#1e6b6b" onclick="downloadMaterialsList()">'+esc(t('⬇ Materials list (.doc)'))+'</button></div>';
  h+='<div class="section-head">'+esc(t('Set this week'))+' — '+esc(gradeLabel(currentGrade))+'</div>';
  h+='<div class="meta-pills" style="margin-bottom:14px"><select id="assignWeekSel" class="gloss-search" style="max-width:280px;margin:0">'+lessons().map(function(l,i){return '<option value="'+i+'"'+(assignedWeek(currentGrade)===i?' selected':'')+'>'+esc(t('Week'))+' '+l.week+' — '+esc(l.title)+'</option>';}).join('')+'</select> <button class="btn-calc" onclick="saveAssignWeek()">'+esc(t('📌 Assign'))+'</button>'+(assignedWeek(currentGrade)!=null?(' <button class="btn-calc ghost" onclick="clearAssignWeek()">'+esc(t('Clear'))+'</button>'):'')+'</div>';
  if(!ids.length){ h+='<div class="fact"><div class="fact-icon">👩‍🏫</div><div class="fact-text">'+esc(t('No students yet — open the Student desk to add one.'))+'</div></div>'; el.innerHTML=h; return; }
  var tlist=teacherList();
  var gradeSeq=['K','1','2','3','4','5','6','7','8'];
  var gradeOptions='<option value="">'+esc(t('All grades'))+'</option>'+gradeSeq.map(function(g){return '<option value="'+g+'"'+(teacherGradeFilter===g?' selected':'')+'>'+esc(GRADE_LABEL[g]||('Grade '+g))+'</option>';}).join('');
  var rosterBase=ids.filter(function(id){
    var st=s.list[id];
    return (!teacherFilter||(st.teacher||'')===teacherFilter) && (!teacherGradeFilter||(st.grade||'K')===teacherGradeFilter);
  });
  var studentOptions='<option value="">'+esc(t('All students'))+'</option>'+rosterBase.slice().sort(function(a,b){return (s.list[a].name||'').localeCompare(s.list[b].name||'');}).map(function(id){
    return '<option value="'+esc(id)+'"'+(teacherStudentFilter===id?' selected':'')+'>'+esc(s.list[id].name)+'</option>';
  }).join('');
  if(tlist.length||ids.length){
    h+='<div class="section-head">'+esc(t('Roster'))+'</div>';
    h+='<div class="v53-verify"><b>🔐 Verify student</b><input id="v53RosterVerifyInput" maxlength="6" placeholder="6-character code" aria-label="Roster verification code" onkeydown="if(event.key===\'Enter\')verifyRosterCode()"><button class="btn-calc ghost" onclick="verifyRosterCode()">Verify</button><span id="v53RosterVerifyMsg" style="font-size:12px"></span></div>';
    h+='<div class="meta-pills" style="margin-bottom:8px">'
      +'<select class="gloss-search" style="max-width:220px;margin:0" onchange="setTeacherFilter(this.value)"><option value="">'+esc(t('All teachers'))+'</option>'+tlist.map(function(tn){return '<option value="'+esc(tn)+'"'+(teacherFilter===tn?' selected':'')+'>'+esc(tn)+'</option>';}).join('')+'</select>'
      +'<select class="gloss-search" style="max-width:190px;margin:0" onchange="setTeacherGradeFilter(this.value)">'+gradeOptions+'</select>'
      +'<select class="gloss-search" style="max-width:240px;margin:0" onchange="setTeacherStudentFilter(this.value)">'+studentOptions+'</select>'
      +'</div>';
  }
  var fids = rosterBase;
  if(teacherStudentFilter) fids=fids.filter(function(id){return id===teacherStudentFilter;});
  let sumPassed=0,sumAvg=0,cnt=0; fids.forEach(function(id){ const x=progStatsFor(s.list[id].prog); sumPassed+=x.passed; sumAvg+=x.avg; cnt++; });
  h+='<div class="card"><div class="card-title">📊 '+esc(t('Class summary'))+(teacherFilter?(' · 👩‍🏫 '+esc(teacherFilter)):'')+(teacherGradeFilter ? (' · '+esc(gradeLabel(teacherGradeFilter))) : '')+(teacherStudentFilter&&s.list[teacherStudentFilter] ? (' · 👤 '+esc(s.list[teacherStudentFilter].name)) : '')+'</div><div class="card-body">'+esc(t('Students'))+': <b>'+cnt+'</b> · '+esc(t('Avg lessons mastered'))+': <b>'+(cnt?Math.round(sumPassed/cnt):0)+'</b> · '+esc(t('Avg quiz score'))+': <b>'+(cnt?Math.round(sumAvg/cnt):0)+'%</b></div></div>';
  if(!fids.length){ h+='<div class="who" style="margin-bottom:10px">'+esc(t('No students for this teacher.'))+'</div>'; }
  fids.forEach(function(id){ const st=s.list[id]; const x=progStatsFor(st.prog); const medal=x.gold>=1?'🏆':x.passed>=1?'🥇':x.taken>=1?'🎖️':'⭐';
    const _next=nextGradeFor(st.grade||'K'); const _gc=gradeCompletionFor(id,st.grade||'K');
    const _opens=(loadUsage().students&&loadUsage().students[id])?(loadUsage().students[id].opens||0):0;
    h+='<div class="unit-card"><div class="unit-head"><div class="unit-title">'+medal+' '+esc(st.name)+' · '+esc(gradeLabel(st.grade||'K'))+(st.teacher?(' · 👩‍🏫 '+esc(st.teacher)):'')+(id===getTabActive()||((!getTabActive())&&id===s.active)?' ('+t('active')+')':'')
      +(_gc.complete?' <span style="font-size:11px;background:#fff3cd;color:#856404;border-radius:6px;padding:2px 7px;margin-left:4px">🎓 Grade complete!</span>':'')
      +'</div>'
      +'<div class="meta-pills"><span class="v53-roster-code" title="Roster verification code">🔐 '+studentVerificationCode(id)+'</span><button class="btn-calc ghost v53-code-btn" onclick="copyStudentVerificationCode(\''+id+'\')">Copy</button><button class="btn-calc ghost v53-code-btn" onclick="regenerateStudentVerificationCode(\''+id+'\')">New</button><button class="btn-calc" onclick="teacherReport(\''+id+'\')">'+esc(t('🖨️ Report'))+'</button>'
      +'<button class="btn-calc" style="background:#1e6b6b" onclick="teacherExport(\''+id+'\')">'+esc(t('⬇ Export'))+'</button>'
      +'<button class="btn-calc ghost" onclick="teacherReset(\''+id+'\')">'+esc(t('Reset progress'))+'</button>'
      +(_next&&_gc.complete?'<button class="btn-calc" style="background:#7a5a10" onclick="promoteStudent(\''+id+'\')">🎓 '+esc(t('Promote'))+'→Gr '+_next+'</button>':'')
      +'<button class="btn-calc" style="background:#a33" onclick="removeStudent(\''+id+'\')">'+esc(t('🗑 Remove'))+'</button></div></div>'
      +'<div class="card-body">'+esc(t('Lessons mastered'))+': <b>'+x.passed+'</b> · '+esc(t('Quiz avg'))+': <b>'+x.avg+'%</b> · '+esc(t('Quizzes taken'))+': '+x.taken+' · '+esc(t('Checkpoints'))+': <b>'+x.testsPassed+'</b>/'+x.tests+' · 📖 Opens: '+_opens+' · '+esc(t('Last active'))+': '+esc(st.lastActive||'—')+'</div></div>'; });
  /* Fix #13: use DocumentFragment for atomic DOM update — eliminates layout shift
     on large rosters by replacing the element's children in one operation       */
  const frag=document.createRange().createContextualFragment(h);
  el.innerHTML='';
  el.appendChild(frag);
  /* scroll to top every time panel opens */
  const pb=el.closest('.panel-body')||el.parentElement;
  if(pb)pb.scrollTop=0;
}
function assignedWeek(g){ try{ const v=localStorage.getItem('mmAssign|'+g); return v==null?null:parseInt(v); }catch(e){ return null; } }
function saveAssignWeek(){ const sel=document.getElementById('assignWeekSel'); if(!sel)return; try{localStorage.setItem('mmAssign|'+currentGrade,sel.value);}catch(e){} infoToast('✓ This week is set — students will start here.'); renderTeacher(); }
function clearAssignWeek(){ try{localStorage.removeItem('mmAssign|'+currentGrade);}catch(e){} renderTeacher(); }
function removeAllStudents(){ mmConfirm('Remove all students?','This will permanently delete every student profile and all progress from this device. This cannot be undone.','Remove all','🗑').then(function(ok){ if(!ok)return; const s=loadStore(); s.list={}; s.active=null; saveStore(s); refreshStudentUI(); buildGradeNav(); renderTeacher(); infoToast('All students removed.'); }); }
function checkContent(){ let issues=[]; const gr=["K","1","2","3","4","5","6","7","8"];
  gr.forEach(function(g){ const lq=(typeof LESSON_QUIZ!=='undefined'&&LESSON_QUIZ[g])?LESSON_QUIZ[g]:[]; lq.forEach(function(w){ (w.questions||[]).forEach(function(q,qi){ if(!q.options||q.answer==null||q.answer<0||q.answer>=q.options.length||q.options.length<3) issues.push('G'+g+' quiz wk'+w.week+' Q'+(qi+1)+': invalid options/answer'); if(q.options&&new Set(q.options.map(function(x){return String(x).trim().toLowerCase();})).size!==q.options.length) issues.push('G'+g+' quiz wk'+w.week+' Q'+(qi+1)+': duplicate answer choices'); if(!q.explain) issues.push('G'+g+' quiz wk'+w.week+' Q'+(qi+1)+': missing explanation'); }); });
    const ts=(typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[g])?SECTION_TESTS[g]:[]; ts.forEach(function(tt,ui){ (tt.questions||[]).forEach(function(q,qi){ if(!q.options||q.answer==null||q.answer<0||q.answer>=q.options.length) issues.push('G'+g+' test u'+(ui+1)+' Q'+(qi+1)+': bad answer index'); }); });
    const ls=(typeof LESSONS!=='undefined'&&LESSONS[g])?LESSONS[g]:[]; ls.forEach(function(l){ ['title','objective','mini','warmUp','check'].forEach(function(f){ if(!l[f]||!(''+l[f]).trim()) issues.push('G'+g+' wk'+l.week+': empty '+f); }); }); });
  if(issues.length){
    _openModal('⚠️','Content check: '+issues.length+' issue(s)',issues.slice(0,30).join('\n')+(issues.length>30?'\n…and '+(issues.length-30)+' more':''),[{label:'OK',value:true}]);
  } else {
    infoToast('✅ All content passed — quiz answers valid, no empty lesson fields.');
  }
}
function runQualityAudit(){
  var grades=['K','1','2','3','4','5','6','7','8'], rows=[], fail=[];
  grades.forEach(function(g){
    var ls=(typeof LESSONS!=='undefined'&&LESSONS[g])?LESSONS[g]:[], qs=(typeof LESSON_QUIZ!=='undefined'&&LESSON_QUIZ[g])?LESSON_QUIZ[g]:[], ts=(typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[g])?SECTION_TESTS[g]:[];
    if(ls.length!==36)fail.push(g+': expected 36 lessons, found '+ls.length);
    if(qs.length!==36)fail.push(g+': expected 36 quiz weeks, found '+qs.length);
    if(ts.length!==6)fail.push(g+': expected 6 checkpoints, found '+ts.length);
    ls.forEach(function(l){['title','sub','objective','duration','standards','vocab','materials','warmUp','mini','guidedPractice','independent','discussion','check','differentiation','homeExtension','worksheet','exit','prep'].forEach(function(k){if(l[k]==null||(Array.isArray(l[k])&&!l[k].length))fail.push(g+' W'+l.week+': missing '+k);});if(!l.worksheet||!Array.isArray(l.worksheet.items)||l.worksheet.items.length<3)fail.push(g+' W'+l.week+': worksheet too short');});
    qs.forEach(function(w){(w.questions||[]).forEach(function(q,i){if(!q.q||!Array.isArray(q.options)||q.options.length<3||!Number.isInteger(q.answer)||q.answer<0||q.answer>=q.options.length||!q.explain)fail.push(g+' W'+w.week+' Q'+(i+1)+': assessment structure');});});
    ts.forEach(function(t){(t.questions||[]).forEach(function(q,i){if(!q.q||!Array.isArray(q.options)||q.options.length<3||!Number.isInteger(q.answer)||q.answer<0||q.answer>=q.options.length||!q.explain)fail.push(g+' T'+t.unit+' Q'+(i+1)+': checkpoint structure');});});
  });
  var pwa=(location.protocol==='http:'||location.protocol==='https:');
  rows.push(['Curriculum structure',fail.filter(function(x){return /expected 36 lessons/.test(x);}).length===0]);
  rows.push(['Grade progression',grades.every(function(g){return LESSONS[g]&&LESSONS[g].length===36;} )]);
  rows.push(['Lesson completeness',fail.filter(function(x){return /missing|worksheet too short/.test(x);}).length===0]);
  rows.push(['Quiz quantity',grades.every(function(g){return LESSON_QUIZ[g]&&LESSON_QUIZ[g].length===36;} )]);
  rows.push(['Quiz quality',grades.every(function(g){return LESSON_QUIZ[g]&&LESSON_QUIZ[g].every(function(w){return (w.questions||[]).every(function(q){return q.explain&&q.options&&q.options.length>=3;});});} )]);
  rows.push(['Assessment rigor',grades.every(function(g){return g==='K'||g==='1'||g==='2'||typeof _mmAssessmentChallenges==='function';} )]);
  rows.push(['Worksheets',fail.filter(function(x){return /worksheet too short/.test(x);}).length===0]);
  rows.push(['Materials system',grades.every(function(g){return LESSONS[g].every(function(l){return Array.isArray(l.materials)&&l.materials.length>0;});})]);
  rows.push(['Printable system',typeof renderDoc==='function'&&typeof downloadDoc==='function']);
  rows.push(['Games',typeof _runMiniGame==='function'&&typeof _mmInitCoin==='function'&&typeof _mmInitShop==='function'&&typeof _mmInitLife==='function']);
  rows.push(['Accessibility',document.querySelector('.skip-link')!==null&&document.querySelector('main#main-content')!==null]);
  rows.push(['PWA deployment path',pwa||typeof navigator.serviceWorker!=='undefined']);
  var passed=rows.filter(function(r){return r[1];}).length;
  var body='<div class="section-head">⭐ 9+ Quality Audit</div><div class="who">Automated audit across all nine grades. A green row means the structural quality gate passed; content pedagogy and commercial compliance still require human/release review.</div>';
  body+='<div class="card" style="margin-bottom:12px"><div class="card-title">Quality gate: '+passed+'/'+rows.length+' automated areas passed</div><div class="card-body">Blocking content errors: <b>'+fail.length+'</b>'+(fail.length?' · Review the flagged items below.':' · No structural content errors found.')+'</div></div>';
  body+=rows.map(function(r){return '<div class="unit-card" style="margin-bottom:7px"><div class="unit-head"><div class="unit-title">'+(r[1]?'✓':'⚠️')+' '+esc(r[0])+'</div><span style="color:'+(r[1]?'var(--green)':'#a33')+';font-weight:800">'+(r[1]?'9+ gate passed':'Needs work')+'</span></div></div>';}).join('');
  if(fail.length)body+='<div class="card"><div class="card-title">Flagged items</div><div class="card-body">'+fail.slice(0,50).map(esc).join('<br>')+(fail.length>50?'<br>…and '+(fail.length-50)+' more':'')+'</div></div>';
  body+='<div class="meta-pills"><button class="btn-calc green" onclick="runQualityAudit()">↻ Run Again</button><button class="btn-calc ghost" onclick="renderTeacher()">← Back to Teacher</button></div>';
  var el=document.getElementById('teacherBody');if(el)el.innerHTML=body;
}
function fullMaterialsEN(g){ g=g||currentGrade; const arr=(typeof LESSONS!=='undefined'&&LESSONS[g])?LESSONS[g]:[]; const seen={},list=[]; arr.forEach(function(l){(l.materials||[]).forEach(function(m){ const k=(''+m).trim().toLowerCase(); if(k&&!seen[k]){seen[k]=1;list.push((''+m).trim());} });}); list.sort(function(a,b){return a.toLowerCase()<b.toLowerCase()?-1:1;}); return list; }
function matCard(term){ const k=(''+term).trim().toLowerCase(); const c=(typeof MATERIAL_CARDS!=='undefined'&&MATERIAL_CARDS[k])?MATERIAL_CARDS[k]:null; const lg=loadLang(); const emoji=c?c.emoji:'📦'; const desc=c?((c[lg]&&c[lg].desc)||(c.en&&c.en.desc)||term):term; const use=c?((c[lg]&&c[lg].usage)||(c.en&&c.en.usage)||''):''; return {emoji:emoji,term:term,desc:desc,use:use}; }
const MICONS={
 coin:'<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="24" fill="#f1c40f" stroke="#b8860b" stroke-width="3"/><text x="32" y="42" font-size="28" text-anchor="middle" fill="#7a5a10" font-family="Arial" font-weight="bold">$</text></svg>',
 bill:'<svg viewBox="0 0 64 64"><rect x="6" y="18" width="52" height="28" rx="3" fill="#7bc47f" stroke="#2e7d32" stroke-width="2"/><circle cx="32" cy="32" r="9" fill="none" stroke="#2e7d32" stroke-width="2"/><text x="32" y="38" font-size="13" text-anchor="middle" fill="#1b5e20" font-family="Arial" font-weight="bold">$</text></svg>',
 piggy:'<svg viewBox="0 0 64 64"><ellipse cx="32" cy="36" rx="22" ry="16" fill="#f8b7cd" stroke="#d16a8e" stroke-width="2"/><circle cx="20" cy="34" r="6" fill="#f8b7cd" stroke="#d16a8e" stroke-width="2"/><circle cx="19" cy="34" r="1.6" fill="#7a3b52"/><circle cx="23" cy="34" r="1.6" fill="#7a3b52"/><circle cx="40" cy="30" r="2" fill="#7a3b52"/><rect x="30" y="20" width="6" height="5" fill="#f8b7cd" stroke="#d16a8e"/><rect x="18" y="50" width="4" height="6" fill="#d16a8e"/><rect x="42" y="50" width="4" height="6" fill="#d16a8e"/></svg>',
 jar:'<svg viewBox="0 0 64 64"><rect x="16" y="16" width="32" height="8" rx="2" fill="#bfe3f0"/><path d="M18 24 h28 v26 a6 6 0 0 1-6 6 H24 a6 6 0 0 1-6-6 Z" fill="#cfeefc" stroke="#5aa9c9" stroke-width="2"/><circle cx="27" cy="44" r="4" fill="#f1c40f"/><circle cx="37" cy="48" r="4" fill="#f1c40f"/></svg>',
 pencil:'<svg viewBox="0 0 64 64"><g transform="rotate(45 32 32)"><rect x="26" y="8" width="12" height="40" fill="#f4d03f" stroke="#b7950b" stroke-width="1.5"/><polygon points="26,48 38,48 32,58" fill="#e6b800"/><polygon points="29,54 35,54 32,58" fill="#5d4037"/><rect x="26" y="8" width="12" height="6" fill="#e74c3c"/></g></svg>',
 marker:'<svg viewBox="0 0 64 64"><g transform="rotate(45 32 32)"><rect x="26" y="10" width="12" height="34" rx="2" fill="#5dade2" stroke="#2874a6" stroke-width="1.5"/><polygon points="27,44 37,44 32,54" fill="#34495e"/><rect x="26" y="10" width="12" height="7" fill="#2874a6"/></g></svg>',
 paper:'<svg viewBox="0 0 64 64"><rect x="14" y="8" width="36" height="48" rx="2" fill="#fff" stroke="#888" stroke-width="2"/><line x1="20" y1="18" x2="44" y2="18" stroke="#bbb" stroke-width="2"/><line x1="20" y1="26" x2="44" y2="26" stroke="#bbb" stroke-width="2"/><line x1="20" y1="34" x2="44" y2="34" stroke="#bbb" stroke-width="2"/><line x1="20" y1="42" x2="36" y2="42" stroke="#bbb" stroke-width="2"/></svg>',
 card:'<svg viewBox="0 0 64 64"><rect x="8" y="16" width="48" height="32" rx="3" fill="#fff" stroke="#888" stroke-width="2"/><line x1="8" y1="24" x2="56" y2="24" stroke="#e74c3c" stroke-width="2"/><line x1="16" y1="32" x2="48" y2="32" stroke="#bbb" stroke-width="2"/><line x1="16" y1="40" x2="40" y2="40" stroke="#bbb" stroke-width="2"/></svg>',
 scissors:'<svg viewBox="0 0 64 64"><circle cx="20" cy="44" r="7" fill="none" stroke="#555" stroke-width="3"/><circle cx="20" cy="20" r="7" fill="none" stroke="#555" stroke-width="3"/><line x1="26" y1="24" x2="52" y2="44" stroke="#888" stroke-width="3"/><line x1="26" y1="40" x2="52" y2="20" stroke="#888" stroke-width="3"/></svg>',
 glue:'<svg viewBox="0 0 64 64"><rect x="24" y="20" width="16" height="30" rx="3" fill="#f5b7b1" stroke="#c0392b" stroke-width="2"/><rect x="28" y="10" width="8" height="10" fill="#fff" stroke="#c0392b" stroke-width="2"/><polygon points="28,10 36,10 32,4" fill="#e67e22"/></svg>',
 chart:'<svg viewBox="0 0 64 64"><rect x="10" y="10" width="44" height="44" fill="#fff" stroke="#888" stroke-width="2"/><rect x="18" y="34" width="6" height="14" fill="#3498db"/><rect x="29" y="26" width="6" height="22" fill="#2ecc71"/><rect x="40" y="18" width="6" height="30" fill="#e67e22"/></svg>',
 calc:'<svg viewBox="0 0 64 64"><rect x="16" y="8" width="32" height="48" rx="3" fill="#34495e"/><rect x="20" y="12" width="24" height="10" fill="#aed6f1"/><g fill="#ecf0f1"><rect x="20" y="26" width="6" height="6"/><rect x="29" y="26" width="6" height="6"/><rect x="38" y="26" width="6" height="6"/><rect x="20" y="35" width="6" height="6"/><rect x="29" y="35" width="6" height="6"/><rect x="38" y="35" width="6" height="6"/><rect x="20" y="44" width="6" height="6"/><rect x="29" y="44" width="6" height="6"/><rect x="38" y="44" width="6" height="6"/></g></svg>',
 dice:'<svg viewBox="0 0 64 64"><rect x="14" y="14" width="36" height="36" rx="6" fill="#fff" stroke="#555" stroke-width="2"/><circle cx="24" cy="24" r="3" fill="#333"/><circle cx="40" cy="24" r="3" fill="#333"/><circle cx="32" cy="32" r="3" fill="#333"/><circle cx="24" cy="40" r="3" fill="#333"/><circle cx="40" cy="40" r="3" fill="#333"/></svg>',
 envelope:'<svg viewBox="0 0 64 64"><rect x="10" y="18" width="44" height="30" rx="2" fill="#fdf2d0" stroke="#c9a227" stroke-width="2"/><polyline points="10,20 32,38 54,20" fill="none" stroke="#c9a227" stroke-width="2"/></svg>',
 box:'<svg viewBox="0 0 64 64"><polygon points="12,22 32,12 52,22 32,32" fill="#e0b088" stroke="#a9744f" stroke-width="2"/><polygon points="12,22 12,46 32,56 32,32" fill="#c8935f" stroke="#a9744f" stroke-width="2"/><polygon points="52,22 52,46 32,56 32,32" fill="#d9a878" stroke="#a9744f" stroke-width="2"/></svg>',
 book:'<svg viewBox="0 0 64 64"><rect x="14" y="12" width="36" height="40" rx="2" fill="#2980b9" stroke="#1b4f72" stroke-width="2"/><rect x="14" y="12" width="8" height="40" fill="#1b4f72"/><line x1="28" y1="22" x2="44" y2="22" stroke="#fff" stroke-width="2"/><line x1="28" y1="30" x2="44" y2="30" stroke="#fff" stroke-width="2"/></svg>',
 board:'<svg viewBox="0 0 64 64"><rect x="8" y="12" width="48" height="34" rx="2" fill="#eafaf1" stroke="#555" stroke-width="2"/><line x1="24" y1="46" x2="24" y2="56" stroke="#555" stroke-width="3"/><line x1="40" y1="46" x2="40" y2="56" stroke="#555" stroke-width="3"/></svg>',
 clock:'<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="22" fill="#fff" stroke="#555" stroke-width="3"/><line x1="32" y1="32" x2="32" y2="18" stroke="#333" stroke-width="3"/><line x1="32" y1="32" x2="42" y2="36" stroke="#333" stroke-width="3"/></svg>',
 note:'<svg viewBox="0 0 64 64"><rect x="14" y="14" width="36" height="36" fill="#fdf07a" stroke="#c9b400" stroke-width="1.5"/><polygon points="42,50 50,50 50,42" fill="#e6d200"/></svg>',
 ruler:'<svg viewBox="0 0 64 64"><rect x="8" y="24" width="48" height="16" fill="#f7dc6f" stroke="#b7950b" stroke-width="2"/><g stroke="#b7950b" stroke-width="1.5"><line x1="16" y1="24" x2="16" y2="32"/><line x1="24" y1="24" x2="24" y2="30"/><line x1="32" y1="24" x2="32" y2="32"/><line x1="40" y1="24" x2="40" y2="30"/><line x1="48" y1="24" x2="48" y2="32"/></g></svg>',
 receipt:'<svg viewBox="0 0 64 64"><path d="M18 10 h28 v44 l-5 -4 -5 4 -4 -4 -4 4 -5 -4Z" fill="#fff" stroke="#888" stroke-width="2"/><line x1="24" y1="20" x2="40" y2="20" stroke="#bbb" stroke-width="2"/><line x1="24" y1="28" x2="40" y2="28" stroke="#bbb" stroke-width="2"/><line x1="24" y1="36" x2="34" y2="36" stroke="#bbb" stroke-width="2"/></svg>',
 calendar:'<svg viewBox="0 0 64 64"><rect x="12" y="14" width="40" height="38" rx="2" fill="#fff" stroke="#888" stroke-width="2"/><rect x="12" y="14" width="40" height="10" fill="#e74c3c"/><g fill="#bbb"><rect x="18" y="30" width="6" height="6"/><rect x="29" y="30" width="6" height="6"/><rect x="40" y="30" width="6" height="6"/><rect x="18" y="40" width="6" height="6"/><rect x="29" y="40" width="6" height="6"/></g></svg>',
 tag:'<svg viewBox="0 0 64 64"><path d="M10 20 h24 l20 20 -24 24 -20 -20 Z" fill="#f5cba7" stroke="#ca6f1e" stroke-width="2"/><circle cx="22" cy="32" r="4" fill="#fff" stroke="#ca6f1e" stroke-width="2"/></svg>'
};
function iconFor(term){ const s=(''+term).toLowerCase();
  if(/penny|nickel|dime|quarter|coin/.test(s)){
    return '<div role="img" aria-label="U.S. coin reference" style="width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 35% 30%,#fff8df,#d8c08a 58%,#9c7b32);border:3px solid #8d6b2b;font-weight:900;color:#5c451b">¢</div>';
  }
  if(/dollar|bill|cash|banknote|currency|money/.test(s)){
    return '<div role="img" aria-label="U.S. dollar bill reference" style="width:110px;height:48px;display:flex;align-items:center;justify-content:center;border-radius:5px;background:#dcebd8;border:2px solid #4d7b4a;color:#31552e;font-weight:900">$1</div>';
  }
  const rules=[[/piggy/,'piggy'],[/jar|savings bank/,'jar'],[/pencil/,'pencil'],[/marker|crayon|\bpen\b/,'marker'],[/worksheet|paper|sheet|handout|printout|\bpage/,'paper'],[/index card|flash ?card|note ?card|\bcard/,'card'],[/scissor/,'scissors'],[/glue/,'glue'],[/chart|graph|poster|\bbar/,'chart'],[/calculator/,'calc'],[/dice|number cube|\bdie\b/,'dice'],[/envelope/,'envelope'],[/\bbox\b|\bbin\b|basket|\bbag\b|container|\bcup\b|bowl|tub/,'box'],[/book|journal|notebook|storybook/,'book'],[/board|easel|whiteboard|chalkboard/,'board'],[/clock|timer|stopwatch|watch/,'clock'],[/sticky|post-?it|\bnote/,'note'],[/ruler|measuring/,'ruler'],[/receipt/,'receipt'],[/calendar/,'calendar'],[/\btag\b|label|price/,'tag']];
  for(var i=0;i<rules.length;i++){ if(rules[i][0].test(s)&&MICONS[rules[i][1]])return MICONS[rules[i][1]]; }
  return null; }
function printMaterialsSheet(g){ g=g||currentGrade; const list=fullMaterialsEN(g); if(!list.length){ alert(t('No materials for this grade.')); return; }
  const cards=list.map(matCard); let body='';
  for(let i=0;i<cards.length;i+=10){ let page=cards.slice(i,i+10).map(function(c){var ic=iconFor(c.term); var pic=ic?ic:('<span class="mc-emo">'+c.emoji+'</span>'); return '<div class="mc"><div class="mc-e">'+pic+'</div><div class="mc-t">'+esc(c.term)+'</div><div class="mc-d">'+esc(c.desc)+'</div><div class="mc-u">'+(c.use?('▶ '+esc(c.use)):'')+'</div></div>';}); body+='<div class="pg">'+page.join('')+'</div>'; }
  const css='@page{size:letter;margin:.4in;}*{box-sizing:border-box;}body{font-family:Arial,Helvetica,sans-serif;margin:0;}h2{text-align:center;font-size:13px;margin:6px 0;}.pg{display:grid;grid-template-columns:1fr 1fr;grid-auto-rows:2in;page-break-after:always;}.mc{border:1px dashed #888;padding:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;overflow:hidden;}.mc.empty{border:1px dashed #ddd;}.mc-e{height:66px;display:flex;align-items:center;justify-content:center;}.mc-e svg{width:64px;height:64px;}.mc-emo{font-size:56px;line-height:1;}.mc-t{font-weight:bold;font-size:15px;margin:4px 0 2px;}.mc-d{font-size:11px;color:#333;}.mc-u{font-size:10px;color:#1e6b6b;font-style:italic;margin-top:3px;}';
  var _mhtml='<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+esc(t('Material Cards'))+' — '+esc(gradeLabel(g))+'</title><style>'+css+'</style></head><body><h2>'+esc(t('Material Cards'))+' — '+esc(gradeLabel(g))+' ('+cards.length+') · '+esc(t('cut along dashed lines'))+'</h2>'+body+'\n</body></html>';
  try{ var _mb=new Blob([_mhtml],{type:'text/html'}); var _mu=URL.createObjectURL(_mb); var _mw=window.open(_mu,'_blank'); if(!_mw){alert(t('Allow pop-ups to print the cards.'));URL.revokeObjectURL(_mu);return;} _mw.addEventListener('load',function(){try{_mw.print();}catch(e){}URL.revokeObjectURL(_mu);},{once:true}); setTimeout(function(){URL.revokeObjectURL(_mu);},30000); }catch(e){ var _fw=window.open('','_blank'); if(_fw){_fw.document.write(_mhtml);_fw.document.close();setTimeout(function(){try{_fw.print();}catch(e){}},400);} }
}
function downloadMaterialsList(g){ g=g||currentGrade; const list=fullMaterialsEN(g); if(!list.length){ alert(t('No materials for this grade.')); return; }
  const items=list.map(function(term){ const c=matCard(term); return '<li style="margin:3px 0;font-size:14px">'+c.emoji+' '+esc(c.term)+'</li>'; }).join('');
  const body='<div class="paper"><h1>Money Matters — '+esc(gradeLabel(g))+' · '+esc(t('Materials list'))+'</h1><p class="meta">'+list.length+' '+esc(t('items'))+'</p><ul style="columns:2;-webkit-columns:2;list-style:disc;padding-left:22px;margin:0">'+items+'</ul></div>';
  const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Materials</title><style>'+PAPER_CSS+'</style></head><body>'+body+'\n</body></html>';
  try{ const b=new Blob(['﻿'+html],{type:'application/msword'}); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='MoneyMatters_Materials_'+g+'_'+loadLang()+'.doc'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){ alert('Download not supported.'); }
}
function reportHTML(id){
  const s=loadStore(),st=s.list[id];if(!st)return '';
  const x=progStatsFor(st.prog||{}),school=getSchoolName(),code=studentVerificationCode(id);
  const grade=st.grade||currentGrade,ls=lessons_for_grade(grade),p=st.prog||{};
  const quizzes=ls.map(function(l){var v=p['quiz|'+grade+'|'+l.week];return{week:l.week,title:l.title,score:v==null?null:Number(v),passed:v!=null&&Number(v)>=75};});
  const tests=[];for(var u=0;u<Math.ceil(ls.length/6);u++){var tv=p['test|'+grade+'|u'+u];tests.push({unit:u+1,score:tv==null?null:Number(tv),passed:tv!=null&&Number(tv)>=75});}
  const reflections=ls.map(function(l){var done=false;try{var sid=typeof mmGameStudentId==='function'?mmGameStudentId():id;var r=JSON.parse(localStorage.getItem('mmQuizReflection_v2|'+sid+'|'+grade+'|'+l.week)||'null');done=!!(r&&(String(r.learned||'').trim()||String(r.realLife||'').trim()||String(r.confidence||'').trim()));}catch(e){}return{week:l.week,done:done};});
  const passedCount=quizzes.filter(function(q){return q.passed;}).length,taken=quizzes.filter(function(q){return q.score!=null;}),avg=taken.length?Math.round(taken.reduce(function(a,q){return a+q.score;},0)/taken.length):0;
  const testPassed=tests.filter(function(t){return t.passed;}).length,refDone=reflections.filter(function(r){return r.done;}).length,next=quizzes.find(function(q){return !q.passed;});
  const rec=next?'Focus on Week '+next.week+' and review missed questions before retrying the quiz.':'Continue applying the skills in real-life situations and complete the next checkpoint when available.';
  const qrows=quizzes.map(function(q){var r=reflections.find(function(z){return z.week===q.week;});return'<tr><td>Week '+q.week+'</td><td>'+esc(q.title)+'</td><td>'+(q.score==null?'Not taken':q.score+'%')+'</td><td class="'+(q.passed?'good':'needs')+'">'+(q.score==null?'Not started':(q.passed?'Passed':'Retry'))+'</td><td>'+(r&&r.done?'Complete':'Not complete')+'</td></tr>';}).join('');
  const trows=tests.map(function(t){return'<tr><td>Unit '+t.unit+'</td><td>'+(t.score==null?'Not taken':t.score+'%')+'</td><td class="'+(t.passed?'good':'needs')+'">'+(t.score==null?'Not started':(t.passed?'Passed':'Retry'))+'</td></tr>';}).join('');
  return '<div class="v53-report"><div class="rhead"><div class="rkicker">Money Matters · Student Progress Report</div><h1>'+esc(st.name)+'</h1><div class="rsub">'+esc(gradeLabel(grade))+(school?' · '+esc(school):'')+(st.teacher?' · Teacher: '+esc(st.teacher):'')+'</div><div style="margin-top:12px"><span class="rcode">Verification '+esc(code)+'</span></div></div>'
    +'<div class="grid"><div class="stat"><b>'+passedCount+'/'+ls.length+'</b><span>Lessons mastered</span></div><div class="stat"><b>'+avg+'%</b><span>Quiz average</span></div><div class="stat"><b>'+testPassed+'/'+tests.length+'</b><span>Checkpoints passed</span></div><div class="stat"><b>'+refDone+'/'+ls.length+'</b><span>Reflections completed</span></div></div>'
    +'<div class="note"><b>Mastery standard:</b> A weekly quiz or checkpoint is passed at <b>75% or higher</b>. The next week remains locked until the required mastery score is reached.</div>'
    +'<h2>Learning snapshot</h2><p style="font-size:12px;line-height:1.6"><b>Current focus:</b> '+esc(next?('Week '+next.week+' · '+next.title):'Ready for the next available learning step.')+'<br><b>Recommendation:</b> '+esc(rec)+'</p>'
    +'<h2>Weekly progress</h2><table><tr><th>Week</th><th>Lesson</th><th>Quiz</th><th>Status</th><th>Reflection</th></tr>'+(qrows||'<tr><td colspan="5">No weekly data recorded yet.</td></tr>')+'</table>'
    +'<h2>Checkpoint tests</h2><table><tr><th>Checkpoint</th><th>Score</th><th>Status</th></tr>'+(trows||'<tr><td colspan="3">No checkpoint data recorded yet.</td></tr>')+'</table>'
    +'<h2>Family conversation starters</h2><div class="note">Ask: What money skill did you practice? Where could you use it at home? What part was easy, and what would you like to practice again?</div>'
    +'<div class="footer">Generated by Money Matters · '+new Date().toLocaleDateString()+' · Verification code: '+esc(code)+' · Report reflects data stored on this device.</div></div>';
}
function teacherReport(id){
  if(!isValidId(id))return;
  const html='<!DOCTYPE html><html><head><meta charset="utf-8"><title>Student Report</title>'
    +'<style>body{font-family:system-ui,sans-serif;padding:24px;max-width:700px;margin:0 auto;}</style>'
    +'</head><body>'+reportHTML(id)+'\n</body></html>';
  try{
    const blob=new Blob([html],{type:'text/html'});
    const url=URL.createObjectURL(blob);
    const pw=window.open(url,'_blank');
    if(!pw){ mmAlert('Pop-ups are blocked. Allow pop-ups for this page to view the report.','⚠️'); URL.revokeObjectURL(url); return; }
    pw.addEventListener('load',function(){ try{pw.print();}catch(e){} URL.revokeObjectURL(url); },{once:true});
    setTimeout(function(){ URL.revokeObjectURL(url); },30000);
  }catch(e){ mmAlert('Could not open report. Try allowing pop-ups for this page.','❌'); }
}
function teacherExport(id){ const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Report</title></head><body>'+reportHTML(id)+'\n</body></html>';
  try{ const b=new Blob(['﻿'+html],{type:'application/msword'}); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='MoneyMatters_Report.doc'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500); }catch(e){ alert('Export not supported in this browser.'); } }
function teacherReset(id){ if(!isValidId(id))return; const s=loadStore(); if(!s.list[id])return; const nm=s.list[id].name; mmConfirm('Reset progress for '+sanitise(nm)+'?','All quiz scores, checkpoints, and lesson history for this student will be cleared. This cannot be undone.','Reset','♻️').then(function(ok){ if(!ok)return; const s2=loadStore(); if(!s2.list[id])return; s2.list[id].prog={}; delete s2.list[id].review; saveStore(s2); renderTeacher(); refreshStudentUI(); infoToast('Progress reset for '+sanitise(nm)+'.'); }); }
function removeStudent(id){ if(!isValidId(id))return; const s=loadStore(); if(!s.list[id])return; const nm=s.list[id].name; mmConfirm('Remove '+sanitise(nm)+'?','This will delete '+sanitise(nm)+'\'s profile and all their progress from this device. This cannot be undone.','Remove','🗑').then(function(ok){ if(!ok)return; const s2=loadStore(); if(!s2.list[id])return; delete s2.list[id]; if(s2.active===id)s2.active=null; if(getTabActive()===id)setTabActive(null); saveStore(s2); refreshStudentUI(); if(openPanelId==='teacher')renderTeacher(); if(openPanelId==='login')renderLogin(); infoToast(sanitise(nm)+' removed.'); }); }

/* ===== SPACED REVIEW (missed questions) ===== */
function reviewList(){ const a=activeStudent(); return (a&&a.review)?a.review:[]; }
function addMissed(list){ const s=loadStore(); const aid=_activeId(); if(!aid||!s.list[aid])return; const st=s.list[aid]; st.review=st.review||[]; list.forEach(function(m){ if(!st.review.some(function(r){return r.q===m.q;})) st.review.push({q:m.q,options:m.options,answer:m.answer,explain:m.explain}); }); saveStore(s); }
function openReview(){ currentTest='review'; if(openPanelId!=='test')openPanel('test'); else renderReview(); }
function renderReview(){
  const list=reviewList(); set('testKicker',GRADE_LABEL[currentGrade]+' · Review'); set('testTitle','Review Missed Questions');
  document.getElementById('testResult').innerHTML=''; testSel={};
  if(!list.length){ document.getElementById('testForm').innerHTML='<div class="fact"><div class="fact-icon">🎉</div><div class="fact-text">No missed questions to review — great job!</div></div>'; document.getElementById('testButtons').innerHTML='<button class="btn-calc ghost" onclick="renderTestMenu()">← All checkpoints</button>'; return; }
  let h='<div class="who">These are questions you missed before. Answer them again to clear them.</div>';
  list.forEach(function(q,i){ h+='<div class="q-item" id="ti-'+i+'"><div class="q-num">'+(i+1)+'. '+esc(rewordSel(q.q))+'</div>';
    q.options.forEach(function(o,j){ h+='<button class="mc-opt" id="to-'+i+'-'+j+'" onclick="pickOpt('+i+','+j+')">'+esc(o)+'</button>'; });
    h+='<div class="q-fb" id="tf-'+i+'"></div></div>'; });
  document.getElementById('testForm').innerHTML=h;
  document.getElementById('testButtons').innerHTML='<button class="btn-calc ghost" onclick="renderTestMenu()">← Back</button><button class="btn-calc green" onclick="submitReview()">✅ Check answers</button>';
}
function submitReview(){
  const list=reviewList(); let correct=0; const keep=[];
  list.forEach(function(q,i){ const sel=(i in testSel)?testSel[i]:-1; const ok=sel===q.answer; if(ok)correct++; else keep.push(q);
    const qi=document.getElementById('ti-'+i); qi.classList.remove('correct','wrong'); qi.classList.add(ok?'correct':'wrong');
    q.options.forEach(function(o,j){ const b=document.getElementById('to-'+i+'-'+j); if(!b)return; b.classList.remove('sel'); if(j===q.answer)b.classList.add('right'); else if(j===sel)b.classList.add('bad'); b.disabled=true; });
    const fb=document.getElementById('tf-'+i); fb.className='q-fb '+(ok?'ok':'no'); fb.innerHTML=(ok?'Correct! ':'Not quite. ')+esc(q.explain||''); });
  const s=loadStore(); if(s.active&&s.list[s.active]){ s.list[s.active].review=keep; saveStore(s); }
  const cleared=list.length-keep.length;
  document.getElementById('testResult').innerHTML='<div class="score-banner" style="background:#1e6b6b"><div class="pct">'+correct+' / '+list.length+'</div><div class="lbl">Cleared '+cleared+' · '+keep.length+' still to review</div></div>';
  document.getElementById('testButtons').innerHTML='<button class="btn-calc ghost" onclick="renderTestMenu()">← All checkpoints</button>'+(keep.length?'<button class="btn-calc green" onclick="renderReview()">↺ Review remaining</button>':'');
  const pb=document.querySelector('#panel-test .panel-body'); if(pb)pb.scrollTop=0;
}

/* ===== ROLE (teacher / student) + PASSCODE LOCK ===== */
/* Teacher role lives in sessionStorage (tab-local, cleared on close) so a student
   cannot elevate access by editing localStorage between sessions. */
function loadRole(){ try{return sessionStorage.getItem('mmRole')||'student';}catch(e){return 'student';} }
/* ===== PIN SECURITY (SHA-256 via Web Crypto) ===== */
/* Pins are stored as "sha256:<hex>" so plain text is never at rest in localStorage.
   Legacy plain-text pins (no prefix) are migrated transparently on first use. */
function _sha256(str){
  if(!window.crypto||!window.crypto.subtle)return Promise.resolve(null);
  const enc=new TextEncoder();
  return window.crypto.subtle.digest('SHA-256',enc.encode(str))
    .then(function(buf){return Array.from(new Uint8Array(buf)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');});
}

/* PIN rate-limiting: 3 consecutive failures → 30-second cooldown */
const _PIN_MAX_ATTEMPTS=3;
const _PIN_COOLDOWN_MS=30000;
function _pinAttempts(){ try{return parseInt(sessionStorage.getItem('mmPinFails')||'0',10);}catch(e){return 0;} }
function _pinLockUntil(){ try{return parseInt(sessionStorage.getItem('mmPinLock')||'0',10);}catch(e){return 0;} }
function _pinRecordFail(){
  const n=_pinAttempts()+1;
  try{ sessionStorage.setItem('mmPinFails',String(n)); }catch(e){}
  if(n>=_PIN_MAX_ATTEMPTS){ try{ sessionStorage.setItem('mmPinLock',String(Date.now()+_PIN_COOLDOWN_MS)); }catch(e){} }
}
function _pinRecordSuccess(){ try{ sessionStorage.removeItem('mmPinFails'); sessionStorage.removeItem('mmPinLock'); }catch(e){} }
function _pinIsLocked(){
  const until=_pinLockUntil(); if(!until)return false;
  if(Date.now()<until)return true;
  try{ sessionStorage.removeItem('mmPinLock'); sessionStorage.removeItem('mmPinFails'); }catch(e){}
  return false;
}
function _pinLockSecondsLeft(){ return Math.ceil(Math.max(0,_pinLockUntil()-Date.now())/1000); }
function _storedPin(){ try{return localStorage.getItem('mmTeacherPin')||'';}catch(e){return '';} }
function _hasPin(){ return !!_storedPin(); }
/* Verify a candidate string against the stored (possibly legacy) hash. Returns a Promise<bool>. */
function _verifyPin(candidate){
  const stored=_storedPin(); if(!stored)return Promise.resolve(false);
  const c=(candidate||'').trim();
  if(stored.startsWith('sha256:')){
    return _sha256(c).then(function(h){ return h?('sha256:'+h===stored):false; });
  }
  /* Legacy plain-text — verify then migrate */
  if(c===stored){
    return _sha256(c).then(function(h){ if(h)try{localStorage.setItem('mmTeacherPin','sha256:'+h);}catch(e){} return true; });
  }
  return Promise.resolve(false);
}
/* Store a new pin as a hash. Returns a Promise. */
function _storePin(p){
  const v=(p||'').trim();
  return _sha256(v).then(function(h){
    try{ localStorage.setItem('mmTeacherPin', h?('sha256:'+h):v); }catch(e){}
  });
}
function getRecQ(){ try{return localStorage.getItem('mmTeacherRecQ')||'';}catch(e){return '';} }
function getRecA(){ try{return localStorage.getItem('mmTeacherRecA')||'';}catch(e){return '';} }
function _storedRecA(){ try{return localStorage.getItem('mmTeacherRecA')||'';}catch(e){return '';} }
function setRecovery(q,a){
  _sha256((a||'').trim()).then(function(h){
    try{
      localStorage.setItem('mmTeacherRecQ',q);
      localStorage.setItem('mmTeacherRecA', h?('sha256:'+h):(a||'').trim().toLowerCase());
    }catch(e){}
  });
}
function _verifyRecA(candidate){
  const stored=_storedRecA(); if(!stored)return Promise.resolve(false);
  const c=(candidate||'').trim();
  if(stored.startsWith('sha256:')){
    return _sha256(c).then(function(h){ return h?('sha256:'+h===stored):false; });
  }
  return Promise.resolve(c.toLowerCase()===stored.toLowerCase());
}
/* mmInput — in-app single-field input modal; returns Promise<string|null> */
function mmInput(title, placeholder, opts){
  opts=opts||{};
  return new Promise(function(resolve){
    const backdrop=document.getElementById('mm-modal-backdrop');
    document.getElementById('mm-modal-icon').textContent=opts.icon||'🔐';
    document.getElementById('mm-modal-title').textContent=title||'';
    const bodyEl=document.getElementById('mm-modal-body');
    bodyEl.innerHTML=''; /* clear text-only body */
    const wrap=document.createElement('div');
    wrap.style.cssText='margin-top:4px;display:flex;flex-direction:column;gap:10px;';
    if(opts.subtext){
      const sub=document.createElement('p');
      sub.style.cssText='font-size:13px;color:var(--ink-mid);font-family:system-ui,sans-serif;margin:0 0 4px;line-height:1.5;text-align:left;';
      sub.textContent=opts.subtext;
      wrap.appendChild(sub);
    }
    const inp=document.createElement('input');
    inp.type=opts.password?'password':'text';
    inp.placeholder=placeholder||'';
    inp.autocomplete=opts.password?'current-password':'off';
    inp.autocorrect='off'; inp.autocapitalize='off'; inp.spellcheck=false;
    inp.style.cssText='width:100%;box-sizing:border-box;padding:11px 14px;border-radius:10px;'
      +'border:1.5px solid rgba(140,90,30,0.3);background:rgba(255,252,242,0.9);'
      +'font-size:15px;font-family:system-ui,sans-serif;color:var(--ink);outline:none;';
    inp.addEventListener('focus',function(){ this.style.borderColor='var(--gold)'; });
    inp.addEventListener('blur',function(){ this.style.borderColor='rgba(140,90,30,0.3)'; });
    if(opts.errId){
      const err=document.createElement('div');
      err.id=opts.errId;
      err.style.cssText='color:#c44;font-size:12px;font-family:system-ui,sans-serif;min-height:16px;text-align:left;';
      wrap.appendChild(inp); wrap.appendChild(err);
    } else {
      wrap.appendChild(inp);
    }
    bodyEl.appendChild(wrap);
    const btnsEl=document.getElementById('mm-modal-btns');
    btnsEl.innerHTML='';
    function dismiss(val){ backdrop.classList.remove('open'); _modalResolve=null; resolve(val); }
    const cancelBtn=document.createElement('button');
    cancelBtn.textContent='Cancel'; cancelBtn.className='btn-calc ghost';
    cancelBtn.onclick=function(){ dismiss(null); };
    const okBtn=document.createElement('button');
    okBtn.textContent=opts.okLabel||'OK';
    okBtn.className='btn-calc';
    okBtn.onclick=function(){ dismiss(inp.value); };
    inp.addEventListener('keydown',function(e){ if(e.key==='Enter'){e.preventDefault();dismiss(inp.value);} if(e.key==='Escape'){e.preventDefault();dismiss(null);} });
    btnsEl.appendChild(cancelBtn);
    btnsEl.appendChild(okBtn);
    backdrop.classList.add('open');
    setTimeout(function(){ inp.focus(); },80);
    /* Override _closeModal so ESC/backdrop also resolve the promise */
    _modalResolve=function(v){ resolve(v===true?inp.value:null); };
  });
}

function forgotPin(){
  const q=getRecQ();
  if(!q){ mmAlert('No recovery question was set. To reset the passcode, clear this browser\'s site data in Settings.','⚠️'); return; }
  mmInput('Recovery question','',{icon:'❓',subtext:q,okLabel:'Submit'}).then(function(a){
    if(a===null)return;
    _verifyRecA(a).then(function(ok){
      if(!ok){ mmAlert('That answer is incorrect.','❌'); return; }
      mmInput('New adult passcode','At least 3 characters',{icon:'🔐',password:true,okLabel:'Set passcode'}).then(function(np){
        if(np===null)return;
        const v=(np||'').trim(); if(v.length<3){ mmAlert('Too short — passcode must be at least 3 characters.','⚠️'); return; }
        _storePin(v).then(function(){ infoToast('✓ Passcode reset. Enter Teacher/Parent mode again with your new passcode.',4000); });
      });
    });
  });
}

function removeStudentLessonMaterials(){
  if(loadRole()!=='teacher'){
    var sec=document.getElementById('lessonMaterialsSection');
    if(sec) sec.remove();
  }
}

function applyRole(){ const r=loadRole(); document.documentElement.classList.toggle('role-student',r!=='teacher'); removeStudentLessonMaterials(); refreshStudentUI(); const b=document.getElementById('roleBtn'); if(b)b.textContent=(r==='teacher')?('👩‍🏫 '+t('Teacher/Parent mode')):('🎒 '+t('Student mode')); if(r!=='teacher'&&currentDoc==='guide'&&openPanelId==='doc')switchDoc('plan'); if(openPanelId==='lessons')renderChips(); if(openPanelId==='path')renderPath(); if(openPanelId==='overview')buildOverview(); if(openPanelId==='teacher')renderTeacher(); }
function _setRoleTeacher(){ try{sessionStorage.setItem('mmRole','teacher');}catch(e){} applyRole(); }
function toggleRole(){
  const r=loadRole();
  if(r!=='teacher'){
    if(!_hasPin()){
      mmInput('Set an adult passcode','At least 3 characters',{icon:'🔐',password:true,okLabel:'Set passcode',
        subtext:'Keep this private from students. You will need it each time you switch to Teacher/Parent mode.'}).then(function(np){
        if(np===null)return;
        const v=(np||'').trim(); if(v.length<3){ mmAlert('Passcode must be at least 3 characters.','⚠️'); return; }
        _storePin(v).then(function(){
          mmInput('Recovery question (optional)','e.g. What is your school name?',{icon:'❓',
            subtext:'If you forget your passcode, this question will help you reset it. Leave blank to skip.',
            okLabel:'Continue'}).then(function(rq){
            if(rq&&rq.trim()){
              mmInput('Recovery answer','',{icon:'💬',okLabel:'Save'}).then(function(ra){
                if(ra&&ra.trim()) setRecovery(rq.trim(),ra.trim());
                infoToast('✓ Adult passcode set.',3000); _setRoleTeacher();
              });
            } else {
              infoToast('✓ Adult passcode set.',3000); _setRoleTeacher();
            }
          });
        });
      });
    } else {
      if(_pinIsLocked()){
        mmAlert('Too many incorrect attempts. Please wait '+_pinLockSecondsLeft()+' seconds before trying again.','🔒');
        return;
      }
      mmInput('Enter adult passcode','',{icon:'🔐',password:true,okLabel:'Enter'}).then(function(e){
        if(e===null)return;
        if(_pinIsLocked()){ mmAlert('Too many incorrect attempts. Please wait '+_pinLockSecondsLeft()+' seconds.','🔒'); return; }
        _verifyPin(e).then(function(ok){
          if(!ok){
            _pinRecordFail();
            if(_pinIsLocked()){
              mmAlert('Too many incorrect attempts. Passcode entry is locked for '+_pinLockSecondsLeft()+' seconds.','🔒');
            } else {
              const left=_PIN_MAX_ATTEMPTS-_pinAttempts();
              mmConfirm('Incorrect passcode',''+left+' attempt'+(left===1?'':'s')+' remaining before a 30-second lockout. Forgot your passcode?','Use recovery','❓').then(function(go){ if(go)forgotPin(); });
            }
            return;
          }
          _pinRecordSuccess();
          _setRoleTeacher();
        });
      });
    }
  } else {
    try{sessionStorage.setItem('mmRole','student');}catch(e){} applyRole();
  }
}
function changePin(){
  if(_hasPin()){
    if(_pinIsLocked()){ mmAlert('Passcode entry is locked for '+_pinLockSecondsLeft()+' seconds.','🔒'); return; }
    mmInput('Current adult passcode','',{icon:'🔐',password:true,okLabel:'Verify'}).then(function(e){
      if(e===null)return;
      _verifyPin(e).then(function(ok){
        if(!ok){
          _pinRecordFail();
          mmAlert(_pinIsLocked()?'Incorrect. Entry locked for '+_pinLockSecondsLeft()+' seconds.':'Incorrect passcode.','❌');
          return;
        }
        _pinRecordSuccess();
        mmInput('New adult passcode','At least 3 characters',{icon:'🔑',password:true,okLabel:'Update'}).then(function(np){
          if(np===null)return;
          const v=(np||'').trim(); if(v.length<3){ mmAlert('Too short.','⚠️'); return; }
          _storePin(v).then(function(){ infoToast('✓ Teacher passcode updated.',3000); });
        });
      });
    });
  } else {
    mmInput('Set an adult passcode','At least 3 characters',{icon:'🔐',password:true,okLabel:'Set'}).then(function(np){
      if(np===null)return;
      const v=(np||'').trim(); if(v.length<3){ mmAlert('Too short.','⚠️'); return; }
      _storePin(v).then(function(){ infoToast('✓ Adult passcode set.',3000); });
    });
  }
}

/* ===== PROGRESSION GATING ===== */
function gateOn(){ try{return localStorage.getItem('mmGate')!=='off';}catch(e){return true;} }
function toggleGate(){ try{localStorage.setItem('mmGate',gateOn()?'off':'on');}catch(e){} if(openPanelId==='teacher')renderTeacher(); if(openPanelId==='lessons')renderChips(); if(openPanelId==='path')renderPath(); }
function isWeekDone(i){ const l=lessons()[i]; if(!l)return false; const v=myProg()['quiz|'+currentGrade+'|'+l.week]; return v!=null&&v>=75; }
function previewOn(){ return typeof PREVIEW!=='undefined'&&PREVIEW; }
function previewSample(){ return typeof PREVIEW_SAMPLE!=='undefined'?PREVIEW_SAMPLE:2; }
function weekUnlocked(i){
  if(previewOn()&&loadRole()!=='teacher'&&i>=previewSample())return false;
  if(loadRole()!=='teacher'&&!previewOn()&&!signedIn())return false;
  if(!gateOn()||loadRole()==='teacher'||!activeStudent())return true;
  if(i<=0)return true;
  const ls=lessons();
  const prev=ls[i-1];
  if(!prev)return false;
  const prevScore=myProg()['quiz|'+currentGrade+'|'+prev.week];
  if(!(prevScore!=null&&Number(prevScore)>=75))return false;
  /* Crossing from one 6-week unit to the next also requires the
     preceding Section Test at 75% or higher. */
  if(i%6===0){
    const priorUnit=(i/6);
    const priorTest=myProg()['test|'+currentGrade+'|u'+priorUnit];
    if(!(priorTest!=null&&Number(priorTest)>=75))return false;
  }
  return true;
}
function unitUnlocked(u){
  if(previewOn()&&loadRole()!=='teacher')return false;
  if(loadRole()!=='teacher'&&!previewOn()&&!signedIn())return false;
  if(!gateOn()||loadRole()==='teacher'||!activeStudent())return true;
  if(u>0){
    const prior=myProg()['test|'+currentGrade+'|u'+u];
    if(!(prior!=null&&Number(prior)>=75))return false;
  }
  const ls=lessons();
  const block=ls.slice(u*6,u*6+6);
  if(!block.length)return false;
  return block.every(function(l){
    var v=myProg()['quiz|'+currentGrade+'|'+l.week];
    return v!=null&&Number(v)>=75;
  });
}
function lockedMsg(i){ if(loadRole()!=='teacher'&&!previewOn()&&!signedIn()){ alert(t('Please sign in first — open the Student desk to start your grade.')); openPanel('login'); return; } if(previewOn()&&loadRole()!=='teacher'){ alert('This is a PREVIEW. Weeks 1 to '+previewSample()+' are open as a sample so you can see how it works. The full lessons, quizzes, tests, and teacher materials unlock when the program owner switches to Teacher/Parent mode.'); return; } const ls=lessons(); const prev=ls[i-1]; alert('This lesson is locked. Finish Week '+(prev?prev.week:i)+' first — pass its quiz with 75 percent or more to unlock the next week.'); }
function previewBanner(){ if(!previewOn())return ''; return '<div class="lang-note" style="background:rgba(196,145,46,.16);border-color:rgba(196,145,46,.4)"><b>🔎 Preview version.</b> You can explore the full structure and a sample (Weeks 1 to '+previewSample()+'). The complete lessons, quizzes, section tests, and teacher materials unlock when the program owner enters <b>Teacher/Parent mode</b> (their passcode).</div>'; }
function renderLexileBar(){ const el=document.getElementById('lexileBarWrap'); if(el)el.innerHTML=lexileBar(); }
function renderLessonProgress(){ const el=document.getElementById('lessonProgress'); if(!el)return; const ls=lessons(); const p=myProg(); const passed=ls.filter(function(l){var v=p['quiz|'+currentGrade+'|'+l.week];return v!=null&&v>=75;}).length; const pct=ls.length?Math.round(passed/ls.length*100):0; const gated=gateOn()&&loadRole()!=='teacher'&&activeStudent(); const locksOff=!gateOn()&&loadRole()!=='teacher'; el.innerHTML='<div class="who">Progress: <b>'+passed+' of '+ls.length+'</b> lessons complete ('+pct+'%)'+(gated?' · each week unlocks when you pass the one before it':'')+(locksOff?' <span style="background:#d4f0dc;color:#1e6b3a;border-radius:8px;padding:2px 9px;font-size:11px;font-weight:700;margin-left:6px">🔓 Locks off</span>':'')+'</div><div class="pbar"><i style="width:'+pct+'%"></i></div>'; }

/* ===== CELEBRATION ===== */
function celebrate(){
  try{
    const w=document.createElement('div'); w.className='confetti-wrap';
    const colors=['#c4912e','#2a6b4a','#1e6b6b','#7a1e4d','#e8b84b','#3d9968','#2e7ab0','#b03070'];
    for(let i=0;i<44;i++){ const d=document.createElement('div'); d.className='confetti';
      d.style.left=(Math.random()*100)+'%'; d.style.background=colors[i%colors.length];
      d.style.animationDuration=(1.6+Math.random()*1.6)+'s'; d.style.animationDelay=(Math.random()*0.35)+'s';
      if(i%3===0)d.style.borderRadius='50%'; w.appendChild(d); }
    document.body.appendChild(w); setTimeout(function(){ w.remove(); },3600);
  }catch(e){}
}

/* ===== GRADEBOOK EXPORT (CSV) ===== */
function csvCell(v){ v=String(v==null?"":v).replace(/\r/g," ").replace(/\n/g," "); return '"'+v.replace(/"/g,'""')+'"'; }
function exportGradebook(){
  const s=loadStore(); const ids=Object.keys(s.list);
  const rows=[['Student','Teacher','School','Profile grade','Type','Grade','Item','Best score (percent)','Lessons viewed','Worksheets attempted']];
  ids.forEach(function(id){ const st=s.list[id]; const prog=st.prog||{};
    const scoreKeys=Object.keys(prog).filter(function(k){return k.indexOf('view|')!==0&&k.indexOf('ws|')!==0;});
    const viewCount=Object.keys(prog).filter(function(k){return k.indexOf('view|')===0;}).length;
    const wsCount=Object.keys(prog).filter(function(k){return k.indexOf('ws|')===0;}).length;
    const school=getSchoolName()||'';
    if(!scoreKeys.length){ rows.push([st.name,st.teacher||'',school,st.grade||'','','','No scores yet','',viewCount,wsCount]); return; }
    scoreKeys.sort().forEach(function(k){ const p=k.split('|'); const kind=(p[0]==='test')?'Checkpoint':'Lesson quiz'; const item=(p[0]==='test')?('Unit '+String(p[2]).replace('u','')):('Week '+p[2]); rows.push([st.name,st.teacher||'',school,st.grade||'',kind,p[1],item,String(prog[k]),viewCount,wsCount]); });
  });
  const csv=rows.map(function(r){return r.map(csvCell).join(',');}).join('\r\n');
  try{ const b=new Blob(['﻿'+csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='MoneyMatters_Gradebook.csv'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500); }
  catch(e){ alert('Export not supported in this browser.'); }
}

/* ===== LANGUAGE (interface) — English / Spanish / Brazilian Portuguese ===== */
const LANG={
 es:{
  'Grade':'Grado','Home':'Inicio','Lessons':'Lecciones','Learning Path':'Ruta de aprendizaje','Quiz':'Cuestionario','Section Test':'Examen de sección','Certificate':'Certificado','Glossary':'Glosario','Lesson Plan':'Plan de clase','Worksheet':'Hoja de trabajo','Workbook':'Cuaderno','Teacher Guide':'Guía docente','Guide & Answer Key':'Guía y respuestas','Class Setup':'Configuración de clase','Story':'Historia','Yes':'Sí','No':'No','Choose one':'Elige una','Teacher':'Maestro','How to Use':'Cómo usar','Reading':'Lectura','Sign in':'Entrar','Student mode':'Modo estudiante','Teacher/Parent mode':'Modo maestro','Overview':'Resumen',
  'How to Use This Site':'Cómo usar el sitio','Prizes & Certificate':'Premios y certificado',"Who's Learning?":'¿Quién está aprendiendo?','Your Learning Path':'Tu ruta de aprendizaje','Reading Options':'Opciones de lectura','Money Words':'Palabras del dinero','Class Progress':'Progreso de la clase','My Dashboard':'Mi panel',
  'Vocabulary':'Vocabulario','Mini Lesson':'Mini lección','Warm-up & Practice':'Calentamiento y práctica','Discussion Questions':'Preguntas de discusión','Quick Check':'Comprobación rápida','Exit Ticket':'Boleto de salida','Choose a student':'Elige un estudiante','Add a new student':'Agregar un estudiante','Your Certificate':'Tu certificado','Language':'Idioma','Badges':'Insignias','Where you are':'Dónde estás','Next steps — Lesson → Worksheet → Quiz':'Próximos pasos — Lección → Hoja → Cuestionario',
  'Getting started':'Primeros pasos','Student':'Estudiante','Achievement':'Logro','Accessibility':'Accesibilidad','💬 Jay — Your Instructor':'💬 Jay — Tu instructor','Instructor':'Instructor','Date':'Fecha',
  '✅ Submit answers':'✅ Enviar respuestas','🔊 Read aloud':'🔊 Leer en voz alta','↺ Reset':'↺ Reiniciar','✅ Check my answers':'✅ Revisar mis respuestas','↺ Clear':'↺ Borrar','▶ Continue where I left off':'▶ Continuar donde lo dejé','📚 Lessons':'📚 Lecciones','📝 Quiz':'📝 Cuestionario','🏆 Certificate':'🏆 Certificado','Re-check':'Volver a revisar','↺ Try again':'↺ Intentar de nuevo','📖 Re-read lesson':'📖 Releer la lección','➡ Next lesson':'➡ Siguiente lección','🏠 Dashboard':'🏠 Panel','Create & sign in':'Crear y entrar','Sign out':'Salir'
 },
 pt:{
  'Grade':'Série','Home':'Início','Lessons':'Lições','Learning Path':'Trilha de aprendizagem','Quiz':'Quiz','Section Test':'Prova da seção','Certificate':'Certificado','Glossary':'Glossário','Lesson Plan':'Plano de aula','Worksheet':'Folha de atividades','Workbook':'Caderno','Teacher Guide':'Guia do professor','Guide & Answer Key':'Guia e gabarito','Class Setup':'Configuração da turma','Story':'História','Yes':'Sim','No':'Não','Choose one':'Escolha uma','Teacher':'Professor','How to Use':'Como usar','Reading':'Leitura','Sign in':'Entrar','Student mode':'Modo aluno','Teacher/Parent mode':'Modo professor','Overview':'Visão geral',
  'How to Use This Site':'Como usar o site','Prizes & Certificate':'Prêmios e certificado',"Who's Learning?":'Quem está aprendendo?','Your Learning Path':'Sua trilha de aprendizagem','Reading Options':'Opções de leitura','Money Words':'Palavras do dinheiro','Class Progress':'Progresso da turma','My Dashboard':'Meu painel',
  'Vocabulary':'Vocabulário','Mini Lesson':'Mini lição','Warm-up & Practice':'Aquecimento e prática','Discussion Questions':'Perguntas para discussão','Quick Check':'Verificação rápida','Exit Ticket':'Bilhete de saída','Choose a student':'Escolha um aluno','Add a new student':'Adicionar um aluno','Your Certificate':'Seu certificado','Language':'Idioma','Badges':'Medalhas','Where you are':'Onde você está','Next steps — Lesson → Worksheet → Quiz':'Próximos passos — Lição → Folha → Quiz',
  'Getting started':'Primeiros passos','Student':'Aluno','Achievement':'Conquista','Accessibility':'Acessibilidade','💬 Jay — Your Instructor':'💬 Jay — Seu instrutor','Instructor':'Instrutor','Date':'Data',
  '✅ Submit answers':'✅ Enviar respostas','🔊 Read aloud':'🔊 Ler em voz alta','↺ Reset':'↺ Reiniciar','✅ Check my answers':'✅ Conferir minhas respostas','↺ Clear':'↺ Limpar','▶ Continue where I left off':'▶ Continuar de onde parei','📚 Lessons':'📚 Lições','📝 Quiz':'📝 Quiz','🏆 Certificate':'🏆 Certificado','Re-check':'Verificar de novo','↺ Try again':'↺ Tentar de novo','📖 Re-read lesson':'📖 Reler a lição','➡ Next lesson':'➡ Próxima lição','🏠 Dashboard':'🏠 Painel','Create & sign in':'Criar e entrar','Sign out':'Sair'
 }
};
Object.assign(LANG.es,{
 'Larger text':'Texto más grande','Zoom everything up for easier reading.':'Amplía todo para leer más fácilmente.',
 'Easy-read font':'Fuente de lectura fácil','Switch to a rounded sans-serif with extra letter spacing.':'Cambia a una fuente redondeada con más espacio entre letras.',
 'High contrast':'Alto contraste','Darken text for stronger contrast.':'Oscurece el texto para lograr un contraste más fuerte.',
 'Sound effects':'Efectos de sonido','Play a cheerful chime when a quiz or checkpoint is passed.':'Reproduce un sonido alegre al aprobar un cuestionario o punto de control.',
 'Make the text easier to read. Your choices are remembered on this device.':'Haz que el texto sea más fácil de leer. Tus opciones se recuerdan en este dispositivo.',
 'K–8 Financial Literacy Curriculum':'Currículo de educación financiera K–8',
 'Now teaching':'Ahora enseñando','click the board for the full curriculum':'haz clic en la pizarra para ver todo el plan de estudios'
});
Object.assign(LANG.pt,{
 'Larger text':'Texto maior','Zoom everything up for easier reading.':'Amplia tudo para facilitar a leitura.',
 'Easy-read font':'Fonte de leitura fácil','Switch to a rounded sans-serif with extra letter spacing.':'Muda para uma fonte arredondada com mais espaçamento entre as letras.',
 'High contrast':'Alto contraste','Darken text for stronger contrast.':'Escurece o texto para um contraste mais forte.',
 'Sound effects':'Efeitos sonoros','Play a cheerful chime when a quiz or checkpoint is passed.':'Toca um som alegre quando um quiz ou checkpoint é aprovado.',
 'Make the text easier to read. Your choices are remembered on this device.':'Deixe o texto mais fácil de ler. Suas escolhas ficam salvas neste dispositivo.',
 'K–8 Financial Literacy Curriculum':'Currículo de educação financeira K–8',
 'Now teaching':'Ensinando agora','click the board for the full curriculum':'clique no quadro para ver todo o currículo'
});
Object.assign(LANG.es,{
 '1 · Lesson':'1 · Lección','2 · Worksheet':'2 · Hoja','3 · Quiz':'3 · Cuestionario',
 'Next: Worksheet →':'Siguiente: Hoja →','Next: Quiz →':'Siguiente: Cuestionario →','📝 Take the quiz':'📝 Hacer el cuestionario',
 'answered':'respondidas','questions. Choose one answer for each, then submit.':'preguntas. Elige una respuesta para cada una y luego envía.'
});
Object.assign(LANG.pt,{
 '1 · Lesson':'1 · Lição','2 · Worksheet':'2 · Folha','3 · Quiz':'3 · Quiz',
 'Next: Worksheet →':'Próximo: Folha →','Next: Quiz →':'Próximo: Quiz →','📝 Take the quiz':'📝 Fazer o quiz',
 'answered':'respondidas','questions. Choose one answer for each, then submit.':'perguntas. Escolha uma resposta para cada uma e depois envie.'
});
Object.assign(LANG.es,{
 'terms':'términos','Tap a word to hear it':'Toca una palabra para escucharla','Tap to hear':'Toca para escuchar',
 '🖨️ Print / Download glossary':'🖨️ Imprimir / Descargar glosario','Word of the day':'Palabra del día','Hear it':'Escuchar','📖 Glossary':'📖 Glosario',
 '🧪 Section Test →':'🧪 Examen de sección →','➡ Next':'➡ Siguiente','Week':'Semana','left — answer every question first':'sin responder — responde todas primero',
 'Read the lesson first, then the quiz unlocks.':'Lee la lección primero y el cuestionario se desbloqueará.','📖 Open the lesson':'📖 Abrir la lección',
 'Please sign in first — open the Student desk to start.':'Primero inicia sesión — abre el escritorio de Estudiante para comenzar.',
 'Please sign in first — open the Student desk to start your grade.':'Primero inicia sesión — abre el escritorio de Estudiante para comenzar tu grado.',
 '👤 Sign in':'👤 Iniciar sesión','You are enrolled in':'Estás inscrito en','Locked — sign in':'Bloqueado — inicia sesión'
});
Object.assign(LANG.pt,{
 'terms':'termos','Tap a word to hear it':'Toque em uma palavra para ouvir','Tap to hear':'Toque para ouvir',
 '🖨️ Print / Download glossary':'🖨️ Imprimir / Baixar glossário','Word of the day':'Palavra do dia','Hear it':'Ouvir','📖 Glossary':'📖 Glossário',
 '🧪 Section Test →':'🧪 Prova da seção →','➡ Next':'➡ Próximo','Week':'Semana','left — answer every question first':'sem resposta — responda todas primeiro',
 'Read the lesson first, then the quiz unlocks.':'Leia a lição primeiro e o quiz será desbloqueado.','📖 Open the lesson':'📖 Abrir a lição',
 'Please sign in first — open the Student desk to start.':'Entre primeiro — abra a mesa do Aluno para começar.',
 'Please sign in first — open the Student desk to start your grade.':'Entre primeiro — abra a mesa do Aluno para começar sua série.',
 '👤 Sign in':'👤 Entrar','You are enrolled in':'Você está matriculado em','Locked — sign in':'Bloqueado — entre'
});
Object.assign(LANG.es,{
 '🔎 Check content':'🔎 Revisar contenido','🗑 Remove ALL students':'🗑 Eliminar TODOS los estudiantes','Set this week':'Fijar esta semana','📌 Assign':'📌 Asignar','Clear':'Borrar',
 'No students yet — open the Student desk to add one.':'Aún no hay estudiantes — abre el escritorio de Estudiante para agregar uno.',
 'Class summary':'Resumen de la clase','Students':'Estudiantes','Avg lessons mastered':'Promedio de lecciones dominadas','Avg quiz score':'Promedio de cuestionarios',
 'active':'activo','Lessons mastered':'Lecciones dominadas','Quiz avg':'Promedio de cuestionario','Quizzes taken':'Cuestionarios hechos','Checkpoints':'Puntos de control','Last active':'Última actividad',
 'This week is set. Students will start here.':'Esta semana quedó fijada. Los estudiantes comenzarán aquí.',
 'Remove ALL students and their progress from this device? This cannot be undone.':'¿Eliminar a TODOS los estudiantes y su progreso de este dispositivo? No se puede deshacer.',
 'issue(s) found':'problema(s) encontrado(s)','All content passed: quiz answers valid and no empty lesson fields.':'Todo el contenido pasó: respuestas válidas y sin campos vacíos.',
 'This week':'Esta semana','Open':'Abrir','Unit progress':'Progreso de la unidad','Unit':'Unidad','Stars':'Estrellas','Grade complete!':'¡Grado completo!','Fact of the day':'Dato del día',
 'Pass one quiz (75%+) to earn your first medal!':'¡Aprueba un cuestionario (75%+) para ganar tu primera medalla!','Score 90%+ on a quiz to earn Gold!':'¡Saca 90%+ en un cuestionario para ganar Oro!',
 'Tip: back up class progress from the Teacher desk — data is saved only in this browser.':'Consejo: respalda el progreso desde el escritorio del Maestro — los datos se guardan solo en este navegador.',
 'Tip: open the Student desk to save your progress and prizes.':'Consejo: abre el escritorio de Estudiante para guardar tu progreso y premios.',
 'Answer Key':'Clave de respuestas','🖨️ Weekly packet':'🖨️ Paquete semanal',
 'Materials':'Materiales','No materials for this grade.':'No hay materiales para este grado.','Allow pop-ups to print the cards.':'Permite las ventanas emergentes para imprimir las tarjetas.',
 'Material Cards':'Tarjetas de materiales','cut along dashed lines':'corta por las líneas punteadas','Materials list':'Lista de materiales','items':'elementos',
 'Material':'Material','Description':'Descripción','Usage':'Uso','🃏 Print material cards':'🃏 Imprimir tarjetas de materiales','⬇ Materials list (.doc)':'⬇ Lista de materiales (.doc)',
 '✓ Mark lesson complete':'✓ Marcar lección como completa','Lesson marked complete — the quiz is now unlocked.':'Lección marcada como completa: el cuestionario ya está desbloqueado.','Finish the lesson first to unlock this download.':'Termina la lección primero para desbloquear esta descarga.',
 'Import teachers & students':'Importar maestros y estudiantes','⬇ CSV template':'⬇ Plantilla CSV','📥 Import roster':'📥 Importar lista','Teachers':'Maestros','Teacher name':'Nombre del maestro','➕ Add teacher or guardian':'➕ Agregar maestro','No teachers or guardians yet.':'Aún no hay maestros.','Teacher (optional)':'Maestro (opcional)',
 'students imported':'estudiantes importados','teachers added':'maestros agregados','rows skipped':'filas omitidas','Paste a roster or choose a CSV file first.':'Primero pega una lista o elige un archivo CSV.',
 'CSV: Student Name, Grade (K-8), Teacher — one per line. A line like "Teacher: Ms. Rivera" adds a teacher only.':'CSV: Nombre del estudiante, Grado (K-8), Maestro — uno por línea. Una línea como "Teacher: Sra. Rivera" agrega solo un maestro.'
});
Object.assign(LANG.pt,{
 '🔎 Check content':'🔎 Verificar conteúdo','🗑 Remove ALL students':'🗑 Remover TODOS os alunos','Set this week':'Definir esta semana','📌 Assign':'📌 Atribuir','Clear':'Limpar',
 'No students yet — open the Student desk to add one.':'Ainda não há alunos — abra a mesa do Aluno para adicionar um.',
 'Class summary':'Resumo da turma','Students':'Alunos','Avg lessons mastered':'Média de lições dominadas','Avg quiz score':'Média dos quizzes',
 'active':'ativo','Lessons mastered':'Lições dominadas','Quiz avg':'Média do quiz','Quizzes taken':'Quizzes feitos','Checkpoints':'Pontos de verificação','Last active':'Última atividade',
 'This week is set. Students will start here.':'Esta semana foi definida. Os alunos começarão aqui.',
 'Remove ALL students and their progress from this device? This cannot be undone.':'Remover TODOS os alunos e seu progresso deste dispositivo? Isso não pode ser desfeito.',
 'issue(s) found':'problema(s) encontrado(s)','All content passed: quiz answers valid and no empty lesson fields.':'Todo o conteúdo passou: respostas válidas e sem campos vazios.',
 'This week':'Esta semana','Open':'Abrir','Unit progress':'Progresso da unidade','Unit':'Unidade','Stars':'Estrelas','Grade complete!':'Série concluída!','Fact of the day':'Curiosidade do dia',
 'Pass one quiz (75%+) to earn your first medal!':'Passe em um quiz (75%+) para ganhar sua primeira medalha!','Score 90%+ on a quiz to earn Gold!':'Tire 90%+ em um quiz para ganhar Ouro!',
 'Tip: back up class progress from the Teacher desk — data is saved only in this browser.':'Dica: faça backup do progresso na mesa do Professor — os dados ficam salvos só neste navegador.',
 'Tip: open the Student desk to save your progress and prizes.':'Dica: abra a mesa do Aluno para salvar seu progresso e prêmios.',
 'Answer Key':'Gabarito','🖨️ Weekly packet':'🖨️ Pacote semanal',
 'Materials':'Materiais','No materials for this grade.':'Não há materiais para esta série.','Allow pop-ups to print the cards.':'Permita pop-ups para imprimir os cartões.',
 'Material Cards':'Cartões de materiais','cut along dashed lines':'recorte nas linhas tracejadas','Materials list':'Lista de materiais','items':'itens',
 'Material':'Material','Description':'Descrição','Usage':'Uso','🃏 Print material cards':'🃏 Imprimir cartões de materiais','⬇ Materials list (.doc)':'⬇ Lista de materiais (.doc)',
 '✓ Mark lesson complete':'✓ Marcar lição como concluída','Lesson marked complete — the quiz is now unlocked.':'Lição marcada como concluída — o quiz agora está desbloqueado.','Finish the lesson first to unlock this download.':'Conclua a lição primeiro para desbloquear este download.',
 'Import teachers & students':'Importar professores e alunos','⬇ CSV template':'⬇ Modelo CSV','📥 Import roster':'📥 Importar lista','Teachers':'Professores','Teacher name':'Nome do professor','➕ Add teacher or guardian':'➕ Adicionar professor','No teachers or guardians yet.':'Ainda não há professores.','Teacher (optional)':'Professor (opcional)',
 'students imported':'alunos importados','teachers added':'professores adicionados','rows skipped':'linhas ignoradas','Paste a roster or choose a CSV file first.':'Primeiro cole uma lista ou escolha um arquivo CSV.',
 'CSV: Student Name, Grade (K-8), Teacher — one per line. A line like "Teacher: Ms. Rivera" adds a teacher only.':'CSV: Nome do aluno, Série (K-8), Professor — um por linha. Uma linha como "Teacher: Sra. Rivera" adiciona apenas um professor.'
});
Object.assign(LANG.es,{
 'Certificate of Completion':'Certificado de Finalización','Certificate of Achievement':'Certificado de Logro','K–8 Financial Literacy Program':'Programa de Educación Financiera K–8','GRADE COMPLETE':'GRADO COMPLETO','This certifies that':'Esto certifica que','Your Name':'Tu Nombre',
 'completed the full grade: every weekly lesson and all checkpoint tests.':'completó todo el grado: cada lección semanal y todas las pruebas de control.','making great progress in earning, saving, budgeting, and smart money decisions.':'progresa muy bien en ganar, ahorrar, presupuestar y tomar buenas decisiones de dinero.','Level':'Nivel',
 'added':'agregados','merged':'combinados','The page will refresh.':'La página se actualizará.','updated':'actualizados',
 '📊 Most-missed questions':'📊 Preguntas más falladas','No quiz data yet — item analysis appears after students take quizzes.':'Aún no hay datos — el análisis aparece después de que los estudiantes hagan cuestionarios.','Ranked by percent of attempts answered incorrectly across all students on this device.':'Ordenadas por porcentaje de respuestas incorrectas de todos los estudiantes en este dispositivo.','Most-missed questions':'Preguntas más falladas','Missed':'Falladas','Allow pop-ups to view the report.':'Permite las ventanas emergentes para ver el informe.',
 'Roster':'Lista de clase','All teachers':'Todos los maestros','No students for this teacher.':'No hay estudiantes para este maestro.','Choose roster CSV file':'Elegir archivo CSV de la lista','Paste roster rows':'Pegar filas de la lista'
});
Object.assign(LANG.pt,{
 'Certificate of Completion':'Certificado de Conclusão','Certificate of Achievement':'Certificado de Conquista','K–8 Financial Literacy Program':'Programa de Educação Financeira K–8','GRADE COMPLETE':'SÉRIE CONCLUÍDA','This certifies that':'Isto certifica que','Your Name':'Seu Nome',
 'completed the full grade: every weekly lesson and all checkpoint tests.':'concluiu toda a série: cada lição semanal e todas as provas de verificação.','making great progress in earning, saving, budgeting, and smart money decisions.':'está progredindo muito bem em ganhar, poupar, orçar e tomar boas decisões de dinheiro.','Level':'Nível',
 'added':'adicionados','merged':'combinados','The page will refresh.':'A página será atualizada.','updated':'atualizados',
 '📊 Most-missed questions':'📊 Perguntas mais erradas','No quiz data yet — item analysis appears after students take quizzes.':'Ainda não há dados — a análise aparece depois que os alunos fizerem os quizzes.','Ranked by percent of attempts answered incorrectly across all students on this device.':'Classificadas pela porcentagem de respostas erradas de todos os alunos neste dispositivo.','Most-missed questions':'Perguntas mais erradas','Missed':'Erradas','Allow pop-ups to view the report.':'Permita pop-ups para ver o relatório.',
 'Roster':'Lista da turma','All teachers':'Todos os professores','No students for this teacher.':'Nenhum aluno para este professor.','Choose roster CSV file':'Escolher arquivo CSV da lista','Paste roster rows':'Colar linhas da lista'
});
const GRADE_LABEL_L={
 es:{K:"Kínder","1":"Grado 1","2":"Grado 2","3":"Grado 3","4":"Grado 4","5":"Grado 5","6":"Grado 6","7":"Grado 7","8":"Grado 8"},
 pt:{K:"Jardim de Infância","1":"Série 1","2":"Série 2","3":"Série 3","4":"Série 4","5":"Série 5","6":"Série 6","7":"Série 7","8":"Série 8"}
};
function gradeLabel(g){ const l=loadLang(); return (l!=='en'&&GRADE_LABEL_L[l]&&GRADE_LABEL_L[l][g])||GRADE_LABEL[g]; }
const LANGNOTE={
 en:"The whole app — interface, lessons, worksheets, quizzes, and tests — switches to your chosen language.",
 es:"Toda la aplicación — interfaz, lecciones, hojas de trabajo, cuestionarios y exámenes — cambia al idioma que elijas.",
 pt:"Todo o aplicativo — interface, lições, folhas de atividades, quizzes e provas — muda para o idioma escolhido."
};
const WELCOME={
 en:"Welcome to Money Matters! I'm Jay, your guide.<br><br>Pick a <b>Grade</b> in the bottom bar (K through 8), open the <b>Lessons</b> desk to teach, and use the <b>Lesson Plan</b>, <b>Worksheet</b>, <b>Workbook</b>, and <b>Teacher Guide</b> desks to print everything you need.",
 es:"¡Bienvenido a Money Matters! Soy Jay, tu guía.<br><br>Elige un <b>Grado</b> en la barra inferior (K a 8), abre el escritorio de <b>Lecciones</b> para enseñar, y usa los escritorios de <b>Plan de clase</b>, <b>Hoja de trabajo</b>, <b>Cuaderno</b> y <b>Guía docente</b> para imprimir todo lo que necesites.",
 pt:"Bem-vindo ao Money Matters! Eu sou o Jay, seu guia.<br><br>Escolha uma <b>Série</b> na barra inferior (K a 8), abra a mesa de <b>Lições</b> para ensinar e use as mesas de <b>Plano de aula</b>, <b>Folha de atividades</b>, <b>Caderno</b> e <b>Guia do professor</b> para imprimir tudo o que você precisa."
};
function loadLang(){ try{return localStorage.getItem('mmLang')||'en';}catch(e){return 'en';} }
function t(k){ const l=loadLang(); return (l!=='en'&&LANG[l]&&LANG[l][k])?LANG[l][k]:k; }
function setLang(l){ try{localStorage.setItem('mmLang',l);}catch(e){} applyLang(); }
function toggleLang(){ const o=['en','es','pt']; setLang(o[(o.indexOf(loadLang())+1)%o.length]); }
function i18nScan(){
  const en=(loadLang()==='en');
  const sel='.panel-title:not([id]),.panel-sub:not([id]),.panel-kicker:not([id]),.section-head,.wlc-name,.board-subtitle,.a11y-row b,.a11y-row .t>span,.flow-step,.lesson-next';
  document.querySelectorAll(sel).forEach(function(el){ if(el.children.length)return; if(el.dataset.en==null)el.dataset.en=el.textContent; el.textContent=en?el.dataset.en:t(el.dataset.en); });
}
function updateLangBtns(){ const cur=loadLang(); ['en','es','pt'].forEach(function(l){var b=document.getElementById('lang-'+l); if(b)b.classList.toggle('active',cur===l);}); }
/* ===== PANEL RENDERER REGISTRY (Fix #12) =====
   Any panel that needs a language-aware re-render registers itself here.
   openPanel() and applyLang() both use this registry, so adding a new panel
   only requires one registration instead of two separate if/else edits.     */
const _panelRenderers={
  dashboard:  function(){ renderDashboard(); },
  overview:   function(){ buildOverview(); },
  lessons:    function(){ renderChips(); loadLesson(currentIndex); },
  path:       function(){ renderPath(); },
  test:       function(){ renderTestPanel(); },
  teacher:    function(){ renderTeacher(); },
  glossary:   function(){ renderGlossary(); },
  login:      function(){ renderLogin(); },
  quiz:       function(){ renderQuiz(); },
  doc:        function(){ renderDoc(); },
  help:       function(){ renderHelp(); },
  whatsnew:   function(){ renderWhatsNew(); },
  feedback:   function(){ renderFeedback(); },
  students:   function(){ renderStudents(); },
  games:      function(){ renderGames(); },
  certificate:function(){ populateSchoolField(); renderPrizeSummary(); renderCert(); },
  assessment:function(){ renderFinancialAssessment(); },
};
function _runPanelRenderer(id){
  if(id&&_panelRenderers[id]) try{ _panelRenderers[id](); }catch(e){ console.warn('Panel renderer error ('+id+'):',e); }
}

function applyLang(){ try{document.documentElement.setAttribute('lang',loadLang());}catch(e){}
  buildNav(); buildGradeNav(); i18nScan();
  const il=document.getElementById('instructorLabel'); if(il)il.innerHTML='Jay<br>'+esc(t('Instructor'));
  const wm=document.getElementById('welcomeMsg'); if(wm)wm.innerHTML=(WELCOME[loadLang()]||WELCOME.en);
  const ln=document.getElementById('langNote'); if(ln)ln.textContent=(LANGNOTE[loadLang()]||LANGNOTE.en);
  refreshBoard();
  const gl=document.getElementById('navGradeLabel'); if(gl)gl.textContent=t('Grade');
  _runPanelRenderer(openPanelId);
  i18nScan(); updateLangBtns();
}
function navDef(){ return [
  ['🏠',t('Home'),false,"openPanel('dashboard')"],['📚',t('Lessons'),false,"openPanel('lessons')"],
  ['🧭',t('Learning Path'),false,"openPanel('path')"],['📝',t('Quiz'),false,"openQuiz()"],
  ['🧪',t('Section Test'),false,"openTestMenu()"],['🏆',t('Certificate'),false,"openPanel('certificate')"],
  ['📖',t('Glossary'),false,"openPanel('glossary')"],['📋',t('Lesson Plan'),true,"openDoc('plan')"],
  ['✏️',t('Worksheet'),false,"openDoc('worksheet')"],['📗',t('Workbook'),true,"openDoc('workbook')"],
  ['🧑‍🏫',t('Guide & Answer Key'),true,"openDoc('guide')"],['🏫',t('Class Setup'),true,"openPanel('teacher')"],['📊','Financial Assessment',true,"openPanel('assessment')"],
  ['❓',t('How to Use'),false,"openPanel('help')"],['🔤',t('Reading'),false,"openPanel('a11y')"],
  ['📜',t('Privacy & Terms'),false,"openPanel('legal')"],
  ...(loadRole()==='teacher' ? [['🆕',t("What's New"),true,"openPanel('whatsnew')"]] : []),
  ['💬',t('Feedback'),false,"openPanel('feedback')"],
  ['🎭',t('Story'),false,"openPanel('story')"],['🎮',t('Games'),false,"openPanel('games')"] ]; }
function buildNav(){ const el=document.getElementById('navBtns'); if(!el)return;
  el.innerHTML=navDef().map(function(d){return '<button class="nav-btn'+(d[2]?' teacher-only':'')+'" onclick="'+d[3]+'">'+d[0]+' '+esc(d[1])+'</button>';}).join('')
    +'<span class="nav-sep"></span>'
    +'<button class="nav-btn" id="studentNavBtn" onclick="openPanel(\'login\')">👤 '+esc(t('Sign in'))+'</button>'
    +'<button class="nav-btn" onclick="toggleLang()">🌐 '+({en:'EN',es:'ES',pt:'PT'}[loadLang()]||'EN')+'</button>'
    +'<button class="nav-btn role-toggle" id="roleBtn" onclick="toggleRole()">🎒 '+esc(t('Student mode'))+'</button>';
  refreshStudentUI(); applyRole();
}

/* ===== FIRST-RUN TOUR ===== */
const TOUR=[
  {ic:'👋',title:'Welcome to Money Matters',text:'A full K–8 money curriculum in one place. This 30-second tour shows the parts you will use most. You can replay it anytime from How to Use.'},
  {ic:'🎒',title:'1. Sign in a student',text:'Open the Student desk, type a name and pick a grade. Progress, prizes, and the certificate save to that student on this device.'},
  {ic:'📚',title:'2. Teach, then practice',text:'Open Lessons and tap a week. Follow the flow Lesson to Worksheet to Quiz with the Next buttons. Younger students can tap Read Aloud.'},
  {ic:'🧭',title:'3. Follow the path',text:'The Learning Path and progress bar show what is done and what is next. Weeks unlock as each quiz is passed, and a Section Test follows every 6 weeks.'},
  {ic:'👩‍🏫',title:'4. Teacher/Parent tools',text:'Tap Student or Teacher/Parent and set a passcode to reveal the Teacher Guide, class progress, gradebook export, and week-lock controls. Enjoy!'}
];
let tourI=0;
function startTour(){ tourI=0; document.getElementById('tour').classList.add('on'); showTourStep(); }
function showTourStep(){ const arr=TOURTX[loadLang()]||TOURTX.en; const s=arr[tourI]; set('tourIcon',ICONS[tourI]||'👋'); set('tourTitle',s[0]); set('tourText',s[1]);
  document.getElementById('tourDots').innerHTML=arr.map(function(_,i){return '<i class="'+(i===tourI?'on':'')+'"></i>';}).join('');
  document.getElementById('tourBack').style.visibility=(tourI===0)?'hidden':'visible';
  set('tourSkip',t('Skip')); set('tourBack',t('Back'));
  set('tourNext',(tourI===arr.length-1)?t('Finish'):t('Next')); }
function tourNext(){ if(tourI>=TOUR.length-1){endTour();return;} tourI++; showTourStep(); }
function tourPrev(){ if(tourI>0){tourI--; showTourStep();} }
function maybeTour(){
  /* Show tour on first ever open, or when APP_VERSION changes (new features to highlight) */
  try{
    const done=localStorage.getItem('mmTourDone')||'';
    const tourVer=localStorage.getItem('mmTourVersion')||'';
    if(!done||tourVer!==APP_VERSION){
      setTimeout(startTour,1000);
    }
  }catch(e){ setTimeout(startTour,1000); }
}
function endTour(){
  document.getElementById('tour').classList.remove('on');
  try{ localStorage.setItem('mmTourDone','1'); localStorage.setItem('mmTourVersion',APP_VERSION); }catch(e){}
}

/* ===== STREAK + BADGES ===== */
function todayStr(){ try{return new Date().toDateString();}catch(e){return '';} }
function touchStreak(){ const s=loadStore(); const aid=_activeId(); if(!aid||!s.list[aid])return; const st=s.list[aid]; const today=todayStr(); if(!today||st.lastDay===today)return;
  let y=''; try{var d=new Date(); d.setDate(d.getDate()-1); y=d.toDateString();}catch(e){}
  st.streak=(st.lastDay===y)?((st.streak||0)+1):1; st.lastDay=today; saveStore(s); }
function badgeRow(){ const st=progStats(); const gc=gradeCompletion(); const a=activeStudent(); const streak=(a&&a.streak)?a.streak:0;
  const b=[['🎯','First quiz',st.taken>=1],['🖐️','5 passed',st.passed>=5],['💪','10 passed',st.passed>=10],['🌟','3 gold',st.gold>=3],['🧪','Checkpoint ace',st.testsPassed>=1],['🔥','3-day streak',streak>=3],['🏆','Grade complete',gc.complete]];
  return b.map(function(x){return '<span class="badge'+(x[2]?'':' lock')+'">'+x[0]+' '+esc(x[1])+'</span>';}).join(''); }

/* ===== DASHBOARD ===== */
function renderDashboard(){
  const el=document.getElementById('dashBody'); if(!el)return; const a=activeStudent(); const nm=a?a.name:'';
  set('dashKicker',GRADE_LABEL[currentGrade]+' · '+(a?nm:'Guest')); set('dashTitle',t('My Dashboard'));
  const ls=lessons(); const p=myProg(); const passed=ls.filter(function(l){var v=p['quiz|'+currentGrade+'|'+l.week];return v!=null&&v>=75;}).length;
  const pct=ls.length?Math.round(passed/ls.length*100):0; const st=progStats(); const gc=gradeCompletion(); const streak=(a&&a.streak)?a.streak:0;
  let h='';
  if(loadLang()!=='en'){ const es=(loadLang()==='es'); h+='<div class="lang-note">'+(contentTranslated()?('✔ '+(es?'Contenido de este grado traducido al español.':'Conteúdo desta série traduzido para o português.')):(es?'Interfaz en español · el contenido de las lecciones está en inglés en este grado.':'Interface em português · o conteúdo das lições está em inglês nesta série.'))+'</div>'; }
  h+='<div class="dash-hero"><h2>'+(a?('Hi, '+esc(nm)+'! 👋'):'Welcome! 👋')+'</h2>'
    +'<div class="sub">'+GRADE_LABEL[currentGrade]+' · '+passed+' of '+ls.length+' lessons complete'+(streak>1?(' · 🔥 '+streak+'-day streak'):'')+(a&&a.teacher?(' · 👩‍🏫 '+esc(a.teacher)):'')+(getSchoolName()?(' · 🏫 '+esc(getSchoolName())):'')+'</div>'
    +'<div class="pbar" style="margin-top:10px"><i style="width:'+pct+'%"></i></div></div>';
  h+='<div class="meta-pills"><button class="btn-calc green" onclick="continuePath()">'+esc(t('▶ Continue where I left off'))+'</button>'
    +'<button class="btn-calc" onclick="openPanel(\'lessons\')">'+esc(t('📚 Lessons'))+'</button>'
    +'<button class="btn-calc" style="background:#7a1e4d" onclick="openQuiz()">'+esc(t('📝 Quiz'))+'</button>'
    +'<button class="btn-calc" onclick="openPanel(\'certificate\')">'+esc(t('🏆 Certificate'))+'</button>'
    +'<button class="btn-calc" style="background:#1e6b6b" onclick="openPanel(\'assessment\')">📊 Financial Profile</button></div>';
  const aw=assignedWeek(currentGrade);
  if(aw!=null&&ls[aw]){ h+='<div class="card" style="border-left:4px solid var(--gold)"><div class="card-body">📌 <b>'+esc(t('This week'))+':</b> '+esc(t('Week'))+' '+ls[aw].week+' — '+esc(ls[aw].title)+'<br><button class="btn-calc" style="margin-top:6px" onclick="gotoLesson('+aw+')">'+esc(t('Open'))+'</button></div></div>'; }
  h+='<div class="section-head">'+esc(t('Where you are'))+'</div><div class="card"><div class="card-body">'+esc(t('Lessons mastered'))+': <b>'+passed+'/'+ls.length+'</b> · '+esc(t('Checkpoints'))+': <b>'+gc.tests+'/'+gc.totalTests+'</b> · '+esc(t('Stars'))+': <b>'+st.stars+'</b>'+(gc.complete?' · <b style="color:var(--green)">'+esc(t('Grade complete!'))+' 🏆</b>':'')+'</div></div>';
  h+='<div class="section-head">'+esc(t('Unit progress'))+'</div><div class="card"><div class="card-body">'+unitProgressHTML()+'</div></div>';
  h+=nextBadgeNudge();
  factToday=factOfDay();
  if(factToday){ h+='<div class="section-head">'+esc(t('Fact of the day'))+'</div><div class="card"><div class="card-body">💡 '+esc(factToday)+'<br><button class="btn-calc" style="margin-top:8px;background:#1e6b6b" onclick="speakFact()">🔊 '+esc(t('Hear it'))+'</button></div></div>'; }
  const wl=gradeGlossary();
  if(wl.length){ wordOfDay=wl[dayIndex()%wl.length];
    h+='<div class="section-head">'+esc(t('Word of the day'))+'</div><div class="card"><div class="card-body"><b>'+esc(wordOfDay.term)+'</b> — '+esc(wordOfDay.def)+'<br><button class="btn-calc" style="margin-top:8px;background:#1e6b6b" onclick="speakWordOfDay()">🔊 '+esc(t('Hear it'))+'</button> <button class="btn-calc ghost" style="margin-top:8px" onclick="openPanel(\'glossary\')">'+esc(t('📖 Glossary'))+'</button></div></div>';
  }
  h+='<div class="section-head">'+esc(t('Badges'))+'</div><div class="badge-row">'+badgeRow()+'</div>';
  h+=backupNudge();
  if(!a) h+='<div class="lang-note" style="margin-top:14px">'+esc(t('Tip: open the Student desk to save your progress and prizes.'))+'</div>';
  el.innerHTML=previewBanner()+h;
}

/* ===== WORKSHEET AUTO-SAVE ===== */
function wsKey(week){ return currentGrade+'|'+week; }
function wsGet(week){ const a=activeStudent(); return (a&&a.ws&&a.ws[wsKey(week)])?a.ws[wsKey(week)]:{}; }
const _wsDebounceTimers={};
function wsAutoSave(week){
  if(_wsDebounceTimers[week])clearTimeout(_wsDebounceTimers[week]);
  _wsDebounceTimers[week]=setTimeout(function(){
    delete _wsDebounceTimers[week];
    const s=loadStore(); const aid=_activeId(); if(!aid||!s.list[aid])return; const st=s.list[aid]; if(!st.ws)st.ws={}; const rec={};
    const nm=document.getElementById('wsName'); if(nm)rec.name=nm.value; const dt=document.getElementById('wsDate'); if(dt)rec.date=dt.value;
    const l=L(); if(l){ l.worksheet.items.forEach(function(it,i){ const el=document.getElementById('wf-'+i); if(el)rec['i'+i]=el.value; }); }
    st.ws[wsKey(week)]=rec; saveStore(s);
  },500);
}

/* ===== SOUND ===== */
function soundOn(){ try{return localStorage.getItem('mmSound')==='on';}catch(e){return false;} }
function toggleSound(){ try{localStorage.setItem('mmSound',soundOn()?'off':'on');}catch(e){} const c=document.getElementById('soundChk'); if(c)c.checked=soundOn(); if(soundOn())playChime(); }
function playChime(){ if(!soundOn())return; try{ const AC=window.AudioContext||window.webkitAudioContext; if(!AC)return; const ac=new AC(); const now=ac.currentTime; [523,659,784].forEach(function(f,i){ const o=ac.createOscillator(); const g=ac.createGain(); o.type='sine'; o.frequency.value=f; o.connect(g); g.connect(ac.destination); const tt=now+i*0.12; g.gain.setValueAtTime(0.0001,tt); g.gain.exponentialRampToValueAtTime(0.2,tt+0.02); g.gain.exponentialRampToValueAtTime(0.0001,tt+0.28); o.start(tt); o.stop(tt+0.3); }); setTimeout(function(){try{ac.close();}catch(e){}},900); }catch(e){} }

/* ===== READ ALOUD (quiz + worksheet) ===== */
function speakText(txt){ if(!voiceOK()){vstatus&&vstatus('Voice not supported.');return;} try{ window.speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(txt); const rt=document.getElementById('voiceRate'); u.rate=rt?(parseFloat(rt.value)||1):1; u.lang='en-US'; const v=pickVoice(); if(v)u.voice=v; window.speechSynthesis.speak(u); }catch(e){} }
function readQuizAloud(){ if(!quizQs.length)return; const parts=[]; quizQs.forEach(function(q,i){ parts.push((i+1)+'. '+q.q+'. '+(q.options||[]).map(function(o,j){return String.fromCharCode(65+j)+', '+o;}).join('. ')); }); speakText(parts.join('. ')); }
function readWorksheetAloud(){ const l=L(); if(!l)return; const parts=[l.worksheet.intro]; l.worksheet.items.forEach(function(it,i){parts.push((i+1)+'. '+rewordWrite(it.q));}); speakText(parts.join('. ')); }

/* ===== FAMILY LETTER ===== */
function familyLetterHTML(){
  const g=GRADE_LABEL[currentGrade],school=getSchoolName();
  return '<div class="v53-report"><div class="rhead"><div class="rkicker">Money Matters · Family Learning Guide</div><h1>'+esc(g)+' · Learning About Money</h1>'+(school?'<div class="rsub">'+esc(school)+'</div>':'')+'</div>'
    +'<p>Dear Family,</p><p>Your child is participating in <b>Money Matters</b>, a K–8 financial literacy program designed to build practical money skills through age-appropriate lessons, practice, quizzes, and reflection. The '+esc(g)+' learning focus is <b>'+esc(GRADE_THEME[currentGrade])+'</b>.</p>'
    +'<h2>How a learning week works</h2><div class="grid"><div class="stat"><b>1</b><span>Lesson</span></div><div class="stat"><b>2</b><span>Worksheet</span></div><div class="stat"><b>3</b><span>Quiz</span></div><div class="stat"><b>4</b><span>Reflection</span></div></div>'
    +'<p style="font-size:12px;line-height:1.6">Students move forward after demonstrating mastery. A score of <b>75% or higher</b> is required to unlock the next week. Periodic checkpoint tests provide another opportunity to demonstrate understanding.</p>'
    +'<h2>What families can do at home</h2><ul><li>Ask your child to explain one money idea they learned this week.</li><li>Let your child help compare prices, count change, or make a simple spending decision.</li><li>Talk about needs, wants, saving, earning, budgeting, and responsible choices during everyday activities.</li><li>Celebrate effort and encourage your child to retry questions they missed.</li></ul>'
    +'<h2>What your child is building</h2><p style="font-size:12px;line-height:1.6">Depending on grade level, students practice earning, spending, saving, budgeting, banking, credit, investing, taxes, and financial decision-making.</p>'
    +'<div class="note"><b>Family conversation starter:</b> “What is one money decision you made this week, and what helped you make it?”</div>'
    +'<p>Thank you for partnering with us as your child builds lifelong financial skills.</p><div class="footer">Money Matters · K–8 Financial Literacy Curriculum'+(school?' · '+esc(school):'')+' · Generated '+new Date().toLocaleDateString()+'</div></div>';
}
function printFamily(){
  const css='body{font-family:Georgia,serif;padding:30px}.paper{max-width:720px;margin:0 auto}h1{font-size:22px}h2{font-size:14px;color:#7a5a1e;font-family:Arial}.doc-kicker{font-family:Arial;font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:#8a5e10;font-weight:bold}p,li{font-family:Arial;font-size:14px;color:#222;line-height:1.6}.doc-note{font-family:Arial;font-size:11px;color:#888;text-align:center;margin-top:10px}';
  const html='<!DOCTYPE html><html><head><meta charset="utf-8"><title>Family Letter</title>'
    +'<style>'+css+'</style></head><body>'+familyLetterHTML()+'\n</body></html>';
  try{
    const blob=new Blob([html],{type:'text/html'});
    const url=URL.createObjectURL(blob);
    const pw=window.open(url,'_blank');
    if(!pw){ URL.revokeObjectURL(url); return; }
    pw.addEventListener('load',function(){ try{pw.print();}catch(e){} URL.revokeObjectURL(url); },{once:true});
    setTimeout(function(){ URL.revokeObjectURL(url); },30000);
  }catch(e){
    const fw=window.open('','_blank'); if(fw){fw.document.write(html);fw.document.close();setTimeout(function(){try{fw.print();}catch(e){}},300);}
  }
}
function downloadFamily(){ const html='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Family Letter</title></head><body>'+familyLetterHTML()+'\n</body></html>'; try{const b=new Blob(['﻿'+html],{type:'application/msword'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='MoneyMatters_'+GRADE_LABEL[currentGrade].replace(/\s+/g,'')+'_FamilyLetter.doc';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);}catch(e){alert('Download not supported.');} }

/* ===== BACKUP / RESTORE ===== */
function backupData(){ try{ const data={v:2,students:loadStore(),lang:loadLang(),gate:gateOn(),gameStats:mmGameStats(),achievements:mmAchievements(),lifeState:(function(){try{return JSON.parse(localStorage.getItem('mmLifeState_v1')||'null');}catch(e){return null;}})(),lifeWallet:(function(){try{return localStorage.getItem('mmLifeWallet_v1');}catch(e){return null;}})(),reflections:(function(){try{return JSON.parse(localStorage.getItem('mmReflection_v1')||'{}');}catch(e){return {};}})()}; const b=new Blob([JSON.stringify(data)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='MoneyMatters_Backup.json'; document.body.appendChild(a); a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500); try{localStorage.setItem('mmLastBackup',String(Date.now()));}catch(e){} }catch(e){ alert('Backup failed.'); } }
function mergeRestore(inc){ const s=loadStore(); if(!s.teachers)s.teachers=[]; const incList=(inc&&inc.list)||{};
  (inc.teachers||[]).forEach(function(tn){ if(s.teachers.indexOf(tn)<0)s.teachers.push(tn); });
  function key(st){ return (st.name||'').toLowerCase()+'|'+(st.grade||'K'); }
  var byKey={}; Object.keys(s.list).forEach(function(id){ byKey[key(s.list[id])]=id; });
  var added=0,merged=0;
  Object.keys(incList).forEach(function(id){ var st=incList[id]; if(!st||!st.name)return; var k=key(st); var exId=byKey[k];
    if(exId){ var cur=s.list[exId]; cur.prog=cur.prog||{}; var ip=st.prog||{}; Object.keys(ip).forEach(function(pk){ if(cur.prog[pk]==null || (typeof ip[pk]==='number' && ip[pk]>cur.prog[pk])) cur.prog[pk]=ip[pk]; }); if(st.teacher&&!cur.teacher)cur.teacher=st.teacher; if(st.review&&!cur.review)cur.review=st.review; if(st.lastActive)cur.lastActive=st.lastActive; merged++; }
    else { var nid=s.list[id]?newId():id; st.id=nid; s.list[nid]=st; byKey[k]=nid; added++; }
  });
  saveStore(s); return {added:added,merged:merged}; }
function restoreData(){ const inp=document.createElement('input'); inp.type='file'; inp.accept='application/json,.json'; inp.onchange=function(){ const f=inp.files&&inp.files[0]; if(!f)return; const r=new FileReader(); r.onload=function(){ try{ const d=JSON.parse(r.result); if(d&&d.students){ const res=mergeRestore(d.students); if(d.lang){try{localStorage.setItem('mmLang',d.lang);}catch(e){}} if(d.gameStats){try{localStorage.setItem(MM_GAME_STATS_KEY,JSON.stringify(d.gameStats));}catch(e){}} if(d.achievements){try{localStorage.setItem(MM_ACH_KEY,JSON.stringify(d.achievements));}catch(e){}} if(d.lifeState){try{localStorage.setItem('mmLifeState_v1',JSON.stringify(d.lifeState));}catch(e){}} if(d.lifeWallet!=null){try{localStorage.setItem('mmLifeWallet_v1',String(d.lifeWallet));}catch(e){}} if(d.reflections){try{localStorage.setItem('mmReflection_v1',JSON.stringify(d.reflections));}catch(e){}} mmConfirm('Restore complete','Added '+res.added+', merged '+res.merged+' student record(s). Reload now to apply all restored data?','Reload','✅').then(function(go){ if(go)location.reload(); else infoToast('✓ Restore applied — reload the page when ready.',4000); }); } else { mmAlert('That file does not look like a Money Matters backup.','⚠️'); } }catch(e){ mmAlert('That file could not be read.','❌'); } }; r.readAsText(f); }; inp.click(); }

/* ===== HELPERS ===== */
function unitPhase(i){ if(i<12)return 'Foundations'; if(i<24)return 'Skills'; return 'Decisions'; }

/* ===== EXTRA TRANSLATIONS (tour, teacher, help) ===== */
Object.assign(LANG.es,{'All grades':'Todos los grados','All students':'Todos los estudiantes','Skip':'Saltar','Back':'Atrás','Next':'Siguiente','Finish':'Terminar','⬇ Export gradebook (CSV)':'⬇ Exportar calificaciones (CSV)','🔑 Change adult passcode':'🔑 Cambiar la contraseña del maestro','🔓 Turn OFF week locks':'🔓 Desactivar bloqueos por semana','🔒 Turn ON week locks':'🔒 Activar bloqueos por semana','🏠 Family letter (print)':'🏠 Carta para la familia (imprimir)','⬇ Family letter (.doc)':'⬇ Carta para la familia (.doc)','💾 Backup all progress':'💾 Copia de seguridad','↩ Restore from file':'↩ Restaurar desde archivo','🖨️ Report':'🖨️ Informe','⬇ Export':'⬇ Exportar','Reset progress':'Reiniciar progreso','🗑 Remove':'🗑 Eliminar','All learner profiles saved on this device. Reports print or download as Word.':'Todos los perfiles guardados en este dispositivo. Los informes se imprimen o descargan como Word.','▶ Replay the welcome tour':'▶ Repetir el recorrido'});
Object.assign(LANG.pt,{'All grades':'Todas as séries','All students':'Todos os alunos','Skip':'Pular','Back':'Voltar','Next':'Próximo','Finish':'Concluir','⬇ Export gradebook (CSV)':'⬇ Exportar notas (CSV)','🔑 Change adult passcode':'🔑 Alterar a senha do professor','🔓 Turn OFF week locks':'🔓 Desativar bloqueios por semana','🔒 Turn ON week locks':'🔒 Ativar bloqueios por semana','🏠 Family letter (print)':'🏠 Carta para a família (imprimir)','⬇ Family letter (.doc)':'⬇ Carta para a família (.doc)','💾 Backup all progress':'💾 Fazer backup','↩ Restore from file':'↩ Restaurar de arquivo','🖨️ Report':'🖨️ Relatório','⬇ Export':'⬇ Exportar','Reset progress':'Redefinir progresso','🗑 Remove':'🗑 Remover','All learner profiles saved on this device. Reports print or download as Word.':'Todos os perfis salvos neste dispositivo. Os relatórios são impressos ou baixados como Word.','▶ Replay the welcome tour':'▶ Repetir o tour'});
const ICONS=['👋','🎒','📚','🧭','👩‍🏫'];
const TOURTX={
 en:[['Welcome to Money Matters','A full K–8 money curriculum in one place. This 30-second tour shows the parts you will use most. You can replay it anytime from How to Use.'],['1. Sign in','Everyone signs in with a username and password. Students use their 6-character sign-in code, or create a profile. Progress, prizes, and the certificate save to that student on this device.'],['2. Teach, then practice','Open Lessons and tap a week. Follow the flow Lesson to Worksheet to Quiz with the Next buttons. Younger students can tap Read Aloud.'],['3. Follow the path','The Learning Path and progress bar show what is done and what is next. Weeks unlock as each quiz is passed, and a Section Test follows every 6 weeks.'],['4. Admin Console','Sign in as a Teacher or Administrator to open the Admin Console: users, rosters, student and teacher profiles, class insights, reports, backups, and settings. Enjoy!']],
 es:[['Bienvenido a Money Matters','Un plan de dinero completo de K a 8 en un solo lugar. Este recorrido de 30 segundos muestra lo que más usarás. Puedes repetirlo desde Cómo usar.'],['1. Registra a un estudiante','Abre la mesa Estudiante, escribe un nombre y elige un grado. El progreso, los premios y el certificado se guardan para ese estudiante en este dispositivo.'],['2. Enseña y practica','Abre Lecciones y toca una semana. Sigue el flujo Lección → Hoja → Cuestionario con los botones Siguiente. Los más pequeños pueden tocar Leer en voz alta.'],['3. Sigue la ruta','La Ruta de aprendizaje y la barra de progreso muestran lo hecho y lo siguiente. Las semanas se desbloquean al aprobar cada cuestionario, y hay un Examen de sección cada 6 semanas.'],['4. Herramientas del maestro','Toca Estudiante/Maestro y crea una contraseña para ver la Guía docente, el progreso de la clase, la exportación de calificaciones y los bloqueos por semana. ¡Disfruta!']],
 pt:[['Bem-vindo ao Money Matters','Um currículo de dinheiro completo do K ao 8 em um só lugar. Este tour de 30 segundos mostra o que você mais vai usar. Você pode repeti-lo em Como usar.'],['1. Cadastre um aluno','Abra a mesa Aluno, digite um nome e escolha uma série. Progresso, prêmios e certificado ficam salvos para esse aluno neste dispositivo.'],['2. Ensine e pratique','Abra Lições e toque numa semana. Siga o fluxo Lição → Folha → Quiz com os botões Próximo. Alunos menores podem tocar em Ler em voz alta.'],['3. Siga a trilha','A Trilha de aprendizagem e a barra de progresso mostram o que já foi feito e o próximo passo. As semanas são liberadas ao passar em cada quiz, e há uma Prova da seção a cada 6 semanas.'],['4. Ferramentas do professor','Toque em Aluno/Professor e defina uma senha para ver o Guia do professor, o progresso da turma, a exportação de notas e os bloqueios por semana. Aproveite!']]
};
const HELPTX={
 en:['<b>Pick a grade.</b> Use the K–8 buttons in the bottom bar. The chalkboard shows the grade you are teaching.','<b>Sign in a student.</b> Open the Student desk, type a name and pick a grade — progress and prizes save to that student.','<b>Teach the week.</b> Open Lessons and tap a week: vocabulary, mini-lesson, practice, discussion, and a quick check. Use Read Aloud for younger students.','<b>Follow the flow.</b> Lesson → Worksheet → Quiz using the Next buttons. The worksheet is fillable; the quiz scores instantly with answers shown.','<b>Earn prizes.</b> 90%+ = 🏆 Gold, 75%+ = 🥇 Silver, 50%+ = 🎖️ Bronze. Passing (75%+) counts toward the certificate.','<b>Checkpoints & locks.</b> A Section Test follows every 6 weeks; weeks unlock as each quiz is passed. Teacher/Parent mode can turn locks off.','<b>Teacher tools &amp; Admin Console.</b> Sign in with a teacher or administrator account to open the Admin Console: users, rosters, student and teacher profiles, reports, backups, and settings. It also reveals the Teacher Guide, class progress, gradebook export, week locks, and family letters.'],
 es:['<b>Elige un grado.</b> Usa los botones K–8 en la barra inferior. La pizarra muestra el grado que enseñas.','<b>Registra a un estudiante.</b> Abre la mesa Estudiante, escribe un nombre y elige un grado; el progreso y los premios se guardan para ese estudiante.','<b>Enseña la semana.</b> Abre Lecciones y toca una semana: vocabulario, mini lección, práctica, discusión y una comprobación rápida. Usa Leer en voz alta para los más pequeños.','<b>Sigue el flujo.</b> Lección → Hoja → Cuestionario con los botones Siguiente. La hoja es rellenable; el cuestionario califica al instante y muestra las respuestas.','<b>Gana premios.</b> 90%+ = 🏆 Oro, 75%+ = 🥇 Plata, 50%+ = 🎖️ Bronce. Aprobar (75%+) cuenta para el certificado.','<b>Exámenes y bloqueos.</b> Hay un Examen de sección cada 6 semanas; las semanas se desbloquean al aprobar cada cuestionario. El modo maestro puede desactivar los bloqueos.','<b>Herramientas del maestro.</b> Crea una contraseña para ver la Guía docente, el progreso de la clase, la exportación de calificaciones, los bloqueos y las cartas para la familia.'],
 pt:['<b>Escolha uma série.</b> Use os botões K–8 na barra inferior. A lousa mostra a série que você está ensinando.','<b>Cadastre um aluno.</b> Abra a mesa Aluno, digite um nome e escolha uma série; o progresso e os prêmios ficam salvos para esse aluno.','<b>Ensine a semana.</b> Abra Lições e toque numa semana: vocabulário, mini lição, prática, discussão e uma verificação rápida. Use Ler em voz alta para os menores.','<b>Siga o fluxo.</b> Lição → Folha → Quiz com os botões Próximo. A folha é preenchível; o quiz corrige na hora e mostra as respostas.','<b>Ganhe prêmios.</b> 90%+ = 🏆 Ouro, 75%+ = 🥇 Prata, 50%+ = 🎖️ Bronze. Passar (75%+) conta para o certificado.','<b>Provas e bloqueios.</b> Há uma Prova da seção a cada 6 semanas; as semanas são liberadas ao passar em cada quiz. O modo professor pode desativar os bloqueios.','<b>Ferramentas do professor.</b> Defina uma senha para ver o Guia do professor, o progresso da turma, a exportação de notas, os bloqueios e as cartas para a família.']
};
const HELPFACT={en:'<strong>Good to know:</strong> everything works offline, and quiz scores &amp; prizes are saved in this browser on this device.',es:'<strong>Bueno saber:</strong> todo funciona sin internet, y las puntuaciones y premios se guardan en este navegador en este dispositivo.',pt:'<strong>Bom saber:</strong> tudo funciona offline, e as pontuações e prêmios ficam salvos neste navegador, neste dispositivo.'};
function renderHelp(){ const el=document.getElementById('helpBody'); if(!el)return; const L=loadLang(); const steps=(HELPTX[L]||HELPTX.en); const fact=(HELPFACT[L]||HELPFACT.en);
  let h=''; steps.forEach(function(s,i){ h+='<div class="help-step"><div class="help-num">'+(i+1)+'</div><div class="help-body">'+s+'</div></div>'; });
  h+='<div class="fact"><div class="fact-icon">💡</div><div class="fact-text">'+fact+'</div></div>';
  h+='<div class="meta-pills"><button class="btn-calc" onclick="startTour()">'+esc(t('▶ Replay the welcome tour'))+'</button></div>';
  h+='<div style="margin-top:24px;padding-top:16px;border-top:1px solid rgba(140,90,30,0.15);font-family:system-ui,sans-serif;font-size:12px;color:var(--ink-light);text-align:center;">'
    +'<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-bottom:10px">'
    +'<button class="btn-calc ghost" style="font-size:12px;padding:6px 14px" onclick="openPanel(\'legal\')">📜 Privacy &amp; Terms</button>'
    +'<button class="btn-calc ghost pwa-install-btn" style="font-size:12px;padding:6px 14px;display:none" onclick="triggerInstall()">📲 Install App</button>'
    +'</div>'
    +'<div style="opacity:0.7;">Money Matters · K–8 Financial Literacy Curriculum · v'+APP_VERSION+' · All data saved locally on this device only.</div>'
    +'</div>';
  el.innerHTML=h; }


/* ===== LEXILE / READING LEVEL ===== */
const LEXILE_KEY='mmLexile'; /* 'simplified' | 'standard' | 'enriched' */
function getLexile(){ try{return localStorage.getItem(LEXILE_KEY)||'standard';}catch(e){return 'standard';} }
function setLexile(level){
  try{localStorage.setItem(LEXILE_KEY,level);}catch(e){}
  document.querySelectorAll('.lexile-bar button').forEach(function(b){
    b.classList.toggle('active', b.dataset.level===level);
  });
  /* Re-render the open lesson panel if it's showing */
  if(openPanelId==='lessons'||openPanelId==='doc') try{loadLesson(currentIndex);}catch(e){}
  infoToast('Reading level: '+level.charAt(0).toUpperCase()+level.slice(1),2000);
}
function lexileBar(){
  const cur=getLexile(); const levels=[['simplified','Simplified'],['standard','Standard'],['enriched','Enriched']];
  return '<div class="lexile-bar"><span class="lexile-label">Reading level:</span>'
    +levels.map(function(lv){ return '<button data-level="'+lv[0]+'" class="'+(cur===lv[0]?'active':'')+'" onclick="setLexile(this.dataset.level)" >'+lv[1]+'</button>'; }).join('')
    +'</div>';
}
function applyLexile(text){
  if(!text)return text;
  const level=getLexile();
  if(level==='simplified'){
    /* shorten sentences: replace semicolons and em-dashes with periods */
    return text.replace(/[;—]/g,'.').replace(/\s+/g,' ');
  }
  if(level==='enriched'){
    /* add context words around key terms (lightweight enrichment) */
    return text.replace(/\b(earn|income)\b/gi,'$1 (money you receive for work)')
               .replace(/\b(budget)\b/gi,'$1 (a plan for your money)')
               .replace(/\b(interest)\b/gi,'$1 (extra money paid for using money)')
               .replace(/\b(inflation)\b/gi,'$1 (when prices rise over time)');
  }
  return text; /* standard: unchanged */
}

/* ===== AUTOSAVE TOAST ===== */
/* showSaveToast is called by the saveStore override defined near loadStore/saveStore above */
let _toastTimer=null;
function showSaveToast(msg){
  const el=document.getElementById('autosave-toast');
  if(!el)return;
  el.textContent=msg||'✓ Progress saved';
  el.classList.add('show');
  if(_toastTimer)clearTimeout(_toastTimer);
  _toastTimer=setTimeout(function(){el.classList.remove('show');},2200);
}

/* Autosave heartbeat — touches lastActive every 30 s for THIS tab's active student */
setInterval(function(){
  try{
    const s=loadStore();
    const aid=_activeId();
    if(aid&&s.list[aid]){     /* Fix #6: guard — only runs with an active student */
      s.list[aid].lastActive=todayStr();
      localStorage.setItem(SKEY,JSON.stringify(s));
    }
  }catch(e){}
},30000);

/* ===== IN-APP MODAL & INFO TOAST (replace window.alert / window.confirm) ===== */
let _infoToastTimer=null;
function infoToast(msg, durationMs){
  const el=document.getElementById('info-toast');
  if(!el){ alert(msg); return; }
  el.textContent=msg;
  el.classList.add('show');
  if(_infoToastTimer)clearTimeout(_infoToastTimer);
  _infoToastTimer=setTimeout(function(){ el.classList.remove('show'); }, durationMs||3000);
}

let _modalResolve=null;
let _modalQueue=[];
let _modalBusy=false;

function _runNextModal(){
  if(_modalBusy||!_modalQueue.length)return;
  _modalBusy=true;
  const task=_modalQueue.shift();
  task();
}
function _modalDone(){
  document.getElementById('mm-modal-backdrop').classList.remove('open');
  _modalBusy=false;
  setTimeout(_runNextModal,180);
}

function _openModal(icon,title,body,buttons){
  return new Promise(function(res){
    _modalQueue.push(function(){
      _modalResolve=res;
      document.getElementById('mm-modal-icon').textContent=icon||'';
      document.getElementById('mm-modal-title').textContent=title||'';
      document.getElementById('mm-modal-body').textContent=body||'';
      const btnsEl=document.getElementById('mm-modal-btns');
      btnsEl.innerHTML='';
      (buttons||[]).forEach(function(b){
        const btn=document.createElement('button');
        btn.textContent=b.label;
        btn.className='btn-calc'+(b.ghost?' ghost':'');
        if(b.danger)btn.style.background='#a33';
        btn.onclick=function(){ _closeModal(b.value); };
        btnsEl.appendChild(btn);
      });
      document.getElementById('mm-modal-backdrop').classList.add('open');
      setTimeout(function(){ const f=btnsEl.querySelector('button'); if(f)f.focus(); },60);
    });
    _runNextModal();
  });
}
function _closeModal(value){
  if(_modalResolve){ const r=_modalResolve; _modalResolve=null; _modalDone(); r(value); }
}
document.getElementById('mm-modal-backdrop').addEventListener('click',function(e){
  if(e.target===this)_closeModal(false);
});
document.addEventListener('keydown',function(e){
  if(e.key==='Escape'&&document.getElementById('mm-modal-backdrop').classList.contains('open'))_closeModal(false);
});

function mmInput(title,placeholder,opts){
  opts=opts||{};
  return new Promise(function(resolve){
    _modalQueue.push(function(){
      document.getElementById('mm-modal-icon').textContent=opts.icon||'🔐';
      document.getElementById('mm-modal-title').textContent=title||'';
      const bodyEl=document.getElementById('mm-modal-body');
      bodyEl.innerHTML='';
      const wrap=document.createElement('div');
      wrap.style.cssText='margin-top:4px;display:flex;flex-direction:column;gap:10px;';
      if(opts.subtext){
        const sub=document.createElement('p');
        sub.style.cssText='font-size:13px;color:var(--ink-mid);font-family:system-ui,sans-serif;margin:0 0 4px;line-height:1.5;text-align:left;';
        sub.textContent=opts.subtext;
        wrap.appendChild(sub);
      }
      const inp=document.createElement('input');
      inp.type=opts.password?'password':'text';
      inp.placeholder=placeholder||'';
      inp.autocomplete=opts.password?'current-password':'off';
      inp.autocorrect='off'; inp.autocapitalize='off'; inp.spellcheck=false;
      inp.style.cssText='width:100%;box-sizing:border-box;padding:11px 14px;border-radius:10px;'
        +'border:1.5px solid rgba(140,90,30,0.3);background:rgba(255,252,242,0.9);'
        +'font-size:15px;font-family:system-ui,sans-serif;color:var(--ink);outline:none;';
      inp.addEventListener('focus',function(){ this.style.borderColor='var(--gold)'; });
      inp.addEventListener('blur',function(){ this.style.borderColor='rgba(140,90,30,0.3)'; });
      wrap.appendChild(inp);
      bodyEl.appendChild(wrap);
      const btnsEl=document.getElementById('mm-modal-btns');
      btnsEl.innerHTML='';
      function dismiss(val){
        inp.removeEventListener('keydown',onKey);
        _modalResolve=null;
        _modalDone();
        resolve(val);
      }
      function onKey(e){
        if(e.key==='Enter'){e.preventDefault();dismiss(inp.value);}
        if(e.key==='Escape'){e.preventDefault();dismiss(null);}
      }
      inp.addEventListener('keydown',onKey);
      const cancelBtn=document.createElement('button');
      cancelBtn.textContent='Cancel'; cancelBtn.className='btn-calc ghost';
      cancelBtn.onclick=function(){ dismiss(null); };
      const okBtn=document.createElement('button');
      okBtn.textContent=opts.okLabel||'OK'; okBtn.className='btn-calc';
      okBtn.onclick=function(){ dismiss(inp.value); };
      btnsEl.appendChild(cancelBtn);
      btnsEl.appendChild(okBtn);
      _modalResolve=function(){ dismiss(null); };
      document.getElementById('mm-modal-backdrop').classList.add('open');
      setTimeout(function(){ inp.focus(); },80);
    });
    _runNextModal();
  });
}

function mmAlert(msg,icon){ return _openModal(icon||'ℹ️','',msg,[{label:'OK',value:true}]); }
function mmConfirm(title,body,confirmLabel,icon){
  return _openModal(icon||'⚠️',title,body,[
    {label:'Cancel',ghost:true,value:false},
    {label:confirmLabel||'Confirm',danger:true,value:true}
  ]);
}

/* ===== EXCEL / XLSX EXPORT ===== */
/* Builds a minimal XLSX file using only the Open XML spec — no library needed.
   A workbook with one sheet is generated as a base64-encoded blob and downloaded. */
function exportGradebookXLSX(){
  const s=loadStore(); const ids=Object.keys(s.list);
  if(!ids.length){ mmAlert('No students to export.','⚠️'); return; }
  /* Build rows identical to CSV export */
  const header=['Student','Teacher','School','Profile grade','Type','Grade','Item','Best score (%)','Lessons viewed','Worksheets attempted'];
  const rows=[header];
  ids.forEach(function(id){
    const st=s.list[id]; const prog=st.prog||{};
    const scoreKeys=Object.keys(prog).filter(function(k){return k.indexOf('view|')!==0&&k.indexOf('ws|')!==0;});
    const viewCount=Object.keys(prog).filter(function(k){return k.indexOf('view|')===0;}).length;
    const wsCount=Object.keys(prog).filter(function(k){return k.indexOf('ws|')===0;}).length;
    const school=getSchoolName()||'';
    if(!scoreKeys.length){ rows.push([st.name,st.teacher||'',school,st.grade||'','','','No scores yet','',viewCount,wsCount]); return; }
    scoreKeys.sort().forEach(function(k){
      const p=k.split('|'); const kind=(p[0]==='test')?'Checkpoint':'Lesson quiz';
      const item=(p[0]==='test')?('Unit '+String(p[2]).replace('u','')):('Week '+p[2]);
      rows.push([st.name,st.teacher||'',school,st.grade||'',kind,p[1],item,String(prog[k]),viewCount,wsCount]);
    });
  });
  /* Build XLSX XML */
  function xmlEscape(v){ return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  const sharedStrings=[]; const ssMap={};
  function si(v){ const sv=String(v==null?'':v); if(ssMap[sv]==null){ssMap[sv]=sharedStrings.length;sharedStrings.push(sv);} return ssMap[sv]; }
  const sheetRows=rows.map(function(row,ri){
    const cells=row.map(function(val,ci){
      const col=String.fromCharCode(65+ci);
      const ref=col+(ri+1);
      const num=(ri>0&&typeof val==='string'&&/^\d+(\.\d+)?$/.test(val.trim()));
      if(num) return '<c r="'+ref+'"><v>'+xmlEscape(val)+'</v></c>';
      return '<c r="'+ref+'" t="s"><v>'+si(val)+'</v></c>';
    });
    return '<row r="'+(ri+1)+'">'+cells.join('')+'</row>';
  }).join('');
  const sheetXML='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    +'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
    +'<sheetData>'+sheetRows+'</sheetData></worksheet>';
  const ssXML='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    +'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="'+sharedStrings.length+'" uniqueCount="'+sharedStrings.length+'">'
    +sharedStrings.map(function(s2){return '<si><t xml:space="preserve">'+xmlEscape(s2)+'</t></si>';}).join('')+'</sst>';
  const wbXML='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    +'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    +'<sheets><sheet name="Gradebook" sheetId="1" r:id="rId1"/></sheets></workbook>';
  const relsXML='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    +'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    +'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
    +'<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
    +'</Relationships>';
  const appRels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    +'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    +'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
    +'</Relationships>';
  const ct='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    +'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    +'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    +'<Default Extension="xml" ContentType="application/xml"/>'
    +'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    +'<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
    +'<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
    +'</Types>';
  /* Minimal ZIP builder */
  function str2ab(str){ const buf=new Uint8Array(str.length); for(let i=0;i<str.length;i++)buf[i]=str.charCodeAt(i)&0xff; return buf; }
  function dosDate(){ const d=new Date(); return ((d.getFullYear()-1980)<<25)|((d.getMonth()+1)<<21)|(d.getDate()<<16)|(d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1); }
  function crc32(buf){ let c=0xffffffff; for(let i=0;i<buf.length;i++){c^=buf[i];for(let j=0;j<8;j++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);} return (c^0xffffffff)>>>0; }
  function u32(n){ return [n&0xff,(n>>8)&0xff,(n>>16)&0xff,(n>>24)&0xff]; }
  function u16(n){ return [n&0xff,(n>>8)&0xff]; }
  const files=[
    ['[Content_Types].xml',ct],
    ['_rels/.rels',appRels],
    ['xl/workbook.xml',wbXML],
    ['xl/_rels/workbook.xml.rels',relsXML],
    ['xl/worksheets/sheet1.xml',sheetXML],
    ['xl/sharedStrings.xml',ssXML],
  ];
  const localHeaders=[]; let offset=0; const parts=[];
  files.forEach(function(f){
    const name=str2ab(f[0]); const data=str2ab(f[1]); const crc=crc32(data); const dd=dosDate();
    const lh=[0x50,0x4b,0x03,0x04,20,0,0,0,0,0].concat(u16(dd&0xffff)).concat(u16(dd>>16))
      .concat(u32(crc)).concat(u32(data.length)).concat(u32(data.length))
      .concat(u16(name.length)).concat([0,0]);
    localHeaders.push({name:f[0],crc:crc,size:data.length,offset:offset,nameLen:name.length});
    const chunk=new Uint8Array(lh.length+name.length+data.length);
    chunk.set(lh,0); chunk.set(name,lh.length); chunk.set(data,lh.length+name.length);
    parts.push(chunk); offset+=chunk.length;
  });
  const cdOffset=offset;
  localHeaders.forEach(function(lh2){
    const name=str2ab(lh2.name); const dd=dosDate();
    const cd=[0x50,0x4b,0x01,0x02,20,0,20,0,0,0,0,0].concat(u16(dd&0xffff)).concat(u16(dd>>16))
      .concat(u32(lh2.crc)).concat(u32(lh2.size)).concat(u32(lh2.size))
      .concat(u16(lh2.nameLen)).concat([0,0,0,0,0,0,0,0,0,0,0,0]).concat(u32(lh2.offset));
    const chunk=new Uint8Array(cd.length+name.length);
    chunk.set(cd,0); chunk.set(name,cd.length);
    parts.push(chunk); offset+=chunk.length;
  });
  const eocd=[0x50,0x4b,0x05,0x06,0,0,0,0]
    .concat(u16(files.length)).concat(u16(files.length))
    .concat(u32(offset-cdOffset)).concat(u32(cdOffset)).concat([0,0]);
  parts.push(new Uint8Array(eocd));
  const total=parts.reduce(function(a,b){return a+b.length;},0);
  const zip=new Uint8Array(total); let pos=0;
  parts.forEach(function(p){zip.set(p,pos);pos+=p.length;});
  const blob=new Blob([zip],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url; a.download='MoneyMatters_Gradebook_'+new Date().toISOString().slice(0,10)+'.xlsx';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(function(){URL.revokeObjectURL(url);},10000);
  infoToast('✓ Gradebook downloaded as Excel (.xlsx)',3000);
}

/* ===== LIVE LINKS (Cee & Math) ===== */
const LIVE_LINKS={
  cee:{
    name:'CEE',
    url:'https://www.councilforeconed.org/policy-advocacy/k-12-standards/',
    desc:'CEE K–12 National Standards for Teaching Economics and Personal Finance'
  },
  math:{
    name:'Math',
    url:'https://www.khanacademy.org/math/cc-sixth-grade-math/cc-6th-factors-and-multiples',
    desc:'Khan Academy — math skills aligned to Money Matters'
  }
};
function openLiveLink(key){
  const lnk=LIVE_LINKS[key]; if(!lnk)return;
  const w=window.open(lnk.url,'_blank','noopener,noreferrer');
  if(!w) mmAlert('Pop-ups are blocked. Allow pop-ups for this page to open '+sanitise(lnk.name)+'.','⚠️');
}

/* ===== GAME TRACKING + DIFFICULTY ===== */
const MM_GAME_STATS_KEY='mmGameStats_v2';
function mmGameStats(){ try{return JSON.parse(localStorage.getItem(MM_GAME_STATS_KEY)||'{}');}catch(e){return {};} }
function mmGameStudentId(){ try{return getTabActive()||loadStore().active||'guest';}catch(e){return 'guest';} }
function mmRecordGame(game,difficulty,correct,attempts){
  try{
    const all=mmGameStats(), sid=mmGameStudentId();
    if(!all[sid])all[sid]={};
    if(!all[sid][game])all[sid][game]={played:0,correct:0,attempts:0,best:0,byDifficulty:{}};
    const x=all[sid][game]; x.played++; x.correct+=correct; x.attempts+=attempts; x.best=Math.max(x.best,correct);
    if(!x.byDifficulty[difficulty])x.byDifficulty[difficulty]={played:0,correct:0};
    x.byDifficulty[difficulty].played++; x.byDifficulty[difficulty].correct+=correct;
    localStorage.setItem(MM_GAME_STATS_KEY,JSON.stringify(all)); mmGameBadgeCheck(game,correct,attempts);
  }catch(e){}
}
function mmGameDifficulty(defaultLevel){
  const g=currentGrade;
  if(g==='K'||g==='1')return 'easy';
  if(g==='2'||g==='3')return 'practice';
  return defaultLevel||'challenge';
}
function mmDiffLabel(d){return d==='easy'?'Easy':d==='practice'?'Practice':'Challenge';}
const MM_ACH_KEY='mmAchievements_v1';
function mmAchievements(){try{return JSON.parse(localStorage.getItem(MM_ACH_KEY)||'{}');}catch(e){return {};}}
function mmAwardAchievement(id,title,desc){try{var a=mmAchievements();if(a[id])return false;a[id]={title:title,desc:desc,date:new Date().toLocaleDateString()};localStorage.setItem(MM_ACH_KEY,JSON.stringify(a));return true;}catch(e){return false;}}
function mmGameAccuracy(game){try{var a=mmGameStats(),sid=mmGameStudentId(),x=a[sid]&&a[sid][game];return x&&x.attempts?x.correct/x.attempts:0;}catch(e){return 0;}}
function mmAdaptiveDifficulty(game,defaultLevel){var a=mmGameAccuracy(game);if(!a)return defaultLevel||'practice';if(a>=.85)return 'challenge';if(a<.5)return 'easy';return 'practice';}
function mmShowReflection(game,prompt){var el=document.getElementById('mm-game-reflection');if(!el)return;var safeGame=encodeURIComponent(game||'Game');el.innerHTML='<div class="card" style="margin-top:12px;border-left:4px solid var(--gold)"><div class="card-title">💭 Think about it</div><div class="card-body">'+esc(prompt||'What would you do differently next time?')+'</div><textarea id="mm-reflect-text" maxlength="300" class="quiz-input" style="width:100%;min-height:70px;margin-top:8px" placeholder="Type a short reflection..."></textarea><div class="meta-pills" style="margin-top:8px"><button class="btn-calc green" onclick="mmSaveReflection(decodeURIComponent(\''+safeGame+'\'))">Save reflection</button></div></div>';}
var _mmReflectionContinue=null;
function mmShowMistakeReflection(game,prompt,continueFn){
  var el=document.getElementById('mm-game-reflection'); if(!el)return;
  _mmReflectionContinue=continueFn||null;
  var safeGame=encodeURIComponent(game||'Game');
  el.innerHTML='<div class="card mm-reflection-alert" style="margin-top:12px"><div class="card-title">💭 Pause and reflect</div><div class="card-body"><b>Three incorrect attempts.</b> Take a moment to think about your strategy before trying again.<br><span style="font-size:12px;color:var(--ink-light)">'+esc(prompt||'What did you try? What could you check or do differently next time?')+'</span></div><textarea id="mm-reflect-text" maxlength="300" class="quiz-input" style="width:100%;min-height:76px;margin-top:8px" placeholder="Write one thing you will try differently..."></textarea><div class="meta-pills" style="margin-top:8px"><button class="btn-calc green" onclick="mmSaveReflectionAndContinue(decodeURIComponent(\''+safeGame+'\'))">Save & Continue</button><button class="btn-calc ghost" onclick="mmContinueGameReflection()">Continue without saving</button></div></div>';
}
function mmSaveReflectionAndContinue(game){mmSaveReflection(game);setTimeout(mmContinueGameReflection,450);}
function mmContinueGameReflection(){var fn=_mmReflectionContinue;_mmReflectionContinue=null;var el=document.getElementById('mm-game-reflection');if(el)el.innerHTML='';if(typeof fn==='function'){try{fn();}catch(e){console.warn('Reflection continue failed',e);}}}
function mmGameWrong(game,prompt,continueFn){try{window._mmMistakes=window._mmMistakes||{};var n=(window._mmMistakes[game]||0)+1;window._mmMistakes[game]=n;if(n>=3){window._mmMistakes[game]=0;mmShowMistakeReflection(game,prompt,continueFn);return true;}}catch(e){console.warn('Game reflection tracker failed',e);}return false;}
function mmResetMistakes(game){try{window._mmMistakes=window._mmMistakes||{};window._mmMistakes[game]=0;}catch(e){}}
function mmSaveReflection(game){try{var t=document.getElementById('mm-reflect-text');var key='mmReflection_v1';var a=JSON.parse(localStorage.getItem(key)||'{}');var sid=mmGameStudentId();if(!a[sid])a[sid]={};a[sid][game]={text:(t&&t.value||'').trim(),date:new Date().toISOString()};localStorage.setItem(key,JSON.stringify(a));}catch(e){}var el=document.getElementById('mm-game-reflection');if(el)el.innerHTML='<div class="who" style="color:var(--green);text-align:center">✓ Reflection saved.</div>';}
function renderAchievements(){var a=mmAchievements(),keys=Object.keys(a);var h='<div class="section-head" style="margin-top:18px">🏆 Achievements</div><div class="card"><div class="card-body">Earn badges by practicing skills. Achievements are saved on this device.</div><div class="meta-pills" style="margin-top:10px">';if(!keys.length)h+='<span class="who">No badges yet. Start a game!</span>';keys.forEach(function(k){h+='<span class="btn-calc" title="'+esc(a[k].desc)+'">🏆 '+esc(a[k].title)+'</span>';});h+='</div></div>';return h;}
function mmGameBadgeCheck(game,correct,attempts){try{var a=mmGameStats(),sid=mmGameStudentId(),x=a[sid]&&a[sid][game];if(!x)return;if((x.played||0)>=1)mmAwardAchievement('first-'+game.toLowerCase().replace(/\s+/g,'-'),'First '+game,'Completed '+game+'.');if((x.played||0)>=5)mmAwardAchievement('five-'+game.toLowerCase().replace(/\s+/g,'-'),'5× '+game,'Completed '+game+' five times.');if((x.attempts||0)>=10&&x.correct===x.attempts)mmAwardAchievement('perfect-'+game.toLowerCase().replace(/\s+/g,'-'),'Perfect '+game,'Answered every recorded attempt correctly.');}catch(e){}}

function mmDiffSelect(id,val){return '<label style="font-size:12px;font-weight:700">Difficulty <select id="'+id+'" class="gloss-search" style="margin:0 0 0 6px;max-width:130px" onchange="'+val+'=this.value"><option value="easy">Easy</option><option value="practice">Practice</option><option value="challenge">Challenge</option></select></label>';}
function renderGameReports(){
  const el=document.getElementById('teacherBody'); if(!el)return;
  const all=mmGameStats(), store=loadStore(), ids=Object.keys(store.list||{});
  let h='<div class="section-head">🎮 Game Performance</div><div class="who">Game results are saved locally on this device and grouped by student.</div>';
  if(!ids.length){h+='<div class="fact"><div class="fact-icon">🎮</div><div class="fact-text">No student profiles yet.</div></div>';el.innerHTML=h;return;}
  ids.forEach(function(id){const st=store.list[id], rows=all[id]||{}; const names=Object.keys(rows); if(!names.length)return;
    let totalP=0,totalC=0,totalA=0;
    names.forEach(function(k){totalP+=rows[k].played||0;totalC+=rows[k].correct||0;totalA+=rows[k].attempts||0;});
    const accuracy=totalA?Math.round(totalC/totalA*100):0;
    h+='<div class="unit-card"><div class="unit-head"><div class="unit-title">👤 '+esc(st.name)+' · '+esc(GRADE_LABEL[st.grade||'K']||st.grade||'K')+'</div></div>';
    h+='<div class="card-body">Games played: <b>'+totalP+'</b> · Correct answers: <b>'+totalC+'</b> · Attempts: <b>'+totalA+'</b> · Accuracy: <b>'+accuracy+'%</b></div>';
    h+='<div style="padding:0 16px 14px"><table style="width:100%;font-size:12px;border-collapse:collapse"><tr><th style="text-align:left">Game</th><th>Played</th><th>Accuracy</th><th>Best</th></tr>';
    names.forEach(function(k){const r=rows[k],a=r.attempts?Math.round(r.correct/r.attempts*100):0;h+='<tr><td style="padding:5px 0">'+esc(k)+'</td><td style="text-align:center">'+r.played+'</td><td style="text-align:center">'+a+'%</td><td style="text-align:center">'+r.best+'</td></tr>';});
    h+='</table></div></div>';
  });
  if(h.indexOf('unit-card')<0)h+='<div class="fact"><div class="fact-icon">📊</div><div class="fact-text">No game activity has been recorded yet.</div></div>';
  h+='<div class="meta-pills"><button class="btn-calc ghost" onclick="renderTeacher()">← Back to Teacher</button></div>';
  el.innerHTML=h;
}


function renderGameQuestionReviewTeacher(){var el=document.getElementById('teacherBody');if(!el)return;var gb=document.getElementById('gamesBody');if(gb)gb.id='teacherBody';renderGameQuestionReview();}
function renderGameQuestionReview(){var el=document.getElementById('gamesBody')||document.getElementById('teacherBody');if(!el)return;var rows=[['Coin Counter','Count mixed coins and identify the total.','Coin values; counting; place value.','K–3','Example: 25¢ + 10¢ + 5¢ = 40¢.'],['Make Change','Price and payment are generated together; student builds exact change.','Subtraction; counting up; denomination selection.','1–4','Example: $5.00 paid for $3.75 = $1.25 change.'],['Smart Shopper','Choose multiple products and quantities, compare needs/wants, pay, and make change.','Multiplication; budgeting; comparison shopping; change.','K–8','Example: 2 × $3 + 1 × $4 = $10 before payment.'],['Budget Blitz','Allocate income across needs, wants, other spending, and savings.','Percentages; needs vs. wants; saving; opportunity cost.','3–8','Sample target: total 100% with savings ≥20%.'],['Interest Racer','Choose a rate and observe compound growth versus inflation.','Compound growth; inflation; long-term tradeoffs.','5–8','Teacher formula: ending balance = starting balance × (1 + rate)^years, adjusted by game events.'],['Market Trader','Buy, sell, hold, or wait while prices and events change.','Risk; diversification; price movement; decision-making.','6–8','No single correct trade. Teacher reviews strategy and final net worth.'],['Tax Time','Calculate taxable income, tax owed, and refund or amount due.','Subtraction; percentages; withholding.','7–8','Example: $42,000 − $13,850 = $28,150; at 12% = $3,378 tax; $5,200 withheld gives $1,822 refund.'],['Money Life Mission','Make connected decisions and reflect on consequences.','Needs/wants; saving; opportunity cost; unexpected expenses.','K–8','Answers depend on the mission scenario; teacher sees the decision rationale.']];var h='<div class="section-head">🧠 Game Question & Skill Review</div><div class="who">Teacher-only review of what each game asks students to practice. Generated scenarios vary, so this page describes the question model and skill target rather than exposing a live answer.</div>';rows.forEach(function(r){h+='<div class="unit-card"><div class="unit-head"><div class="unit-title">'+r[0]+'</div><span style="font-size:11px;color:var(--ink-light)">'+r[3]+'</span></div><div class="card-body"><b>Question model:</b> '+r[1]+'<br><b>Skills:</b> '+r[2]+'<br><b>Teacher example:</b> '+r[4]+'</div></div>';});h+='<div class="meta-pills"><button class="btn-calc ghost" onclick="renderCurriculumQuestionAudit()">🔎 Full Question & Answer Audit</button><button class="btn-calc ghost" onclick="renderGames()">← Back to Games</button></div>';el.innerHTML=h;}

/* ===== TEACHER SYSTEM CHECK ===== */
function openSystemCheck(){var el=document.getElementById('teacherBody');if(!el)return;var checks=[['Browser storage',function(){localStorage.setItem('__mm_test','1');var ok=localStorage.getItem('__mm_test')==='1';localStorage.removeItem('__mm_test');return ok;}],['Game runner',function(){return typeof _runMiniGame==='function';}],['Game modules',function(){return [_mmInitCoin,_mmInitChange,_mmInitBudget,_mmInitInterest,_mmInitMarket,_mmInitTax,_mmInitShop,_mmInitLife].every(function(x){return typeof x==='function';});}],['Responsive viewport',function(){return window.innerWidth>0&&window.innerHeight>0;}],['Touch support (optional)',function(){return ('ontouchstart' in window)||navigator.maxTouchPoints>0||window.matchMedia&&window.matchMedia('(pointer:fine)').matches;}],['Read Aloud',function(){return 'speechSynthesis' in window;}],['Offline awareness',function(){return 'onLine' in navigator;}],['Backup / Restore',function(){return typeof backupData==='function'&&typeof restoreData==='function';}],['Game reporting',function(){return typeof mmRecordGame==='function'&&typeof renderGameReports==='function';}],['Achievements',function(){return typeof mmAwardAchievement==='function'&&typeof renderAchievements==='function';}],['Money Life',function(){return typeof _mmInitLife==='function'&&typeof _lifeGameHTML==='function';}],['Backup includes game data',function(){return typeof backupData==='function'&&typeof restoreData==='function';}],['Quiz bank integrity',function(){var qs=lessonQuizQuestions(),bad=0;(qs||[]).forEach(function(q){if(!q||!q.q||!Array.isArray(q.options)||q.options.length<2||!Number.isInteger(q.answer)||q.answer<0||q.answer>=q.options.length)bad++;});return bad===0;}],['Print engine',function(){return typeof renderDoc==='function'&&typeof downloadDoc==='function'&&typeof window.print==='function';}],['Game template readiness',function(){return [_coinGameHTML,_changeGameHTML,_budgetGameHTML,_interestGameHTML,_marketGameHTML,_taxGameHTML,_shopGameHTML,_lifeGameHTML].every(function(x){return typeof x==='function'&&String(x).length>100;});}]];var rows=checks.map(function(c){var ok=false,msg='';try{ok=!!c[1]();}catch(e){msg=e.message||String(e);}return '<div class="unit-card" style="margin-bottom:8px"><div class="unit-head"><div class="unit-title">'+(ok?'✓':'⚠️')+' '+esc(c[0])+'</div><span style="font-size:12px;color:'+(ok?'var(--green)':'#a33')+'">'+(ok?'Working':'Needs attention')+'</span></div>'+(msg?'<div class="card-body">'+esc(msg)+'</div>':'')+'</div>';}).join('');el.innerHTML='<div class="section-head">🛠️ System Check</div><div class="who">Teacher-only diagnostic for this classroom device.</div>'+rows+'<div class="meta-pills"><button class="btn-calc green" onclick="openSystemCheck()">↻ Run Again</button><button class="btn-calc ghost" onclick="renderTeacher()">← Back to Teacher</button></div>';}

/* ===== V47 CURRICULUM QUESTION AUDIT =====
   Automated integrity audit for the English lesson quiz bank. It checks every question
   for valid answer indexes, duplicate options, empty text, duplicate question wording,
   and source answer-position concentration. It does not silently change answers.
*/
function renderCurriculumQuestionAudit(){
  var el=document.getElementById('gamesBody')||document.getElementById('teacherBody');if(!el)return;
  var rows=[],total=0,bad=0,dupQ=0,dupO=0,shortQuizzes=0,answerPos={0:0,1:0,2:0,3:0,other:0},seen={};
  try{
    Object.keys(LESSON_QUIZ||{}).forEach(function(g){(LESSON_QUIZ[g]||[]).forEach(function(w){var qs=w.questions||[];if(qs.length<4)shortQuizzes++;qs.forEach(function(q,i){total++;var ok=!!q.q&&Array.isArray(q.options)&&q.options.length>=4&&Number.isInteger(q.answer)&&q.answer>=0&&q.answer<q.options.length&&q.explain; if(!ok){bad++;rows.push('<tr><td>'+esc(g)+'</td><td>'+w.week+'</td><td>Integrity</td><td>'+esc(q.q||'(blank)')+'</td></tr>');}var opts=(q.options||[]).map(function(x){return String(x).trim().toLowerCase();});if(new Set(opts).size!==opts.length){dupO++;rows.push('<tr><td>'+esc(g)+'</td><td>'+w.week+'</td><td>Duplicate options</td><td>'+esc(q.q)+'</td></tr>');}var k=String(q.q||'').trim().toLowerCase();if(k&&seen[k]){dupQ++;if(dupQ<=40)rows.push('<tr><td>'+esc(g)+'</td><td>'+w.week+'</td><td>Repeated wording</td><td>'+esc(q.q)+'</td></tr>');}else if(k)seen[k]=g+':W'+w.week;var p=(q.answer in answerPos)?q.answer:'other';answerPos[p]++;});});});
  }catch(e){rows.push('<tr><td colspan="4">Audit error: '+esc(String(e))+'</td></tr>');}
  var concentration=Math.max(answerPos[0],answerPos[1],answerPos[2],answerPos[3])/Math.max(1,total);
  var quality=(bad===0&&dupO===0&&shortQuizzes===0&&concentration<0.8)?'PASS':'REVIEW';
  var h='<div class="section-head">🔎 Curriculum Question & Answer Audit</div><div class="who">Teacher-only automated audit of the English lesson quiz bank. Source answer positions are checked before the app shuffles choices for students. Repeated concepts can be valid reinforcement, so repeated wording is flagged for teacher review rather than automatically deleted.</div>';
  h+='<div class="two-col"><div class="card"><div class="card-title">Integrity</div><div class="card-body"><b>'+total+'</b> questions checked<br><b>'+bad+'</b> structural answer issues<br><b>'+dupO+'</b> duplicate-option issues<br><b>'+shortQuizzes+'</b> quizzes below 4 questions<br><b>'+dupQ+'</b> repeated question wordings<br><b>'+Math.round(concentration*100)+'%</b> highest source answer-position concentration<br><div style="margin-top:8px;font-weight:800">Overall automated status: '+quality+'</div></div></div>';
  h+='<div class="card"><div class="card-title">Answer-position distribution</div><div class="card-body">A: <b>'+answerPos[0]+'</b><br>B: <b>'+answerPos[1]+'</b><br>C: <b>'+answerPos[2]+'</b><br>D: <b>'+answerPos[3]+'</b><br><small>Student answer choices are shuffled at quiz render, so this source distribution does not determine the students visible answer position.</small></div></div></div>';
  if(rows.length){h+='<div class="section-head" style="margin-top:14px">Items to Review</div><div class="card"><div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr><th style="text-align:left;padding:7px">Grade</th><th style="text-align:left;padding:7px">Week</th><th style="text-align:left;padding:7px">Flag</th><th style="text-align:left;padding:7px">Question</th></tr></thead><tbody>'+rows.slice(0,60).join('')+'</tbody></table></div></div>';}else h+='<div class="card"><div class="card-body">✓ No structural issues were found in the English question bank.</div></div>';
  h+='<div class="meta-pills" style="margin-top:12px"><button class="btn-calc ghost" onclick="renderGames()">← Back to Games</button></div>';el.innerHTML=h;
}

/* ===== MINI GAMES ===== */
const MINI_GAMES=[
  {
    id:'budget',
    title:'Budget Blitz',
    icon:'💰',
    desc:'Allocate $500 across needs, wants, and savings before time runs out.',
    grades:['3','4','5','6','7','8'],
    play:function(){ openGame('budget'); }
  },
  {
    id:'coin',
    title:'Coin Counter',
    icon:'🪙',
    desc:'Count the coins as fast as you can — pennies, nickels, dimes, quarters.',
    grades:['K','1','2','3'],
    play:function(){ openGame('coin'); }
  },
  {
    id:'interest',
    title:'Interest Racer',
    icon:'📈',
    desc:'Watch compound interest grow your savings over time — beat the inflation rate!',
    grades:['5','6','7','8'],
    play:function(){ openGame('interest'); }
  },
  {
    id:'market',
    title:'Market Trader',
    icon:'🏪',
    desc:'Buy low, sell high — navigate a simple stock market and grow your portfolio.',
    grades:['6','7','8'],
    play:function(){ openGame('market'); }
  },
  {
    id:'tax',
    title:'Tax Time',
    icon:'🧾',
    desc:'Fill out a simple tax form correctly to get your refund. Learn what deductions mean.',
    grades:['7','8'],
    play:function(){ openGame('tax'); }
  },
  {
    id:'shop',
    title:'Smart Shopper',
    icon:'🛍️',
    desc:'Choose an item, pay with real coin/bill denominations, calculate your change, and protect your wallet balance.',
    grades:['K','1','2','3','4','5','6','7','8'],
    play:function(){ openGame('shop'); }
  },
  {
    id:'change',
    title:'Make Change',
    icon:'🛒',
    desc:'A customer gives you money — make the correct change before the next customer arrives.',
    grades:['1','2','3','4'],
    play:function(){ openGame('change'); }
  },
  {
    id:'life',
    title:'Money Life Mission',
    icon:'🌟',
    desc:'Make connected money decisions about needs, wants, saving, shopping, surprises, and opportunity cost.',
    grades:['K','1','2','3','4','5','6','7','8'],
    play:function(){ openGame('life'); }
  },
];

function renderGames(){
  window.__mmGamesScroll=window.scrollY||0;
  const el=document.getElementById('gamesBody'); if(!el)return;
  const g=currentGrade, gl=GRADE_LABEL[g]||('Grade '+g), GS=window.MMGameShow;
  const staff=(function(){try{return MM91.auth.roleKey()!=='student';}catch(e){return loadRole()==='teacher';}})();
  let h='<div class="mmg">';
  /* 1. class game show */
  h+='<section class="mmg-hero"><div><div class="mmg-k">Class Game Show · '+esc(gl)+'</div><h2>Money Game Show</h2><p>Game-show rounds built from this grade’s lessons. Play on one shared screen with 1–8 players or teams, or practice alone with the Daily 5.</p></div>'
    +'<div class="mmg-act"><button class="mmg-btn" onclick="MMGameShow.open()">Open the Game Show</button><button class="mmg-btn ghost" onclick="MMGameShow.open(\'daily\')">Play today’s Daily 5</button></div></section>';
  if(GS)h+='<div class="mmg-sec"><h3>Quick start</h3><p>Jumps straight into a round with your saved players or teams.</p></div><div class="mmg-modes">'+GS.modes.map(function(m){return '<button class="mmg-mode" onclick="MMGameShow.open(\''+m.id+'\')" title="'+esc(m.desc)+'"><b>'+esc(m.name)+'</b><span>'+esc(m.tag)+'</span></button>';}).join('')+'</div>';
  /* 2. practice games for this grade */
  const avail=MINI_GAMES.filter(function(gm){return gm.grades.indexOf(g)>-1;});
  const locked=MINI_GAMES.filter(function(gm){return gm.grades.indexOf(g)===-1;});
  h+='<div class="mmg-sec"><h3>Skill practice</h3><p>Solo practice games. Difficulty adapts to the grade, and wrong answers get another try.</p></div>';
  h+=avail.length?'<div class="mmg-grid">'+avail.map(function(gm){return gameCard(gm,false);}).join('')+'</div>':'<p class="mmg-k">No practice games for this grade yet.</p>';
  /* 3. workshops */
  h+='<div class="mmg-ws"><div><b>Running a money camp or workshop?</b><p>Intensive 1- to 5-day workshops for '+esc(gl)+', 2–4 hours a day, with a certificate for every day.</p></div><button class="btn-calc green" onclick="openPanel(\'workshops\')">Open Workshops</button></div>';
  h+=renderAchievements();
  /* 4. reference material, collapsed */
  if(locked.length)h+='<details class="mmg-more"><summary>Practice games for other grades ('+locked.length+')</summary><div class="mmg-grid" style="margin-bottom:12px">'+locked.map(function(gm){return gameCard(gm,true);}).join('')+'</div></details>';
  h+='<details class="mmg-more"><summary>Money reference: U.S. coins and bills</summary><div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;justify-content:center;margin:6px 0 14px">';
  h+='<div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">'+[['25¢','Quarter'],['10¢','Dime'],['5¢','Nickel'],['1¢','Penny']].map(function(x){return '<div style="text-align:center"><div style="width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 35% 30%,#fff8df,#d8c08a 58%,#9c7b32);border:3px solid #8d6b2b;font-weight:900">'+x[0]+'</div><div class="doc-note">'+x[1]+'</div></div>';}).join('')+'</div>';
  h+='<div style="min-width:220px;max-width:360px;padding:18px 24px;border-radius:10px;background:#dcebd8;border:3px solid #4d7b4a;text-align:center;font-weight:900;color:#31552e">ONE DOLLAR<br><span style="font-size:34px">$1</span></div></div></details>';
  h+='<div class="mmg-ws"><div><b>Looking for more?</b><p>The Resource Guide lists free, trusted money-learning sites for teachers, families and students, sorted by grade and topic.</p></div><button class="btn-calc" onclick="openPanel(\'resources\')">Open the Resource Guide</button></div>';
  if(staff)h+='<div class="meta-pills"><button class="btn-calc ghost" onclick="renderCurriculumQuestionAudit()">Question and answer audit</button></div>';
  h+='</div>';
  const frag=document.createRange().createContextualFragment(h);
  el.innerHTML=''; el.appendChild(frag);
}

function gameCard(gm, locked){
  return '<article class="mmg-card"'+(locked?' style="opacity:.7"':'')+'><h4><span aria-hidden="true">'+gm.icon+'</span>'+esc(gm.title)+'</h4><p>'+esc(gm.desc)+'</p>'
    +(locked?'<span class="mmg-k">Grades '+esc(gm.grades.join(', '))+'</span>':'<button class="btn-calc green" onclick="openGame(\''+gm.id+'\')">Play</button>')+'</article>';
}

function backFromGame(){var y=window.__mmGamesScroll||0;var panel=document.getElementById('panel-games');var py=panel?panel.scrollTop:0;renderGames();setTimeout(function(){window.scrollTo(0,y);var p=document.getElementById('panel-games');if(p)p.scrollTop=py;},30);}
function openGame(id){
  window.__mmGamesScroll=window.scrollY||0;
  /* Games run in the game canvas inside the panel */
  const el=document.getElementById('gamesBody'); if(!el)return;
  const GAMES={
    coin:    buildCoinGame,
    change:  buildChangeGame,
    budget:  buildBudgetGame,
    interest:buildInterestGame,
    market:  buildMarketGame,
    tax:     buildTaxGame,
    shop:    buildShopGame,
    life:    buildLifeGame,
  };
  const fn=GAMES[id]; if(!fn){infoToast('Game coming soon!',2000);return;}
  fn(el);
}

/* V39 mini-game runner: real functions, CSP-safe initialization. */
function _runMiniGame(container, gameId){var GAME_HTML={coin:_coinGameHTML,change:_changeGameHTML,budget:_budgetGameHTML,interest:_interestGameHTML,market:_marketGameHTML,tax:_taxGameHTML,shop:_shopGameHTML,life:_lifeGameHTML};var INIT={coin:_mmInitCoin,change:_mmInitChange,budget:_mmInitBudget,interest:_mmInitInterest,market:_mmInitMarket,tax:_mmInitTax,shop:_mmInitShop,life:_mmInitLife};if(!GAME_HTML[gameId]||!INIT[gameId]){infoToast('Game coming soon!',2000);return;}try{var frag=document.createRange().createContextualFragment(GAME_HTML[gameId]());container.innerHTML='';container.appendChild(frag);INIT[gameId]();}catch(err){console.error('Money Matters game initialization failed:',gameId,err);infoToast('Game could not start. Please try again.',3000);}}
function buildCoinGame(c){ _runMiniGame(c,'coin'); }
function buildChangeGame(c){ _runMiniGame(c,'change'); }
function buildBudgetGame(c){ _runMiniGame(c,'budget'); }
function buildInterestGame(c){ _runMiniGame(c,'interest'); }
function buildMarketGame(c){ _runMiniGame(c,'market'); }
function buildTaxGame(c){ _runMiniGame(c,'tax'); }
function buildShopGame(c){ _runMiniGame(c,'shop'); }
function buildLifeGame(c){ _runMiniGame(c,'life'); }

function _mmInitCoin(){
  var COINS=[{v:25,n:'Quarter',mark:'25¢'},{v:10,n:'Dime',mark:'10¢'},{v:5,n:'Nickel',mark:'5¢'},{v:1,n:'Penny',mark:'1¢'}];
  var score=0,attempts=0,locked=false,question=0,diff=mmAdaptiveDifficulty('Coin Counter','practice');
  function money(c){return c<100?c+'¢':'$'+(c/100).toFixed(2);}
  function visual(c){return '<div style="text-align:center;min-width:76px"><div role="img" aria-label="'+c.n+' worth '+c.v+' cents" style="width:66px;height:66px;margin:auto;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 32% 28%,#fffdf1,#d8c08a 58%,#8d6b2b);border:3px solid #8d6b2b;box-shadow:inset 0 0 0 2px rgba(255,255,255,.5),0 3px 8px rgba(0,0,0,.16);font-weight:900;color:#5b451d">'+c.mark+'</div><div style="font-size:10px;color:var(--ink-light);margin-top:4px">'+c.n+'</div></div>';}
  function newQ(){
    mmResetMistakes('Coin Counter');
    if(question>0)diff=mmAdaptiveDifficulty('Coin Counter',diff);locked=false;attempts=0;question++;
    var d=diff==='easy'?2:diff==='challenge'?Math.floor(Math.random()*4)+6:Math.floor(Math.random()*3)+4;
    var pool=diff==='easy'?COINS.slice(0,3):COINS,disp=[];
    for(var i=0;i<d;i++)disp.push(pool[Math.floor(Math.random()*pool.length)]);
    var target=disp.reduce(function(a,c){return a+c.v;},0);
    var choices=[target];
    while(choices.length<4){var delta=(Math.floor(Math.random()*5)+1)*(Math.random()<.5?-1:1);var x=target+delta;if(x>0&&choices.indexOf(x)<0)choices.push(x);}
    choices.sort(function(){return Math.random()-.5;});
    var cs=document.getElementById('cg-score');if(cs)cs.textContent='Score: '+score+' · Question '+question+' · '+mmDiffLabel(diff);
    var cc=document.getElementById('cg-coins');if(cc)cc.innerHTML=disp.map(visual).join('');
    var fb=document.getElementById('cg-feedback');if(fb)fb.textContent='';
    var cd=document.getElementById('cg-choices');if(cd)cd.innerHTML=choices.map(function(x){return '<button class="btn-calc ghost" onclick="_cg_answer('+x+','+target+')">'+money(x)+'</button>';}).join('');
  }
  window._cg_answer=function(ans,target){if(locked)return;attempts++;if(ans===target){locked=true;score++;mmRecordGame('Coin Counter',diff,1,attempts);mmShowReflection('Coin Counter','What helped you count the coins accurately?');var f=document.getElementById('cg-feedback');if(f)f.textContent='✓ Correct! Nice counting.';document.querySelectorAll('#cg-choices button').forEach(function(b){b.disabled=true;});setTimeout(newQ,850);}else{var reflected=mmGameWrong('Coin Counter','Which coin values did you count first? How can you organize the coins so you do not skip one?',function(){var f=document.getElementById('cg-feedback');if(f)f.textContent='Take your time and try the next question.';});var f2=document.getElementById('cg-feedback');if(f2)f2.textContent=reflected?'Pause for a quick reflection before trying again.':'Not quite. Count each coin again and try another choice.';}};
  window._cg_setDiff=function(v){diff=v||'practice';newQ();};window._game_coin_init=newQ;newQ();
}

function _mmInitChange(){
  var score=0,price=0,paid=0,correct=0,selected=[],attempts=0,locked=false,diff=mmAdaptiveDifficulty('Cash Register','practice');
  function money(c){if(!Number.isFinite(c))return '$0.00';return c<100?c+'¢':'$'+(c/100).toFixed(2);}
  function denoms(){return diff==='easy'?[1,5,10,25,100]:diff==='challenge'?[1,5,10,25,50,100,200,500,1000]:[1,5,10,25,50,100,500];}
  function makeable(amount){var vals=denoms(),out=[];for(var i=vals.length-1;i>=0;i--){while(amount>=vals[i]){out.push(vals[i]);amount-=vals[i];}}return amount===0;}
  function newQ(){
    mmResetMistakes('Cash Register');
    diff=mmAdaptiveDifficulty('Cash Register',diff);locked=false;selected=[];attempts=0;
    var payPool=diff==='easy'?[25,50,100]:diff==='challenge'?[500,1000,2000]:[100,200,500];
    for(var guard=0;guard<100;guard++){
      paid=payPool[Math.floor(Math.random()*payPool.length)];
      var min=diff==='easy'?1:diff==='challenge'?25:5;
      price=min+Math.floor(Math.random()*Math.max(1,paid-min));
      correct=paid-price;
      if(correct>0&&makeable(correct))break;
    }
    if(correct<=0||!makeable(correct)){paid=100;price=25;correct=75;}
    var p=document.getElementById('chg-prompt');if(p)p.innerHTML='<div style="font-size:13px">Item price</div><div style="font-size:30px;font-weight:900">'+money(price)+'</div><div style="margin-top:6px">Customer pays <b>'+money(paid)+'</b></div><div style="font-size:12px;color:var(--ink-light);margin-top:4px">Build the exact change. Bills and coins may both be used.</div>';
    render();
  }
  function render(){
    var total=selected.reduce(function(a,b){return a+b;},0),sd=document.getElementById('chg-score');if(sd)sd.textContent='Score: '+score+' · '+mmDiffLabel(diff);
    var md=document.getElementById('chg-money');if(md)md.innerHTML=denoms().map(function(v){return '<button class="btn-calc ghost" '+(locked?'disabled':'')+' onclick="_chg_add('+v+')">'+money(v)+'</button>';}).join('');
    var tr=document.getElementById('chg-tray');if(tr)tr.innerHTML=selected.length?selected.map(function(v,i){return '<button class="btn-calc" '+(locked?'disabled':'')+' onclick="_chg_remove('+i+')">'+money(v)+' ×</button>';}).join(' '):'<div style="font-size:12px;color:var(--ink-light)">Your change goes here.</div>';
    var ct=document.getElementById('chg-total');if(ct)ct.textContent='Change selected: '+money(total);
    var fb=document.getElementById('chg-feedback');if(fb&&!locked&&total>correct)fb.textContent='You selected too much. Clear some money and try again.';
  }
  window._chg_add=function(v){if(locked||!Number.isFinite(v))return;var total=selected.reduce(function(a,b){return a+b;},0);if(total+v<=correct){selected.push(v);render();}};
  window._chg_remove=function(i){if(locked)return;if(i>=0&&i<selected.length)selected.splice(i,1);render();};
  window._chg_clear=function(){if(locked)return;selected=[];var f=document.getElementById('chg-feedback');if(f)f.textContent='';render();};
  window._chg_submit=function(){if(locked)return;var total=selected.reduce(function(a,b){return a+b;},0);if(total===correct){locked=true;score++;mmRecordGame('Cash Register',diff,1,Math.max(1,attempts+1));mmShowReflection('Cash Register','How did you decide which denominations to use for the change?');var f=document.getElementById('chg-feedback');if(f)f.textContent='✓ Correct! Great job making change.';render();setTimeout(newQ,900);}else{attempts++;var reflected=mmGameWrong('Cash Register','What information did you check first: the price, the payment, or the selected denominations?',function(){var f=document.getElementById('chg-feedback');if(f)f.textContent='Review the price and payment, then build the change one denomination at a time.';});var f2=document.getElementById('chg-feedback');if(f2)f2.textContent=reflected?'Pause for a quick reflection before trying again.':'Not quite. Recheck the price, payment, and coins/bills you selected.';}};
  window._chg_setDiff=function(v){diff=v||'practice';newQ();};window._game_change_init=newQ;newQ();
}

function _mmInitBudget(){
  var income=500,score=0,recorded=false;
  var cats=[{name:'Housing',pct:30,color:'#2a6b4a',kind:'need'},{name:'Food',pct:15,color:'#1e6b6b',kind:'need'},{name:'Transport',pct:10,color:'#4a5a8a',kind:'need'},{name:'Fun',pct:15,color:'#8a5a1e',kind:'want'},{name:'Savings',pct:20,color:'#6b1e6b',kind:'save'},{name:'Other',pct:10,color:'#6b6b1e',kind:'other'}];
  function update(){
    var total=cats.reduce(function(a,c){return a+c.pct;},0),save=cats[4].pct,valid=total===100&&save>=20;
    var result=document.getElementById('bdg-result');if(result){result.innerHTML='<div style="height:22px;background:#eee;border-radius:999px;overflow:hidden;position:relative"><div style="height:100%;width:'+Math.min(100,total)+'%;background:var(--green);transition:width .2s"></div></div><div style="margin-top:7px"><b>'+total+'%</b> allocated · <b>'+save+'%</b> saved · $'+Math.round(income*save/100)+' saved</div><div style="margin-top:7px;color:'+(valid?'var(--green)':'#a33')+'">'+(valid?'✓ Budget balanced and savings goal met.':'Aim for exactly 100% and at least 20% savings.')+'</div>'+(valid?'<button class="btn-calc green" style="margin-top:9px" onclick="_bdg_check()">Lock In Budget</button>':'');}
    cats.forEach(function(c,i){var el=document.getElementById('bdg-val-'+i);if(el)el.textContent=c.pct+'% = $'+Math.round(income*c.pct/100);});
    if(!valid)recorded=false;
  }
  window._bdg_reset=function(){mmResetMistakes('Budget Blitz');cats[0].pct=30;cats[1].pct=15;cats[2].pct=10;cats[3].pct=15;cats[4].pct=20;cats[5].pct=10;recorded=false;var sl=document.getElementById('bdg-sliders');if(sl)sl.querySelectorAll('input[type=range]').forEach(function(el,i){el.value=cats[i].pct;});update();};window._bdg_cats=cats;window._bdg_update=update;window._bdg_adjust=function(i,v){cats[i].pct=Math.max(0,Math.min(60,Number(v)||0));recorded=false;update();};window._bdg_check=function(){var total=cats.reduce(function(a,c){return a+c.pct;},0);if(total===100&&cats[4].pct>=20&&!recorded){recorded=true;score++;mmRecordGame('Budget Blitz',mmAdaptiveDifficulty('Budget Blitz','practice'),1,1);mmShowReflection('Budget Blitz','What did you have to give up to protect your savings goal?');var r=document.getElementById('bdg-result');if(r)r.innerHTML+='<div style="margin-top:8px;color:var(--green);font-weight:800">🏆 Budget locked in! Score: '+score+'</div>';}else{var reflected=mmGameWrong('Budget Blitz','Which category is taking too much of your budget? What could you adjust while protecting savings?',function(){update();});var r2=document.getElementById('bdg-result');if(r2&&reflected)r2.innerHTML+='<div style="margin-top:8px;color:#8a5e10;font-weight:800">Pause for reflection, then adjust your budget.</div>';}};
  var sl=document.getElementById('bdg-sliders');if(sl)sl.innerHTML=cats.map(function(c,i){return '<div style="margin-bottom:16px"><div style="display:flex;justify-content:space-between;gap:8px;font-size:13px"><span>'+c.name+' <small>('+c.kind+')</small></span><b id="bdg-val-'+i+'">'+c.pct+'% = $'+Math.round(income*c.pct/100)+'</b></div><input aria-label="'+c.name+' percentage" type="range" min="0" max="60" step="1" value="'+c.pct+'" style="width:100%;accent-color:'+c.color+'" oninput="_bdg_adjust('+i+',this.value)"></div>';}).join('');update();window._game_budget_init=function(){};
}

function _mmInitInterest(){
  var rate=5,year=0,balance=1000,price=1000,running=false,timer=null,events=[],scoreRecorded=false;var host=document.getElementById('ir-chart');
  function render(){if(!host)return;var ahead=balance-price;var pct=Math.max(8,Math.min(92,(balance/Math.max(balance,price))*100));host.innerHTML='<div style="display:grid;gap:8px"><div style="display:flex;justify-content:space-between"><b>Year '+year+'/10</b><span>Rate: <b>'+rate.toFixed(1)+'%</b></span></div><div>💰 Savings: <b>$'+balance.toFixed(0)+'</b></div><div>🛒 Inflation cost: <b>$'+price.toFixed(0)+'</b></div><div style="height:24px;background:#eee;border-radius:999px;overflow:hidden"><div style="height:100%;width:'+pct+'%;background:var(--green);transition:width .35s"></div></div><div style="font-size:12px;color:var(--ink-light)">'+(ahead>=0?'You are ahead by $'+ahead.toFixed(0):'Inflation is ahead by $'+Math.abs(ahead).toFixed(0))+'. '+(events.length?events[events.length-1]:'Choose a rate, then start the race.')+'</div></div>'+(year<10?'<div class="meta-pills" style="justify-content:center;margin-top:10px"><button class="btn-calc green" onclick="_ir_start()">'+(running?'Running…':'▶ '+(year?'Continue':'Start')+' Race')+'</button><button class="btn-calc ghost" onclick="_ir_reset()">↺ Reset</button></div>':'<div class="meta-pills" style="justify-content:center;margin-top:10px"><button class="btn-calc green" onclick="_ir_reset();_ir_start()">Play Again</button></div>');}
  function step(){if(!running)return;if(year>=10){running=false;clearTimeout(timer);mmRecordGame('Interest Racer',mmAdaptiveDifficulty('Interest Racer','practice'),balance>=price?1:0,10);mmShowReflection('Interest Racer','Would you choose the same interest rate again? Why?');render();return;}year++;balance*=1+rate/100;price*=1.03;if(Math.random()<.22){var e=[['Unexpected expense: −$40 from savings.',function(){balance=Math.max(0,balance-40);} ],['Bonus deposit: +$75 to savings.',function(){balance+=75;}],['Prices rise faster this year: inflation +1%.',function(){price*=1.01;}]][Math.floor(Math.random()*3)];e[1]();events.push(e[0]);}render();timer=setTimeout(step,650);}
  function reset(){mmResetMistakes('Interest Racer');running=false;clearTimeout(timer);year=0;balance=1000;price=1000;events=[];scoreRecorded=false;render();}
  window._ir_start=function(){if(running)return;if(year>=10)reset();running=true;step();};window._ir_reset=reset;window._ir_simulate=function(r){rate=Math.max(1,Math.min(15,Number(r)||5));reset();};window._game_interest_init=reset;reset();
}

function _mmInitMarket(){
  var cash=1000,round=1,maxRounds=15,log=[],stocks=[];var base=[{name:'SafeBank',price:50,vol:2,sector:'Banking',div:1},{name:'TechWorks',price:80,vol:10,sector:'Technology',div:0},{name:'GreenGrid',price:35,vol:7,sector:'Energy',div:0},{name:'HealthPlus',price:60,vol:5,sector:'Health',div:1},{name:'RetailCo',price:40,vol:9,sector:'Retail',div:0}];
  function reset(){mmResetMistakes('Market Trader');cash=1000;round=1;log=[];stocks=base.map(function(s){return {name:s.name,price:s.price,vol:s.vol,sector:s.sector,div:s.div,owned:0};});render();}
  function net(){return Math.round(cash+stocks.reduce(function(a,s){return a+s.price*s.owned;},0));}
  function advance(action){log.unshift(action);if(round>=maxRounds){finish();return;}stocks.forEach(function(s){var shock=(Math.random()*2-1)*s.vol;s.price=Math.max(5,Math.round((s.price+shock)*10)/10);if(Math.random()<.15){s.price=Math.max(5,Math.round(s.price*(Math.random()<.5?.9:1.1)*10)/10);}});stocks.forEach(function(s){if(s.owned&&s.div)cash+=s.owned*s.div;});round++;render();}
  function finish(){var n=net();mmRecordGame('Market Trader',mmAdaptiveDifficulty('Market Trader','challenge'),n>=1000?1:0,maxRounds);mmShowReflection('Market Trader','What made you decide to buy, sell, or wait?');var sd=document.getElementById('mkt-stocks');if(sd)sd.innerHTML='<div class="fact"><div class="fact-icon">'+(n>=1000?'🏆':'📚')+'</div><div class="fact-text"><b>15-round market complete</b><br>Final portfolio: $'+n+'. '+(n>=1000?'You grew your starting money.':'Use the replay to test a different strategy.')+'<br><button class="btn-calc green" style="margin-top:10px" onclick="_mkt_init()">Play Again</button></div></div>';}
  function render(){var st=document.getElementById('mkt-status');if(st)st.innerHTML='Round <b>'+round+'/'+maxRounds+'</b> · Cash <b>$'+Math.round(cash)+'</b> · Net worth <b>$'+net()+'</b>';var sd=document.getElementById('mkt-stocks');if(sd)sd.innerHTML=stocks.map(function(s,i){var maxBuy=Math.floor(cash/s.price);return '<div class="unit-card" style="margin-bottom:9px"><div class="unit-head"><div><div class="unit-title">'+s.name+' · $'+s.price.toFixed(1)+'/share</div><div style="font-size:11px;color:var(--ink-light)">'+s.sector+' · Owned: '+s.owned+(s.div?' · dividend $'+s.div:'')+'</div></div><div class="meta-pills"><button class="btn-calc green" onclick="_mkt_buy('+i+',1)" '+(maxBuy<1?'disabled':'')+'>Buy 1</button><button class="btn-calc" onclick="_mkt_buy('+i+',5)" '+(maxBuy<5?'disabled':'')+'>Buy 5</button><button class="btn-calc ghost" onclick="_mkt_sell('+i+',1)" '+(s.owned<1?'disabled':'')+'>Sell 1</button><button class="btn-calc ghost" onclick="_mkt_sell('+i+',5)" '+(s.owned<1?'disabled':'')+'>Sell 5</button></div></div></div>';}).join('')+'<div class="meta-pills" style="justify-content:center;margin-top:10px"><button class="btn-calc ghost" onclick="_mkt_skip()">⏭ Advance Round</button></div>';var ld=document.getElementById('mkt-log');if(ld)ld.innerHTML=log.slice(0,8).map(function(x){return '<div>• '+x+'</div>';}).join('');}
  window._mkt_buy=function(i,q){var s=stocks[i],qty=Math.min(q,Math.floor(cash/s.price));if(qty<1)return;cash-=qty*s.price;s.owned+=qty;advance('Bought '+qty+' '+s.name);};window._mkt_sell=function(i,q){var s=stocks[i],qty=Math.min(q,s.owned);if(qty<1)return;cash+=qty*s.price;s.owned-=qty;advance('Sold '+qty+' '+s.name);};window._mkt_skip=function(){var reflected=mmGameWrong('Market Trader','What are you watching before deciding to wait? Consider price movement, risk, and your available cash.',function(){advance('Advanced without trading');});if(!reflected)advance('Advanced without trading');};window._mkt_init=reset;window._game_market_init=reset;reset();
}

function _mmInitShop(){
  var score=0,items=[],cart=[],cash=[],change=[],changeDue=0,attempts=0,locked=false;
  var maxCartQty=8, tripBudget=20*100, scenario=null;
  function money(c){return '$'+(Number.isFinite(c)?(c/100).toFixed(2):'0.00');}
  function gradeNum(){var g=String(currentGrade||'K').toUpperCase();return g==='K'?0:(parseInt(g,10)||0);}
  function denoms(){var g=gradeNum();return g<=1?[1,5,10,25,100]:g<=3?[1,5,10,25,50,100,200,500]:[1,5,10,25,50,100,200,500,1000,2000,5000];}
  function budgetForGrade(){var g=gradeNum();return g<=2?2000:g<=4?3000:g<=6?5000:7500;}
  function totalCart(){var src=(cart&&cart.length)?cart:items;return (src||[]).reduce(function(a,x){return a+(Number(x.price)||0)*(Number(x.qty)||0);},0);}
  function itemCatalog(){
    var common=[
      ['Pencil',50,'need','school'],['Eraser',75,'need','school'],['Notebook',250,'need','school'],
      ['Water Bottle',399,'need','everyday'],['Snack',149,'want','food'],['Socks',499,'need','clothing'],
      ['Paperback Book',799,'want','reading'],['Toy Car',599,'want','toy'],['Lunch',650,'need','food'],
      ['Art Set',1299,'want','art'],['Headphones',1499,'want','technology'],['Backpack',2499,'need','school'],
      ['Board Game',1999,'want','game'],['Sports Ball',1799,'want','sports'],['Jacket',2999,'need','clothing']
    ];
    var g=gradeNum();
    if(g<=2)return common.filter(function(x){return ['Pencil','Eraser','Notebook','Snack','Water Bottle','Socks','Toy Car','Paperback Book'].indexOf(x[0])>-1;});
    if(g<=4)return common.slice(0,12);
    return common;
  }
  function newTrip(){
    mmResetMistakes('Smart Shopper');
    tripBudget=budgetForGrade();items=[];cart=[];cash=[];change=[];changeDue=0;attempts=0;locked=false;
    var pool=itemCatalog().slice();shuffleArr(pool);items=pool.slice(0,gradeNum()<=2?6:gradeNum()<=4?8:10).map(function(x){return {name:x[0],price:x[1],qty:0,kind:x[2],category:x[3]};});
    cart=items;
    scenario={budget:tripBudget,needTarget:gradeNum()<=2?1:2};render();
  }
  function render(){
    var ss=document.getElementById('shop-score');if(ss)ss.textContent='Shopping budget: '+money(tripBudget)+' · Score: '+score;
    var pr=document.getElementById('shop-prompt');if(pr)pr.innerHTML='<b>Real-Life Shopping Challenge</b><br>You have '+money(tripBudget)+' to spend. Choose items you actually need first, then decide whether a want fits your budget. You may buy multiple items and change quantities.';
    var ie=document.getElementById('shop-items');if(ie)ie.innerHTML=items.map(function(x,i){return '<div class="unit-card" style="margin-bottom:8px"><div class="unit-head"><div><div class="unit-title">'+esc(x.name)+' · '+money(x.price)+'</div><div style="font-size:11px;color:var(--ink-light)">'+(x.kind==='need'?'Need':'Want')+' · Quantity: <b>'+x.qty+'</b></div></div><div class="meta-pills"><button class="btn-calc ghost" onclick="_shop_qty('+i+',-1)" aria-label="Decrease '+esc(x.name)+' quantity">−</button><button class="btn-calc" onclick="_shop_qty('+i+',1)" aria-label="Increase '+esc(x.name)+' quantity">+1</button></div></div></div>';}).join('');
    var total=totalCart(),paid=cash.reduce(function(a,b){return a+b;},0),ct=change.reduce(function(a,b){return a+b;},0);
    var ce=document.getElementById('shop-cart');if(ce)ce.innerHTML='<b>Cart total:</b> '+money(total)+'<br>Cash selected: <b>'+money(paid)+'</b> · Remaining budget: <b>'+money(Math.max(0,tripBudget-total))+'</b> · Change selected: <b>'+money(ct)+'</b>';
    var pe=document.getElementById('shop-pay');if(pe)pe.innerHTML='<div style="width:100%;text-align:center;font-size:12px;color:var(--ink-light);margin-bottom:5px">Choose the bills and coins you will use to pay.</div>'+denoms().map(function(v){return '<button class="btn-calc ghost" onclick="_shop_cash('+v+')">'+money(v)+'</button>';}).join('')+'<button class="btn-calc" onclick="_shop_clearCash()">Clear Cash</button>';
    var ch=document.getElementById('shop-change');if(ch){ch.style.display=changeDue>0?'block':'none';ch.innerHTML='<b>Build the exact change</b><br><span style="font-size:12px;color:var(--ink-light)">The change due is hidden until you finish. Selected: '+money(ct)+'</span><div class="meta-pills" style="justify-content:center;margin-top:9px">'+denoms().map(function(v){return '<button class="btn-calc ghost" onclick="_shop_addChange('+v+')">'+money(v)+'</button>';}).join('')+'</div><div style="margin-top:8px;text-align:center">'+(change.length?change.map(function(v,i){return '<button class="btn-calc" onclick="_shop_removeChange('+i+')">'+money(v)+' ×</button>';}).join(' '):'No change selected yet.')+'<br><button class="btn-calc green" style="margin-top:9px" onclick="_shop_submitChange()">Give Change</button></div>';}
  }
  window._shop_qty=function(i,delta){if(!items[i]||locked)return;items[i].qty=Math.max(0,Math.min(maxCartQty,items[i].qty+delta));render();};
  window._shop_cash=function(v){if(locked||!Number.isFinite(v))return;var paid=cash.reduce(function(a,b){return a+b;},0);if(paid+v<=tripBudget)cash.push(v);render();};
  window._shop_clearCash=function(){cash=[];change=[];changeDue=0;locked=false;render();};
  window._shop_checkout=function(){
    var total=totalCart(),paid=cash.reduce(function(a,b){return a+b;},0),fb=document.getElementById('shop-feedback');
    var needQty=cart.filter(function(x){return x.qty>0&&x.kind==='need';}).reduce(function(a,x){return a+x.qty;},0);
    if(!total){var reflected=mmGameWrong('Smart Shopper','What kind of item are you trying to buy? Choose a realistic need or want before checking out.',function(){});if(fb)fb.textContent=reflected?'Pause for a quick reflection before trying again.':'Choose at least one item.';return;}
    if(total>tripBudget){var reflected=mmGameWrong('Smart Shopper','Look at the quantities and prices. Which item or quantity could you change to stay within the budget?',function(){});if(fb)fb.textContent=reflected?'Pause for a quick reflection before trying again.':'That cart is over your shopping budget. Reduce a quantity or remove an item.';return;}
    if(needQty<scenario.needTarget&&gradeNum()>=3){var reflected=mmGameWrong('Smart Shopper','Which items are needs and which are wants? Try to make sure the cart includes the important needs first.',function(){});if(fb)fb.textContent=reflected?'Pause for a quick reflection before trying again.':'Before checking out, try including '+scenario.needTarget+' item(s) labeled Need. Smart shoppers handle needs before wants.';return;}
    if(paid<total){var reflected=mmGameWrong('Smart Shopper','Compare the cart total with the cash you selected. Do you need to add another bill or coin?',function(){});if(fb)fb.textContent=reflected?'Pause for a quick reflection before trying again.':'Not enough cash. Add another bill or coin.';return;}
    changeDue=paid-total;change=[];attempts=0;if(changeDue===0)finish();else{if(fb)fb.textContent='Payment accepted. Now build the exact change without seeing the answer.';render();}
  };
  window._shop_addChange=function(v){if(locked)return;var ct=change.reduce(function(a,b){return a+b;},0);if(ct+v<=changeDue)change.push(v);render();};
  window._shop_removeChange=function(i){if(locked)return;if(i>=0&&i<change.length)change.splice(i,1);render();};
  window._shop_submitChange=function(){if(locked)return;attempts++;var ct=change.reduce(function(a,b){return a+b;},0);if(ct===changeDue)finish();else{var reflected=mmGameWrong('Smart Shopper','Recheck the item prices, quantity, cash paid, and denominations. Which part should you verify first?',function(){var f=document.getElementById('shop-feedback');if(f)f.textContent='Try the change again one denomination at a time.';});var fb=document.getElementById('shop-feedback');if(fb)fb.textContent=reflected?'Pause for a quick reflection before trying again.':'Not quite. Recheck the price, the cash you paid, and the denominations you selected.';}};
  function finish(){
    locked=true;var total=totalCart(),paid=cash.reduce(function(a,b){return a+b;},0),finalWallet=tripBudget-total;
    score++;mmRecordGame('Smart Shopper',mmAdaptiveDifficulty('Smart Shopper','practice'),1,Math.max(1,attempts));
    var fb=document.getElementById('shop-feedback');if(fb)fb.textContent='✓ Purchase complete. Review your receipt and think about your choices.';
    var ch=document.getElementById('shop-change');if(ch){ch.style.display='block';var lines=cart.filter(function(x){return x.qty>0;}).map(function(x){return '<div>'+esc(x.name)+' × '+x.qty+' = <b>'+money(x.price*x.qty)+'</b></div>';}).join('');ch.innerHTML='<b>🧾 Receipt</b><div style="margin-top:8px">'+lines+'<hr style="border:0;border-top:1px solid rgba(140,90,30,.18)"><div>Subtotal: <b>'+money(total)+'</b></div><div>Cash paid: <b>'+money(paid)+'</b></div><div>Change: <b>'+money(paid-total)+'</b></div><div>Budget remaining: <b>'+money(finalWallet)+'</b></div></div><div class="meta-pills" style="justify-content:center;margin-top:10px"><button class="btn-calc green" onclick="_shop_new()">New Shopping Trip</button></div>';}
    mmShowReflection('Smart Shopper','Which item was a need, which was a want, and how did the price affect your decision?');render();
  }
  window._shop_new=function(){newTrip();};window._game_shop_init=newTrip;newTrip();
}

function _mmInitLife(){
  var state;try{state=JSON.parse(localStorage.getItem('mmLifeState_v1')||'null');}catch(e){state=null;}
  if(!state||!Number.isFinite(state.wallet))state={wallet:10000,round:0,score:0,history:[]};
  var scenarios=[
    {title:'Mission 1: Need or Want?',text:'You have $'+(state.wallet/100).toFixed(2)+'. A notebook costs $4 and a game costs $7. You need the notebook for school. What should you buy first?',choices:['Buy the notebook first','Buy the game first','Buy both without checking'],best:0,why:'Needs can come before wants when money is limited.'},
    {title:'Mission 2: Save or Spend?',text:'You receive $10. Your goal is $30. You already have $22. What choice best reaches the goal?',choices:['Save the $10','Spend $8 and save $2','Spend all $10'],best:0,why:'Saving toward a goal means keeping money available for the goal.'},
    {title:'Mission 3: Best Buy',text:'Two snack packs meet the same need. Pack A costs $3 for 6 snacks. Pack B costs $4 for 10 snacks. Which is the better value per snack?',choices:['Pack A','Pack B','They cost the same per snack'],best:1,why:'Comparing unit cost helps shoppers compare different package sizes.'},
    {title:'Mission 4: Unexpected Expense',text:'An unexpected $8 expense appears. You have $25 saved and $15 planned for a want. What is the strongest choice?',choices:['Use savings and keep the want budget','Use the want money for the expense and keep savings','Ignore the expense'],best:1,why:'A flexible budget can redirect money from wants when an unexpected need appears.'},
    {title:'Mission 5: Opportunity Cost',text:'You have $12 and can buy a book for $12 or two $6 games. If you choose the book, what is the opportunity cost?',choices:['The two games you give up','The $12 you still have','Nothing'],best:0,why:'Opportunity cost is the next-best choice you give up.'},
    {title:'Mission 6: Payday Plan',text:'You receive $50. Which plan best balances today and tomorrow?',choices:['Save $15, needs $25, wants $10','Save $0, needs $25, wants $25','Save $5, needs $10, wants $35'],best:0,why:'A balanced plan protects needs and gives saving a place in the budget.'}
  ];
  function save(){try{localStorage.setItem('mmLifeState_v1',JSON.stringify(state));localStorage.setItem('mmLifeWallet_v1',String(Math.max(25,state.wallet)));}catch(e){}}
  function render(){var r=scenarios[state.round%scenarios.length],host=document.getElementById('life-body');if(!host)return;host.innerHTML='<div class="card"><div class="card-title">'+r.title+'</div><div class="card-body">'+r.text+'</div></div><div class="who" style="margin:10px 0">Wallet: <b>$'+(state.wallet/100).toFixed(2)+'</b> · Mission '+(state.round+1)+'/6 · Score '+state.score+'</div><div class="meta-pills" style="display:grid;gap:8px">'+r.choices.map(function(c,i){return '<button class="btn-calc" onclick="_life_choose('+i+')">'+esc(c)+'</button>';}).join('')+'</div><div id="life-feedback" class="who" style="margin-top:10px;min-height:30px"></div><div id="mm-game-reflection"></div>'+(state.history.length?'<div class="card" style="margin-top:12px"><div class="card-title">Recent decisions</div><div class="card-body">'+state.history.slice(-3).map(function(h){return '• '+esc(h);}).join('<br>')+'</div></div>':'');}
  window._life_choose=function(i){var r=scenarios[state.round%scenarios.length],fb=document.getElementById('life-feedback');if(!fb)return;if(i===r.best){state.score++;state.wallet+=100;fb.innerHTML='<span style="color:var(--green);font-weight:800">✓ Strong choice.</span> '+r.why;mmRecordGame('Money Life Mission','practice',1,1);if(state.score>=3)mmAwardAchievement('life-3','Money Decision Maker','Made three strong Money Life decisions.');}else{state.wallet=Math.max(0,state.wallet-25);var reflected=mmGameWrong('Money Life Mission','What information in the scenario could help you make a stronger decision next time?',function(){render();});fb.innerHTML='<span style="color:#a33;font-weight:800">Try thinking again.</span>'+(reflected?' Pause for a quick reflection.':' Look back at the choices and try again.');mmRecordGame('Money Life Mission','practice',0,1);if(reflected){save();return;}}state.history.push((i===r.best?'Good':'Retry')+': '+r.title);state.round++;save();setTimeout(function(){render();if(state.round%6===0){setTimeout(function(){mmShowReflection('Money Life Mission','Which decision would you make differently next time, and why?');},50);}},500);};
  window._life_reset=function(){state={wallet:10000,round:0,score:0,history:[]};save();render();};window._game_life_init=render;render();
}

function _mmInitTax(){
  var attempts=0,scenario=null;function money(n){return '$'+Number(n).toLocaleString('en-US');}
  function newScenario(){attempts=0;mmResetMistakes('Tax Time');var wages=[28000,34000,42000,48000,56000,68000,76000][Math.floor(Math.random()*7)];var deduction=[6000,8000,10000,12000,13850,15000][Math.floor(Math.random()*6)];var rate=[0.08,0.10,0.12,0.15][Math.floor(Math.random()*4)];deduction=Math.min(deduction,wages-5000);var taxable=wages-deduction;var withheld=Math.max(0,Math.round(taxable*rate+(Math.random()*3000-800)));scenario={wages:wages,deduction:deduction,rate:rate,withheld:withheld};render();}
  function render(){var r=scenario,info=document.getElementById('tx-info'),rateLabel=document.getElementById('tx-rate-label');if(rateLabel)rateLabel.textContent=(r.rate*100).toFixed(0)+'%';if(info)info.innerHTML='Wages: <b>'+money(r.wages)+'</b> · Withheld: <b>'+money(r.withheld)+'</b> · Deduction: <b>'+money(r.deduction)+'</b> · Practice rate: <b>'+(r.rate*100).toFixed(0)+'%</b>';['tx1','tx2','tx3'].forEach(function(id){var e=document.getElementById(id);if(e)e.value='';});var out=document.getElementById('tx-result');if(out)out.textContent='';}
  window._tx_new=function(){newScenario();};window._tx_check=function(){attempts++;var r=scenario,v1=Number(document.getElementById('tx1').value),v2=Number(document.getElementById('tx2').value),v3=Number(document.getElementById('tx3').value),a1=r.wages-r.deduction,a2=Math.round(a1*r.rate),a3=r.withheld-a2,out=document.getElementById('tx-result');if(v1===a1&&v2===a2&&v3===a3){out.style.color='var(--green)';out.textContent='✓ Return completed correctly.';mmRecordGame('Tax Time',mmAdaptiveDifficulty('Tax Time','practice'),1,attempts);mmShowReflection('Tax Time','Which step was easiest, and which step required the most checking?');setTimeout(newScenario,1400);}else{var hints=[];if(v1!==a1)hints.push('recheck wages minus deduction');if(v2!==a2)hints.push('recheck taxable income times the rate');if(v3!==a3)hints.push('recheck withheld minus tax owed');out.style.color='#a33';var reflected=mmGameWrong('Tax Time','Which step should you verify first? Recheck the operation and the numbers you entered.',function(){var o=document.getElementById('tx-result');if(o)o.textContent='Try the calculation again carefully.';});out.textContent=reflected?'Pause for a quick reflection before trying again.':'Not quite. '+hints.join(' · ')+'. Try again.';}};window._game_tax_init=newScenario;newScenario();
}

function _coinGameHTML(){
  return `<div id="cg" style="font-family:system-ui,sans-serif">
<div class="section-head">🪙 Coin Counter</div>
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div id="cg-score" class="who">Score: 0</div><div><select class="gloss-search" onchange="_cg_setDiff(this.value)"><option value="easy">Easy</option><option value="practice" selected>Practice</option><option value="challenge">Challenge</option></select></div></div>
<div id="cg-coins" style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;padding:18px 8px;min-height:110px"></div>
<div id="cg-label" style="text-align:center;color:var(--ink-light);font-size:12px;margin-bottom:14px">Count the coins, then choose the total.</div>
<div id="cg-feedback" class="who" style="text-align:center;min-height:22px"></div>
<div id="cg-choices" class="meta-pills" style="justify-content:center"></div><div id="mm-game-reflection"></div>
<div style="text-align:center;margin-top:12px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div>
</div>
`;
}
function _changeGameHTML(){
  return `<div style="font-family:system-ui,sans-serif"><div class="section-head">🛒 Cash Register: Make Change</div>
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div id="chg-score" class="who">Score: 0</div><div><select class="gloss-search" onchange="_chg_setDiff(this.value)"><option value="easy">Easy</option><option value="practice" selected>Practice</option><option value="challenge">Challenge</option></select></div></div>
<div id="chg-prompt" class="card" style="margin-top:12px"></div><div id="chg-tray" style="min-height:90px;padding:12px;border:2px dashed rgba(140,90,30,.3);border-radius:12px;margin:12px 0;text-align:center"><div style="font-size:12px;color:var(--ink-light)">Select coins and bills for the customer's change.</div></div>
<div id="chg-money" class="meta-pills" style="justify-content:center"></div><div id="chg-total" class="who" style="text-align:center">Change selected: 0¢</div><div id="chg-feedback" class="who" style="text-align:center;min-height:24px"></div>
<div class="meta-pills" style="justify-content:center"><button class="btn-calc green" onclick="_chg_submit()">Give Change</button><button class="btn-calc ghost" onclick="_chg_clear()">Clear</button></div><div id="mm-game-reflection"></div>
<div style="text-align:center;margin-top:12px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div></div>
`;
}
function _budgetGameHTML(){
  return `<div style="font-family:system-ui,sans-serif"><div class="section-head">💰 Budget Blitz</div>
<div class="who">Build a balanced monthly budget. Keep savings at 20% or more and make the total exactly 100%.</div>
<div id="bdg-sliders" style="padding:16px 0"></div><div id="bdg-result" style="padding:8px 16px;font-size:14px;font-weight:700"></div><div class="meta-pills" style="justify-content:center"><button class="btn-calc green" onclick="_bdg_check()">Check Budget</button><button class="btn-calc ghost" onclick="_bdg_reset()">↺ Reset Budget</button></div><div id="mm-game-reflection"></div>
<div style="text-align:center;margin-top:12px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div></div>`;
}

function _interestGameHTML(){
  return `<div style="font-family:system-ui,sans-serif"><div class="section-head">📈 Interest Racer</div>
<div class="who">Choose a rate, then race 10 years against 3% inflation. Unexpected events can change the outcome.</div>
<div style="padding:16px 0"><label style="font-size:13px;font-weight:700">Interest rate: <span id="ir-rate-lbl">5</span>%</label><input type="range" min="1" max="15" step="0.5" value="5" style="width:100%;accent-color:var(--green);margin-top:6px" oninput="document.getElementById('ir-rate-lbl').textContent=this.value;_ir_simulate(this.value)"></div>
<div id="ir-chart" style="padding:8px 0"></div><div id="mm-game-reflection"></div><div style="text-align:center;margin-top:12px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div></div>`;
}

function _marketGameHTML(){
  return `<div style="font-family:system-ui,sans-serif"><div class="section-head">🏪 Market Trader</div>
<div class="who">Start with $1,000. Trade up to 5 companies over 15 rounds. You may buy, sell, or wait. Prices move after each round.</div>
<div id="mkt-status" style="font-size:13px;color:var(--ink-mid);padding:8px 0"></div><div id="mkt-stocks" style="padding:8px 0"></div>
<div id="mkt-log" style="font-size:12px;color:var(--ink-light);max-height:110px;overflow-y:auto;padding:6px 0;border-top:1px solid rgba(140,90,30,.15);margin-top:8px"></div><div id="mm-game-reflection"></div>
<div style="text-align:center;margin-top:12px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div></div>`;
}

function _shopGameHTML(){
  return `<div style="font-family:system-ui,sans-serif"><div class="section-head">🛍️ Smart Shopper</div>
<div id="shop-score" class="who">Wallet: $20.00 · Score: 0</div><div id="shop-prompt" class="card" style="margin-top:12px"></div>
<div id="shop-items" style="display:grid;gap:8px;margin-top:12px"></div><div id="shop-cart" class="card" style="margin-top:12px"></div>
<div id="shop-pay" class="meta-pills" style="justify-content:center"></div><div id="shop-change" class="card" style="margin-top:12px;display:none"></div><div id="shop-feedback" class="who" style="text-align:center;min-height:24px"></div><div id="mm-game-reflection"></div>
<div class="meta-pills" style="justify-content:center"><button class="btn-calc green" onclick="_shop_checkout()">Check Payment</button><button class="btn-calc ghost" onclick="_shop_clearCash()">Clear Cash</button><button class="btn-calc ghost" onclick="_shop_new()">New Shopping Trip</button></div>
<div style="text-align:center;margin-top:12px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div></div>`;
}
function _lifeGameHTML(){return `<div style="font-family:system-ui,sans-serif"><div class="section-head">🌟 Money Life Mission</div><div class="who">Make connected choices about needs, wants, saving, opportunity cost, and unexpected expenses. Strong decisions grow your Money Life wallet.</div><div id="life-body" style="padding:12px 0"></div><div class="meta-pills" style="justify-content:center"><button class="btn-calc ghost" onclick="_life_reset()">↺ Reset Mission</button><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div></div>`;}
function _taxGameHTML(){
  return `<div style="font-family:system-ui,sans-serif">
<div class="section-head">🧾 Tax Time</div>
<div class="who">Practice a simplified tax scenario. Calculate each step, then submit your return.</div>
<div style="padding:12px 0">
  <div style="background:var(--gold-pale);border-radius:12px;padding:16px;margin-bottom:12px">
    <div style="font-size:12px;font-weight:700;color:var(--ink-light);margin-bottom:10px">YOUR INFORMATION FOR THIS YEAR</div>
    <div id="tx-info" style="font-size:13px;color:var(--ink)">Wages earned: <b>$42,000</b> · Federal withheld: <b>$5,200</b> · Standard deduction: <b>$13,850</b> · Tax rate on taxable income: <b>12%</b></div>
  </div>
  <div style="font-size:14px;font-weight:700;margin-bottom:8px;color:var(--ink)">Complete the return:</div>
  <div style="display:grid;gap:10px">
    <label style="font-size:13px">1. Taxable income = Wages − Deduction = $<input id="tx1" type="number" class="quiz-input" style="width:120px;margin:0 0 0 6px" placeholder="?"></label>
    <label style="font-size:13px">2. Tax owed = Taxable income × <span id="tx-rate-label">12%</span> = $<input id="tx2" type="number" class="quiz-input" style="width:120px;margin:0 0 0 6px" placeholder="?"></label>
    <label style="font-size:13px">3. Refund = Withheld − Tax owed = $<input id="tx3" type="number" class="quiz-input" style="width:120px;margin:0 0 0 6px" placeholder="?"></label>
  </div>
  <div class="meta-pills" style="margin-top:14px"><button class="btn-calc green" onclick="_tx_check()">Submit return</button><button class="btn-calc ghost" onclick="_tx_new()">New Scenario</button></div>
  <div id="tx-result" style="margin-top:10px;font-size:14px;font-weight:700"></div><div id="mm-game-reflection"></div>
</div>
<div style="text-align:center;margin-top:8px"><button class="btn-calc ghost" onclick="backFromGame()">← Back</button></div>
</div>
`;
}

/* Register games panel — added to _panelRenderers registry above */
/* Fix #4: first-use consent banner — shown once, dismissed to localStorage */
const CONSENT_KEY='mmConsent_v1';
function consentGiven(){ try{return !!localStorage.getItem(CONSENT_KEY);}catch(e){return true;} }
function acceptConsent(){
  try{localStorage.setItem(CONSENT_KEY,'1');}catch(e){}
  const b=document.getElementById('consent-banner');
  if(b){
    b.classList.add('hidden');
    setTimeout(function(){ if(b.parentNode)b.parentNode.removeChild(b); },500);
  }
}
function openLegalFromConsent(tab){
  acceptConsent();
  openPanel('legal');
  setTimeout(function(){
    const btn=document.querySelector('.legal-nav button[onclick*="\''+tab+'\'"]');
    showLegalTab(tab, btn||null);
  },80);
}
function maybeShowConsent(){
  const b=document.getElementById('consent-banner');
  if(!b)return;
  if(consentGiven()){ b.classList.add('hidden'); }
  /* else leave visible — it starts visible by default */
}

/* ===== LEGAL PANEL ===== */
/* Fix #5: centralise the effective date so it only needs editing in one place */
const LEGAL_DATE='October 26, 2026'; /* the legal panel now carries its date directly */
(function(){
  document.querySelectorAll('.legal-effective').forEach(function(el){
    el.innerHTML=el.innerHTML.replace(/August 2026/g, LEGAL_DATE);
  });
})();

function showLegalTab(id, btn){
  document.querySelectorAll('.legal-doc').forEach(function(d){d.classList.remove('active');});
  document.querySelectorAll('.legal-nav button').forEach(function(b){b.classList.remove('active');});
  const doc=document.getElementById('legal-'+id);
  if(doc)doc.classList.add('active');
  if(btn)btn.classList.add('active');
}
/* Fix #2: null-check for closest(); Fix #7: tapping open item now closes it */
function toggleFaq(btn){
  if(!btn)return;
  const item=btn.closest('.faq-item');
  if(!item)return;                                    /* Fix #2: guard against missing parent */
  const wasOpen=item.classList.contains('open');
  document.querySelectorAll('.faq-item.open').forEach(function(el){ el.classList.remove('open'); });
  if(!wasOpen)item.classList.add('open');             /* Fix #7: if it was open, leave all closed */
}

/* ===== WHAT'S NEW (Fix #8) ===== */
const APP_VERSION='100'; /* V23 file release */
const CHANGELOG=[{date:'October 2026',items:['Money Game Show: eight class game modes adapted from Japarty for financial literacy (Quiz Rush, Money Board with Daily Double and Final Wager, True or False Blitz, Put It in Order, Cash or Case, What Am I?, Closest Guess, Money Crossword) plus a Daily 5. Questions come from each grade’s own lessons and vocabulary.','Money Workshops: 1-, 2-, 3-, 4- and 5-day intensive workshops for every grade, 2–4 hours a day, with facilitator agendas, materials lists, student passports, and a printable certificate for each day.','Teachers now land on the classroom home screen, like students, with cards for their class, this week’s lesson, and class activities.','Sign-in page: scales from phones to large displays, adds a Student / Teacher switch (sign-in code vs password), and a searchable school field.','Games panel reorganized: Game Show first, practice games in a grid, reference material collapsed.']},{date:'August 2026',items:['Lesson path now explicitly follows Lesson → Worksheet → Quiz → Reflection. Game reliability and assessment reflection pass: fixed Smart Shopper cart synchronization so quantity selections update totals, payment, change, and receipts. Added a persistent post-quiz reflection with understanding and real-life transfer prompts. Audited all seven interactive games for initialization, reset/advance controls, numeric safety, and answer protection.']},{date:'August 2026',items:['Holistic lesson UX pass: clearer student language, student-friendly objectives, time planning, completion status, and improved responsive accessibility.','Student navigation now hides teacher-preparation documents, while Materials remain teacher-only at render time.','Worksheet practice now includes age-appropriate Apply It prompts and a reflection/transfer opportunity.','Teacher Quality Audit expanded to review quiz rigor signals, repeated wording, answer balance, worksheet depth, and lesson completeness.','Improved post-quiz reflection persistence and student-specific storage.']},{date:'August 2026',items:['Question-bank QA update: all 1,782 English lesson-quiz questions now have valid answer indexes and no duplicate options, and source answer positions are balanced across A–D while preserving the correct answer.','Added missing fourth questions to the six K–1 short quizzes, including age-appropriate application and arithmetic items.','Smart Shopper now uses realistic everyday U.S. prices, grade-aware budgets, needs/wants, quantities, and realistic checkout scenarios.','Teacher Question & Answer Audit flags structural issues, repeated wording, short quizzes, and answer-position concentration for review.']},{date:'August 2026',items:['Realistic Smart Shopper catalog with age-appropriate U.S. prices, multiple quantities, needs/wants, budget scenarios, and exact-change checkout.','Teacher-only automated Question & Answer Audit checks all English lesson quiz questions for structural errors, duplicate options, repeated wording, short quizzes, and source answer-position concentration.','No answer keys are exposed during student game play.']},{date:'August 2026',items:[
    '9+ quality remediation: application-focused quiz layer for Grades 3–8.',
    'Student worksheets add a real-life reasoning challenge for Grades 3–8.',
    'Teacher-only 9+ Quality Audit checks all 324 lessons, quizzes, checkpoints, worksheets, materials, games, printing, and accessibility gates.',
    'Improved print page-break behavior, keyboard focus, skip navigation, and reduced-motion support.',
  ]},{date:'August 2026',items:['Added multi-user session login with clear Student and Teacher indicators. Each browser tab can maintain its own role and active student so different users can work at the same time.','Added a guided reflection after three incorrect attempts in interactive games, without revealing the answer. Budget Blitz now counts unsuccessful checks toward the same reflection support.','Improved student session switching and active-session visibility in the Student desk.']},{date:'August 2026',items:['Quality pass based on the lower-rated areas: stronger game feedback and reset controls, hidden student quick-check answers, improved quiz completion flow, teacher materials-readiness checklist, stronger system diagnostics, and corrected CEE standards link.','Make Change no longer exposes the target answer while students build change.','Budget Blitz now has a reliable reset control and clearer allocation feedback.','Tax Time now supports an explicit new-scenario control.']},{date:'August 2026',items:['Added Money Life Mission with connected needs/wants, saving, opportunity cost, unexpected expense, and reflection decisions.','Added achievements, adaptive difficulty guidance, teacher game question/skill review, receipts, and persistent Money Life wallet.','Expanded Smart Shopper with needs/wants labels and a saved receipt.']},{date:'August 2026',items:['Expanded and rebuilt the mini-games: multi-item quantities in Smart Shopper, real bill/coin denominations, NaN-safe change logic, interactive Budget Blitz, event-driven Interest Racer, 15-round Market Trader, and randomized Tax Time.','Rebuilt mini-games with CSP-safe initialization so they start reliably on phones, tablets, and computers.','Fixed Coin Counter, Make Change, Smart Shopper, Budget Blitz, Interest Racer, Market Trader, and Tax Time.','Added Teacher System Check, offline money visuals, responsive classroom layout, and game back-position memory.']},
  {date:'August 2026',items:['Expanded the game progression into a K–8 Money Skills Path.','Smart Shopper keeps the change amount hidden during checkout.','Tax Time provides retry attempts with step-specific hints without revealing final answers.']},
  {date:'August 2026',items:['Fixed Cash Register question generation so every generated price has a valid payment and change amount.','Checked all seven games and enabled reliable script initialization and game-result tracking.','Budget, Market Trader, and Tax Time now record completed game results.']},
  {date:'August 2026',items:['Fixed game initialization so interactive games run reliably when opened.','Coin Counter now calculates the target from the exact displayed coins and supports retry-on-wrong-answer.','Smart Shopper no longer reveals change before checkout.','Simplified Tax Time scenario is clearly labeled as practice.']},
  {date:'August 2026',items:['Interactive cash-register change game with real coin and bill selection.','Difficulty levels, retry-on-wrong-answer learning flow, Smart Shopper game, and teacher game-performance reporting.',"Student mode hides What's New and update popups."]},
  {date:'August 2026',items:[
    'Student Roster panel (👥): full list of all students grouped by grade, with progress bars, usage opens, last-seen date, promote button, and grade-history badges.',
    'Grade promotion: when a student completes all lessons in their grade, a Promote button appears in both the Student Roster and Teacher/Parent view — moves them to the next grade while preserving prior-grade history.',
    'Usage tracking: every app open and every student sign-in is recorded. Total opens, unique days, first/last used, and per-student open counts appear in the Student Roster and Teacher/Parent view.',
    'Welcome tour now re-shows when APP_VERSION changes so returning users see new features highlighted.',
    'Excel export (📊 Excel): generates a proper .xlsx file using Open XML — no library required. Same columns as the CSV gradebook.',
    'Finance mini-games panel (🎮): six grade-adaptive games — Coin Counter, Make Change, Budget Blitz, Interest Racer, Market Trader, and Tax Time.',
    'Live links for Cee and Math open in a new tab with noopener/noreferrer.',
    'Teacher/Parent view: grades-taught tags shown next to each teacher name.',
    'Teacher/Parent view: promote button and usage opens visible per student.',
    'Games and Students panels added to the navigation bar.',
  ]},
  {date:'August 2026',items:[
    'CSV injection fix. UUID v4 student IDs. Quota check without Blob alloc.',
    'Teacher role in sessionStorage — DevTools elevation blocked.',
    'Mid-quiz navigation guard. Locks-off badge. Certificate verification code.',
    'Gradebook extended: Teacher, School, Lessons Viewed, Worksheets Attempted.',
    'Glossary See Also cross-links. Lexile reading level toggle.',
    'Panel renderer registry. DocumentFragment in renderTeacher.',
    'SW cache versioned to APP_VERSION. renderQuiz error boundary.',
  ]},
  {date:'August 2026',items:[
    'Feedback panel with star ratings, categories, history, and CSV/Excel download.',
    'School name on certificates, reports, family letters, and dashboard.',
  ]},
  {date:'August 2026',items:[
    'Multi-tab BroadcastChannel sync. PWA — installable, works offline.',
    'SHA-256 PIN hashing, rate-limiting, in-app PIN modal.',
    'All print functions use Blob URL. Modal promise queue.',
    'Privacy Policy, Terms, FAQ, What\'s New, and Feedback panels.',
  ]},
];
function renderWhatsNew(){
  const el=document.getElementById('whatsNewBody'); if(!el)return;
  let h='';
  var groups=[],byDate={};
  CHANGELOG.forEach(function(entry){var d=entry.date||'Earlier';if(!byDate[d]){byDate[d]={date:d,items:[]};groups.push(byDate[d]);}byDate[d].items=byDate[d].items.concat(entry.items||[]);});
  groups.forEach(function(g){
    h+='<div class="card" style="margin-bottom:14px">'
      +'<div class="card-title">'+esc(g.date)+'</div>'
      +'<div class="card-body"><ul>'+g.items.map(function(i){return '<li>'+i+'</li>';}).join('')+'</ul></div>'
      +'</div>';
  });
  el.innerHTML=h;
  /* Fix #10: always scroll to top when panel opens */
  const pb=el.closest('.panel-body')||el.parentElement;
  if(pb)pb.scrollTop=0;
}

/* ===== PWA: MANIFEST (injected as blob — works from file:// and any origin) ===== */
(function _injectManifest(){
  const icons=[
    {src:'data:image/svg+xml,'+encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">'
      +'<rect width="512" height="512" rx="96" fill="#231a0a"/>'
      +'<text x="256" y="340" font-size="280" text-anchor="middle" font-family="system-ui">💰</text>'
      +'</svg>'),
     sizes:'512x512',type:'image/svg+xml',purpose:'any maskable'}
  ];
  const manifest={
    name:'Money Matters',
    short_name:'Money Matters',
    description:'K–8 Financial Literacy Curriculum — 324 lessons, quizzes, printables, and interactive money practice.',
    start_url:location.href.split('?')[0],
    display:'standalone',
    orientation:'portrait-primary',
    background_color:'#231a0a',
    theme_color:'#231a0a',
    lang:'en-US',
    categories:['education','kids'],
    icons:icons
  };
  try{
    const link=document.getElementById('pwa-manifest-link');
    if(link){
      const blob=new Blob([JSON.stringify(manifest)],{type:'application/manifest+json'});
      link.href=URL.createObjectURL(blob);
    }
  }catch(e){}
})();

/* ===== PWA: SERVICE WORKER (cache-first, offline-capable) ===== */
(function _registerSW(){
  if(!('serviceWorker' in navigator))return;
  function after(reg){
    if(reg.active)return;
    reg.addEventListener('updatefound',function(){
      const sw=reg.installing;if(!sw)return;
      sw.addEventListener('statechange',function(){if(sw.state==='activated')showSaveToast('✓ App ready to use offline');});
    });
  }
  if(location.protocol==='http:'||location.protocol==='https:'){
    navigator.serviceWorker.register('./sw.js',{scope:'./'}).then(after).catch(function(){
      try{navigator.serviceWorker.register('./sw.js').then(after).catch(function(){});}catch(e){}
    });
  }
})();

/* ===== SECURITY: INPUT SANITISATION HELPERS ===== */
/* isValidId — validate student IDs before any s.list[id] lookup */
function isValidId(id){ return /^s_[a-z0-9_]+$/.test(id||''); }

/* ===== SECURITY: LOCALSTORAGE QUOTA GUARD ===== */
/* Prevent unbounded localStorage growth (denial-of-service via worksheet spam) */
function storageQuotaOk(){
  /* Estimate bytes without allocating a Blob — UTF-16 string length × 2 bytes */
  try{ const kb=(localStorage.getItem(SKEY)||'').length*2/1024; return kb<2048; }catch(e){ return true; }
}
/* Wrap saveStore with quota check */
(function(){
  const _qs=saveStore;
  saveStore=function(o){
    if(!storageQuotaOk()){
      infoToast('⚠ Storage nearly full — back up and clear old data in Teacher/Parent view.',5000);
      return;
    }
    _qs(o);
  };
})();

/* ===== SECURITY: PREVENT CLICKJACKING AT RUNTIME ===== */
/* Belt-and-suspenders: if the page is framed by a different origin, break out */
(function(){
  try{ if(window.top!==window.self&&window.top.location.hostname!==window.self.location.hostname) window.top.location=window.self.location; }catch(e){ /* cross-origin frame — break out */ try{window.top.location=window.self.location;}catch(e2){} }
})();

/* ===== MULTI-TAB: SHOW TAB INDICATOR IF >1 TAB OPEN ===== */
(function _tabIndicator(){
  const TAB_PING_KEY='mmTabPings';
  const MY_TAB=Date.now()+'-'+Math.random().toString(36).slice(2);
  function pingTabs(){
    try{
      const raw=JSON.parse(localStorage.getItem(TAB_PING_KEY)||'{}');
      raw[MY_TAB]=Date.now();
      /* prune stale pings older than 12 s */
      Object.keys(raw).forEach(function(k){ if(Date.now()-raw[k]>12000)delete raw[k]; });
      localStorage.setItem(TAB_PING_KEY,JSON.stringify(raw));
      const count=Object.keys(raw).length;
      const ind=document.getElementById('tab-count-badge');
      if(ind){
        ind.textContent=count>1?count+'':' ';
        ind.title=count>1?(count+' tabs open — each can have a different student'):'';
        ind.style.display=count>1?'flex':'none';
      }
    }catch(e){}
  }
  /* Fix #2: remove this tab's ping on close so the count is immediately accurate */
  window.addEventListener('pagehide',function(){
    try{
      const raw=JSON.parse(localStorage.getItem(TAB_PING_KEY)||'{}');
      delete raw[MY_TAB];
      localStorage.setItem(TAB_PING_KEY,JSON.stringify(raw));
    }catch(e){}
  });
  /* Fix #2: remove this tab's ping on close */
  window.addEventListener('pagehide',function(){
    try{
      const raw=JSON.parse(localStorage.getItem(TAB_PING_KEY)||'{}');
      delete raw[MY_TAB];
      localStorage.setItem(TAB_PING_KEY,JSON.stringify(raw));
    }catch(e){}
  });
  setInterval(pingTabs,5000);
  setTimeout(pingTabs,500);
})();

/* ===== PWA INSTALL PROMPT ===== */
let _installPrompt=null;
window.addEventListener('beforeinstallprompt',function(e){
  e.preventDefault();
  _installPrompt=e;
  /* Show install button wherever it's rendered */
  document.querySelectorAll('.pwa-install-btn').forEach(function(b){ b.style.display='inline-flex'; });
});
window.addEventListener('appinstalled',function(){
  _installPrompt=null;
  document.querySelectorAll('.pwa-install-btn').forEach(function(b){ b.style.display='none'; });
  infoToast('✓ Money Matters installed — find it on your home screen.',4000);
});
/* Fix #9: detect already-installed (standalone) state and hide install button */
(function(){
  if(window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches){
    /* already running as installed PWA — no install button needed */
    document.querySelectorAll('.pwa-install-btn').forEach(function(b){ b.style.display='none'; });
  }
  /* Also watch for future transitions (e.g. user installs while app is open) */
  if(window.matchMedia){
    window.matchMedia('(display-mode: standalone)').addEventListener('change',function(e){
      if(e.matches){
        _installPrompt=null;
        document.querySelectorAll('.pwa-install-btn').forEach(function(b){ b.style.display='none'; });
      }
    });
  }
})();
/* Fix #9: detect already-installed (standalone) state */
(function(){
  if(window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches){
    document.querySelectorAll('.pwa-install-btn').forEach(function(b){ b.style.display='none'; });
  }
  if(window.matchMedia){
    window.matchMedia('(display-mode: standalone)').addEventListener('change',function(e){
      if(e.matches){
        _installPrompt=null;
        document.querySelectorAll('.pwa-install-btn').forEach(function(b){ b.style.display='none'; });
      }
    });
  }
})();
function triggerInstall(){
  if(_installPrompt){ _installPrompt.prompt(); _installPrompt.userChoice.then(function(r){ if(r.outcome==='accepted')_installPrompt=null; }); }
  else { mmAlert('To install:\n• Chrome/Edge: tap the ⋮ menu → "Add to Home Screen"\n• Safari (iOS): tap Share → "Add to Home Screen"','📲'); }
}

/* Fix #8: Online/offline status banner */
(function _onlineStatus(){
  const banner=document.getElementById('offline-banner');
  function update(){
    const offline=!navigator.onLine;
    if(banner){ banner.classList.toggle('show',offline); }
    document.body.classList.toggle('offline-mode',offline);
    const toast=document.getElementById('autosave-toast');
    if(toast){ toast.style.background=offline?'rgba(90,50,10,0.92)':''; }
  }
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
  update(); /* check on load */
})();

/* ===== FEEDBACK ===== */
const FEEDBACK_KEY='mmFeedback_v1';
const STAR_LABELS=['','Poor','Fair','Good','Great','Excellent'];
let _fbStar=0;
let _fbCat='General';
let _fbGrade='';
let _fbUrgency='Suggestion';

function loadFeedback(){ try{return JSON.parse(localStorage.getItem(FEEDBACK_KEY)||'[]');}catch(e){return [];} }
function saveFeedbackList(list){ try{localStorage.setItem(FEEDBACK_KEY,JSON.stringify(list));}catch(e){} }

function setFeedbackStar(n){
  _fbStar=n;
  const btns=document.querySelectorAll('#feedbackStars button');
  btns.forEach(function(b,i){
    const active=i<n;
    b.classList.toggle('selected',active);
    b.style.filter=active?'none':'grayscale(1) opacity(0.4)';
    b.setAttribute('aria-pressed',active?'true':'false');
  });
  const lbl=document.getElementById('feedbackStarLabel');
  if(lbl)lbl.textContent=STAR_LABELS[n]||'';
}

function toggleFeedbackCat(btn,cat){
  document.querySelectorAll('#feedbackCats button').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  _fbCat=cat;
}

function toggleFeedbackGrade(btn,grade){
  if(btn.classList.contains('active')){ btn.classList.remove('active'); _fbGrade=''; return; }
  document.querySelectorAll('#feedbackGrades button').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  _fbGrade=grade;
}

function updateFeedbackChar(){
  const ta=document.getElementById('feedbackText');
  const cc=document.getElementById('feedbackCharCount');
  if(ta&&cc)cc.textContent=ta.value.length;
}

function _resetFeedbackForm(){
  _fbStar=0; _fbCat='General'; _fbGrade=''; _fbUrgency='Suggestion';
  const ta=document.getElementById('feedbackText'); if(ta)ta.value='';
  document.querySelectorAll('#feedbackStars button').forEach(function(b){
    b.classList.remove('selected'); b.style.filter=''; b.setAttribute('aria-pressed','false');
  });
  document.querySelectorAll('#feedbackCats button').forEach(function(b){b.classList.remove('active');});
  /* Pre-select General */
  const genBtn=document.querySelector('#feedbackCats button[onclick*="\'General\'"]');
  if(genBtn)genBtn.classList.add('active');
  document.querySelectorAll('#feedbackGrades button').forEach(function(b){b.classList.remove('active');});
  const lbl=document.getElementById('feedbackStarLabel'); if(lbl)lbl.textContent='';
  const cc=document.getElementById('feedbackCharCount'); if(cc)cc.textContent='0';
  const msg=document.getElementById('feedbackFormMsg'); if(msg)msg.textContent='';
  const fs=document.getElementById('feedbackScreen'); if(fs)fs.value=''; document.querySelectorAll('#feedbackUrgency button').forEach(function(b){b.classList.remove('active');});
  _updateFeedbackCount();
}

function _updateFeedbackCount(){
  const list=loadFeedback();
  const el=document.getElementById('feedbackCount'); if(el)el.textContent=list.length;
}

function setFeedbackUrgency(btn,value){
  document.querySelectorAll('#feedbackUrgency button').forEach(function(b){b.classList.remove('active');});
  if(btn)btn.classList.add('active');_fbUrgency=value;
}
function submitFeedback(){
  const text=(document.getElementById('feedbackText')||{}).value||'';
  if(!_fbStar&&!text.trim()){const msg=document.getElementById('feedbackFormMsg');if(msg){msg.style.color='#c44';msg.textContent='Please add a star rating or a comment before submitting.';}return;}
  const entry={
    id:'fb_'+Date.now(),ts:new Date().toISOString(),star:_fbStar,category:_fbCat,grade:_fbGrade,
    urgency:_fbUrgency||'Suggestion',screen:(document.getElementById('feedbackScreen')||{}).value||'',
    text:text.trim().slice(0,1000),appVersion:APP_VERSION,studentGrade:currentGrade||'',
    role:loadRole()||'',device:{width:window.innerWidth,height:window.innerHeight,online:navigator.onLine}
  };
  const list=loadFeedback();list.unshift(entry);if(list.length>200)list.splice(200);saveFeedbackList(list);
  const msg=document.getElementById('feedbackFormMsg');if(msg){msg.style.color='var(--green)';msg.textContent='✓ Feedback saved with diagnostic context. Thank you!';}
  infoToast('✓ Feedback saved — thank you!',3000);setTimeout(_resetFeedbackForm,2000);
}
function showFeedbackHistory(){
  const wrap=document.getElementById('feedback-history-wrap');
  const form=document.getElementById('feedback-form-wrap');
  if(form)form.style.display='none';
  if(wrap)wrap.style.display='';
  renderFeedbackHistory();
}

function showFeedbackForm(){
  const wrap=document.getElementById('feedback-history-wrap');
  const form=document.getElementById('feedback-form-wrap');
  if(wrap)wrap.style.display='none';
  if(form)form.style.display='';
  _updateFeedbackCount();
}

function renderFeedbackHistory(){
  const list=loadFeedback();
  const el=document.getElementById('feedbackHistoryList');
  if(!el)return;
  if(!list.length){
    el.innerHTML='<div class="feedback-empty"><div style="font-size:40px;margin-bottom:12px">💬</div><div style="font-weight:700;margin-bottom:6px">No feedback yet</div><div>Submit your first rating or comment using the form.</div></div>';
    return;
  }
  el.innerHTML=list.map(function(e){
    const stars=e.star?'⭐'.repeat(e.star):'—';
    const date=e.ts?new Date(e.ts).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}):'';
    const tags=[e.category,e.screen||'',e.urgency||'',e.grade?('Grade '+e.grade):'',''].filter(Boolean).join(' · ');
    return '<div class="feedback-history-item">'
      +'<div class="fh-meta"><span class="fh-stars">'+esc(stars)+'</span><span>'+esc(tags)+'</span><span>'+esc(date)+'</span></div>'
      +(e.text?'<div class="fh-text">'+esc(e.text)+'</div>':'<div class="fh-text" style="opacity:0.5;font-style:italic;">No comment</div>')
      +'</div>';
  }).join('');
}

function _buildTSV(){
  const list=loadFeedback();
  if(!list.length)return null;
  const rows=list.map(function(e){
    const date=e.ts?new Date(e.ts).toLocaleDateString():'';
    return [date,e.star?e.star+'★':'—',e.category||'',e.grade?'Gr '+e.grade:'',
            e.studentGrade||'',
            (e.text||'').replace(/\t/g,' ').replace(/\n/g,' ')].join('\t');
  });
  return 'Date\tStars\tCategory\tTeacher Grade\tStudent Grade\tComment\n'+rows.join('\n');
}
function exportFeedback(){
  const tsv=_buildTSV();
  if(!tsv){infoToast('No feedback to export.',2000);return;}
  try{
    navigator.clipboard.writeText(tsv).then(function(){
      infoToast('✓ Feedback copied to clipboard as tab-separated text.',3000);
    }).catch(function(){ _fallbackCopy(tsv); });
  }catch(e){ _fallbackCopy(tsv); }
}
function downloadFeedbackCSV(){
  const tsv=_buildTSV();
  if(!tsv){infoToast('No feedback to download.',2000);return;}
  try{
    const blob=new Blob([tsv],{type:'text/tab-separated-values'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url; a.download='MoneyMatters_Feedback_'+new Date().toISOString().slice(0,10)+'.tsv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function(){URL.revokeObjectURL(url);},5000);
    infoToast('✓ Feedback downloaded as .tsv file.',3000);
  }catch(e){ exportFeedback(); /* fallback to clipboard */ }
}
function _fallbackCopy(text){
  const ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); infoToast('✓ Feedback copied to clipboard.',3000); }
  catch(e){ infoToast('Could not copy — try exporting from Teacher/Parent view.',3000); }
  ta.remove();
}

function clearFeedback(){
  mmConfirm('Clear all feedback?','This will permanently delete all '+loadFeedback().length+' saved feedback entries from this device.','Clear all','🗑').then(function(ok){
    if(!ok)return;
    try{localStorage.removeItem(FEEDBACK_KEY);}catch(e){}
    showFeedbackForm();
    infoToast('All feedback cleared.',2500);
  });
}

function renderFeedback(){
  showFeedbackForm();
  _resetFeedbackForm();
  /* pre-select current grade as convenience */
  if(currentGrade){
    const btn=document.querySelector('#feedbackGrades button[onclick*="\''+currentGrade+'\'"]');
    if(btn){ btn.classList.add('active'); _fbGrade=currentGrade; }
  }
}
/* welcome message + instructor label are set by applyLang() (language-aware) */
buildGradeNav();
setGrade((activeStudent()&&activeStudent().grade)?activeStudent().grade:'K');
applyLang();
applyA11y();
if(!voiceOK())vstatus('Voice reading is not supported in this browser.');
setTimeout(toggleWelcome,600);
maybeTour();
maybeShowConsent();
trackAppOpen(); /* usage tracking — record every app open */

/* Version tracking: auto-show What's New for returning users on upgrade */
(function(){
  const VER_KEY='mmAppVersion';
  try{
    const last=localStorage.getItem(VER_KEY);
    localStorage.setItem(VER_KEY,APP_VERSION);
    if(last&&last!==APP_VERSION && loadRole()==='teacher'){
      setTimeout(function(){ openPanel('whatsnew'); },1200);
    }
  }catch(e){}
})();
