/* =====================================================================
   V23 · LAYOUT  (window.MMLayout)
   One place that decides the app's frame on every screen:
   · The top bar clears the notch / status bar (safe area) and the offline
     banner. Its real height is measured into --mm-top, and everything that
     sits under it (panels, notices) uses that, so nothing overlaps it.
   · When the top bar is short of room (phones, narrow tablets), it keeps the
     logo, the grade, the notification bell and the person's avatar; the other
     buttons move into an account menu that opens from the avatar.
   · Layout tiers: phone ≤ 640 px, tablet ≤ 1024 px, desktop. Teachers and
     administrators get the dashboard home with a slim bottom tab bar at every
     size; students get the tab bar on phones and tablets and the classroom
     (with its shelf of buttons) on desktops.
   · "Classroom view" (a staff quick action) shows the classroom picture for
     projecting to a class; Home brings the dashboard back.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var A=MM.auth,root=document.documentElement,CV='mmClassroomView';
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function staff(){try{var a=A.get();return !!a&&!a.sample&&A.roleKey()!=='student';}catch(e){return false;}}
function isCV(){try{return sessionStorage.getItem(CV)==='1';}catch(e){return false;}}
function set(c,on){if(root.classList.contains(c)!==!!on)root.classList.toggle(c,!!on);}
function tier(){var w=innerWidth;return w<=640?'phone':w<=1024?'tablet':'desk';}
function bar(){var tb=document.getElementById('mm-topbar');return tb&&tb.style.display!=='none'&&getComputedStyle(tb).display!=='none'?tb:null;}

var API=window.MMLayout={apply:apply,isClassroomView:function(){return staff()&&isCV();},
  classroomView:function(on){try{if(on)sessionStorage.setItem(CV,'1');else sessionStorage.removeItem(CV);}catch(e){}apply();try{closePanel(true);}catch(e){}try{MM.shell.topbar();}catch(e){}
    if(on)try{MM.util.toast(T('Classroom view. Tap Home to return to your dashboard.'),3500);}catch(e){}},
  tier:tier};

/* ---------- frame ---------- */
var busy=false;
function apply(){if(busy)return;busy=true;try{
  var t=tier();['phone','tablet','desk'].forEach(function(x){set('mm-l-'+x,t===x);});
  var cv=staff()&&isCV();
  set('mm-classroom-view',cv);
  set('mm-tabs-all',t!=='phone'&&(t==='tablet'||(staff()&&!cv)));
  compact();measure();
}finally{busy=false;}}
function measure(){var tb=bar(),top=tb?Math.round(tb.getBoundingClientRect().bottom):0;
  if(root.style.getPropertyValue('--mm-top')!==top+'px')root.style.setProperty('--mm-top',top+'px');
  set('mm-top-ready',true);}
/* compact top bar: decided with the full bar laid out, so the choice never flips back and forth */
function compact(){var tb=bar();if(!tb){set('mm-bar-compact',false);return;}
  if(tier()==='phone'){set('mm-bar-compact',true);return;}
  var was=root.classList.contains('mm-bar-compact');if(was)root.classList.remove('mm-bar-compact');
  var over=tb.scrollWidth>tb.clientWidth+1;if(over)root.classList.add('mm-bar-compact');}

/* ---------- account menu (compact top bar) ---------- */
var menu=null,opener=null;
function items(){var tb=bar();if(!tb)return [];
  return [].slice.call(tb.querySelectorAll('.tb')).filter(function(b){return !b.classList.contains('gradepick')&&!b.matches('[data-v19=bell]')&&getComputedStyle(b).display==='none';});}
function openMenu(){var tb=bar();if(!tb)return;var u=tb.querySelector('.user');opener=u;
  if(!menu){menu=document.createElement('div');menu.id='mm-acct-menu';menu.setAttribute('role','menu');document.body.appendChild(menu);
    menu.addEventListener('click',function(e){var it=e.target.closest('[data-i]');if(!it)return;var i=+it.getAttribute('data-i'),list=items();closeMenu(false);   /* the bar may have been re-drawn: use its current buttons */
      if(i===-1){try{if(staff())MM.admin.open('me');else openPanel('login');}catch(x){}return;}var b=list[i];if(b)b.click();});
    menu.addEventListener('keydown',function(e){var its=[].slice.call(menu.querySelectorAll('[role=menuitem]')),k=its.indexOf(document.activeElement);
      if(e.key==='Escape'){e.preventDefault();closeMenu(true);}
      else if(e.key==='ArrowDown'){e.preventDefault();its[(k+1)%its.length].focus();}
      else if(e.key==='ArrowUp'){e.preventDefault();its[(k-1+its.length)%its.length].focus();}
      else if(e.key==='Tab'){closeMenu(false);}});}
  var list=items();menu.__list=list;
  var nm='',rl='';try{nm=A.displayName();rl=A.roleLabel();}catch(e){}
  var av=u&&u.querySelector('.mm-avatar')?u.querySelector('.mm-avatar').outerHTML:'';
  menu.innerHTML='<div class="am-head">'+av+'<div><b>'+esc(nm)+'</b><span>'+esc(T(rl))+'</span></div></div>'
    +'<button type="button" role="menuitem" data-i="-1"><span class="am-ic" aria-hidden="true">👤</span>'+esc(T(staff()?'My profile':'Session details'))+'</button>'
    +list.map(function(b,i){var ic=(b.textContent||'').trim().split(/\s+/)[0],txt=(b.querySelector('span')?b.querySelector('span').textContent:b.getAttribute('title')||b.textContent).trim();
      return '<button type="button" role="menuitem" data-i="'+i+'"'+(b.getAttribute('data-a')==='out'?' class="am-out"':'')+'><span class="am-ic" aria-hidden="true">'+esc(ic&&ic!==txt?ic:'•')+'</span>'+esc(txt)+'</button>';}).join('');
  menu.classList.add('open');if(u)u.setAttribute('aria-expanded','true');
  var r=u?u.getBoundingClientRect():{bottom:48,right:innerWidth-8};menu.style.top=(r.bottom+8)+'px';menu.style.right=Math.max(8,innerWidth-r.right)+'px';
  var f=menu.querySelector('[role=menuitem]');if(f)f.focus();}
function closeMenu(refocus){if(!menu||!menu.classList.contains('open'))return;menu.classList.remove('open');if(opener){opener.setAttribute('aria-expanded','false');if(refocus)try{opener.focus();}catch(e){}}}
/* on window, capture: runs before the older avatar handlers (which open My profile) */
window.addEventListener('click',function(e){
  var u=e.target.closest&&e.target.closest('#mm-topbar .user');
  if(u&&root.classList.contains('mm-bar-compact')){e.preventDefault();e.stopPropagation();if(menu&&menu.classList.contains('open'))closeMenu(true);else openMenu();return;}
  if(menu&&menu.classList.contains('open')&&!e.target.closest('#mm-acct-menu'))closeMenu(false);
  /* Home (logo, tab bar, dashboard link) leaves Classroom view */
  if(isCV()&&e.target.closest&&(e.target.closest('#mm-topbar [data-a=home]')||(e.target.closest('#mm-tabbar button')&&e.target.closest('#mm-tabbar button')===document.querySelector('#mm-tabbar button')))){try{sessionStorage.removeItem(CV);}catch(x){}setTimeout(apply,0);}
},true);
window.addEventListener('keydown',function(e){var u=e.target.closest&&e.target.closest('#mm-topbar .user');if(u&&root.classList.contains('mm-bar-compact')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();e.stopPropagation();openMenu();}},true);

/* ---------- keep it current ---------- */
var t=0;function soon(){clearTimeout(t);t=setTimeout(function(){apply();place();},60);}
/* the bar re-draws now and then (bell, grade): keep an open menu attached to the new avatar */
function place(){if(!menu||!menu.classList.contains('open'))return;var tb=bar(),u=tb&&tb.querySelector('.user');if(!u||!root.classList.contains('mm-bar-compact')){closeMenu(false);return;}opener=u;u.setAttribute('aria-expanded','true');var r=u.getBoundingClientRect();menu.style.top=(r.bottom+8)+'px';menu.style.right=Math.max(8,innerWidth-r.right)+'px';}
function watch(){var tb=document.getElementById('mm-topbar');if(tb&&!tb.__lay){tb.__lay=1;new MutationObserver(soon).observe(tb,{childList:true,attributes:true,attributeFilter:['style']});}
  if(!watch.__ro&&window.ResizeObserver&&tb){watch.__ro=new ResizeObserver(function(){measure();});watch.__ro.observe(tb);}}
window.addEventListener('resize',soon);window.addEventListener('orientationchange',soon);
/* (no observer on <html> classes: this module changes them itself, and V21 showed such an observer can loop) */
/* the offline banner moves the top bar down: re-measure when <body> classes change (this module never changes them) */
new MutationObserver(function(){soon();}).observe(document.body,{attributes:true,attributeFilter:['class']});
function boot(){watch();apply();setTimeout(function(){watch();apply();},700);setInterval(function(){watch();},3000);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
