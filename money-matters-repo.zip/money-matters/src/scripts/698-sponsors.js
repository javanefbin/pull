/* =====================================================================
   V19 · AD SUPPORT FOR THE FREE EDITION  (window.MMAds)
   Rules (enforced here, not left to the ad provider):
     · hosted free edition only: a school license removes every ad
     · adults only: shown to signed-in teachers, parents and administrators;
       never to students, never in sample mode as a student, never on the
       sign-in screen, never during the Game Show or on a phone player screen,
       never in printouts
     · no tracking: sponsor cards are plain links (rel="sponsored noopener");
       nothing is counted or sent anywhere when they are shown
   Source, set in /ads.json (src/hosting/ads.json in the repository):
     house     your direct sponsors' cards (text, optional image in /ads/, link).
               V22: no ad network. Ad networks on a K-8 site raise children's
               privacy issues (COPPA) and earn little on a small site; a local
               credit union or bank sponsoring financial literacy fits better.
     becomeSponsor  optional https:// or mailto: link shown as "Sponsor this
               program" under each card (docs/SPONSORS.md has a sponsor kit).
   Placements: "home" (adult home screen, #mm-staff-home) and "resources" (Resource Guide).
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var HOSTED=!!window.MM_PUBLIC_BUILD&&/^https?:$/.test(location.protocol);
var cfg=null,shown={},dismissed={};
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
try{dismissed=JSON.parse(sessionStorage.getItem('mmAdsHidden')||'{}')||{};}catch(e){}

function licensed(){try{return !window.MMLicense||MMLicense.has();}catch(e){return true;}}
function adult(){try{var k=MM.auth.roleKey();if(k!=='teacher'&&k!=='admin')return false;if(MM.sample&&MM.sample.active()&&MM.sample.role()!=='teacher')return false;return true;}catch(e){return false;}}
function busy(){var c=document.documentElement.classList;return c.contains('mm-gs-on')||c.contains('mm-lp-on')||c.contains('mm-gated');}
function eligible(place){return !!(cfg&&cfg.enabled&&HOSTED&&!licensed()&&adult()&&!busy()&&!dismissed[place]&&(cfg.placements||['home','resources']).indexOf(place)>-1);}
function safeUrl(u){u=String(u||'');return /^https:\/\//i.test(u)||/^\/(?!\/)[\w\/.-]*$/.test(u)?u:'';}   /* https:// or a page on this site (/quote) */
function safeImg(u){u=String(u||'');return /^(\/|ads\/)[\w\/.-]+\.(svg|png|jpe?g|webp)$/i.test(u)?u:'';}

var API=window.MMAds={eligible:eligible,refresh:refresh,_setConfig:function(c){cfg=c;refresh();}};

function pick(){var list=(cfg.house||[]).filter(function(a){return a&&a.title&&safeUrl(a.url);});
  return list.length?{house:list[Math.floor(Math.random()*list.length)]}:null;}
function why(){return T('The free edition is supported by sponsors. Ads appear only to adults, never to students, and never track you. A school license removes them.');}
function card(place){var a=pick();if(!a)return null;var el=document.createElement('aside');el.className='mm-ad mm-ad-'+place;el.setAttribute('aria-label',T('Sponsored'));el.setAttribute('data-ad',place);
  var head='<div class="mm-ad-top"><span class="mm-ad-tag">'+esc(T('Sponsored'))+'</span><button type="button" class="mm-ad-why" data-ad-why title="'+esc(why())+'">'+esc(T('Why?'))+'</button><button type="button" class="mm-ad-x" data-ad-hide="'+esc(place)+'" aria-label="'+esc(T('Hide this ad'))+'">×</button></div>';
  var h=a.house,img=safeImg(h.image);
  el.innerHTML=head+'<a class="mm-ad-body" href="'+esc(safeUrl(h.url))+'" target="_blank" rel="sponsored noopener noreferrer">'+(img?'<img src="'+esc(img)+'" alt="" loading="lazy">':'')+'<span class="mm-ad-text"><b>'+esc(h.title)+'</b>'+(h.text?'<span>'+esc(h.text)+'</span>':'')+(h.sponsor?'<small>'+esc(T('From'))+' '+esc(h.sponsor)+'</small>':'')+'</span>'+(h.cta?'<span class="mm-ad-cta">'+esc(h.cta)+'</span>':'')+'</a>'
    +(becomeUrl()?'<a class="mm-ad-become" href="'+esc(becomeUrl())+'" target="_blank" rel="noopener">'+esc(T('Sponsor this program'))+'</a>':'');
  return el;}
function becomeUrl(){var u=String(cfg&&cfg.becomeSponsor||'');return /^(https:\/\/|mailto:)[^\s"'<>]+$/i.test(u)?u:'';}

/* ---------- placements ---------- */
/* adults see the staff home (#mm-staff-home); #mm-home is the student home and stays hidden under it */
var SPOTS={home:function(){var ph=document.getElementById('mm-home');if(ph&&ph.classList.contains('compact')&&getComputedStyle(ph).display!=='none'&&ph.getClientRects().length){var sh0=document.getElementById('mm-staff-home');if(!sh0||getComputedStyle(sh0).display==='none'||!sh0.getClientRects().length)return ph.querySelector('.mm-home-grid')||ph;}var h=document.getElementById('mm-staff-home');if(!h||!(h.classList.contains('on')||document.documentElement.classList.contains('mm-staff-home-on'))||getComputedStyle(h).display==='none'||!h.getClientRects().length)return null;return h.querySelector('.mmsh-wrap')||h;},
  resources:function(){var p=document.getElementById('panel-resources');return p&&p.classList.contains('open')?p.querySelector('.panel-body')||p:null;}};
function refresh(){Object.keys(SPOTS).forEach(function(place){var host=SPOTS[place](),cur=document.querySelector('[data-ad="'+place+'"]');
  if(!eligible(place)||!host){if(cur)cur.remove();return;}
  if(cur&&host.contains(cur))return;if(cur)cur.remove();
  var el=card(place);if(el)host.appendChild(el);});}
document.addEventListener('click',function(e){var x=e.target.closest&&e.target.closest('[data-ad-hide]');
  if(x){e.preventDefault();e.stopPropagation();var place=x.getAttribute('data-ad-hide');dismissed[place]=1;try{sessionStorage.setItem('mmAdsHidden',JSON.stringify(dismissed));}catch(er){}var c=document.querySelector('[data-ad="'+place+'"]');if(c)c.remove();return;}
  var w=e.target.closest&&e.target.closest('[data-ad-why]');if(w){try{MM.util.toast(why(),6000);}catch(er){}}},true);

/* ---------- boot ---------- */
if(!HOSTED)return;
fetch('/ads.json',{headers:{Accept:'application/json'}}).then(function(r){return r.ok?r.json():null;}).catch(function(){return null;}).then(function(c){cfg=c;if(!cfg||!cfg.enabled)return;
  var t=0,kick=function(){clearTimeout(t);t=setTimeout(refresh,250);};
  new MutationObserver(kick).observe(document.documentElement,{attributes:true,attributeFilter:['class']});
  ['mm-staff-home','panel-resources'].forEach(function(id){var el=document.getElementById(id);if(el)new MutationObserver(kick).observe(el,{childList:true,attributes:true,attributeFilter:['class','style']});});
  setInterval(refresh,4000);refresh();});
})();
