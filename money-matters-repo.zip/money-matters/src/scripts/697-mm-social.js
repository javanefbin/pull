/* =====================================================================
   V19 · SIGN IN WITH GOOGLE, MICROSOFT OR FACEBOOK  (window.MMSocial)
   Hosted build only, and only for adults (teachers, parents, administrators).
   Students keep their sign-in codes: these providers do not allow accounts
   for children under 13, and students need no email.
   Flow
     1. A "Continue with …" button sends the person to the provider through
        Supabase Auth (PKCE). Nothing is stored before they choose.
     2. Back on the page, the one-time code is exchanged for a Supabase session,
        and /api/link asks Supabase who it is (the page cannot fake the email)
        and whether a license covers that email or its domain.
     3. The person is signed in to the account on this device with the same
        email. On a new device with no administrator yet, they become the
        administrator. Otherwise an administrator must add their email first.
     4. A licensed person's device gets a 30-day device token in place of an
        access code, and the page reloads with the full program.
     5. The Supabase session is discarded; only the device token is kept.
   Settings come from /api/config (off until the server is configured).
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
var ACC=MM.accounts,GATE=MM.gate,A=MM.auth,U=MM.util;
var HOSTED=!!window.MM_PUBLIC_BUILD&&/^https?:$/.test(location.protocol);
var NAMES={google:'Google',azure:'Microsoft',facebook:'Facebook',apple:'Apple'};
var INTENT='mmSocial_v1',cfg=null,client=null,busy=false;
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function toast(m,ms){try{U.toast(m,ms||4500);}catch(e){try{infoToast(m,ms||4500);}catch(x){}}}
function say(m,cls){try{GATE.message(m,cls||'');}catch(e){toast(m);}}

var API=window.MMSocial={enabled:function(){return !!(cfg&&cfg.auth);},providers:function(){return cfg&&cfg.auth?cfg.auth.providers:[];},start:start,buttons:buttons,_finish:finish,_setConfig:function(c){cfg=c;client=null;inject();}};

/* ---------- config + Supabase client ---------- */
function loadConfig(){if(!HOSTED)return Promise.resolve(null);
  return fetch('/api/config',{headers:{Accept:'application/json'}}).then(function(r){return r.ok?r.json():null;}).catch(function(){return null;}).then(function(c){cfg=c||{};return cfg;});}
function sb(){if(client)return client;if(!cfg||!cfg.auth||!window.supabase||!window.supabase.createClient)return null;
  client=window.supabase.createClient(cfg.auth.url,cfg.auth.key,{auth:{flowType:'pkce',storageKey:'mmSbAuth',persistSession:true,autoRefreshToken:false,detectSessionInUrl:false}});return client;}

/* ---------- buttons ---------- */
function buttons(){if(!API.enabled())return '';
  return '<div class="mm-social" role="group" aria-label="'+esc(T('Sign in with another account'))+'"><div class="mm-social-or"><span>'+esc(T('or continue with'))+'</span></div><div class="mm-social-row">'
    +API.providers().map(function(p){return '<button type="button" class="mm-social-btn" data-social="'+esc(p)+'"><span class="mm-social-mark" aria-hidden="true">'+esc(NAMES[p].charAt(0))+'</span>'+esc(NAMES[p])+'</button>';}).join('')
    +'</div><p class="mm-social-note">'+esc(T('For teachers, parents and administrators. Students sign in with their code.'))+'</p></div>';}
/* add the buttons to the staff side of the sign-in screen, the first-run setup, and the unlock dialog */
function inject(){if(!API.enabled())return;
  var g=document.getElementById('mm-auth');
  if(g&&!g.classList.contains('mm-hidden')&&!g.querySelector('.mm-social')){
    var staff=g.querySelector('[data-a=as][data-v=staff][aria-pressed=true]'),setup=g.querySelector('[data-a=dosetup]');
    var anchor=staff?g.querySelector('[data-a=login]'):setup;
    if(anchor&&anchor.parentNode){var d=document.createElement('div');d.innerHTML=buttons();anchor.parentNode.insertBefore(d.firstChild,anchor.nextSibling);}}
  var s=document.getElementById('mm-subscribe');
  if(s&&s.classList.contains('open')&&!s.querySelector('.mm-social')&&s.querySelector('[data-s=code]')){var acts=s.querySelector('.acts');if(acts){var d2=document.createElement('div');d2.innerHTML=buttons();acts.parentNode.insertBefore(d2.firstChild,acts.nextSibling);}}}
function watch(){['mm-auth'].forEach(function(id){var el=document.getElementById(id);if(el&&!el.__social){el.__social=1;new MutationObserver(inject).observe(el,{childList:true,subtree:true,attributes:true,attributeFilter:['class','aria-pressed']});}});
  new MutationObserver(function(){var s=document.getElementById('mm-subscribe');if(s&&!s.__social){s.__social=1;new MutationObserver(inject).observe(s,{childList:true,attributes:true,attributeFilter:['class']});inject();}}).observe(document.body,{childList:true});inject();}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-social]');if(!b)return;e.preventDefault();e.stopPropagation();start(b.getAttribute('data-social'));},true);

/* ---------- 1. leave for the provider ---------- */
function start(provider){if(busy||!NAMES[provider])return;var c=sb();if(!c){toast(T('Sign-in with other accounts is not set up for this site yet.'));return;}
  busy=true;try{sessionStorage.setItem(INTENT,JSON.stringify({p:provider,at:Date.now()}));}catch(e){}
  var opts={redirectTo:location.origin+location.pathname};if(provider==='azure')opts.scopes='email';
  c.auth.signInWithOAuth({provider:provider,options:opts}).then(function(r){if(r&&r.error){busy=false;toast(T('Could not start sign-in')+': '+r.error.message);}}).catch(function(err){busy=false;toast(T('Could not start sign-in')+': '+(err&&err.message||err));});}

/* ---------- 2. back from the provider ---------- */
function returning(){var q=new URLSearchParams(location.search),intent=null;try{intent=JSON.parse(sessionStorage.getItem(INTENT)||'null');}catch(e){}
  if(!intent||(!q.get('code')&&!q.get('error')))return false;
  try{sessionStorage.removeItem(INTENT);}catch(e){}
  var clean=location.pathname+location.hash;try{history.replaceState(null,'',clean);}catch(e){}
  if(q.get('error')){say((q.get('error_description')||T('Sign-in was cancelled.')).replace(/\+/g,' '),'err');return true;}
  var c=sb();if(!c){say(T('Sign-in with other accounts is not set up for this site yet.'),'err');return true;}
  say(T('Finishing sign-in with')+' '+(NAMES[intent.p]||'')+'…','info');
  c.auth.exchangeCodeForSession(q.get('code')).then(function(r){if(r.error||!r.data||!r.data.session)throw new Error(r.error?r.error.message:'no session');
      return fetch('/api/link',{method:'POST',headers:{Authorization:'Bearer '+r.data.session.access_token}}).then(function(x){return x.json().then(function(j){if(!x.ok)throw new Error(j.error||('HTTP '+x.status));return j;});});})
    .then(function(res){return finish(res);})
    .catch(function(err){say(T('Sign-in did not finish')+': '+(err&&err.message||err),'err');})
    .then(function(){try{c.auth.signOut({scope:'local'});}catch(e){}try{localStorage.removeItem('mmSbAuth');localStorage.removeItem('mmSbAuth-code-verifier');}catch(e){}});
  return true;}

/* ---------- 3-4. sign in on this device, license the device ---------- */
function rand(){var a=new Uint8Array(18);crypto.getRandomValues(a);return Array.from(a).map(function(b){return ('0'+b.toString(16)).slice(-2);}).join('');}
function finish(res){
  if(!res||!res.email){say(T('Sign-in did not return an email address.'),'err');return Promise.resolve(false);}
  var email=String(res.email).toLowerCase(),via=NAMES[res.provider]||res.provider||'';
  var acc=ACC.list().filter(function(a){return a.role!=='student'&&String(a.email||'').toLowerCase()===email;})[0]||null;
  var make=Promise.resolve(acc);
  if(!acc&&!ACC.admins().length){
    /* brand-new device: the first person to sign in sets it up as its administrator */
    make=ACC.add({username:ACC.uniqueUsername(email.split('@')[0]),name:res.name||email,email:email,role:'admin',password:rand(),by:'sign-in:'+(res.provider||'')}).then(function(r){if(r.error)throw new Error(r.error);try{localStorage.setItem('mmSetupDone','1');}catch(e){}ACC.log('user-add',r.account.u,'Administrator (signed in with '+via+')');return r.account;});}
  return make.then(function(a){
    var licensedNow=false;
    if(res.token){try{localStorage.setItem('mmAccess_v1',res.token);licensedNow=!window.__MM_FULL;}catch(e){}}
    if(!a){say(T('Signed in with')+' '+via+' '+T('as')+' '+email+'. '+T('This device has no Money Matters account with that email. Ask your administrator to add it in Admin Console → Users, then sign in again.')+(res.token?' '+T('The full program is unlocked on this device.'):''),res.token?'info':'err');
      if(licensedNow)setTimeout(function(){location.reload();},2600);return false;}
    if(a.locked||a.pending){say(T('Your account on this device is locked or waiting for approval. Ask your administrator.'),'err');return false;}
    if(!GATE.signInAccount(a,{})){say(T('Could not sign in to the account for')+' '+email+'.','err');return false;}
    if(!res.licensed&&res.reason)setTimeout(function(){toast(res.reason+' '+T('You are using the free edition (week 1 of every grade).'),6000);},800);
    if(licensedNow){toast(T('Unlocking the full program…'),2500);setTimeout(function(){location.reload();},900);}
    return true;
  }).catch(function(err){say(String(err&&err.message||err),'err');return false;});}

/* ---------- boot ---------- */
if(!HOSTED)return;
loadConfig().then(function(){if(!API.enabled())return;
  var go=function(){watch();returning();};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(go,400);});else setTimeout(go,400);});
})();
