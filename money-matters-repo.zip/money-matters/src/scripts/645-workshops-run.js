/* =====================================================================
   V21 · WORKSHOP RUN MODE  (window.MMWorkshopRun)
   A full-screen way to run a workshop day in front of the class, on a
   projector or from the teacher's phone:
     · one activity at a time, with a countdown timer sized to its minutes
       (start, pause, +1 minute, reset; a chime and a flash at time's up)
     · what students should see for that activity: the day's "I can" goals,
       words of the day, discussion questions, a brain-break idea, or a
       one-tap Game Show launcher
     · teacher notes (what to do, materials), shown or hidden with one tap
       so the projected screen stays clean
     · a team points board that lasts the whole day
     · progress dots, "Up next", Back / Next, and a finish step that marks
       the class complete so certificates can be printed
   Keys: → / PageDown next · ← / PageUp back · Space start or pause · N notes ·
   F full screen · Esc close. The screen stays awake while the timer runs.
   State lives in mmWorkshop_v1.run[<day key>] = {i, done, finished, points}
   and mmWorkshop_v1.teams, so a day can be paused and resumed.
   ===================================================================== */
(function(){
'use strict';
var WS=window.MMWorkshops;if(!WS||!WS._)return;var X=WS._;
var el=null,ctx=null,timer={left:0,total:0,running:false,last:0,id:0,warned:false},lastFocus=null,wake=null,gameReturn=false;
function T(s){try{return window.MMI18N?MMI18N.t(s):s;}catch(e){return s;}}
var esc=X.esc;
function sound(){try{return localStorage.getItem('mmWsRunSound')!=='off';}catch(e){return true;}}
function beep(kind){if(!sound())return;try{var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;var a=beep.ac||(beep.ac=new AC());var t=a.currentTime+.02;
  (kind==='end'?[784,659,523,784]:[880]).forEach(function(f,i){var o=a.createOscillator(),g=a.createGain();o.type='triangle';o.frequency.value=f;g.gain.setValueAtTime(0.0001,t+i*.18);g.gain.exponentialRampToValueAtTime(0.25,t+i*.18+.02);g.gain.exponentialRampToValueAtTime(0.0001,t+i*.18+.3);o.connect(g);g.connect(a.destination);o.start(t+i*.18);o.stop(t+i*.18+.32);});}catch(e){}}
function say(m){var l=el&&el.querySelector('.wr-live');if(l){l.textContent='';setTimeout(function(){l.textContent=m;},30);}}
function mmss(s){s=Math.max(0,Math.ceil(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');}

/* ---------- state ---------- */
function key(){return X.dkey(ctx.g,ctx.f,ctx.d);}
function state(){var s=X.st();s.run=s.run||{};var r=s.run[key()]||{i:0,done:{},points:{}};r.done=r.done||{};r.points=r.points||{};return r;}
function save(r){var s=X.st();s.run=s.run||{};s.run[key()]=r;X.put(s);}
function teams(){var s=X.st();return (s.teams&&s.teams.length?s.teams:[T('Team 1'),T('Team 2'),T('Team 3'),T('Team 4')]).slice(0,8);}
function setTeams(list){var s=X.st();s.teams=list;X.put(s);}

/* ---------- content for the current activity ---------- */
function blockAt(i){var D=ctx.D,b=D.blocks[i];if(!b)return null;var txt=b.how?b:X.frameText(b,ctx.g,ctx.f,ctx.d);var w=ctx.w,mod=b.mod!=null?w.modules[b.mod]:null;
  return {b:b,title:txt.title,how:txt.how,fun:txt.fun,kind:(X.KIND[b.kind]||['Activity','#555']),mod:mod};}
function studentPart(x){var w=ctx.w,mods=ctx.mods,h='',k=x.b.kind;
  var vocab=[];(x.mod?[x.mod]:mods).forEach(function(m){m.vocab.forEach(function(v){if(vocab.length<5&&!vocab.some(function(y){return y[0]===v[0];}))vocab.push(v);});});
  if(k==='welcome')h+='<div class="wr-box"><div class="wr-k">'+esc(T('Today I can'))+'</div><ul class="wr-list">'+w.outcomes.slice(0,4).map(function(o){return '<li>'+esc(o.replace(/^I can /i,''))+'</li>';}).join('')+'</ul></div>';
  else if(k==='discuss'||k==='reflect'){var qs=[].concat.apply([],(x.mod?[x.mod]:mods).map(function(m){return m.debrief;})).slice(0,3);if(qs.length)h+='<div class="wr-box"><div class="wr-k">'+esc(T('Talk about it'))+'</div><ol class="wr-list">'+qs.map(function(q){return '<li>'+esc(q)+'</li>';}).join('')+'</ol></div>';
    if(k==='reflect'){var last=mods[mods.length-1];h+='<div class="wr-box wr-home"><div class="wr-k">'+esc(T('Take-home challenge'))+'</div><p>'+esc(last.takeHome)+'</p></div>';}}
  else if(k==='break')h+='<div class="wr-box wr-break"><div class="wr-big" aria-hidden="true">🤸</div><p>'+esc(x.how)+'</p></div>';
  else if(k==='game'){var gm=mods[mods.length-1].game;h+='<div class="wr-box wr-game"><p>'+esc(T('Teams play a Game Show round built from this grade’s lessons. Winning team earns bonus points.'))+'</p><button type="button" class="wr-btn wr-gold" data-wr="game" data-m="'+esc(gm)+'">🎮 '+esc(T('Launch'))+' '+esc(X.gameName(gm))+'</button></div>';}
  if(vocab.length&&k!=='break'&&k!=='game'&&k!=='reflect')h+='<div class="wr-box"><div class="wr-k">'+esc(T('Words of the day'))+'</div><dl class="wr-vocab">'+vocab.map(function(v){return '<div><dt>'+esc(v[0])+'</dt><dd>'+esc(v[1])+'</dd></div>';}).join('')+'</dl></div>';
  return h;}
function notesPart(x){return '<div class="wr-notes"><div class="wr-k">'+esc(T('Teacher notes'))+'</div><p>'+esc(x.how||'')+'</p>'+(x.b.materials&&x.b.materials.length?'<p class="wr-mat"><b>'+esc(T('Materials'))+':</b> '+esc(x.b.materials.join(', '))+'</p>':'')+'</div>';}

/* ---------- render ---------- */
function build(){if(el)return el;el=document.createElement('div');el.id='ws-run';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label',T('Run workshop'));el.hidden=true;document.body.appendChild(el);
  el.addEventListener('click',onClick);el.addEventListener('toggle',function(e){if(e.target.classList&&e.target.classList.contains('wr-teams'))tOpen=e.target.open;},true);return el;}
var tOpen=null;function teamsOpen(){return tOpen==null?innerWidth>560:tOpen;}
function notesOn(){try{var v=localStorage.getItem('mmWsRunNotes');if(v)return v==='on';}catch(e){}return innerWidth<900;}
function render(){var r=state(),i=Math.min(r.i||0,ctx.D.blocks.length-1),x=blockAt(i),N=ctx.D.blocks.length,next=blockAt(i+1),fin=!!r.finished&&i===N-1;
  var t=0;for(var j=0;j<i;j++)t+=ctx.D.blocks[j].min;
  var h='<div class="wr-top"><div class="wr-title"><span class="wr-k">'+esc(ctx.w.title)+' · '+esc(T('Day'))+' '+(ctx.d+1)+' '+esc(T('of'))+' '+wsDays(ctx.f)+'</span><b>'+esc(T('Activity'))+' '+(i+1)+' '+esc(T('of'))+' '+N+' · '+esc(X.clock(X.st().start,t))+'</b></div>'
    +'<div class="wr-tools"><button type="button" class="wr-ic" data-wr="notes" aria-pressed="'+notesOn()+'" title="'+esc(T('Teacher notes'))+' (N)">📝<span>'+esc(T('Notes'))+'</span></button><button type="button" class="wr-ic" data-wr="sound" aria-pressed="'+sound()+'" title="'+esc(T('Sound'))+'">'+(sound()?'🔔':'🔕')+'<span>'+esc(T('Sound'))+'</span></button><button type="button" class="wr-ic" data-wr="fs" title="'+esc(T('Full screen'))+' (F)">⛶<span>'+esc(T('Full screen'))+'</span></button><button type="button" class="wr-ic wr-x" data-wr="close" aria-label="'+esc(T('Close'))+'">✕</button></div></div>';
  h+='<div class="wr-main"><section class="wr-stage" style="--kc:'+x.kind[1]+'"><div class="wr-kind">'+esc(T(x.kind[0]))+(x.mod&&ctx.mods.length>1&&x.b.kind!=='game'&&x.b.kind!=='break'?' · <span>'+esc(x.mod.title)+'</span>':'')+'</div><h2 id="wr-h">'+esc(x.title)+'</h2>'+(x.fun?'<p class="wr-fun">'+esc(x.fun)+'</p>':'')
    +'<div class="wr-content">'+studentPart(x)+'</div>'+(notesOn()?notesPart(x):'')+'</section>';
  h+='<aside class="wr-side"><div class="wr-timer'+(timer.left<=0&&timer.total?' up':'')+'" role="timer" aria-live="off"><svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="52" class="wr-ring-bg"/><circle cx="60" cy="60" r="52" class="wr-ring" style="stroke-dasharray:326.7;stroke-dashoffset:'+(326.7*(1-(timer.total?timer.left/timer.total:1))).toFixed(1)+'"/></svg><div class="wr-clock"><b>'+mmss(timer.left)+'</b><span>'+esc(timer.left<=0&&timer.total?T('Time’s up'):x.b.min+' '+T('min'))+'</span></div></div>'
    +'<div class="wr-tbtns"><button type="button" class="wr-btn wr-go" data-wr="tstart">'+(timer.running?'⏸ '+esc(T('Pause')):'▶ '+esc(T(timer.left<timer.total?'Resume':'Start timer')))+'</button><button type="button" class="wr-btn" data-wr="tplus">+1 '+esc(T('min'))+'</button><button type="button" class="wr-btn" data-wr="treset">↺</button></div>'
    +(function(){var tm=teams(),best=-1,bi=-1;tm.forEach(function(_,ti){var v=r.points[ti]||0;if(v>best){best=v;bi=ti;}});var lead=best>0?tm[bi]+' '+T('leads')+' · '+best:T('No points yet');
      return '<details class="wr-teams"'+(teamsOpen()?' open':'')+'><summary><span class="wr-k">'+esc(T('Team points'))+'</span><span class="wr-lead">'+esc(lead)+'</span></summary>';})()+teams().map(function(n,ti){var p=r.points[ti]||0;return '<div class="wr-team"><span class="wr-tn">'+esc(n)+'</span><button type="button" class="wr-pt" data-wr="pt" data-t="'+ti+'" data-v="-1" aria-label="'+esc(T('Take a point from'))+' '+esc(n)+'">−</button><b aria-live="polite">'+p+'</b><button type="button" class="wr-pt" data-wr="pt" data-t="'+ti+'" data-v="1" aria-label="'+esc(T('Give a point to'))+' '+esc(n)+'">+</button></div>';}).join('')+'<button type="button" class="wr-link" data-wr="teams">'+esc(T('Edit teams'))+'</button></details></aside></div>';
  h+='<div class="wr-bottom"><button type="button" class="wr-btn" data-wr="prev"'+(i===0?' disabled':'')+'>← '+esc(T('Back'))+'</button><ol class="wr-dots" aria-label="'+esc(T('Activities'))+'">'+ctx.D.blocks.map(function(b,j){var y=blockAt(j);return '<li><button type="button" data-wr="jump" data-i="'+j+'" class="'+(j===i?'on ':'')+(r.done[j]?'done':'')+'" style="--kc:'+y.kind[1]+'" aria-label="'+esc((j+1)+'. '+y.title+(r.done[j]?' ('+T('done')+')':''))+'"'+(j===i?' aria-current="step"':'')+'>'+(r.done[j]?'✓':j+1)+'</button></li>';}).join('')+'</ol>'
    +(i<N-1?'<div class="wr-next"><span>'+esc(T('Up next'))+'</span><b>'+esc(next.title)+'</b><em>'+next.b.min+' '+esc(T('min'))+'</em></div><button type="button" class="wr-btn wr-gold" data-wr="next">'+esc(T('Next'))+' →</button>'
      :'<button type="button" class="wr-btn wr-gold" data-wr="finish">'+(fin?'🎓 '+esc(T('Day finished')):'🎓 '+esc(T('Finish the day'))) +'</button>')+'</div>'
    +'<div class="wr-live sr-only" aria-live="assertive"></div>';
  el.innerHTML=h;el.style.setProperty('--kc',x.kind[1]);}
function paint(){if(!el||el.hidden)return;var c=el.querySelector('.wr-clock b'),ring=el.querySelector('.wr-ring'),tb=el.querySelector('.wr-timer'),lbl=el.querySelector('.wr-clock span');
  if(c)c.textContent=mmss(timer.left);if(ring)ring.style.strokeDashoffset=(326.7*(1-(timer.total?timer.left/timer.total:1))).toFixed(1);
  if(tb){tb.classList.toggle('up',timer.left<=0&&timer.total>0);tb.classList.toggle('low',timer.left>0&&timer.left<=60);}
  if(lbl&&timer.left<=0&&timer.total)lbl.textContent=T('Time’s up');}

/* ---------- timer ---------- */
function setTimer(min){stop();timer.total=timer.left=min*60;timer.warned=false;}
function tick(){var now=Date.now(),dt=(now-timer.last)/1000;timer.last=now;timer.left-=dt;
  if(!timer.warned&&timer.left<=60&&timer.total>90){timer.warned=true;say(T('One minute left'));beep('warn');}
  if(timer.left<=0){timer.left=0;stop();beep('end');say(T('Time’s up'));render();return;}paint();}
function startT(){if(timer.left<=0)timer.left=timer.total;timer.running=true;timer.last=Date.now();clearInterval(timer.id);timer.id=setInterval(tick,250);awake(true);}
function stop(){timer.running=false;clearInterval(timer.id);awake(false);}
function awake(on){try{if(on&&navigator.wakeLock&&!wake){navigator.wakeLock.request('screen').then(function(w){wake=w;}).catch(function(){});}else if(!on&&wake){wake.release();wake=null;}}catch(e){}}

/* ---------- navigation ---------- */
function go(i,markDone){var r=state(),N=ctx.D.blocks.length;if(markDone)r.done[r.i||0]=true;r.i=Math.max(0,Math.min(N-1,i));save(r);setTimer(ctx.D.blocks[r.i].min);render();var h=el.querySelector('#wr-h');if(h){h.setAttribute('tabindex','-1');try{h.focus({preventScroll:true});}catch(e){}}say(blockAt(r.i).title);}
function finish(){var r=state(),N=ctx.D.blocks.length;r.done[N-1]=true;r.finished=Date.now();save(r);stop();
  var side=el.querySelector('.wr-side');if(side)side.remove();var ro=X.roster(ctx.g),pts=r.points,tm=teams(),best=Object.keys(pts).sort(function(a,b){return (pts[b]||0)-(pts[a]||0);})[0];
  el.querySelector('.wr-main').innerHTML='<section class="wr-stage wr-end"><div class="wr-big" aria-hidden="true">🎓</div><h2 id="wr-h">'+esc(T('Day'))+' '+(ctx.d+1)+' '+esc(T('complete'))+'</h2>'
    +(best!=null&&pts[best]>0?'<p class="wr-fun">🏆 '+esc(tm[best]||'')+' · '+pts[best]+' '+esc(T('points'))+'</p>':'')
    +'<div class="wr-box"><div class="wr-k">'+esc(T('Certificates'))+'</div>'+(ro.length?'<p>'+esc(T('Mark every student in this grade complete, then print a certificate for each one.'))+'</p><button type="button" class="wr-btn wr-gold" data-wr="allcert">'+esc(T('Mark all complete and print certificates'))+'</button>':'<p>'+esc(T('Add students to this grade to track completion and print certificates for the whole class. You can still print one certificate at a time on the plan page.'))+'</p>')+'</div>'
    +'<div class="wr-box wr-home"><div class="wr-k">'+esc(T('Take-home challenge'))+'</div><p>'+esc(ctx.mods[ctx.mods.length-1].takeHome)+'</p></div></section>';
  say(T('Day complete'));}
function allCert(){var s=X.st(),k=key();X.roster(ctx.g).forEach(function(x){s.done[x.id]=s.done[x.id]||{};if(!s.done[x.id][k])s.done[x.id][k]=Date.now();});X.put(s);close();
  try{openPanel('workshops');}catch(e){}setTimeout(function(){X.view.day=ctx.d;WS.render();var b=document.querySelector('#workshopsBody [data-ws=cert-class]');if(b){b.scrollIntoView({block:'center'});b.click();}},200);}

/* ---------- events ---------- */
function onClick(e){var b=e.target.closest&&e.target.closest('[data-wr]');if(!b||b.disabled)return;var a=b.getAttribute('data-wr'),r=state();
  if(a==='close')return close();
  if(a==='next')return go((r.i||0)+1,true);
  if(a==='prev')return go((r.i||0)-1,false);
  if(a==='jump')return go(+b.getAttribute('data-i'),false);
  if(a==='finish')return finish();
  if(a==='allcert')return allCert();
  if(a==='tstart'){if(timer.running)stop();else startT();render();return;}
  if(a==='tplus'){timer.left+=60;timer.total+=60;if(timer.left>timer.total)timer.total=timer.left;render();return;}
  if(a==='treset'){setTimer(ctx.D.blocks[r.i||0].min);render();return;}
  if(a==='notes'){try{localStorage.setItem('mmWsRunNotes',notesOn()?'off':'on');}catch(x){}render();return;}
  if(a==='sound'){try{localStorage.setItem('mmWsRunSound',sound()?'off':'on');}catch(x){}render();return;}
  if(a==='fs'){try{if(document.fullscreenElement)document.exitFullscreen();else el.requestFullscreen();}catch(x){}return;}
  if(a==='pt'){var ti=b.getAttribute('data-t');r.points[ti]=Math.max(0,(r.points[ti]||0)+(+b.getAttribute('data-v')));save(r);var v=b.parentNode.querySelector('b');if(v)v.textContent=r.points[ti];if(+b.getAttribute('data-v')>0)beep('warn');return;}
  if(a==='teams'){var cur=teams().join(', ');var ask=function(v){if(v==null)return;var l=String(v).split(',').map(function(s){return s.trim().slice(0,24);}).filter(Boolean).slice(0,8);if(l.length){setTeams(l);render();}};
    try{mmInput(T('Team names'),cur,{icon:'🏆',okLabel:T('Save'),subtext:T('Separate names with commas (up to 8 teams).')}).then(ask);var inp=document.querySelector('#mm-modal-body input');if(inp)setTimeout(function(){inp.value=cur;},90);}catch(x){ask(prompt(T('Team names'),cur));}return;}
  if(a==='game'){stop();gameReturn=true;el.hidden=true;document.documentElement.classList.remove('wr-on');behind(false);try{MMGameShow.open(b.getAttribute('data-m'),{grade:ctx.g});}catch(x){gameReturn=false;el.hidden=false;}return;}}
document.addEventListener('keydown',function(e){if(!el||el.hidden)return;if(document.getElementById('mm-modal-backdrop')&&document.getElementById('mm-modal-backdrop').classList.contains('open'))return;
  var t=e.target,typing=t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName);if(typing)return;var r=state();
  if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();}
  else if(e.key==='ArrowRight'||e.key==='PageDown'){e.preventDefault();if((r.i||0)<ctx.D.blocks.length-1)go((r.i||0)+1,true);}
  else if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();go((r.i||0)-1,false);}
  else if(e.key===' '&&!(t&&t.tagName==='BUTTON')){e.preventDefault();if(timer.running)stop();else startT();render();}
  else if(e.key==='n'||e.key==='N'){try{localStorage.setItem('mmWsRunNotes',notesOn()?'off':'on');}catch(x){}render();}
  else if(e.key==='f'||e.key==='F'){try{if(document.fullscreenElement)document.exitFullscreen();else el.requestFullscreen();}catch(x){}}},true);
/* back from the Game Show: reopen where we were */
new MutationObserver(function(){if(gameReturn&&!document.documentElement.classList.contains('mm-gs-on')){gameReturn=false;if(ctx){el.hidden=false;document.documentElement.classList.add('wr-on');behind(true);var r=state();go((r.i||0)+1,true);}}}).observe(document.documentElement,{attributes:true,attributeFilter:['class']});

/* ---------- open / close ---------- */
var BEHIND=['.panel.open','#mm-topbar','#nav','#mm-tabbar','#scene','#mm-staff-home','#mm-home'];
function behind(on){BEHIND.forEach(function(sel){document.querySelectorAll(sel).forEach(function(n){if(on){if(!n.hasAttribute('inert')){n.setAttribute('inert','');n.__wrInert=1;}}else if(n.__wrInert){n.removeAttribute('inert');n.__wrInert=0;}});});}
function open(g,f,d){var w=X.W(g);if(!w||w.locked)return;var D=X.day(g,f,d);ctx={g:g,f:f,d:d,w:w,D:D,mods:D.mods.map(function(i){return w.modules[i];})};
  lastFocus=document.activeElement;build();var r=state();if(r.finished){r.finished=0;r.i=0;r.done={};save(r);}
  setTimer(D.blocks[Math.min(r.i||0,D.blocks.length-1)].min);el.hidden=false;document.documentElement.classList.add('wr-on');behind(true);render();
  var f0=el.querySelector('.wr-go');if(f0)try{f0.focus({preventScroll:true});}catch(e){}}
function close(){stop();if(!el)return;el.hidden=true;document.documentElement.classList.remove('wr-on');behind(false);try{if(document.fullscreenElement)document.exitFullscreen();}catch(e){}
  try{if(document.querySelector('#panel-workshops.open'))WS.render();}catch(e){}
  if(lastFocus&&document.contains(lastFocus))try{lastFocus.focus({preventScroll:true});}catch(e){}else{var b=document.querySelector('#workshopsBody [data-ws=run]');if(b)try{b.focus();}catch(e){}}}
window.MMWorkshopRun={open:open,close:close,isOpen:function(){return !!(el&&!el.hidden);}};
})();
