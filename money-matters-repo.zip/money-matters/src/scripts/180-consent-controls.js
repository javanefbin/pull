/* Mobile-safe consent controls. This listener is intentionally placed immediately
   after the banner so it still works even if a later app feature throws an error. */
(function(){
  var banner=document.getElementById('consent-banner');
  if(!banner)return;
  function dismiss(){
    try{localStorage.setItem('mmConsent_v1','1');}catch(e){}
    banner.classList.add('hidden');
    banner.style.pointerEvents='none';
    setTimeout(function(){ if(banner && banner.parentNode) banner.parentNode.removeChild(banner); },450);
  }
  var accept=document.getElementById('consent-accept-btn');
  if(accept){
    accept.addEventListener('click',dismiss,{passive:true});
    accept.addEventListener('touchend',function(e){ e.preventDefault(); dismiss(); },{passive:false});
  }
  banner.querySelectorAll('[data-legal]').forEach(function(btn){
    btn.addEventListener('click',function(){
      var tab=btn.getAttribute('data-legal');
      dismiss();
      setTimeout(function(){
        if(typeof openPanel==='function') openPanel('legal');
        setTimeout(function(){
          if(typeof showLegalTab==='function'){
            var target=document.querySelector('.legal-nav button[onclick*="\''+tab+'\'"]');
            showLegalTab(tab,target||null);
          }
        },80);
      },20);
    });
  });
})();
