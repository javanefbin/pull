(function(){'use strict';
/* V81 Story Mode: four acts, eight scenes, events, a loan, matching, and a finale decision. */
var S_DATA=/*@include data/S_DATA.json*/;
var SC={
 goal:{name:'Goal Builder',difficulty:'Practice',icon:'\uD83C\uDFAF',desc:'Steady earnings and visible money effects. Practice saving toward a goal.',a:'Earnings are steady, and each choice shows its money effect.'},
 spending:{name:'Smart Spending',difficulty:'Core',icon:'\uD83D\uDED2',desc:'Earnings vary with luck, and a tempting limited-time deal appears.',a:'Earnings change from play to play, and a tempting deal is waiting.'},
 surprise:{name:'Plan for the Unexpected',difficulty:'Challenge',icon:'\uD83E\uDDF0',desc:'Earnings vary, the surprise costs 50 percent more, and effects stay hidden until you choose.',a:'Earnings vary, effects stay hidden, and the surprise costs more.'}};
var SKILL={'Earning':'Earning & Income','Spending':'Spending Decisions','Saving':'Saving & Goals','A surprise':'Planning for the Unexpected'};
var ICON={'Earning':'\uD83D\uDEE0\uFE0F','Spending':'\uD83D\uDED2','Saving':'\uD83C\uDFFA','A surprise':'\uD83C\uDF81'};
var ST=null,SCN={};
var EMO={'Earning':'\uD83D\uDEE0\uFE0F','A second chance to earn':'\uD83E\uDD1D','Spending':'\uD83D\uDED2','Everyone has one':'\uD83D\uDECD\uFE0F','Saving':'\uD83C\uDFFA','A lucky find':'\uD83D\uDD0D','A friend asks for a loan':'\uD83D\uDE4F','A matching offer':'\uD83C\uDF81','A coupon':'\uD83C\uDFF7\uFE0F','A surprise':'\u26A1','Goal day':'\uD83C\uDFC1'};
function sidK(){try{var a=activeStudent();return a?a.id:'guest';}catch(x){return 'guest';}}
function scnGet(){return SCN[sidK()+':'+currentGrade]||null;}
function scnSet(v){SCN[sidK()+':'+currentGrade]=v;}
function runKey(){return 'mmStoryRun_v2_'+sidK()+'_'+currentGrade;}
function persist(){try{if(!ST||!ST.on)return;var c=JSON.parse(JSON.stringify(ST));delete c.v;c.ver=2;localStorage.setItem(runKey(),JSON.stringify(c));}catch(x){}}
function clearRun(){try{localStorage.removeItem(runKey());}catch(x){}}
function savedRun(){try{var r=JSON.parse(localStorage.getItem(runKey())||'null');return r&&r.on&&r.ver===2&&r.g===currentGrade&&r.id&&r.a<4?r:null;}catch(x){return null;}}
function ensureFree(sc){var has=sc.o.some(function(o){return (Array.isArray(o[1])||o[1]>=0)&&(o[2]||0)>=0&&o[4]==null;});if(!has)sc.o.push(['Keep the money for now',0,0,'Nothing changes this time. Wallet: ${w}. Jar: ${j}.']);}
function bindKeys(){if(bindKeys.d)return;bindKeys.d=1;document.addEventListener('keydown',function(ev){var p=$('panel-story');if(!p||!p.classList.contains('open'))return;if(ev.ctrlKey||ev.metaKey||ev.altKey)return;var t=ev.target;if(t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)&&t.type!=='radio')return;var n=parseInt(ev.key,10);if(!(n>=1&&n<=9))return;
  var b=document.querySelectorAll('#storyBody .st-opt:not([disabled])');if(b.length){if(b[n-1]){ev.preventDefault();b[n-1].click();}return;}
  var r=document.querySelectorAll('#storyBody input[name=stq]:not([disabled])');if(r.length&&r[n-1]){ev.preventDefault();r[n-1].click();r[n-1].focus();}});}
function langNote(){var l='en';try{l=loadLang();}catch(x){}if(l==='en')return '';return '<div class="card"><p class="st-note">Story Mode is in English for now. Press Listen to hear it read aloud. \u00B7 El modo Historia est\u00E1 en ingl\u00E9s por ahora. \u00B7 O modo Hist\u00F3ria est\u00E1 em ingl\u00EAs por enquanto.</p></div>';}
function resumeCard(S){var r=savedRun();if(!r)return '';return '<div class="card st-resume"><div class="st-kicker">Story in progress</div><p class="st-scene">You stopped in Act '+(r.a+1)+' of 4 ('+E(SC[r.id].name)+'). Your choices and money are saved.</p><div class="meta-pills"><button type="button" class="btn-calc green" id="stResume">Resume my story</button></div><p class="st-note">Starting a new story below replaces this one.</p></div>';}
function bindResume(S){var b=$('stResume');if(b)b.onclick=function(){var r=savedRun();if(!r)return;ST=r;ST.v=variant(S,r.id);ST.on=1;window.renderStory();};}
function $(i){return document.getElementById(i);}
function E(x){return String(x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function cap(s){return s.charAt(0).toUpperCase()+s.slice(1);}
function sid(){try{var a=activeStudent();return a?a.id:'guest';}catch(e){return 'guest';}}
function rk(g){return 'mmStoryRef_'+sid()+'_'+g;}
function ek(id,g){return 'mmStoryEvidence_v1_'+id+'_'+g;}
function loadEv(g,id){try{return JSON.parse(localStorage.getItem(ek(id||sid(),g))||'[]')||[];}catch(e){return [];}}
function saveEv(g,rec){try{var x=loadEv(g);x.unshift(rec);localStorage.setItem(ek(sid(),g),JSON.stringify(x.slice(0,20)));}catch(e){}}
function best(g){try{var v=myProg()['story|'+g+'|1'];return v==null?null:Math.round(v/25);}catch(e){return null;}}
function adaptive(g){var ev=loadEv(g);if(!ev.length)return 'goal';var s=ev[0].score;return s<60?'goal':(s<85?'spending':'surprise');}
function rn(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function shuf(a){var r=a.slice(),i,j,t;for(i=r.length-1;i>0;i--){j=Math.floor(Math.random()*(i+1));t=r[i];r[i]=r[j];r[j]=t;}return r;}
function variant(S,id){var V=JSON.parse(JSON.stringify(S)),f=function(n){return Math.round(n*1.5);},sc=function(t){return t.replace(/\$(\d+)/g,function(m,n){return '$'+f(+n);});};
 if(id==='goal')V.c.forEach(function(c){c.o.forEach(function(o){if(Array.isArray(o[1]))o[1]=Math.round((o[1][0]+o[1][1])/2);});});
 if(id==='spending'){var deal=Math.max(3,Math.round(V.w*0.6));V.c[1].o.splice(1,0,['Limited-time deal: buy it now!',-deal,0,'The deal looked exciting, and the money is gone. Wallet: ${w}.',deal]);V.c[1].x+=' A sign says: Limited-time deal, today only!';}
 if(id==='surprise'){var c=V.c[3];c.x=sc(c.x)+' Prices are higher than expected this time.';c.o.forEach(function(o){var cost=o[1]<0||o[2]<0;if(o[1]<0)o[1]=-f(-o[1]);if(o[2]<0)o[2]=-f(-o[2]);if(o[4]!=null)o[4]=f(o[4]);if(cost)o[0]=sc(o[0]);});}
 return V;}
function bar(S){var pct=Math.max(0,Math.min(100,Math.round(ST.j/S.g[1]*100)));
 return '<div class="st-bar" role="group" aria-label="Money status"><span>\uD83D\uDC5B Wallet: $'+ST.w+'</span><span>\uD83C\uDFFA Jar: $'+ST.j+' of $'+S.g[1]+'</span><div class="st-prog" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+pct+'" aria-label="Savings goal progress"><i style="width:'+pct+'%"></i></div></div>';}
function sub(t){return t.replace(/\{w\}/g,ST.w).replace(/\{j\}/g,ST.j).replace(/\{d\}/g,ST.d);}
function listen(){return ('speechSynthesis' in window)?'<button type="button" class="st-listen" id="stLis">\uD83D\uDD0A Listen</button>':'';}
function bindListen(){var b=$('stLis');if(!b)return;b.onclick=function(){try{var ss=window.speechSynthesis;if(ss.speaking){ss.cancel();return;}var u=new SpeechSynthesisUtterance($('storyBody').innerText.replace(/\s+/g,' '));var lg=(typeof loadLang==='function'?loadLang():'en');u.lang=lg==='es'?'es-ES':(lg==='pt'?'pt-BR':'en-US');u.rate=.9;ss.cancel();ss.speak(u);}catch(e){}};}
function draw(h){try{window.speechSynthesis&&window.speechSynthesis.cancel();}catch(e){}var b=$('storyBody');if(b)b.innerHTML=h;bindListen();persist();var p=$('panel-story'),pb=p&&p.querySelector('.panel-body');if(pb){var cs=b?b.querySelectorAll('.card,.story-question'):[],tg=cs.length?cs[cs.length-1]:null;if(tg&&ST&&ST.ph){setTimeout(function(){pb.scrollTop=Math.max(0,tg.getBoundingClientRect().top-pb.getBoundingClientRect().top+pb.scrollTop-10);},30);}else pb.scrollTop=0;}try{var f=b&&b.querySelector('.st-kicker');if(f&&p&&p.classList.contains('open')){f.setAttribute('tabindex','-1');f.focus({preventScroll:true});}}catch(x){}}
function actPills(S){return '<div class="st-acts" role="list">'+S.c.map(function(c,i){var cls=i<ST.a?'done':(i===ST.a?'current':''),dots='';
  for(var k=0;k<2;k++){var dn=i<ST.a||(i===ST.a&&(k<ST.k||(k===ST.k&&(ST.ph==='result'||ST.ph==='ask'||ST.ph==='fb'))||(ST.ph==='ask'||ST.ph==='fb')));dots+='<i class="'+(dn?'on':'')+'"></i>';}
  return '<div class="st-act '+cls+'" role="listitem"><span>'+(ICON[c.n]||'')+' Act '+(i+1)+'</span><b>'+E(c.n)+'</b><span class="st-dots" aria-hidden="true">'+dots+'</span></div>';}).join('')+'</div>';}
function journal(){if(!ST.log.length)return '';return '<details class="st-log"><summary>Story so far ('+ST.log.length+' of 8 scenes)</summary><ol>'+ST.log.map(function(l){return '<li><b>'+E(l.t)+':</b> '+E(l.c)+'<br><small>'+E(l.r)+'</small></li>';}).join('')+'</ol></details>';}
function shell(S,inner){return listen()+'<div class="st-kicker">'+E(S.h)+'\u2019s story \u00B7 '+E(SC[ST.id].name)+'</div>'+actPills(S)+bar(S)+inner+journal();}
function tTable(){try{if(loadRole()!=='teacher')return '';var s=loadStore(),rows='';
 Object.keys(s.list).forEach(function(id){var st=s.list[id],g=st.grade||'K',ev=loadEv(g,id)[0];if(!ev)return;
  var sk=Object.keys(ev.skills||{}).map(function(k){var x=ev.skills[k];return E(k)+' '+x.correct+'/'+x.total;}).join('; ');
  rows+='<tr><td>'+E(st.name)+'</td><td>'+E(g)+'</td><td>'+ev.score+'%</td><td>'+E((SC[ev.scenario]||{}).name||ev.scenario)+'</td><td>'+sk+'</td><td>'+E((ev.decisions||[]).join(' \u2192 '))+'</td></tr>';});
 return rows?'<div class="card"><div class="st-kicker">Story evidence (Teacher/Parent view)</div><div style="overflow-x:auto"><table class="st-table"><tr><th>Student</th><th>Grade</th><th>Latest</th><th>Path</th><th>Skills</th><th>Decisions</th></tr>'+rows+'</table></div></div>':'';}catch(e){return '';}}
function intro(S,pickId){var rec=adaptive(currentGrade),id=pickId||scnGet()||rec,sc=SC[id],ev=loadEv(currentGrade)[0],b=best(currentGrade);
 var pk='<div class="card"><div class="st-kicker">Choose your story path</div><p class="st-note">All three paths use the same story and different rules. Recommended next: <b>'+SC[rec].icon+' '+E(SC[rec].name)+'</b>.</p><div class="story-scenario-grid">'
  +Object.keys(SC).map(function(k){var x=SC[k];return '<button type="button" class="story-scenario '+(k===id?'selected':'')+'" data-scenario="'+k+'" aria-pressed="'+(k===id)+'"><span class="story-scenario-title">'+x.icon+' '+E(x.name)+'</span><span class="story-scenario-meta">'+E(x.difficulty)+' \u00B7 '+E(x.desc)+'</span></button>';}).join('')+'</div></div>';
 draw(listen()+'<div class="story-hero"><div class="story-hero-top"><div class="story-avatar">\uD83C\uDFAD</div><div><div class="st-kicker">'+E(S.h)+'\u2019s story \u00B7 '+E(sc.name)+'</div><h2>'+E(S.t)+'</h2><p>'+E(S.i)+'</p><p class="st-note"><b>This path:</b> '+E(sc.a)+'</p></div></div><div class="story-goal"><span class="story-chip">\uD83C\uDFAF Goal: $'+S.g[1]+' '+E(S.g[0])+'</span><span class="story-chip">\uD83D\uDC5B Starting wallet: $'+S.w+'</span><span class="story-chip">\uD83D\uDCD6 4 acts, 8 scenes</span><span class="story-chip">\uD83E\uDDE0 4 scored checkpoints</span></div></div>'
  +langNote()+resumeCard(S)+pk+'<div class="card"><div class="st-kicker">How Story Mode works</div><ol class="card-body" style="padding-left:20px"><li>Read each scene and make a choice. Choices are not scored.</li><li>See what happens. Luck, friends, and surprises all play a part.</li><li>After two scenes, answer a checkpoint question. Checkpoints are scored.</li><li>End with a big decision, look back, and rewind to try again.</li></ol>'
  +(ev?'<p class="st-note">Latest result: <b>'+ev.score+'%</b> on '+E((SC[ev.scenario]||{}).name||'')+'.</p>':'')+(b!=null?'<p class="st-note">Best so far: <b>'+b+' of 4</b> checkpoints.</p>':'')
  +'<button type="button" class="btn-calc green" id="stGo">Start '+E(sc.name)+'</button></div>'+tTable());
 bindResume(S);$('storyBody').querySelectorAll('[data-scenario]').forEach(function(x){x.onclick=function(){scnSet(x.dataset.scenario);intro(S,x.dataset.scenario);};});
 $('stGo').onclick=function(){scnSet(id);var V=variant(S,id);ST={on:1,g:currentGrade,id:id,v:V,a:0,k:0,w:V.w,j:0,p:[],log:[],s:0,e:0,sp:0,sv:0,u:0,d:0,pre:V.w,lent:0,rp:null,bought:null,cp:0,cpUsed:0,ph:'scene',o:null,cur:null,res:'',cq:null,at:0,hist:[],ad:[],sk:{}};startAct(V);};}
function startAct(S){ST.k=0;ST.pre=ST.w;ST.cq=null;ST.at=0;
 ST.hist[ST.a]={w:ST.w,j:ST.j,pl:ST.p.length,ll:ST.log.length,s:ST.s,e:ST.e,sp:ST.sp,sv:ST.sv,u:ST.u,lent:ST.lent,rp:ST.rp,bought:ST.bought,cp:ST.cp,cpUsed:ST.cpUsed,sk:JSON.parse(JSON.stringify(ST.sk)),ad:JSON.parse(JSON.stringify(ST.ad))};
 var c=S.c[ST.a];ST.cur={t:c.n,x:c.x,o:c.o};showScene(S);}
function second(S){var a=ST.a,p=S.p,h=S.h,f=p.f,o,x,t;
 if(a===0){var j=p.job;t='A second chance to earn';x=f+' needs help to '+j[0]+' this weekend and will pay $'+j[1]+'. It is at the same time as '+j[2]+'.';
  o=[['Take the job',j[1],0,h+' earns $'+j[1]+' and misses '+j[2]+'.'],['Go to '+j[2]+' instead',0,0,h+' has a great time. No money comes in.'],['Ask '+f+' to do it another day',[0,j[1]],0,f+' says maybe later. This time '+h+' earns ${d}.']];}
 else if(a===1){var s=p.shop;t='Everyone has one';x=f+' is showing '+s[0]+' that costs $'+s[1]+'. Other kids already have one.';
  o=[['Buy '+s[0],-s[1],0,h+' has one too, and '+f+' grins. Wallet: ${w}.',s[1]],['Buy '+s[2]+' for $'+s[3],-s[3],0,h+' gets something similar for less. Wallet: ${w}.',s[3]],['Skip it and keep the money',0,0,h+' keeps the money while '+f+' shows the others. Wallet: ${w}.']];}
 else if(a===2){var kind=['found','borrow','match','coupon'][rn(0,3)],e=p.ev;ST.evk=kind;
  if(kind==='found'){t='A lucky find';x=h+' finds $'+e[0]+' in an old coat pocket. It is '+h+'\u2019s to use. Wallet: $'+(ST.w+e[0])+'.';ST.w+=e[0];ST.e+=e[0];
   o=[['Put it in the jar',-e[0],e[0],'The jar grows. Jar: ${j}.'],['Spend it on a treat',-e[0],0,'The treat is tasty and gone by lunch. Wallet: ${w}.'],['Keep it in the wallet',0,0,'The money waits in the wallet. Wallet: ${w}.']];}
  else if(kind==='borrow'){var b=e[1],hb=Math.max(1,Math.floor(b/2));t='A friend asks for a loan';x=f+' forgot lunch money and asks to borrow $'+b+'. '+f+' says they will pay it back.';
   o=[['Lend $'+b,-b,0,f+' says thanks. The wallet is smaller now. Wallet: ${w}.',b,{ln:b}],['Lend half ($'+hb+')',-hb,0,f+' says thanks and buys a smaller lunch. Wallet: ${w}.',hb,{ln:hb}],['Say no kindly',0,0,f+' understands and asks someone else. Wallet: ${w}.']];}
  else if(kind==='coupon'){var cv=Math.max(1,Math.round(e[2]/2));t='A coupon';x=h+' is handed a coupon for 20 percent off one purchase.';o=[['Keep the coupon for goal day',0,0,h+' tucks the coupon away. It could make a purchase cheaper later.',null,{cp:1}],['Sell the coupon to '+f+' for $'+cv,cv,0,f+' pays $'+cv+' for it. Wallet: ${w}.'],['Say no thanks',0,0,'Nothing changes. Wallet: ${w}.']];}
  else{var m=e[2],hm=Math.max(1,Math.floor(m/2));t='A matching offer';x='A family member offers to match any money '+h+' puts in the jar today, up to $'+m+'.';
   o=[['Put in $'+m,-m,2*m,'The family member adds $'+m+' too. Jar: ${j}.',m],['Put in $'+hm,-hm,2*hm,'The family member adds $'+hm+' too. Jar: ${j}.',hm],['Not today',0,0,'The offer ends. Jar: ${j}.']];}}
 else{var G0=S.g[1],pre='';t='Goal day';
  if(ST.lent>0&&!ST.rp){if(Math.random()<0.65){ST.w+=ST.lent;ST.rp='yes';pre=f+' pays back $'+ST.lent+'. ';}else{ST.rp='no';pre=f+' says they need more time to pay back $'+ST.lent+'. ';}}
  var W=ST.w,J=ST.j,on=W+J,al=p.alt,cpn=!!ST.cp,G=cpn?Math.ceil(G0*0.8):G0,AL=cpn?Math.ceil(al[1]*0.8):al[1],pay=function(c){var wd=Math.min(W,c);return [-wd,-(c-wd)];};
  x=pre+'It is goal day. '+cap(S.g[0])+' costs $'+G0+'.'+(cpn?' With the 20 percent coupon it costs $'+G+'.':'')+' '+h+' has $'+W+' in the wallet and $'+J+' in the jar.';
  var bg=pay(G),ba=pay(AL),f1={buy:'goal'},f2={buy:'alt'};if(cpn){f1.disc=1;f2.disc=1;}
  o=[['Buy '+S.g[0]+(cpn?' with the coupon for $'+G:''),on>=G?bg[0]:0,on>=G?bg[1]:0,h+' buys '+S.g[0]+'. Wallet: ${w}. Jar: ${j}.',on>=G?null:1e9,f1],
     ['Buy '+al[0]+(cpn?' with the coupon':'')+' for $'+AL+' instead',on>=AL?ba[0]:0,on>=AL?ba[1]:0,h+' brings home '+al[0]+'. The bigger goal is still waiting. Wallet: ${w}. Jar: ${j}.',on>=AL?null:1e9,f2]];
  if(W>0)o.push(['Move the wallet money into the jar',-W,W,'All the money is in one place now. Jar: ${j}.']);
  o.push(['Keep saving for now',0,0,h+' decides to wait. Wallet: ${w}. Jar: ${j}.']);}
 if(ST.id==='goal')o.forEach(function(q){if(Array.isArray(q[1]))q[1]=Math.round((q[1][0]+q[1][1])/2);});return {t:t,x:x,o:o};}
function showScene(S){ST.ph='scene';var sc=ST.cur,show=ST.id!=='surprise',n=ST.a*2+ST.k+1;ensureFree(sc);
 var h='<div class="card"><div class="st-kicker">Scene '+n+' of 8 \u00B7 '+E(sc.t)+'</div><div class="st-row"><span class="st-emoji" aria-hidden="true">'+(EMO[sc.t]||'\u2728')+'</span><p class="st-scene">'+E(sc.x)+'</p></div><p class="st-tip">Tip: press 1, 2, or 3 to choose.</p><div class="st-opts">';
 sc.o.forEach(function(o,i){var need=Array.isArray(o[1])?0:-o[1],lowW=(need>0&&ST.w<need)||(o[4]!=null&&ST.w<o[4]),lowJ=(o[2]<0&&ST.j<-o[2]),dis=lowW||lowJ;
  h+='<button type="button" class="story-choice-card st-opt" data-i="'+i+'"'+(dis?' disabled':'')+'><span class="story-choice-title">'+E(o[0])+'</span><span class="story-choice-meta">'+chips(o,show)+(dis?'<span class="story-impact cost">'+(lowJ&&!lowW?'Not enough in the jar':'Not enough money')+'</span>':'')+'</span></button>';});
 draw(shell(S,h+'</div></div>'));
 $('storyBody').querySelectorAll('.st-opt').forEach(function(b){b.onclick=function(){choose(S,+b.dataset.i);};});}
function chips(o,show){if(!show)return '<span class="story-impact">Result unknown until you choose</span>';var h='',d=o[1],j=o[2]||0,ln=o[5]&&o[5].ln;
 if(Array.isArray(d))h+='<span class="story-impact save">+$'+d[0]+' to +$'+d[1]+' wallet (varies)</span>';else{if(d>0)h+='<span class="story-impact save">+$'+d+' wallet</span>';if(d<0)h+='<span class="story-impact cost">\u2212$'+(-d)+' wallet'+(ln?' (a loan)':'')+'</span>';}
 if(j>0)h+='<span class="story-impact save">+$'+j+' to jar</span>';if(j<0)h+='<span class="story-impact cost">\u2212$'+(-j)+' from jar</span>';if(!d&&!j)h+='<span class="story-impact">No money changes</span>';return h;}
function choose(S,i){var sc=ST.cur,o=sc.o[i],d=Array.isArray(o[1])?rn(o[1][0],o[1][1]):o[1],jd=o[2]||0,fl=o[5]||{},w0=ST.w,j0=ST.j;
 ST.d=d;ST.w+=d;ST.j+=jd;if(d>0)ST.e+=d;if(d<0&&!fl.ln)ST.sp+=Math.max(0,-d-Math.max(0,jd));if(jd>0)ST.sv+=jd;if(jd<0&&!fl.buy)ST.u+=-jd;if(fl.ln)ST.lent+=fl.ln;if(fl.cp)ST.cp=1;if(fl.buy){ST.bought=fl.buy;if(fl.disc)ST.cpUsed=1;}
 if(ST.k===0){var t=SKILL[S.c[ST.a].n]||S.c[ST.a].n;ST.sk[t]={skill:t,chapter:S.c[ST.a].n,choice:o[0],correct:0,total:0};ST.ad[ST.a]={pre:ST.pre,d:d,j:ST.j,jpre:j0,jd:jd};}
 ST.res=sub(o[3]);ST.dw=ST.w-w0;ST.dj=ST.j-j0;ST.log.push({t:sc.t,c:o[0],r:ST.res});ST.p.push(o[0]);ST.o=o;ST.ph='result';showResult(S);}
function dchip(v,l){return v?'<span class="story-impact '+(v>0?'save':'cost')+'">'+l+' '+(v>0?'+':'\u2212')+'$'+Math.abs(v)+'</span>':'';}
function showResult(S){var last=ST.k===1;
 draw(shell(S,'<div class="card"><div class="st-kicker">What happened</div><p class="st-result" role="status">'+E(ST.res)+'</p><div class="st-delta">'+dchip(ST.dw,'Wallet')+dchip(ST.dj,'Jar')+'</div><button type="button" class="btn-calc green" id="stCont">'+(last?'Go to the checkpoint':'Next scene')+'</button></div>'));
 var b=$('stCont');b.onclick=function(){cont(S);};b.focus();}
function cont(S){if(ST.k===0){ST.k=1;ST.cur=second(S);showScene(S);}else{ST.ph='ask';ST.cq=null;ST.at=0;ask(S);}}
function mk(q,ans,dist,ex){var d=[];dist.forEach(function(x){if(x>=0&&x!==ans&&d.indexOf(x)<0)d.push(x);});d=d.slice(0,2);var o=shuf([ans].concat(d)).map(function(x){return '$'+x;});return {q:q,o:o,a:o.indexOf('$'+ans),e:ex};}
function mkQ(S){var a=ST.a,h=S.h,q=S.c[a].q,m=ST.ad[a]||{};
 if(a===1&&m.d<0){var s=-m.d,b=m.pre,r=b-s;return mk('Before the first spending scene, '+h+' had $'+b+'. '+h+' spent $'+s+' there. How much was left right after?',r,[b+s,s,r+1,b],'$'+b+' \u2212 $'+s+' = $'+r+'.');}
 if(a===2&&m.j>0){var g=S.g[1],r2=g-m.j;return mk('After the saving scene, the jar held $'+m.j+'. '+cap(S.g[0])+' costs $'+g+'. How much more does '+h+' need in the jar?',r2,[g+m.j,m.j,r2+1,r2-1],'$'+g+' \u2212 $'+m.j+' = $'+r2+'.');}
 if(a===3&&m.jd<0){var cj=-m.jd,rj=m.jpre-cj;return mk('Before the surprise, the jar held $'+m.jpre+'. The jar paid $'+cj+'. How much was left in the jar right after?',rj,[m.jpre+cj,cj,rj+1,m.jpre],'$'+m.jpre+' \u2212 $'+cj+' = $'+rj+'.');}
 if(a===3&&m.d<0){var cs=-m.d,bs=m.pre,rs=bs-cs;return mk('Before the surprise, '+h+' had $'+bs+' in the wallet. The surprise cost $'+cs+'. How much was left right after?',rs,[bs+cs,cs,rs+1,bs],'$'+bs+' \u2212 $'+cs+' = $'+rs+'.');}
 var ix=shuf([0,1,2]);return {q:q[0],o:ix.map(function(i){return q[1][i];}),a:ix.indexOf(q[2]),e:q[3]};}
function ask(S){if(!ST.cq)ST.cq=mkQ(S);var Q=ST.cq,last=ST.a===S.c.length-1;
 var h='<div class="story-question"><div class="st-kicker">Checkpoint '+(ST.a+1)+' of 4 \u00B7 '+E(S.h)+' asks</div><p class="st-scene" id="stq">'+E(Q.q)+'</p><div role="radiogroup" aria-labelledby="stq" class="st-opts">';
 Q.o.forEach(function(t,i){h+='<label class="st-radio"><input type="radio" name="stq" value="'+i+'"> <span>'+E(t)+'</span></label>';});
 draw(shell(S,h+'</div><button type="button" class="btn-calc" id="stChk" disabled>Check my answer</button><div id="stFb" aria-live="polite"></div></div>'));
 var chk=$('stChk'),radios=function(){return $('storyBody').querySelectorAll('input[name=stq]');};
 radios().forEach(function(r){r.onchange=function(){chk.disabled=false;};});
 function done(ok,first){ST.ph='fb';radios().forEach(function(r){r.disabled=true;});chk.disabled=true;
  $('stFb').innerHTML='<div class="story-feedback"><p class="st-fb '+(ok?'ok':'no')+'"><b>'+(ok?(first?'\u2713 That\u2019s right.':'\u2713 Right this time.'):'Not quite.')+'</b> '+E(Q.e)+'</p><button type="button" class="btn-calc green" id="stNext">'+(last?'See how it ended':'Continue to Act '+(ST.a+2))+'</button></div>';
  var nb=$('stNext');nb.onclick=function(e){if(e)e.preventDefault();if(nb.disabled)return;nb.disabled=true;nextAct(S);};nb.focus();}
 chk.onclick=function(){var sel=$('storyBody').querySelector('input[name=stq]:checked');if(!sel)return;var ok=+sel.value===Q.a;ST.at++;
  var t=SKILL[S.c[ST.a].n]||S.c[ST.a].n;if(ST.at===1&&ST.sk[t]){ST.sk[t].total=1;if(ok)ST.sk[t].correct=1;}
  if(ok){if(ST.at===1)ST.s++;done(true,ST.at===1);}
  else if(ST.at===1){$('stFb').innerHTML='<p class="st-fb no"><b>Not quite.</b> Look at the numbers and the story again, then try once more.</p>';sel.checked=false;chk.disabled=true;}
  else done(false,false);};}
function nextAct(S){if(ST.a+1<S.c.length){ST.a++;ST.ph='scene';startAct(S);}else end(S);}
function rewind(S,a){var h=ST.hist[a];if(!h)return;ST.on=1;ST.a=a;ST.w=h.w;ST.j=h.j;ST.p=ST.p.slice(0,h.pl);ST.log=ST.log.slice(0,h.ll);ST.s=h.s;ST.e=h.e;ST.sp=h.sp;ST.sv=h.sv;ST.u=h.u;ST.lent=h.lent;ST.rp=h.rp;ST.bought=h.bought;ST.cp=h.cp;ST.cpUsed=h.cpUsed;ST.sk=JSON.parse(JSON.stringify(h.sk));ST.ad=JSON.parse(JSON.stringify(h.ad));startAct(S);}
function snap(S){return '<ul class="st-skills">'+S.c.map(function(c){var t=SKILL[c.n]||c.n,x=ST.sk[t],ok=x&&x.total&&x.correct;return '<li>'+(ok?'\u2713':'\u2022')+' <b>'+E(t)+':</b> '+(x&&x.total?(ok?'right on the first try':'needed another look'):'not checked')+'</li>';}).join('')+'</ul>';}
function cmp(prev,score){if(!prev)return '';var d=score-prev.score;return '<p class="st-note">Last time: '+prev.score+'% ('+E((SC[prev.scenario]||{}).name||'')+'). This time: '+score+'%'+(d>0?' \u2014 up '+d+' points.':(d<0?' \u2014 down '+(-d)+' points. Try rewinding to an act.':' \u2014 the same.'))+'</p>';}
function end(S){var prev=loadEv(currentGrade)[0];ST.on=0;ST.ph='end';clearRun();var j=ST.j,g=S.g[1],st=[],score=Math.round(ST.s/S.c.length*100);
 try{recordScore('story',currentGrade,'1',score);}catch(e){}
 saveEv(currentGrade,{date:new Date().toLocaleString(),score:score,scenario:ST.id,difficulty:SC[ST.id].difficulty,correct:ST.s,decisions:ST.p.slice(),skills:ST.sk,wallet:ST.w,saved:ST.j,earned:ST.e,spent:ST.sp,bought:ST.bought,lent:ST.lent,repaid:ST.rp,coupon:ST.cp?1:0,couponUsed:ST.cpUsed?1:0});
 if(ST.bought==='goal')st.push(S.h+' reached the goal and bought '+S.g[0]+'. What would you do if a surprise cost came tomorrow?');
 else if(ST.bought==='alt')st.push(S.h+' chose '+S.p.alt[0]+' instead of '+S.g[0]+'. What did that trade give up, and what did it give?');
 else if(ST.w+j>=g)st.push(S.h+' had enough for '+S.g[0]+' and chose to wait. What are the good and bad parts of waiting?');
 else if(j>0)st.push('If '+S.h+' put $'+j+' in the jar every weekend, '+S.g[0]+' would take about '+Math.ceil((g-j)/j)+' more weekends.');
 if(ST.lent>0)st.push(ST.rp==='yes'?'The loan was paid back. How could you decide who is safe to lend to?':'The loan was not paid back yet. What could you ask or agree on before lending?');
 if(ST.sv===0&&ST.u===0)st.push('The jar stayed empty. What would a small deposit have changed?');
 if(ST.u>0)st.push('Jar money paid for the surprise. How did that change the goal?');
 if(ST.sp===0)st.push('Nothing was spent. What could the money do that spending could not?');
 if(ST.cp&&!ST.cpUsed)st.push('The coupon was never used. When would a coupon help most?');
 if(ST.cp&&ST.cpUsed)st.push('The coupon saved money. Why is it smart to plan before you buy?');
 var saved='';try{saved=localStorage.getItem(rk(currentGrade))||'';}catch(e){}
 var rw='';S.c.forEach(function(c,i){rw+='<button type="button" class="btn-calc st-rw" data-c="'+i+'">Act '+(i+1)+': '+E(c.n)+'</button>';});
 var fam='What is one money choice we can plan for before it happens?';
 draw(listen()+'<div class="st-kicker">\uD83D\uDD0D Looking back \u00B7 '+E(SC[ST.id].name)+'</div>'+bar(S)+'<div class="card"><h2 class="st-title">'+E(S.h)+'\u2019s story is done</h2>'
  +'<ul class="st-stats"><li>Earned: $'+ST.e+'</li><li>Spent: $'+ST.sp+'</li><li>Put in the jar: $'+ST.sv+'</li>'+(ST.u?'<li>Taken from the jar: $'+ST.u+'</li>':'')+(ST.lent?'<li>Lent to '+E(S.p.f)+': $'+ST.lent+(ST.rp==='yes'?' (paid back)':' (not paid back yet)')+'</li>':'')+'<li>Ended with: wallet $'+ST.w+' and jar $'+j+'</li><li>The goal: '+E(S.g[0])+' for $'+g+(ST.bought==='goal'?' (bought)':ST.bought==='alt'?' (chose '+E(S.p.alt[0])+' instead)':' (not bought yet)')+'</li></ul>'
  +'<p><b>Your path:</b> '+ST.p.map(E).join(' \u2192 ')+'</p><p><b>'+E(S.h)+' asks:</b> '+ST.s+' of '+S.c.length+' checkpoints answered correctly on the first try.</p>'+snap(S)+cmp(prev,score)
  +(st.length?'<div class="st-starters"><b>Think about it:</b><ul>'+st.map(function(x){return '<li>'+E(x)+'</li>';}).join('')+'</ul></div>':'')+'</div>'
  +'<div class="card"><label for="stRef" class="st-scene">'+E(S.r)+'</label><textarea id="stRef" class="quiz-input" rows="4" maxlength="600" style="width:100%;box-sizing:border-box">'+E(saved)+'</textarea>'
  +'<div class="meta-pills"><button type="button" class="btn-calc green" id="stSave">Save reflection</button><button type="button" class="btn-calc" id="stAgain">Choose a path and play again</button></div><div id="stSt" class="who" role="status"></div></div>'
  +'<div class="story-family"><b>\uD83C\uDFE0 Family connection</b><div style="margin-top:5px">Ask someone at home: \u201C'+fam+'\u201D Share one idea from your story.</div><div class="meta-pills" style="margin-top:8px"><button type="button" class="btn-calc ghost" id="stCopyFamily">Copy family prompt</button></div></div>'
  +'<div class="card"><div class="st-kicker">Rewind and try a different choice</div><div class="meta-pills">'+rw+'</div></div>'+journal());
 $('stSave').onclick=function(){var v=$('stRef').value;try{localStorage.setItem(rk(currentGrade),v);var ev=loadEv(currentGrade);if(ev[0]){ev[0].reflection=v;localStorage.setItem(ek(sid(),currentGrade),JSON.stringify(ev));}}catch(e){}$('stSt').textContent='\u2713 Reflection saved.';};
 $('stAgain').onclick=function(){scnSet(null);intro(S0());};
 $('stCopyFamily').onclick=function(){var cp=$('stCopyFamily'),tx='Money Matters family prompt: '+fam+' Share one idea from your story.';if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(tx).then(function(){cp.textContent='\u2713 Copied';},function(){prompt('Copy this family prompt:',tx);});else prompt('Copy this family prompt:',tx);};
 $('storyBody').querySelectorAll('.st-rw').forEach(function(b){b.onclick=function(){rewind(S,+b.dataset.c);};});}
function S0(){return S_DATA[currentGrade];}
window.renderStory=function(){var S=S0();
 if(!S){draw('<div class="card"><p>This grade\u2019s story is part of the full curriculum. Enter an access code from the sign-in screen or the settings button to play it.</p></div>');return;}
 if(ST&&ST.on&&ST.g===currentGrade){var V=ST.v;if(ST.ph==='fb'){nextAct(V);return;}if(ST.ph==='ask'){ask(V);return;}if(ST.ph==='result'){showResult(V);return;}showScene(V);return;}
 intro(S);};
bindKeys();
if(typeof _panelRenderers!=='undefined')_panelRenderers.story=function(){window.renderStory();};
try{if(typeof CHANGELOG!=='undefined')CHANGELOG.unshift({date:'October 2026',items:['Story Mode fix: every grade\u2019s savings goal can now be reached on a careful path.','New coupon event that changes the price on goal day.','Resume a story after closing the page. Your path choice is remembered per student.','Checkpoint 4 now uses your own numbers. Scene pictures, keyboard shortcuts (press 1, 2, 3), and a skills snapshot at the end.']});}catch(e){}
})();
