/* =====================================================================
   V91 · PROFESSIONAL SUITE — CORE
   Modules in this file:
     MM91.util   small DOM/format helpers shared by every v91 module
     MM91.data   read-only + write helpers over the existing local store
     MM91.auth   session helpers + the professional sign-in gate
     MM91.shell  top bar, grouped navigation, routing, session panel
   Everything here wraps existing globals; nothing in the original
   curriculum engine is removed.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91=window.MM91||{};
MM.VERSION='91';

/* ---------- MM91.util ---------- */
var U=MM.util={
  $:function(id){return document.getElementById(id);},
  E:function(s){try{return typeof esc==='function'?esc(s):String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}catch(e){return '';}},
  t:function(k){try{return typeof t==='function'?t(k):k;}catch(e){return k;}},
  toast:function(m,ms){try{infoToast(m,ms||3000);}catch(e){try{alert(m);}catch(x){}}},
  initials:function(name){var p=String(name||'?').trim().split(/\s+/);return ((p[0]||'?').charAt(0)+(p.length>1?p[p.length-1].charAt(0):'')).toUpperCase();},
  hue:function(str){var h=0,s=String(str||'');for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h%360;},
  avatar:function(name,cls){return '<span class="mm-avatar '+(cls||'')+'" style="background:linear-gradient(135deg,hsl('+U.hue(name)+',38%,34%),hsl('+((U.hue(name)+30)%360)+',45%,48%))" aria-hidden="true">'+U.E(U.initials(name))+'</span>';},
  pct:function(a,b){return b?Math.round(a/b*100):0;},
  fmtDate:function(d){try{var x=(d instanceof Date)?d:new Date(d);return isNaN(x)?String(d||'—'):x.toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'});}catch(e){return '—';}},
  fmtDateTime:function(d){try{var x=new Date(d);return isNaN(x)?String(d||'—'):x.toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}catch(e){return '—';}},
  download:function(name,content,type){try{var b=new Blob([content],{type:type||'text/plain'});var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},1500);return true;}catch(e){U.toast('Download is not supported in this browser.');return false;}},
  csv:function(rows){return '﻿'+rows.map(function(r){return r.map(function(v){v=String(v==null?'':v).replace(/\r?\n/g,' ');return '"'+v.replace(/"/g,'""')+'"';}).join(',');}).join('\r\n');},
  openHTML:function(title,body,extraCss){var html='<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+U.E(title)+'</title><style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:28px;max-width:900px;margin:0 auto;color:#222}h1{font-family:Georgia,serif;font-size:26px;margin:0 0 4px}h2{font-size:14px;letter-spacing:.08em;text-transform:uppercase;color:#7a5a1e;border-bottom:2px solid #c4912e;padding-bottom:4px;margin:22px 0 8px}table{width:100%;border-collapse:collapse;font-size:12.5px;margin:8px 0}th,td{border:1px solid #ddd;padding:7px 9px;text-align:left;vertical-align:top}th{background:#f3e9d6;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#7a5a1e}.k{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#8a5e10;font-weight:800}.sub{color:#666;font-size:13px}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0}.stat{border:1px solid #e3d6bd;border-radius:10px;padding:10px;background:#fffdf8}.stat b{display:block;font-size:22px;color:#2a6b4a}.stat span{font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:#786c5b}.note{padding:10px 12px;border-left:4px solid #c4912e;background:#fbf5e8;border-radius:6px;font-size:12.5px}.foot{margin-top:24px;padding-top:10px;border-top:1px solid #ddd;color:#888;font-size:10px}@media print{body{padding:0}}'+(extraCss||'')+'</style></head><body>'+body+'</body></html>';
    try{var b=new Blob([html],{type:'text/html'});var u=URL.createObjectURL(b);var w=window.open(u,'_blank');if(!w){U.toast('Allow pop-ups to open this report.');URL.revokeObjectURL(u);return;}setTimeout(function(){URL.revokeObjectURL(u);},30000);}catch(e){var fw=window.open('','_blank');if(fw){fw.document.write(html);fw.document.close();}}},
  on:function(root,evt,sel,fn){root.addEventListener(evt,function(e){var el=e.target.closest(sel);if(el&&root.contains(el))fn(e,el);});},
  debounce:function(fn,ms){var tm;return function(){var a=arguments,s=this;clearTimeout(tm);tm=setTimeout(function(){fn.apply(s,a);},ms||150);};}
};
var $=U.$,E=U.E;

/* ---------- MM91.data ---------- */
var D=MM.data={
  GRADES:['K','1','2','3','4','5','6','7','8'],
  store:function(){try{return loadStore();}catch(e){return {list:{},teachers:[]};}},
  list:function(){var s=D.store();return Object.keys(s.list||{}).map(function(id){var st=s.list[id];if(!st.id)st.id=id;return st;});},
  get:function(id){var s=D.store();return (s.list&&s.list[id])||null;},
  update:function(id,fn){var s=D.store();if(!s.list||!s.list[id])return false;fn(s.list[id],s);saveStore(s);return true;},
  teachers:function(){var s=D.store(),set={};(s.teachers||[]).forEach(function(x){if(x)set[x]=1;});Object.keys(s.list||{}).forEach(function(id){var x=s.list[id].teacher;if(x)set[x]=1;});return Object.keys(set).sort(function(a,b){return a.localeCompare(b);});},
  teacherMeta:function(name){var s=D.store();return (s.teacherMeta&&s.teacherMeta[name])||{};},
  setTeacherMeta:function(name,meta){var s=D.store();s.teacherMeta=s.teacherMeta||{};s.teacherMeta[name]=Object.assign({},s.teacherMeta[name]||{},meta);saveStore(s);},
  renameTeacher:function(oldName,newName){newName=String(newName||'').trim().slice(0,60);if(!newName||newName===oldName)return false;var s=D.store();s.teachers=(s.teachers||[]).map(function(x){return x===oldName?newName:x;}).filter(function(x,i,a){return a.indexOf(x)===i;});Object.keys(s.list||{}).forEach(function(id){if(s.list[id].teacher===oldName)s.list[id].teacher=newName;});if(s.teacherMeta&&s.teacherMeta[oldName]){s.teacherMeta[newName]=s.teacherMeta[oldName];delete s.teacherMeta[oldName];}saveStore(s);return true;},
  removeTeacher:function(name){var s=D.store();s.teachers=(s.teachers||[]).filter(function(x){return x!==name;});Object.keys(s.list||{}).forEach(function(id){if(s.list[id].teacher===name)delete s.list[id].teacher;});if(s.teacherMeta)delete s.teacherMeta[name];saveStore(s);},
  studentsOf:function(name){return D.list().filter(function(st){return (st.teacher||'')===name;});},
  lessons:function(g){try{return (typeof LESSONS!=='undefined'&&LESSONS[g])||[];}catch(e){return [];}},
  tests:function(g){try{return (typeof SECTION_TESTS!=='undefined'&&SECTION_TESTS[g])||[];}catch(e){return [];}},
  gradeLabel:function(g){try{return gradeLabel(g);}catch(e){return g==='K'?'Kindergarten':'Grade '+g;}},
  gradeShort:function(g){return g==='K'?'K':'Gr '+g;},
  fa:function(id){try{var o=JSON.parse(localStorage.getItem('mmFinancialAssessment_v1')||'{}'),a=(o[id]&&o[id].attempts)||[];return {latest:a.length?a[a.length-1]:null,attempts:a};}catch(e){return {latest:null,attempts:[]};}},
  faReflection:function(id){try{var o=JSON.parse(localStorage.getItem('mmFinancialAssessmentReflection_v1')||'{}');return o[id]||null;}catch(e){return null;}},
  story:function(id,g){try{return JSON.parse(localStorage.getItem('mmStoryEvidence_v1_'+id+'_'+g)||'[]')||[];}catch(e){return [];}},
  storyReflection:function(id,g){var ev=D.story(id,g)[0];if(ev&&ev.reflection)return ev.reflection;try{return localStorage.getItem('mmStoryRef_'+id+'_'+g)||'';}catch(e){return '';}},
  games:function(id){var all={};try{all=mmGameStats();}catch(e){}var g=all[id]||{},rows=[],p=0,c=0,a=0;Object.keys(g).forEach(function(k){var x=g[k]||{};if(!(x.played>0))return;rows.push({name:k,played:x.played,correct:x.correct||0,attempts:x.attempts||0,acc:x.attempts?Math.round(x.correct/x.attempts*100):0,best:x.best||0});p+=x.played;c+=x.correct||0;a+=x.attempts||0;});rows.sort(function(x,y){return y.played-x.played;});return {rows:rows,played:p,correct:c,attempts:a,acc:a?Math.round(c/a*100):0};},
  gameReflections:function(id){try{var o=JSON.parse(localStorage.getItem('mmReflection_v1')||'{}'),g=o[id]||{};return Object.keys(g).filter(function(k){return g[k]&&g[k].text;}).map(function(k){return {game:k,text:g[k].text,date:g[k].date};}).sort(function(a,b){return String(b.date).localeCompare(String(a.date));});}catch(e){return [];}},
  quizReflections:function(id,g){var out=[];D.lessons(g).forEach(function(l){try{var r=JSON.parse(localStorage.getItem('mmQuizReflection_v2|'+id+'|'+g+'|'+l.week)||'null');if(!r)return;var parts=[];if(Array.isArray(r))parts=r.filter(Boolean);else['learned','realLife','confidence'].forEach(function(k){if(r[k]&&String(r[k]).trim())parts.push(String(r[k]).trim());});if(parts.length)out.push({week:l.week,title:l.title,text:parts.join(' · '),date:r.date||r.at||null});}catch(e){}});return out;},
  achievements:function(){try{return mmAchievements();}catch(e){return {};}},
  usage:function(){try{return loadUsage();}catch(e){return {};}},
  lastActive:function(st){if(!st||!st.lastActive)return {date:null,days:null,label:'Never'};var d=new Date(st.lastActive);if(isNaN(d))return {date:null,days:null,label:String(st.lastActive)};var days=Math.floor((Date.now()-d.getTime())/86400000);return {date:d,days:days,label:days<=0?'Today':days===1?'Yesterday':days+' days ago'};},
  stats:function(st){
    var g=st.grade||'K',ls=D.lessons(g),p=st.prog||{},passed=0,viewed=0,retry=0,sum=0,n=0,gold=0;
    ls.forEach(function(l){var v=p['quiz|'+g+'|'+l.week];if(v!=null){n++;sum+=Number(v);if(v>=90)gold++;if(v>=75)passed++;else retry++;}if(p['view|'+g+'|'+l.week])viewed++;});
    var tests=D.tests(g),tp=0,tt=0;tests.forEach(function(x,i){var v=p['test|'+g+'|u'+(i+1)];if(v!=null){tt++;if(v>=75)tp++;}});
    var fa=D.fa(st.id).latest,story=D.story(st.id,g)[0]||null,games=D.games(st.id),last=D.lastActive(st);
    var all=0;try{all=progStatsFor(p).taken;}catch(e){}
    var out={grade:g,total:ls.length,passed:passed,retry:retry,viewed:viewed,pct:U.pct(passed,ls.length),avg:n?Math.round(sum/n):0,taken:n,takenAll:all,gold:gold,tests:tp,testsTaken:tt,totalTests:tests.length,complete:ls.length>0&&passed>=ls.length,fa:fa,story:story,games:games,last:last,streak:st.streak||0,ws:Object.keys(st.ws||{}).length};
    out.medal=out.gold>=1?'🏆':out.passed>=1?'🥇':out.taken>=1?'🎖️':'⭐';
    out.status=D.status(out);
    return out;
  },
  status:function(s){if(s.complete)return {k:'complete',l:'Grade complete',c:'ok'};if(s.last.days==null&&!s.taken&&!s.viewed)return {k:'new',l:'Not started',c:'info'};if(s.retry>0&&s.avg<60)return {k:'support',l:'Needs support',c:'bad'};if(s.last.days!=null&&s.last.days>14)return {k:'inactive',l:'Inactive 14+ days',c:'warn'};return {k:'ontrack',l:'On track',c:'ok'};},
  classStats:function(list){var out={n:list.length,avgPct:0,avgQuiz:0,active7:0,assessed:0,faAvg:0,byStatus:{},complete:0,storyRuns:0,gamePlays:0},sp=0,sq=0,qn=0,fs=0;list.forEach(function(st){var s=D.stats(st);sp+=s.pct;if(s.taken){sq+=s.avg;qn++;}if(s.last.days!=null&&s.last.days<=7)out.active7++;if(s.fa){out.assessed++;fs+=s.fa.score;}out.byStatus[s.status.k]=(out.byStatus[s.status.k]||0)+1;if(s.complete)out.complete++;if(s.story)out.storyRuns++;out.gamePlays+=s.games.played;});out.avgPct=list.length?Math.round(sp/list.length):0;out.avgQuiz=qn?Math.round(sq/qn):0;out.faAvg=out.assessed?Math.round(fs/out.assessed):0;return out;},
  notes:function(id){var st=D.get(id);return (st&&st.notes)||[];},
  addNote:function(id,text,by){text=String(text||'').trim().slice(0,600);if(!text)return false;return D.update(id,function(st){st.notes=st.notes||[];st.notes.unshift({d:new Date().toISOString(),t:text,by:by||''});if(st.notes.length>50)st.notes.length=50;});},
  removeNote:function(id,idx){return D.update(id,function(st){if(st.notes)st.notes.splice(idx,1);});},
  storageBytes:function(){var b=0;try{Object.keys(localStorage).forEach(function(k){if(/^mm/i.test(k))b+=(k.length+String(localStorage.getItem(k)||'').length)*2;});}catch(e){}return b;},
  makeCode:function(){var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',used={};D.list().forEach(function(st){if(st.verifyCode)used[String(st.verifyCode).toUpperCase()]=1;});var c='';do{c='';for(var i=0;i<6;i++)c+=chars[(crypto.getRandomValues(new Uint32Array(1))[0]%chars.length)];}while(used[c]);return c;},
  codeOf:function(st){if(!st)return '';if(st.verifyCode)return String(st.verifyCode).toUpperCase();try{return studentVerificationCode(st.id);}catch(e){return '';}},
  createStudent:function(name,grade,teacher){name=String(name||'').trim().slice(0,40);if(!name)return null;var s=D.store();if(!s.list)s.list={};var id=(typeof newId==='function')?newId():'s_'+Date.now().toString(36)+Math.random().toString(36).slice(2,9);var rec={id:id,name:name,grade:grade||'K',prog:{},verifyCode:D.makeCode(),created:new Date().toISOString()};teacher=String(teacher||'').trim().slice(0,60);if(teacher){rec.teacher=teacher;s.teachers=s.teachers||[];if(s.teachers.indexOf(teacher)<0)s.teachers.push(teacher);}s.list[id]=rec;saveStore(s);return rec;}
};

/* ---------- MM91.auth (session) ---------- */
var AUTHK='mmAuth_v1';
var A=MM.auth={
  get:function(){try{return JSON.parse(sessionStorage.getItem(AUTHK)||'null');}catch(e){return null;}},
  set:function(o){try{sessionStorage.setItem(AUTHK,JSON.stringify(Object.assign({at:Date.now()},o)));}catch(e){}},
  clear:function(){try{sessionStorage.removeItem(AUTHK);sessionStorage.removeItem('mmRole');sessionStorage.removeItem('mmLoginRole');sessionStorage.removeItem('mmDemo');}catch(e){}},
  isAdmin:function(){var a=A.get();return !!(a&&a.role==='teacher'&&a.id==='admin');},
  isTeacher:function(){try{return loadRole()==='teacher';}catch(e){return false;}},
  roleKey:function(){var a=A.get();if(!a)return 'guest';if(A.isAdmin())return 'admin';return a.role==='teacher'?'teacher':'student';},
  roleLabel:function(){return {admin:'Administrator',teacher:'Teacher',student:'Student',guest:'Guest'}[A.roleKey()];},
  displayName:function(){var a=A.get();if(!a)return 'Guest';if(A.isAdmin())return 'Administrator';if(a.role==='student'){try{var st=activeStudent();if(st)return st.name;}catch(e){}return a.name||'Student';}return a.name||'Teacher';},
  /* Administrator-only profile switching. The admin session is stashed so the
     administrator can view the app exactly as a student and return without
     re-entering a password. Teachers and students cannot switch profiles. */
  stash:function(){try{return JSON.parse(sessionStorage.getItem('mmAdminStash_v1')||'null');}catch(e){return null;}},
  canSwitch:function(){return A.isAdmin()||!!A.stash();},
  impersonate:function(id){var st=D.get(id);if(!st)return false;if(!A.canSwitch()){U.toast('Only an administrator can switch profiles.',3000);return false;}
    if(!A.stash()){try{sessionStorage.setItem('mmAdminStash_v1',sessionStorage.getItem(AUTHK)||'');}catch(e){}}
    try{sessionStorage.setItem('mmRole','student');}catch(e){}
    A.set({role:'student',name:st.name,id:st.id});
    window.__mmLogin=1;try{switchStudent(st.id);}catch(e){try{setTabActive(st.id);}catch(x){}}window.__mmLogin=0;
    try{applyRole();buildNav();MM.shell.topbar();}catch(e){}U.toast('Viewing as '+st.name+'. Use "Return to Admin" when you are done.',3500);return true;},
  returnToAdmin:function(){var s=A.stash();if(!s)return;try{sessionStorage.setItem(AUTHK,JSON.stringify(s));sessionStorage.removeItem('mmAdminStash_v1');sessionStorage.setItem('mmRole','teacher');sessionStorage.setItem('mmLoginRole','teacher');}catch(e){}
    try{setTabActive(null);}catch(e){}try{closePanel(true);applyRole();buildNav();openPanel('admin');}catch(e){}U.toast('Back to the administrator session.',2500);}
};

/* ---------- SIGN-IN GATE ---------- */
var GATE=MM.gate=(function(){
  var el=null,tab='student',view='signin',created=null,busy=false,returnAfterPanel=false;
  var QS='Quick start (about 60 seconds)\n\nTeachers and families: choose Teacher, create a passcode, add your learners, then open a week. Each learner receives a 6-character sign-in code.\n\nStudents: sign in with your name and code, read the lesson, do the worksheet, take the quiz, and write your reflection.\n\nAdministrators: use the Administrator tab for device-level setup, reports, and data tools.\n\nProgress stays on this device. Back it up from the Admin Console.';
  function ensure(){if(el)return el;el=document.createElement('div');el.id='mm-auth';el.className='mm-hidden';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label','Sign in to Money Matters');document.body.appendChild(el);
    U.on(el,'click','[data-a]',function(e,b){e.preventDefault();act(b.getAttribute('data-a'),b);});
    el.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target&&/^(INPUT|SELECT)$/.test(e.target.tagName)){e.preventDefault();submit();}});
    el.addEventListener('input',function(e){if(e.target&&e.target.id==='a-code')e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);});
    return el;}
  function remembered(k){try{return localStorage.getItem(k)||'';}catch(e){return '';}}
  function remember(k,v){try{if(v)localStorage.setItem(k,v);else localStorage.removeItem(k);}catch(e){}}
  function hasPin(){try{return typeof _hasPin==='function'&&_hasPin();}catch(e){return false;}}
  function show(opts){opts=opts||{};ensure();if(opts.tab)tab=opts.tab;else{try{var r=sessionStorage.getItem('mmLoginRole')||'student';tab=(r==='teacher'||r==='owner')?'teacher':'student';}catch(e){tab='student';}}view=opts.view||'signin';created=null;el.classList.remove('mm-hidden');document.documentElement.classList.add('mm-gated');render();}
  function hide(){if(el)el.classList.add('mm-hidden');document.documentElement.classList.remove('mm-gated');try{MM.shell&&MM.shell.topbar();}catch(e){}}
  function visible(){return !!(el&&!el.classList.contains('mm-hidden'));}
  function field(ic,label,id,attrs,extra){return '<div class="mm-auth-field"><span class="ic" aria-hidden="true">'+ic+'</span><label for="'+id+'">'+E(label)+'</label><input id="'+id+'" '+attrs+'>'+(extra||'')+'</div>';}
  function brand(){var school='';try{school=getSchoolName();}catch(e){}var lic='';try{lic=window.__MM_LICENSE||'';}catch(e){}
    return '<aside class="mm-auth-brand"><div class="logo" aria-hidden="true">💰</div><div><div class="tag">K–8 Financial Literacy</div><h1>Money Matters</h1></div><p>A complete classroom program: 324 lessons, printable materials, quizzes, checkpoints, games, and a decision-based Story Mode.</p><ul class="mm-auth-feats"><li><i>📚</i><span><b>Teach</b> a 36-week sequence for every grade with plans, worksheets, and guides.</span></li><li><i>📊</i><span><b>Track</b> mastery, assessments, reflections, and growth for each learner.</span></li><li><i>🔒</i><span><b>Private by design.</b> All data is stored on this device only.</span></li></ul><div class="foot">'+(school?E(school)+' · ':'')+(lic?'Licensed to '+E(lic)+' · ':'')+'Stored on this device only'+'</div></aside>';}
  function tabs(){return '<div class="mm-auth-tabs" role="tablist">'+[['student','🎒','Student'],['teacher','👩‍🏫','Teacher'],['admin','🛡️','Administrator']].map(function(x){return '<button type="button" role="tab" aria-selected="'+(tab===x[0])+'" class="'+(tab===x[0]?'on':'')+'" data-a="tab:'+x[0]+'"><span aria-hidden="true">'+x[1]+'</span>'+x[2]+'</button>';}).join('')+'</div>';}
  function foot(){return '<div class="mm-auth-foot"><button type="button" data-a="sample">👀 Explore a sample lesson</button><button type="button" data-a="quick">❓ 60-second quick start</button><button type="button" data-a="legal">📜 Privacy &amp; Terms</button></div>';}
  function studentForm(){var list=D.list().slice().sort(function(a,b){return a.name.localeCompare(b.name);}),u=remembered('mmLoginUser_v1');
    var h='<h2>Welcome back</h2><p class="lead">Sign in with your name and your 6-character sign-in code.</p>';
    h+=field('👤','Your name','a-name','type="text" list="a-names" autocomplete="off" autocapitalize="words" spellcheck="false" value="'+E(u)+'"')+'<datalist id="a-names">'+list.map(function(st){return '<option value="'+E(st.name)+'">';}).join('')+'</datalist>';
    h+=field('🔑','Sign-in code','a-code','type="text" inputmode="text" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="6" style="letter-spacing:.2em;font-family:ui-monospace,Menlo,Consolas,monospace"');
    if(list.length&&list.length<=14)h+='<div><div class="mm-label" style="margin:2px 0 6px">Quick pick</div><div class="mm-auth-pick">'+list.map(function(st){return '<button type="button" data-a="pick" data-n="'+E(st.name)+'">'+E(st.name)+' <span style="opacity:.6">· '+E(D.gradeShort(st.grade||'K'))+'</span></button>';}).join('')+'</div></div>';
    h+='<div class="mm-auth-row"><label><input type="checkbox" id="a-rem" '+(u?'checked':'')+'> Remember my name</label><button type="button" class="mm-auth-link" data-a="needcode">Need your code?</button></div>';
    h+='<div class="mm-auth-err" id="a-err" role="alert"></div><button type="button" class="mm-auth-submit" data-a="login">Sign in <span aria-hidden="true">→</span></button>';
    h+='<div class="mm-auth-alt">New here? <button type="button" class="mm-auth-link" data-a="create">Create a student profile</button></div>';
    return h;}
  function teacherForm(){if(!hasPin())return '<h2>Set up teacher access</h2><p class="lead">This device has no teacher passcode yet. Create one to unlock lesson guides, class progress, reports, and the Admin Console.</p><div class="mm-alert info"><span class="ic">🛡️</span><div>The passcode is stored only on this device as a one-way hash. Keep it private from students.</div></div><div class="mm-auth-err" id="a-err" role="alert"></div><button type="button" class="mm-auth-submit green" data-a="setup">Create teacher passcode</button>';
    var u=remembered('mmLoginTeacher_v1'),names=D.teachers();
    var h='<h2>Teacher &amp; family sign-in</h2><p class="lead">Enter the shared teacher passcode for this device. Your display name appears on reports and notes.</p>';
    h+=field('👩‍🏫','Display name (optional)','a-tname','type="text" list="a-tnames" autocomplete="off" autocapitalize="words" value="'+E(u)+'"')+'<datalist id="a-tnames">'+names.map(function(n){return '<option value="'+E(n)+'">';}).join('')+'</datalist>';
    h+=field('🔒','Teacher passcode','a-pass','type="password" autocomplete="current-password"','<button type="button" class="eye" data-a="eye" data-for="a-pass" aria-label="Show passcode">👁</button>');
    h+='<div class="mm-auth-row"><label><input type="checkbox" id="a-trem" '+(u?'checked':'')+'> Remember my name</label><button type="button" class="mm-auth-link" data-a="forgot">Forgot passcode?</button></div>';
    h+='<div class="mm-auth-err" id="a-err" role="alert"></div><button type="button" class="mm-auth-submit green" data-a="login">Sign in <span aria-hidden="true">→</span></button>';
    return h;}
  function adminForm(){var h='<h2>Administrator</h2><p class="lead">Device-level administration: roster management, teacher accounts, reports, data backup, and settings.</p>';
    h+=field('🛡️','Username','mm55-user','type="text" value="admin" readonly autocomplete="username"');
    h+=field('🔒','Administrator password','mm55-pass','type="password" autocomplete="current-password"','<button type="button" class="eye" data-a="eye" data-for="mm55-pass" aria-label="Show password">👁</button>');
    h+='<div class="mm-auth-err" id="mm55-error" role="alert"></div><button type="button" class="mm-auth-submit plum" data-a="login">Sign in as administrator <span aria-hidden="true">→</span></button>';
    h+='<div class="mm-auth-note">Administrator access unlocks everything a teacher can do plus device administration. The password can be changed from the Admin Console.</div>';
    return h;}
  function setupForm(){return '<button type="button" class="mm-auth-link" data-a="back" style="align-self:flex-start">← Back</button><h2>Create teacher passcode</h2><p class="lead">Choose a passcode of at least 4 characters. A recovery question is optional but recommended.</p>'
    +field('🔒','New passcode','s-p1','type="password" autocomplete="new-password"','<button type="button" class="eye" data-a="eye" data-for="s-p1" aria-label="Show">👁</button>')
    +field('🔒','Confirm passcode','s-p2','type="password" autocomplete="new-password"')
    +field('❓','Recovery question (optional)','s-q','type="text" autocomplete="off" placeholder=" "')
    +field('💬','Recovery answer','s-a','type="text" autocomplete="off" placeholder=" "')
    +'<div class="mm-auth-err" id="a-err" role="alert"></div><button type="button" class="mm-auth-submit green" data-a="savesetup">Save passcode &amp; continue</button>';}
  function createForm(){var gs=D.GRADES.map(function(g){return '<option value="'+g+'"'+(g===(currentGrade||'K')?' selected':'')+'>'+E(D.gradeLabel(g))+'</option>';}).join('');
    return '<button type="button" class="mm-auth-link" data-a="back" style="align-self:flex-start">← Back to sign in</button><h2>Create a student profile</h2><p class="lead">Progress, prizes, and certificates are saved to this profile on this device.</p>'
    +field('👤','Student name','c-name','type="text" autocomplete="off" autocapitalize="words" maxlength="40"')
    +'<div class="mm-auth-field"><span class="ic" aria-hidden="true">🎓</span><label for="c-grade">Grade</label><select id="c-grade">'+gs+'</select></div>'
    +field('🏫','Teacher or class (optional)','c-teacher','type="text" list="c-teachers" autocomplete="off" maxlength="60" placeholder=" "')+'<datalist id="c-teachers">'+D.teachers().map(function(n){return '<option value="'+E(n)+'">';}).join('')+'</datalist>'
    +'<div class="mm-auth-err" id="a-err" role="alert"></div><button type="button" class="mm-auth-submit" data-a="docreate">Create profile <span aria-hidden="true">→</span></button><div class="mm-auth-note">A unique 6-character sign-in code is generated automatically.</div>';}
  function createdView(){return '<h2>Profile created</h2><p class="lead">'+E(created.name)+' is enrolled in '+E(D.gradeLabel(created.grade))+'. Write down this sign-in code — it is needed to sign in next time.</p><div class="mm-auth-code"><div class="mm-label">Sign-in code</div><div class="big">'+E(created.verifyCode)+'</div><button type="button" class="mm-btn secondary sm" data-a="copycode">Copy code</button></div><div class="mm-auth-err" id="a-err" role="alert"></div><button type="button" class="mm-auth-submit green" data-a="continue">Continue to the classroom <span aria-hidden="true">→</span></button><div class="mm-auth-note">Teachers can see every student code in the Admin Console.</div>';}
  function render(){ensure();var body=view==='setup'?setupForm():view==='create'?createForm():view==='created'?createdView():(tabs()+(tab==='student'?studentForm():tab==='teacher'?teacherForm():adminForm()));
    el.innerHTML='<div class="mm-auth-card">'+brand()+'<section class="mm-auth-form">'+body+(view==='signin'?foot():'')+'</section></div>';
    setTimeout(function(){var f=el.querySelector('input:not([readonly]):not([type=checkbox])');if(f)try{f.focus({preventScroll:true});}catch(e){}},60);}
  function err(m){var e=$('a-err')||$('mm55-error');if(e)e.innerHTML=m?'<span aria-hidden="true">⚠️</span> '+E(m):'';}
  function setBusy(b){busy=b;var s=el&&el.querySelector('.mm-auth-submit');if(s)s.disabled=b;}
  function val(id){var x=$(id);return x?x.value:'';}
  function act(a,b){
    if(a.indexOf('tab:')===0){tab=a.slice(4);try{sessionStorage.setItem('mmLoginRole',tab==='admin'?'teacher':tab);}catch(e){}render();return;}
    switch(a){
      case 'eye':{var inp=$(b.getAttribute('data-for'));if(inp){inp.type=inp.type==='password'?'text':'password';b.textContent=inp.type==='password'?'👁':'🙈';}break;}
      case 'pick':{var n=$('a-name');if(n){n.value=b.getAttribute('data-n');var c=$('a-code');if(c)c.focus();}break;}
      case 'login':submit();break;
      case 'needcode':try{mmAlert('Your sign-in code is a 6-character code your teacher can see in the Admin Console (Students). If you are the only student with your name, you can sign in without it.','🔑');}catch(e){}break;
      case 'forgot':try{if(typeof forgotPin==='function')forgotPin();}catch(e){}break;
      case 'setup':view='setup';render();break;
      case 'savesetup':saveSetup();break;
      case 'create':view='create';render();break;
      case 'docreate':doCreate();break;
      case 'copycode':try{navigator.clipboard.writeText(created.verifyCode).then(function(){U.toast('Code copied.');});}catch(e){}break;
      case 'continue':finishCreated();break;
      case 'back':view='signin';render();break;
      case 'sample':try{sessionStorage.setItem('mmDemo','1');}catch(e){}hide();try{openPanel('lessons');}catch(e){}U.toast('Sample mode: explore a lesson. Sign in to save progress.',3500);break;
      case 'quick':try{mmAlert(QS,'❓');}catch(e){alert(QS);}break;
      case 'legal':returnAfterPanel=true;hide();try{openPanel('legal');}catch(e){}break;
    }
  }
  function submit(){if(busy)return;if(view==='setup')return saveSetup();if(view==='create')return doCreate();if(view==='created')return finishCreated();if(tab==='student')loginStudent();else if(tab==='teacher'){if(hasPin())loginTeacher();else{view='setup';render();}}else loginAdmin();}
  function loginStudent(){var name=val('a-name').trim(),code=val('a-code').trim().toUpperCase();err('');if(!name){err('Enter your name to continue.');return;}
    var matches=D.list().filter(function(st){return String(st.name||'').trim().toLowerCase()===name.toLowerCase();});
    if(!matches.length){err('We could not find a student named "'+name+'". Check the spelling or create a profile.');return;}
    var st=null;
    if(code){st=matches.filter(function(x){return D.codeOf(x)===code;})[0]||null;if(!st){err('That sign-in code does not match this name.');return;}}
    else{if(matches.length>1){err('More than one student has this name. Enter your sign-in code.');return;}st=matches[0];}
    remember('mmLoginUser_v1',($('a-rem')&&$('a-rem').checked)?st.name:'');
    try{sessionStorage.setItem('mmRole','student');sessionStorage.setItem('mmLoginRole','student');}catch(e){}
    A.set({role:'student',name:st.name,id:st.id});
    window.__mmLogin=1;try{switchStudent(st.id);}catch(e){try{setTabActive(st.id);}catch(x){}}window.__mmLogin=0;
    hide();try{applyRole();buildNav();}catch(e){}U.toast('Welcome back, '+st.name+'!',2500);}
  function loginTeacher(){var name=val('a-tname').trim().slice(0,60),pass=val('a-pass');err('');if(!pass){err('Enter the teacher passcode.');return;}
    try{if(_pinIsLocked()){err('Too many attempts. Try again in '+_pinLockSecondsLeft()+' seconds.');return;}}catch(e){}
    setBusy(true);
    _verifyPin(pass).then(function(ok){setBusy(false);
      if(!ok){try{_pinRecordFail();if(_pinIsLocked()){err('Too many incorrect attempts. Locked for '+_pinLockSecondsLeft()+' seconds.');}else{var left=_PIN_MAX_ATTEMPTS-_pinAttempts();err('Incorrect passcode. '+left+' attempt'+(left===1?'':'s')+' left.');}}catch(e){err('Incorrect passcode.');}return;}
      try{_pinRecordSuccess();}catch(e){}
      remember('mmLoginTeacher_v1',($('a-trem')&&$('a-trem').checked)?name:'');
      try{sessionStorage.setItem('mmRole','teacher');sessionStorage.setItem('mmLoginRole','teacher');}catch(e){}
      if(name){try{addTeacherName(name);}catch(e){}}
      A.set({role:'teacher',name:name||'Teacher',id:'teacher'});
      hide();try{applyRole();buildNav();}catch(e){}
      try{openPanel('admin');}catch(e){}
      U.toast('Signed in as '+(name||'Teacher')+'.',2500);
    }).catch(function(){setBusy(false);err('Sign-in is temporarily unavailable in this browser.');});}
  function loginAdmin(){err('');var p=val('mm55-pass');if(!p){err('Enter the administrator password.');return;}
    if(typeof window.mmV55Login!=='function'){err('Administrator sign-in is unavailable in this build.');return;}
    var u=$('mm55-user');if(u)u.value='admin';
    try{window.mmV55Login();}catch(e){err('Administrator sign-in failed. Try again.');return;}
    var t0=Date.now();(function chk(){if(A.isAdmin()){try{sessionStorage.setItem('mmLoginRole','teacher');}catch(e){}hide();try{applyRole();buildNav();}catch(e){}try{if(openPanelId!=='admin')openPanel('admin');}catch(e){}return;}if(Date.now()-t0<2500)setTimeout(chk,120);})();}
  function saveSetup(){var p1=val('s-p1').trim(),p2=val('s-p2').trim(),q=val('s-q').trim(),a=val('s-a').trim();err('');
    if(p1.length<4){err('Use at least 4 characters for the passcode.');return;}if(p1!==p2){err('The two passcodes do not match.');return;}if(q&&!a){err('Add an answer for your recovery question, or clear the question.');return;}
    setBusy(true);_storePin(p1).then(function(){if(q&&a)try{setRecovery(q,a);}catch(e){}setBusy(false);view='signin';tab='teacher';render();U.toast('Teacher passcode created. Sign in to continue.',3000);});}
  function doCreate(){var name=val('c-name').trim(),g=val('c-grade')||'K',tn=val('c-teacher').trim();err('');if(!name){err('Enter the student name.');return;}
    var dupe=D.list().some(function(st){return st.name.trim().toLowerCase()===name.toLowerCase()&&(st.grade||'K')===g;});if(dupe){err('A student with this name already exists in '+D.gradeLabel(g)+'. Sign in instead, or add a last initial.');return;}
    var rec=D.createStudent(name,g,tn);if(!rec){err('Could not create the profile.');return;}created=rec;view='created';render();}
  function finishCreated(){if(!created)return;var st=created;created=null;
    try{sessionStorage.setItem('mmRole','student');sessionStorage.setItem('mmLoginRole','student');}catch(e){}
    A.set({role:'student',name:st.name,id:st.id});
    var s=D.store();s.active=st.id;saveStore(s);try{setTabActive(st.id);}catch(e){}
    hide();try{refreshStudentUI();setGrade(st.grade);applyRole();buildNav();}catch(e){}
    try{if(typeof window.mmV59StudentAssessment==='function')window.mmV59StudentAssessment();else openPanel('dashboard');}catch(e){}
    U.toast('Welcome, '+st.name+'! Your profile is ready.',3000);}
  function signOut(){A.clear();try{sessionStorage.removeItem('mmAdminStash_v1');}catch(e){}try{setTabActive(null);}catch(e){}try{closePanel(true);}catch(e){}try{applyRole();buildNav();}catch(e){}show();try{MM.shell&&MM.shell.topbar();}catch(e){}}
  function afterPanelClose(){if(returnAfterPanel&&!A.get()){returnAfterPanel=false;show();}}
  return {show:show,hide:hide,visible:visible,signOut:signOut,showCreate:function(){show({view:'create'});},afterPanelClose:afterPanelClose};
})();

/* ---------- MM91.shell: top bar, navigation, routing, session panel ---------- */
var S=MM.shell={};
S.allowLegacy=false;
S.panelTitle=function(){var id=openPanelId;if(!id)return '';var p=$('panel-'+id);var tt=p&&p.querySelector('.panel-title');return tt?tt.textContent.trim():'';};
S.topbar=function(){var el=$('mm-topbar');if(!el){el=document.createElement('div');el.id='mm-topbar';el.setAttribute('role','banner');document.body.appendChild(el);
    U.on(el,'click','[data-a]',function(e,b){var a=b.getAttribute('data-a');if(a==='home'){try{closePanel(true);}catch(x){}S.topbar();}if(a==='admin')openPanel('admin');if(a==='dash')openPanel('dashboard');if(a==='session')openPanel('login');if(a==='return')A.returnToAdmin();if(a==='out')GATE.signOut();});
    el.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.classList.contains('user'))openPanel('login');});}
  var a=A.get();if(!a||GATE.visible()){el.style.display='none';var hm=$('mm-home');if(hm)hm.classList.add('hidden');return;}el.style.display='flex';
  var rk=A.roleKey(),nm=A.displayName(),g='',stash=A.stash();try{g=D.gradeLabel(currentGrade||'K');}catch(e){}
  var title=S.panelTitle();
  el.innerHTML='<button class="brand" data-a="home" title="Back to the classroom"><span class="logo" aria-hidden="true">💰</span><span>Money Matters</span></button>'
    +'<div class="ctx"><span class="crumb"><b class="cg">'+E(g)+'</b>'+(title?'<span class="cs" style="opacity:.5"> › </span><span class="ct">'+E(title)+'</span>':'')+'</span></div>'
    +(stash&&rk!=='admin'?'<span class="imp" title="An administrator is viewing this student profile">🛡️ Admin view</span>':'')
    +'<div class="user" data-a="session" role="button" tabindex="0" title="Session details">'+U.avatar(nm,rk==='student'?'':'teacher')+'<span class="nm">'+E(nm)+'</span><span class="rl '+rk+'">'+E(A.roleLabel())+'</span></div>'
    +(stash&&rk!=='admin'?'<button class="tb hi" data-a="return">↩ <span>Return to Admin</span></button>':rk==='student'?'<button class="tb hi" data-a="dash">🏠 <span>My Dashboard</span></button>':'<button class="tb hi" data-a="admin">🛠️ <span>'+(A.isAdmin()?'Admin Console':'Teacher Console')+'</span></button>')
    +(rk==='admin'?'<button class="tb" data-a="session" title="Switch profile">⇄ <span>Switch profile</span></button>':'')
    +'<button class="tb" data-a="out" title="Sign out">⎋ <span>Sign out</span></button>';
  setTimeout(S.renderHome,0);
};
/* ---------- "Today" strip: fills the empty classroom floor/wall with live, role-aware cards ---------- */
S.homeCards=function(){var a=A.get(),rk=A.roleKey(),cards=[],g=currentGrade||'K',ls=D.lessons(g),aw=null;try{aw=assignedWeek(g);}catch(e){}
  if(!a)return cards;
  if(rk==='student'){var st=null;try{st=activeStudent();}catch(e){}if(!st)return cards;var s=D.stats(st),nw=null;for(var i=0;i<ls.length;i++){var v=(st.prog||{})['quiz|'+g+'|'+ls[i].week];if(!(v!=null&&v>=75)){nw={i:i,l:ls[i]};break;}}
    cards.push({cls:'hi',k:'▶ Continue',v:nw?'Week '+nw.l.week+' · '+nw.l.title:'All weeks mastered 🎓',s:nw?(nw.l.sub||''):'Open the certificate or try a Story.',a:'<button class="mm-btn sm primary" onclick="continuePath()">Continue</button>'+(nw?'<button class="mm-btn sm ghost" onclick="openQuiz()">Quiz</button>':'<button class="mm-btn sm ghost" onclick="openPanel(\'certificate\')">Certificate</button>')});
    cards.push({k:'📚 My progress',big:s.pct+'%',s:s.passed+' of '+s.total+' weeks mastered'+(s.streak>1?' · 🔥 '+s.streak+'-day streak':''),prog:s.pct,a:'<button class="mm-btn sm ghost" onclick="openPanel(\'path\')">Learning Path</button>'});
    if(aw!=null&&ls[aw])cards.push({k:'📌 This week',v:'Week '+ls[aw].week+' · '+ls[aw].title,s:'Set by your teacher for '+D.gradeLabel(g)+'.',a:'<button class="mm-btn sm secondary" onclick="gotoLesson('+aw+')">Open lesson</button>'});
    else{var w=null;try{var wl=gradeGlossary();if(wl.length)w=wl[dayIndex()%wl.length];}catch(e){}cards.push(w?{k:'📖 Word of the day',v:w.term,s:w.def,a:'<button class="mm-btn sm ghost" onclick="openPanel(\'glossary\')">Glossary</button>'}:{k:'🎭 Story Mode',v:'Make the choices',s:'A money story in four acts with checkpoints.',a:'<button class="mm-btn sm secondary" onclick="openPanel(\'story\')">Play</button>'});}
    cards.push({k:'📊 Readiness',v:s.fa?'Level '+s.fa.level.n+' · '+s.fa.level.name:'Financial profile',s:s.fa?'Assessment '+s.fa.score+'% · '+s.tests+'/'+s.totalTests+' checkpoints passed':'Take the grade-level assessment to personalize your path.',a:'<button class="mm-btn sm secondary" onclick="openPanel(\'assessment\')">'+(s.fa?'View profile':'Start assessment')+'</button><button class="mm-btn sm ghost" onclick="openPanel(\'games\')">Games</button>'});
    return cards;}
  var list=D.list(),cs=D.classStats(list),rows=list.map(function(x){return D.stats(x);}),attn=rows.filter(function(x){return x.status.k==='support'||x.status.k==='inactive';}).length,today=rows.filter(function(x){return x.last.days===0;}).length;
  cards.push({cls:'hi',k:'🏫 Class today',big:String(list.length),s:list.length?today+' active today · '+cs.active7+' this week · avg mastery '+cs.avgPct+'%':'No students enrolled yet.',a:'<button class="mm-btn sm primary" onclick="MM91.admin.open(\'students\''+(list.length?'':',{add:true}')+')">'+(list.length?'Students':'Add students')+'</button>'});
  cards.push({k:'🚩 Needs attention',big:String(attn),s:attn?'Failed quizzes with a low average, or inactive 14+ days.':'Everyone is on track.',a:'<button class="mm-btn sm '+(attn?'secondary':'ghost')+'" onclick="MM91.admin.open(\'students\',{sort:\'status\'})">Review</button><button class="mm-btn sm ghost" onclick="MM91.admin.open(\'reports\')">Reports</button>'});
  cards.push({k:'📌 This week · '+D.gradeShort(g),v:aw!=null&&ls[aw]?'Week '+ls[aw].week+' · '+ls[aw].title:'Not set for '+D.gradeLabel(g),s:aw!=null&&ls[aw]?(ls[aw].objective||''):'Choose the lesson students should start with.',a:(aw!=null&&ls[aw]?'<button class="mm-btn sm secondary" onclick="gotoLesson('+aw+')">Open lesson</button>':'')+'<button class="mm-btn sm ghost" onclick="MM91.admin.open(\'classes\')">Set week</button>'});
  var lb=null;try{var l=parseInt(localStorage.getItem('mmLastBackup')||'0',10);if(l)lb=Math.floor((Date.now()-l)/86400000);}catch(e){}
  cards.push({k:'🛠️ Quick actions',v:lb==null?'No backup yet':lb===0?'Backed up today':'Backup '+lb+'d ago',s:cs.assessed+' assessed · '+cs.storyRuns+' story runs · '+cs.gamePlays+' game plays',a:'<button class="mm-btn sm secondary" onclick="openPanel(\'admin\')">Admin Console</button><button class="mm-btn sm ghost" onclick="openPanel(\'lessons\')">Lessons</button>'});
  return cards;};
S.renderHome=function(){var room=document.querySelector('#scene .room');if(!room)return;var el=$('mm-home');if(!el){el=document.createElement('div');el.id='mm-home';el.setAttribute('aria-label','Today');room.appendChild(el);}
  var cards=A.get()&&!GATE.visible()?S.homeCards():[];
  if(!cards.length){el.classList.add('hidden');return;}
  var key=JSON.stringify(cards);if(el.__key!==key){el.__key=key;el.innerHTML='<div class="mm-home-grid">'+cards.map(function(c){return '<div class="mm-home-card '+(c.cls||'')+'"><div class="k">'+c.k+'</div>'+(c.big!=null?'<div class="big">'+E(c.big)+'</div>':'')+(c.v?'<div class="v" title="'+E(c.v)+'">'+E(c.v)+'</div>':'')+(c.prog!=null?'<div class="mm-prog"><i style="width:'+c.prog+'%"></i></div>':'')+(c.s?'<div class="s">'+E(c.s)+'</div>':'')+(c.a?'<div class="a">'+c.a+'</div>':'')+'</div>';}).join('')+'</div>';}
  el.classList.remove('hidden');S.placeHome();};
S.placeHome=function(){var el=$('mm-home'),room=document.querySelector('#scene .room'),chalk=document.querySelector('.chalkboard'),row=document.querySelector('.station-row'),nav=$('nav');if(!el||!room||!chalk||!row||!nav)return;
  var R=room.getBoundingClientRect(),C=chalk.getBoundingClientRect(),S1=row.getBoundingClientRect(),N=nav.getBoundingClientRect(),tb=$('mm-topbar'),T=tb&&tb.style.display!=='none'?tb.getBoundingClientRect().bottom:0;
  var wall={top:C.bottom+20,bottom:S1.top-8},floor={top:S1.bottom+12,bottom:N.top-8},pick=(floor.bottom-floor.top)>=(wall.bottom-wall.top)?floor:wall,h=pick.bottom-pick.top;
  if(h<76){el.classList.add('hidden');return;}el.classList.remove('hidden');
  el.style.top=(pick.top-R.top)+'px';el.style.height=h+'px';
  var narrow=innerWidth<=1024,max=narrow?(h<250?2:4):4;
  el.classList.toggle('compact',h<150||(narrow&&max===4&&h<300));
  var grid=el.querySelector('.mm-home-grid');if(grid){grid.style.maxHeight=h+'px';grid.style.gridAutoRows='minmax(0,1fr)';}
  /* on tablets and phones a shallow gap shows one row of the two most important cards */
  el.querySelectorAll('.mm-home-card').forEach(function(c,i){c.style.display=i>=max?'none':'';});};
window.addEventListener('resize',U.debounce(function(){S.placeHome();},120));
S.homeLater=U.debounce(function(){try{S.renderHome();}catch(e){}},200);
/* navigation */
S.navGroups=function(){var tt=U.t;return [
  {label:tt('Learn'),items:[['🏠',tt('Home'),"openPanel('dashboard')"],['📚',tt('Lessons'),"openPanel('lessons')"],['🧭',tt('Learning Path'),"openPanel('path')"],['📖',tt('Glossary'),"openPanel('glossary')"],['🎭',tt('Story'),"openPanel('story')"],['🎮',tt('Games'),"openPanel('games')"]]},
  {label:tt('Assess'),items:[['📝',tt('Quiz'),"openQuiz()"],['🧪',tt('Section Test'),"openTestMenu()"],['📊','Financial Profile',"openPanel('assessment')"],['🏆',tt('Certificate'),"openPanel('certificate')"]]},
  {label:tt('Documents'),items:[['✏️',tt('Worksheet'),"openDoc('worksheet')"],['📋',tt('Lesson Plan'),"openDoc('plan')",1],['📗',tt('Workbook'),"openDoc('workbook')",1],['🧑‍🏫','Answer Key',"openDoc('guide')",1]]},
  {label:A.isAdmin()?'Admin':'Teacher',cls:'admin teacher-only',items:[['🛠️',A.isAdmin()?'Admin Console':'Teacher Console',"openPanel('admin')",1]]}
];};
S.moreItems=function(){var tt=U.t,items=[['❓',tt('How to Use'),"openPanel('help')"],['🔤',tt('Reading')+' & Accessibility',"openPanel('a11y')"],['💬',tt('Feedback'),"openPanel('feedback')"],['📜',tt('Privacy & Terms'),"openPanel('legal')"]];
  if(A.isTeacher())items.push(['🆕',tt("What's New"),"openPanel('whatsnew')"]);
  items.push('sep');var lg='en';try{lg=loadLang();}catch(e){}items.push(['🌐','Language: '+({en:'English',es:'Español',pt:'Português'}[lg]||'English')+' → next',"toggleLang()"]);
  items.push('sep');items.push(['👤',A.isAdmin()?'Session & switch profile':'My session',"openPanel('login')"]);items.push(['⎋','Sign out',"MM91.gate.signOut()"]);return items;};
S.buildNav=function(){var nav=$('nav'),btns=$('navBtns'),gl=$('navGradeLabel'),gn=$('gradeNav');if(!nav||!btns)return;
  if(!nav.__v91){nav.__v91=1;var r1=document.createElement('div');r1.className='mm-nav-row grades';var r2=document.createElement('div');r2.className='mm-nav-row main';
    if(gl)r1.appendChild(gl);if(gn)r1.appendChild(gn);r2.appendChild(btns);nav.querySelectorAll(':scope > .nav-sep').forEach(function(x){x.remove();});nav.innerHTML='';nav.appendChild(r1);nav.appendChild(r2);}
  var h='';S.navGroups().forEach(function(g){var vis=g.items;h+='<div class="mm-nav-group '+(g.cls||'')+'"><span class="glabel">'+E(g.label)+'</span>'+vis.map(function(d){return '<button class="nav-btn'+(d[3]?' teacher-only':'')+'" onclick="'+d[2]+'">'+d[0]+' '+E(d[1])+'</button>';}).join('')+'</div>';});
  h+='<div class="mm-nav-group"><button class="nav-btn mm-more" id="mmMoreBtn" aria-haspopup="menu" aria-expanded="false" onclick="MM91.shell.toggleMore(event)">⋯ '+E(U.t('More'))+'</button></div>';
  btns.innerHTML=h;try{refreshStudentUI();applyRole();}catch(e){}S.topbar();};
S.toggleMore=function(ev){if(ev)ev.stopPropagation();var pop=$('mm-more-pop');if(!pop){pop=document.createElement('div');pop.id='mm-more-pop';pop.setAttribute('role','menu');document.body.appendChild(pop);document.addEventListener('click',function(e){if(pop.classList.contains('open')&&!pop.contains(e.target))S.closeMore();});document.addEventListener('keydown',function(e){if(e.key==='Escape')S.closeMore();});}
  if(pop.classList.contains('open')){S.closeMore();return;}
  pop.innerHTML=S.moreItems().map(function(it){if(it==='sep')return '<div class="sep"></div>';return '<button role="menuitem" onclick="MM91.shell.closeMore();'+it[2]+'"><span aria-hidden="true">'+it[0]+'</span>'+E(it[1])+'</button>';}).join('');
  var b=$('mmMoreBtn'),r=b?b.getBoundingClientRect():{left:innerWidth-260,top:innerHeight-80};pop.style.left=Math.max(8,Math.min(innerWidth-248,r.left))+'px';pop.style.bottom=(innerHeight-r.top+8)+'px';pop.classList.add('open');if(b)b.setAttribute('aria-expanded','true');};
S.closeMore=function(){var pop=$('mm-more-pop');if(pop)pop.classList.remove('open');var b=$('mmMoreBtn');if(b)b.setAttribute('aria-expanded','false');};
S.legacyTeacher=function(){S.allowLegacy=true;try{openPanel('teacher');}finally{setTimeout(function(){S.allowLegacy=false;},50);}};
S.home=function(){try{closePanel(true);}catch(e){}S.topbar();};
/* session panel (replaces the old Student desk body) */
S.renderSession=function(){var el=$('loginBody');if(!el)return;var a=A.get(),rk=A.roleKey(),nm=A.displayName();
  var h='<div class="mm-profile-head" style="margin-bottom:14px">'+U.avatar(nm,rk==='student'?'lg':'lg teacher')+'<div class="meta"><div class="mm-label">Signed in on this tab</div><h2>'+E(nm)+'</h2><div class="chips"><span class="mm-chip '+(rk==='student'?'info':rk==='admin'?'bad':'ok')+'">'+E(A.roleLabel())+'</span>';
  var st=null;try{st=activeStudent();}catch(e){}
  if(rk==='student'&&st){h+='<span class="mm-chip gold">'+E(D.gradeLabel(st.grade||'K'))+'</span>'+(st.teacher?'<span class="mm-chip">👩‍🏫 '+E(st.teacher)+'</span>':'')+'<span class="mm-chip mono" title="Sign-in code">🔑 '+E(D.codeOf(st))+'</span>';}
  if(rk!=='student'){h+='<span class="mm-chip">Viewing '+E(D.gradeLabel(currentGrade||'K'))+'</span>';}
  var stash=A.stash();
  h+='</div></div><div class="acts">'+(stash&&rk!=='admin'?'<button class="mm-btn plum" onclick="MM91.auth.returnToAdmin()">↩ Return to Admin</button>':rk==='student'?'<button class="mm-btn primary" onclick="openPanel(\'dashboard\')">🏠 My Dashboard</button>':'<button class="mm-btn primary" onclick="openPanel(\'admin\')">🛠️ '+(A.isAdmin()?'Admin Console':'Teacher Console')+'</button>')+'<button class="mm-btn ghost" onclick="MM91.gate.signOut()">⎋ Sign out</button></div></div>';
  if(rk==='student'&&st){h+='<div class="mm-grid c2"><div class="mm-card"><div class="mm-card-title">🔑 Your sign-in code</div><div class="mm-card-sub">Use your name and this code the next time you sign in. Your teacher can also look it up.</div><div style="margin-top:10px"><span class="mm-code" style="font-size:18px">'+E(D.codeOf(st))+'</span></div></div><div class="mm-card"><div class="mm-card-title">🔒 Privacy</div><div class="mm-card-sub">Your progress is saved only in this browser on this device. Nothing is sent to the internet.</div></div></div>';
    if(stash)h+='<div class="mm-alert info" style="margin-top:12px"><span class="ic">🛡️</span><div><b>Administrator view.</b> You are seeing the classroom exactly as '+E(st.name)+' does. Progress you record here is saved to this student.</div></div>';}
  else if(A.canSwitch()){var list=D.list().sort(function(x,y){return D.GRADES.indexOf(x.grade||'K')-D.GRADES.indexOf(y.grade||'K')||x.name.localeCompare(y.name);});
    h+='<div class="mm-card accent"><div class="mm-card-title">⇄ Switch profile <span class="spacer"></span><button class="mm-btn sm secondary" onclick="MM91.admin.open(\'students\')">Manage roster</button></div><div class="mm-card-sub">Administrator only. Open the classroom as a student to review their dashboard, path, and assessments. You return to this session with one click.</div>'+(list.length?'<div class="mm-row" style="margin-top:10px">'+list.map(function(x){return '<button class="mm-btn sm secondary" onclick="MM91.auth.impersonate(\''+x.id+'\')">'+U.avatar(x.name,'sm')+' '+E(x.name)+' <span style="opacity:.6">· '+E(D.gradeShort(x.grade||'K'))+'</span></button>';}).join('')+'</div>':'<div class="mm-empty" style="margin-top:10px"><b>No students yet</b>Add students from the Admin Console.</div>')+'</div>';
    h+='<div class="mm-alert info" style="margin-top:12px"><span class="ic">🗂️</span><div><b>Multiple people at once?</b> Open Money Matters in another browser tab. Each tab keeps its own signed-in user, so a teacher and a student can work side by side on one device.</div></div>';}
  else{h+='<div class="mm-grid c2"><div class="mm-card"><div class="mm-card-title">👩‍🏫 Teacher session</div><div class="mm-card-sub">Lesson guides, class progress, reports, and the Admin Console are unlocked in this tab. To work as a student, sign out and sign in with that student\'s name and code, or ask an administrator.</div></div><div class="mm-card"><div class="mm-card-title">🗂️ Multiple people at once</div><div class="mm-card-sub">Open Money Matters in another browser tab. Each tab keeps its own signed-in user, so a teacher and a student can work side by side on one device.</div></div></div>';}
  el.innerHTML=h;};
/* routing wrappers */
S.installRouting=function(){
  if(typeof openPanel==='function'&&!openPanel.__v91){var o=openPanel;var w=function(id){
      if(id==='login'&&!A.get()){GATE.show();return;}
      if((id==='teacher'||id==='students')&&A.isTeacher()&&!S.allowLegacy)id='admin';
      if(id==='admin'&&!A.isTeacher())id='help';
      S.closeMore();o(id);S.topbar();};w.__v91=true;openPanel=w;}
  if(typeof closePanel==='function'&&!closePanel.__v91){var oc=closePanel;var wc=function(force){oc(force);S.topbar();GATE.afterPanelClose();};wc.__v91=true;closePanel=wc;}
  if(typeof setGrade==='function'&&!setGrade.__v91){var og=setGrade;var wg=function(g){og(g);S.topbar();if(openPanelId==='admin'&&MM.admin)MM.admin.render();};wg.__v91=true;setGrade=wg;}
  if(typeof saveStore==='function'&&!saveStore.__v91h){var oss=saveStore;var wss=function(x){oss(x);S.homeLater();};wss.__v91h=true;saveStore=wss;}
  if(typeof signOut==='function'&&!signOut.__v91){var os=signOut;var ws=function(){A.clear();try{os.apply(this,arguments);}catch(e){}GATE.show();S.topbar();};ws.__v91=true;signOut=ws;}
  if(typeof renderLogin==='function'&&!renderLogin.__v91){var wl=function(){S.renderSession();};wl.__v91=true;renderLogin=wl;if(typeof _panelRenderers!=='undefined')_panelRenderers.login=function(){renderLogin();};}
  if(typeof buildNav==='function'&&!buildNav.__v91){var wb=function(){S.buildNav();};wb.__v91=true;buildNav=wb;}
  /* grade buttons in teaching order (K first); the original relied on object key order */
  if(typeof buildGradeNav==='function'&&!buildGradeNav.__v91){var wgn=function(){var el=$('gradeNav');if(!el)return;el.innerHTML=D.GRADES.map(function(g){var locked=false;try{locked=!gradeUnlocked(g);}catch(e){}return '<button class="grade-btn'+(g===currentGrade?' active':'')+(locked?' locked':'')+'" data-g="'+g+'" onclick="pickGrade(\''+g+'\')" aria-label="'+E(D.gradeLabel(g))+(locked?' (locked)':'')+'" title="'+(locked?E(U.t('Locked — sign in')):E(D.gradeLabel(g)))+'">'+(g==='K'?'K':g)+(locked?' 🔒':'')+'</button>';}).join('');};wgn.__v91=true;buildGradeNav=wgn;}
  /* only administrators may switch the active profile */
  if(typeof switchStudent==='function'&&!switchStudent.__v91){var osw=switchStudent;var wsw=function(id){var a=A.get();if(!window.__mmLogin&&a&&a.role==='teacher'&&!A.isAdmin()){U.toast('Only an administrator can switch profiles.',3000);return;}return osw.apply(this,arguments);};wsw.__v91=true;switchStudent=wsw;}
  /* dialogs with long titles read as title + explanation */
  if(typeof mmInput==='function'&&!mmInput.__v91){var omi=mmInput;var wmi=function(title,ph,opts){opts=opts||{};if(title&&title.length>42&&!opts.subtext){var m=String(title).match(/^(.+?[.!?])\s+(.+)$/);if(m){opts.subtext=m[2];title=m[1];}}return omi(title,ph,opts);};wmi.__v91=true;mmInput=wmi;}
  /* the welcome tour waits until the sign-in screen and any dialog are gone */
  if(typeof startTour==='function'&&!startTour.__v91){var ost=startTour;var wst=function(){var modal=$('mm-modal-backdrop');if(GATE.visible()||(modal&&modal.classList.contains('open'))){setTimeout(startTour,900);return;}ost();};wst.__v91=true;startTour=wst;}
  window.mmV55Show=function(){GATE.show();};window.mmV55Hide=function(){GATE.hide();};window.mmV56NewStudent=function(){GATE.showCreate();};window.mmV55NewStudent=function(){GATE.showCreate();};window.mmV56SignOut=function(){GATE.signOut();};window.mmV55Update=function(){S.topbar();};
};
S.boot=function(){S.installRouting();S.buildNav();if(!A.get()){var demo='';try{demo=sessionStorage.getItem('mmDemo')||'';}catch(e){}if(!demo)GATE.show();}else GATE.hide();S.topbar();
  /* keep the top bar in sync with tab switches and external store changes */
  if(!S.__sync){S.__sync=1;try{var bc=new BroadcastChannel('mm_sync');bc.onmessage=function(){setTimeout(S.topbar,30);};}catch(e){}window.addEventListener('focus',S.topbar);}
};
MM.boot=function(){try{S.boot();}catch(e){console.warn('V91 shell boot',e);}};
/* The welcome tour is for first-ever use only; a version change no longer replays it. */
try{window.__mmPrevTourVersion=localStorage.getItem('mmTourVersion')||'';if(localStorage.getItem('mmTourDone')&&typeof APP_VERSION!=='undefined')localStorage.setItem('mmTourVersion',APP_VERSION);}catch(e){}
/* The page is a fixed-layout app; never let focus or anchors scroll the viewport. */
window.addEventListener('focusin',function(){if(window.scrollY||window.scrollX)window.scrollTo(0,0);});
window.addEventListener('scroll',function(){if(window.scrollY||window.scrollX)window.scrollTo(0,0);},{passive:true});
document.addEventListener('DOMContentLoaded',function(){if(!A.get()){var demo='';try{demo=sessionStorage.getItem('mmDemo')||'';}catch(e){}if(!demo)GATE.show();}
  setTimeout(MM.boot,260);setTimeout(MM.boot,1300);setTimeout(MM.boot,2800);});
})();
