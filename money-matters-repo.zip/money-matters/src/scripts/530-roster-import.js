(function(){
'use strict';
var NON_STUDENT=/teacher|instructor|staff|faculty|admin|principal|counselor|aide|paraeducator|parent|guardian|owner|coteacher|substitute/;
var OK=['K','1','2','3','4','5','6','7','8'];
var W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
function say(m,ms){try{infoToast(m,ms||6000);}catch(e){alert(m);}}
function key(h){return String(h==null?'':h).replace(/^\uFEFF/,'').toLowerCase().replace(/[^a-z0-9]/g,'');}
function parseCSV(text){var rows=[],row=[],cur='',q=false;for(var i=0;i<text.length;i++){var c=text[i];
 if(q){if(c==='"'){if(text[i+1]==='"'){cur+='"';i++;}else q=false;}else cur+=c;}
 else{if(c==='"')q=true;else if(c===','||c==='\t'||c===';'){row.push(cur);cur='';}
  else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cur);rows.push(row);row=[];cur='';}else cur+=c;}}
 if(cur.length||row.length){row.push(cur);rows.push(row);}
 return rows.filter(function(r){return r.some(function(x){return String(x).trim();});});}
function grade(raw){var g=String(raw==null?'':raw).trim().toLowerCase();if(!g)return null;
 if(/^(k|kg|kdg|kinder|kindergarten|jardin|jardim)/.test(g))return 'K';
 if(/^(pre|tk|pk|nursery|toddler)/.test(g))return 'out';
 var m=g.match(/\d+/);if(!m)return 'out';var n=parseInt(m[0],10);return n>=1&&n<=8?String(n):'out';}
function accounts(){try{var m=window.MM91||{};return m.accounts||m.acc||(window.MM&&window.MM.accounts)||null;}catch(e){return null;}}
function cols(hdr){var k=hdr.map(key);function f(fn){for(var i=0;i<k.length;i++)if(fn(k[i]))return i;return -1;}
 return {first:f(function(h){return /^(first|given|studentfirst)/.test(h);}),
  last:f(function(h){return /^(last|family|sur|studentlast)/.test(h);}),
  name:f(function(h){return /^(name|studentname|fullname|student|learner|pupil|studentfullname)$/.test(h);}),
  grade:f(function(h){return /grade|level/.test(h)&&!/graduat/.test(h);}),
  role:f(function(h){return /^(role|roles|usertype|type|persontype|accounttype|position|userrole)$/.test(h);}),
  teacher:f(function(h){return /(teacher|homeroom|advisor)/.test(h)&&!/email|id$/.test(h);})};}
function isHeader(row){return row.map(key).some(function(h){return /^(name|studentname|fullname|student|first|firstname|givenname|studentfirstname|lastname|grade|gradelevel|role|teacher|email|studentid|id)$/.test(h);});}
function tname(x){return String(x==null?'':x).replace(/\s+/g,' ').trim().slice(0,60);}
function gOrder(g){return g==='K'?0:parseInt(g,10);}
function esc(x){return String(x==null?'':x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function download(name,text){try{var b=new Blob([text],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},800);}catch(e){}}
function showResult(r){
 var old=document.getElementById('mm-roster-result');if(old)old.remove();
 var o=document.createElement('div');o.id='mm-roster-result';
 o.style.cssText='position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;padding:14px';
 var h='<div role="dialog" aria-modal="true" style="background:#fffaf0;color:#2b1d0e;border-radius:16px;max-width:480px;width:100%;max-height:86vh;overflow:auto;padding:18px;font:15px/1.45 system-ui,sans-serif;box-shadow:0 12px 40px rgba(0,0,0,.5)">';
 h+='<h2 style="margin:0 0 8px;font-size:20px">\u2705 Roster import complete</h2><ul style="margin:0 0 10px;padding-left:20px">';
 r.lines.forEach(function(l){h+='<li>'+esc(l)+'</li>';});h+='</ul>';
 if(r.warn)h+='<div style="background:#fde8e8;border:1px solid #c0392b;border-radius:10px;padding:8px 10px;margin:8px 0;font-weight:600">'+esc(r.warn)+'</div>';
 if(r.made.length){h+='<div style="font-weight:700;margin:10px 0 4px">New teacher and staff sign-ins</div><div style="font-size:13px;margin-bottom:6px">Temporary passwords are shown only now. They must be changed at first sign-in.</div><div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:13px"><tr style="text-align:left"><th style="padding:4px 6px">Name</th><th style="padding:4px 6px">Username</th><th style="padding:4px 6px">Password</th></tr>';
  r.made.forEach(function(m){h+='<tr style="border-top:1px solid #e0d2b8"><td style="padding:4px 6px">'+esc(m.name)+'</td><td style="padding:4px 6px"><code>'+esc(m.u)+'</code></td><td style="padding:4px 6px"><code>'+esc(m.pw)+'</code></td></tr>';});h+='</table></div>';}
 h+='<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button type="button" id="mm-rr-us" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid #2e7d57;background:#fff;color:#14472d;font-weight:700">\uD83D\uDC65 View users</button><button type="button" id="mm-rr-sw" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid #2e7d57;background:#fff;color:#14472d;font-weight:700">\u21C4 Switch profile</button></div>';
 h+='<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">';
 if(r.added>=10)h+='<div style="background:#fff3cd;border:1px solid #c4912e;border-radius:10px;padding:8px 10px;margin:8px 0">You just added '+r.added+' students. Download a backup so this roster is safe.</div>';
 h+='<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">'; if(r.added)h+='<button type="button" id="mm-rr-bk" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid #c4912e;background:#fff;color:#5a3d0a;font-weight:700">\uD83D\uDCBE Back up now</button>'; if(r.undo)h+='<button type="button" id="mm-rr-un" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid #c0392b;background:#fff;color:#8e2418;font-weight:700">\u21A9 Undo import</button>'; h+='</div>';
 if(r.made.length)h+='<button type="button" id="mm-rr-dl" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid #2e7d57;background:#fff;color:#14472d;font-weight:700">Download sign-in sheet</button>';
 h+='<button type="button" id="mm-rr-ok" style="flex:1;padding:10px 12px;border-radius:10px;border:0;background:#2e7d57;color:#fff;font-weight:700">Done</button></div></div>';
 o.innerHTML=h;document.body.appendChild(o);
 var ok=document.getElementById('mm-rr-ok');ok.onclick=function(){o.remove();};ok.focus();
 var us=document.getElementById('mm-rr-us');if(us)us.onclick=function(){o.remove();try{openPanel('admin');MM91.admin.open('users');}catch(e){}};
 var sw=document.getElementById('mm-rr-sw');if(sw)sw.onclick=function(){o.remove();try{openPanel('login');}catch(e){}};
 var bk=document.getElementById('mm-rr-bk');if(bk)bk.onclick=function(){try{backupData();}catch(e){say('Use Data & Backup to download a backup.');}};
 var un=document.getElementById('mm-rr-un');if(un)un.onclick=function(){var u=window.mmUndoLastImport();o.remove();say(u?('\u21A9 Import undone: '+u.students+' students and '+u.teachers+' teacher profiles removed'):'Nothing to undo.',5000);};
 var dl=document.getElementById('mm-rr-dl');
 if(dl)dl.onclick=function(){var csv='Name,Role,Username,Temporary password\n'+r.made.map(function(m){return [m.name,m.role,m.u,m.pw].map(function(x){return '"'+String(x).replace(/"/g,'""')+'"';}).join(',');}).join('\n');download('teacher-sign-ins.csv',csv);};}
function refreshUI(){
 try{refreshStudentUI();buildGradeNav();if(openPanelId==='teacher')renderTeacher();}catch(e){}
 try{var ae=document.activeElement;if(ae&&ae.blur)ae.blur();}catch(e){}
 function again(){try{var ad=window.MM91&&MM91.admin;if(!ad)return;if(ad.state){ad.state.grade='';ad.state.q='';ad.state.teacher='';}
  if(openPanelId==='admin')ad.open('students');}catch(e){}}
 again();setTimeout(again,500);}
function planOf(cand,staffRows,have,A){
 var seen={},newN=0,already=0,dup=0,gc={},sample=[],tn={},tNew=[],tOld=0,named={};
 try{A&&A.list&&A.list().forEach(function(a){if(a.role!=='student')named[String(a.name||'').toLowerCase()]=1;});}catch(e){}
 cand.forEach(function(x){var k=x.name.toLowerCase()+'|'+x.grade;
  if(have[k])already++;else if(seen[k])dup++;else{seen[k]=1;newN++;gc[x.grade]=(gc[x.grade]||0)+1;if(sample.length<8)sample.push(x);}
  if(x.teacher)tn[x.teacher.toLowerCase()]=x.teacher;});
 staffRows.forEach(function(x){tn[x.name.toLowerCase()]=x.name;});
 Object.keys(tn).forEach(function(k){if(named[k])tOld++;else tNew.push(tn[k]);});
 return {newN:newN,already:already,dup:dup,gc:gc,sample:sample,tNew:tNew,tOld:tOld};}
async function previewDialog(p,w){
 if(typeof window.mmDlg!=='function')return true;
 var g=Object.keys(p.gc).sort(function(a,b){return gOrder(a)-gOrder(b);}).map(function(k){return (k==='K'?'K':'Gr '+k)+': '+p.gc[k];}).join(' \u00B7 ');
 var shown=p.cap!=null?p.cap:p.newN;
 var h='<ul style="margin:0 0 8px;padding-left:20px"><li><b>'+shown+'</b> new students'+(g?' ('+esc(g)+')':'')+'</li>';
 if(p.already)h+='<li>'+p.already+' already on the roster (not duplicated; teacher updated if given)</li>';
 h+='<li><b>'+p.tNew.length+'</b> new teacher/staff profiles'+(p.tNew.length?': '+esc(p.tNew.slice(0,8).join(', '))+(p.tNew.length>8?'\u2026':''):'')+(p.tOld?' ('+p.tOld+' already exist)':'')+'</li></ul>';
 var wr=[];
 if(p.cap!=null)wr.push('Your plan has '+p.cap+' seats left, so only the first '+p.cap+' of '+p.newN+' new students will be imported.');
 if(w.noGrade)wr.push(w.noGrade+' rows have no grade; Grade '+w.fb+' will be used.');
 if(w.out)wr.push(w.out+' rows are outside K\u20138 and will be left out.');
 if(p.dup)wr.push(p.dup+' repeated names in the file will be imported once.');
 if(w.blocked)wr.push(w.blocked+' administrator rows will be left out for safety.');
 if(w.blank)wr.push(w.blank+' blank rows will be skipped.');
 if(wr.length)h+='<div style="background:#fff3cd;border:1px solid #c4912e;border-radius:10px;padding:8px 10px;margin:8px 0;font-size:13px">\u26A0 '+wr.map(esc).join('<br>\u26A0 ')+'</div>';
 if(p.sample.length){h+='<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:13px"><tr style="text-align:left"><th style="padding:3px 6px">Student</th><th style="padding:3px 6px">Grade</th><th style="padding:3px 6px">Teacher</th></tr>';
  p.sample.forEach(function(x){h+='<tr style="border-top:1px solid #e0d2b8"><td style="padding:3px 6px">'+esc(x.name)+'</td><td style="padding:3px 6px">'+esc(x.grade)+'</td><td style="padding:3px 6px">'+esc(x.teacher||'')+'</td></tr>';});
  h+='</table></div>'+(p.newN>p.sample.length?'<div style="font-size:12px;margin-top:4px">Showing the first '+p.sample.length+' of '+p.newN+'.</div>':'');}
 var nothing=!p.newN&&!p.tNew.length;
 var d=window.mmDlg('Review roster import',h,nothing?[{id:'no',label:'Close',primary:true}]:[{id:'no',label:'Cancel'},{id:'go',label:'Import '+shown+' students',primary:true}]);
 var id=await d.promise;d.close();return id==='go';}
window.mmUndoLastImport=function(){
 var u=null;try{u=JSON.parse(localStorage.getItem('mmLastImport')||'null');}catch(e){}
 if(!u)return null;var s=loadStore(),n=0;
 (u.students||[]).forEach(function(id){if(s.list[id]){delete s.list[id];n++;}});
 (u.updated||[]).forEach(function(x){if(s.list[x.id]){if(x.prev)s.list[x.id].teacher=x.prev;else delete s.list[x.id].teacher;}});
 s.teachers=(u.prevTeachers||[]).slice();saveStore(s);
 var A=accounts();(u.accounts||[]).forEach(function(un){try{A.remove(un);}catch(e){}});try{A.ensureStudents();}catch(e){}
 try{localStorage.removeItem('mmLastImport');}catch(e){}refreshUI();
 return {students:n,teachers:(u.accounts||[]).length};};
async function importRows(rows,forceHdr){
 if(window.mmFixStaleSample)window.mmFixStaleSample();
 try{if(window.MM91&&MM91.sample&&MM91.sample.active()){say('Sample mode is on, so nothing would be saved. Tap Exit sample, sign in, then import.',7000);return;}}catch(e){}
 try{if(window.mmPurgeSample)window.mmPurgeSample();}catch(e){}
 if(!rows||!rows.length){say('That file has no rows to import.');return;}
 var hasHdr=forceHdr||isHeader(rows[0]),c=hasHdr?cols(rows[0]):{first:-1,last:-1,name:0,grade:1,role:-1,teacher:2};
 if(hasHdr&&c.first<0&&c.name<0){say('Could not find a student name column. Use a header such as "Student Name" or "First Name" and "Last Name".',7000);return;}
 var data=hasHdr?rows.slice(1):rows,s=loadStore();if(!s.list)s.list={};if(!s.teachers)s.teachers=[];
 var fb=(typeof currentGrade!=='undefined'&&OK.indexOf(currentGrade)>=0)?currentGrade:'K';
 var cand=[],staffRows=[],out=0,blank=0,noGrade=0,blocked=0;
 data.forEach(function(r){
  var cell=function(i){return i>=0&&i<r.length?String(r[i]==null?'':r[i]).trim():'';};
  if(!hasHdr&&/^teacher\s*[:\-]/i.test(String(r[0]||''))){var tn0=tname(String(r[0]).replace(/^teacher\s*[:\-]\s*/i,''));if(tn0)staffRows.push({name:tn0,role:'teacher'});return;}
  var name=c.first>=0?(cell(c.first)+' '+cell(c.last)).trim():'';if(!name&&c.name>=0)name=cell(c.name);
  name=tname(name).slice(0,40);
  var rk=c.role>=0?key(cell(c.role)):'';
  if(rk){if(/admin|principal|owner/.test(rk)){blocked++;return;}
   if(/coteacher/.test(rk)){if(name)staffRows.push({name:name,role:'coteacher'});return;}
   if(/teacher|instructor|faculty|staff|aide|paraeducator|substitute|counselor/.test(rk)){if(name)staffRows.push({name:name,role:'teacher'});return;}
   if(/parent|guardian/.test(rk)){if(name)staffRows.push({name:name,role:'guardian'});return;}}
  if(!name){blank++;return;}
  var g=grade(cell(c.grade));
  if(g===null){g=fb;noGrade++;}else if(g==='out'){out++;return;}
  cand.push({name:name,grade:g,teacher:c.teacher>=0?tname(cell(c.teacher)):''});});
 var have={};Object.keys(s.list).forEach(function(id){var st=s.list[id];if(st&&st.name)have[st.name.toLowerCase()+'|'+(st.grade||'K')]=id;});
 var A0=accounts(),plan=planOf(cand,staffRows,have,A0),cap=Infinity,seat=null;
 try{seat=window.mmCloud&&window.mmCloud.seatInfo?window.mmCloud.seatInfo():null;}catch(e){}
 if(seat&&isFinite(seat.limit)){cap=seat.remaining;
  if(plan.newN>0&&cap<=0){say('Your plan allows '+seat.limit+' students and every seat is used. Add seats in Account and subscription.',8000);try{window.mmCloud.open();}catch(e){}return;}
  if(plan.newN>cap)plan.cap=cap;}
 var okGo=await previewDialog(plan,{out:out,blocked:blocked,blank:blank,noGrade:noGrade,fb:fb,total:cand.length+staffRows.length});
 if(!okGo){say('Import cancelled. Nothing was changed.');return;}
 var before=Object.keys(s.list).length,added=0,already=0,assigned=0,overLimit=0,tmap={},prevT=s.teachers.slice(),addedIds=[],updatedT=[];
 function tnote(name,role,g){if(!name)return;var k=name.toLowerCase();if(!tmap[k])tmap[k]={name:name,role:role||'teacher',grades:{}};if(g)tmap[k].grades[g]=1;if(s.teachers.indexOf(name)<0)s.teachers.push(name);}
 cand.forEach(function(x){var k=x.name.toLowerCase()+'|'+x.grade,id=have[k];
  if(id){already++;if(x.teacher){updatedT.push({id:id,prev:s.list[id].teacher||''});s.list[id].teacher=x.teacher;assigned++;}}
  else{if(added>=cap){overLimit++;return;}id=newId();s.list[id]={id:id,name:x.name,grade:x.grade,prog:{},created:new Date().toISOString()};if(x.teacher)s.list[id].teacher=x.teacher;have[k]=id;addedIds.push(id);added++;if(x.teacher)assigned++;}
  tnote(x.teacher,'teacher',x.grade);});
 staffRows.forEach(function(x){tnote(x.name,x.role,null);});
 saveStore(s);
 var A=accounts();try{if(A&&A.ensureStudents)A.ensureStudents();}catch(e){}
 var want=before+added,got=want;try{got=MM91.data.list().length;}catch(e){}
 var warn='';if(got!==want){try{saveStore(s);got=MM91.data.list().length;}catch(e){}if(got!==want)warn='Your browser did not keep the imported students ('+got+' saved, '+want+' expected). Storage may be blocked or full. Back up, free some space, then import again.';}
 var made=[],existingT=0,failed=0,failList=[];
 if(A&&A.add&&A.list){var named={};A.list().forEach(function(a){if(a.role!=='student')named[String(a.name||'').toLowerCase()]=1;});
  var keys=Object.keys(tmap);
  for(var i=0;i<keys.length;i++){var tm=tmap[keys[i]];if(named[keys[i]]){existingT++;continue;}
   var gs=Object.keys(tm.grades).sort(function(a,b){return gOrder(a)-gOrder(b);});
   try{var res=await A.add({name:tm.name,role:tm.role,scope:gs.length?gs:'all',mustChange:true,by:'roster import'});
    if(res&&res.account)made.push({name:tm.name,role:tm.role,u:res.account.u,pw:res.password});else{failed++;failList.push(tm.name+(res&&res.error?' ('+res.error+')':''));}}catch(e){failed++;failList.push(tm.name+' ('+(e&&e.message?e.message:'error')+')');}}}
 if(addedIds.length||made.length||updatedT.length){try{localStorage.setItem('mmLastImport',JSON.stringify({t:Date.now(),students:addedIds,updated:updatedT,prevTeachers:prevT,accounts:made.map(function(m){return m.u;})}));}catch(e){}}
 refreshUI();
 var lines=[added+' students added'];
 if(already)lines.push(already+' students were already on the roster');
 if(overLimit)lines.push(overLimit+' students were not imported because your plan has no seats left');
 if(assigned)lines.push(assigned+' students assigned to a teacher');
 lines.push(made.length+' teacher/staff profiles created'+(existingT?(' ('+existingT+' already existed)'):''));
 if(failed)lines.push(failed+' teacher profiles could not be created: '+failList.join('; '));
 if(out)lines.push(out+' rows outside K\u20138 left out');
 if(blocked)lines.push(blocked+' administrator rows left out for safety');
 if(blank)lines.push(blank+' blank rows');
 if(noGrade)lines.push(noGrade+' rows had no grade, so Grade '+fb+' was used');
 say('\u2705 '+added+' students and '+made.length+' teachers added',4000);
 try{if(window.mmCloud&&window.mmCloud.reportUsage)window.mmCloud.reportUsage();}catch(e){}
 showResult({lines:lines,made:made,warn:warn,added:added,undo:!!(addedIds.length||made.length||updatedT.length)});}
function jsonRows(v){
 if(typeof v==='string'){try{v=JSON.parse(v);}catch(e){return null;}}
 if(v&&!Array.isArray(v)&&typeof v==='object'){var a=v.students||v.roster||v.list||v.data||v.items||v.users||v.people;v=a||v;}
 if(v&&!Array.isArray(v)&&typeof v==='object')v=Object.keys(v).map(function(k){return v[k];});
 if(!Array.isArray(v))return null;
 if(v.every(function(x){return typeof x==='string'||typeof x==='number';}))return {rows:v.map(function(x){return String(x).split(/[,\t;]/);}),hdr:false};
 var keys=[],objs=v.filter(function(o){return o&&typeof o==='object';});
 objs.forEach(function(o){Object.keys(o).forEach(function(k){if(keys.indexOf(k)<0&&(o[k]==null||typeof o[k]!=='object'))keys.push(k);});});
 return {rows:[keys].concat(objs.map(function(o){return keys.map(function(k){return o[k]==null?'':o[k];});})),hdr:true};}
async function importText(text){
 text=String(text||'').replace(/^\uFEFF/,'');
 if(!text.trim()){say('Paste a roster or choose a file first.');return;}
 var h=text.trim().charAt(0);
 if(h==='{'||h==='['){var j=jsonRows(text);if(j){await importRows(j.rows,j.hdr);return;}}
 await importRows(parseCSV(text),false);}
function u16(d,o){return d[o]|(d[o+1]<<8);}
function u32(d,o){return (d[o]|(d[o+1]<<8)|(d[o+2]<<16)|(d[o+3]<<24))>>>0;}
async function unzip(buf,name){
 var d=new Uint8Array(buf),i=d.length-22;
 for(;i>=0;i--)if(u32(d,i)===0x06054b50)break;
 if(i<0)throw new Error('This is not a valid Word (.docx) file.');
 var n=u16(d,i+10),off=u32(d,i+16);
 for(var k=0;k<n;k++){if(u32(d,off)!==0x02014b50)break;
  var method=u16(d,off+10),cs=u32(d,off+20),nl=u16(d,off+28),el=u16(d,off+30),cl=u16(d,off+32),lho=u32(d,off+42);
  var nm=new TextDecoder().decode(d.subarray(off+46,off+46+nl));
  if(nm===name){var st=lho+30+u16(d,lho+26)+u16(d,lho+28),data=d.subarray(st,st+cs);
   if(method===0)return data;
   if(method===8){if(typeof DecompressionStream==='undefined')throw new Error('This browser cannot open Word files. Save the roster as CSV instead.');
    var stream=new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());}
   throw new Error('Unsupported Word file compression.');}
  off+=46+nl+el+cl;}
 return null;}
function wText(el){var out='',all=el.getElementsByTagNameNS('*','*');
 for(var i=0;i<all.length;i++){var ln=all[i].localName;if(ln==='t')out+=all[i].textContent;else if(ln==='tab')out+='\t';else if(ln==='br')out+=' ';}
 return out;}
async function docxRows(buf){
 var xml=await unzip(buf,'word/document.xml');if(!xml)throw new Error('No text found in that Word file.');
 var doc=new DOMParser().parseFromString(new TextDecoder().decode(xml),'application/xml');
 var body=doc.getElementsByTagNameNS(W,'body')[0];if(!body)throw new Error('No text found in that Word file.');
 var rows=[],kids=body.children;
 for(var i=0;i<kids.length;i++){var el=kids[i];
  if(el.localName==='tbl'){var trs=el.getElementsByTagNameNS(W,'tr');
   for(var r=0;r<trs.length;r++){var tcs=trs[r].getElementsByTagNameNS(W,'tc'),row=[];for(var c=0;c<tcs.length;c++)row.push(wText(tcs[c]).trim());if(row.some(Boolean))rows.push(row);}}
  else if(el.localName==='p'){var tx=wText(el).replace(/^\s*(?:\d{1,3}[.)]|[-\u2022*])\s+/,'').trim();if(tx)rows.push(tx.split(/[,\t;]/).map(function(x){return x.trim();}));}}
 return rows;}
function decode(buf){var d=new Uint8Array(buf);
 if(d[0]===0xFF&&d[1]===0xFE)return new TextDecoder('utf-16le').decode(d);
 if(d[0]===0xFE&&d[1]===0xFF)return new TextDecoder('utf-16be').decode(d);
 return new TextDecoder('utf-8').decode(d);}
window.importRosterText=function(text){return Promise.resolve().then(function(){return importText(text);}).catch(function(e){say('Import failed: '+(e&&e.message?e.message:e),8000);});};
window.importRosterFile=async function(ev){
 var inp=ev&&ev.target,f=inp&&inp.files&&inp.files[0];if(!f)return;
 try{
  say('Reading '+f.name+'\u2026',2500);
  var buf=await f.arrayBuffer(),d=new Uint8Array(buf),name=(f.name||'').toLowerCase();
  if(d[0]===0x50&&d[1]===0x4B){await importRows(await docxRows(buf),false);}
  else if(/\.doc$/.test(name)||(d[0]===0xD0&&d[1]===0xCF)){say('Older .doc files cannot be read. In Word, choose Save As and pick .docx, CSV, or plain text.',9000);}
  else{await importText(decode(buf));}
 }catch(e){say('Import failed: '+(e&&e.message?e.message:e),8000);}
 try{inp.value='';}catch(e){}};
})();
