(function(){
  'use strict';
  var AUTH='mmAuth_v1', LOGIN_USER='mmLoginUser_v1';
  var gate=null, role='student', selectedUser=null;
  function esc55(s){try{return typeof esc==='function'?esc(String(s||'')):String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]||c});}catch(e){return '';}}
  function auth(){try{return JSON.parse(sessionStorage.getItem(AUTH)||'null')}catch(e){return null}}
  function setAuth(r,name,id){try{sessionStorage.setItem(AUTH,JSON.stringify({role:r,name:name||'',id:id||'',at:Date.now()}));}catch(e){}}
  function clearAuth(){try{sessionStorage.removeItem(AUTH)}catch(e){} }
  function savedUser(){try{return localStorage.getItem(LOGIN_USER)||''}catch(e){return ''}}
  function saveUser(v){try{if(v)localStorage.setItem(LOGIN_USER,v);else localStorage.removeItem(LOGIN_USER)}catch(e){}}
  function store(){try{return loadStore()}catch(e){return {list:{},teachers:[]}}}
  function findStudent(name,code){
    var s=store(), ids=Object.keys(s.list||{}), n=String(name||'').trim().toLowerCase(), c=String(code||'').trim().toUpperCase(); if(!n||!c)return null;
    for(var i=0;i<ids.length;i++){var st=s.list[ids[i]]; if(st&&String(st.name||'').trim().toLowerCase()===n&&String(st.verifyCode||'').trim().toUpperCase()===c)return st;}
    return null;
  }
  function ensureCodes(){
    try{
      var s=store(), ids=Object.keys(s.list||{}), used={}; ids.forEach(function(id){var c=s.list[id]&&s.list[id].verifyCode;if(c)used[String(c).toUpperCase()]=1;});
      var changed=false;
      function code(){var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',x='';do{x='';for(var i=0;i<6;i++)x+=chars[Math.floor(Math.random()*chars.length)];}while(used[x]);used[x]=1;return x;}
      ids.forEach(function(id){if(s.list[id]&&!s.list[id].verifyCode){s.list[id].verifyCode=code();changed=true;}}); if(changed)saveStore(s);
    }catch(e){}
  }
  function setRole(r){role=r;render();}
  function roleScreen(){
    return '<div class="mm-login-brand"><div class="logo">💰</div><h1>Money Matters</h1><p>K–8 Financial Literacy Curriculum</p></div>'+
      '<div class="mm-login-title">Who are you?</div><div class="mm-role-choice">'+
      '<button class="mm-role-card '+(role==='student'?'selected':'')+'" onclick="window.mmV55Role(\'student\')"><span class="mm-role-icon">🎒</span><span class="mm-role-name">Student</span><div class="mm-role-help">Sign in to your learning profile</div></button>'+
      '<button class="mm-role-card '+(role==='teacher'?'selected':'')+'" onclick="window.mmV55Role(\'teacher\')"><span class="mm-role-icon">👩‍🏫</span><span class="mm-role-name">Teacher or Parent/Guardian</span><div class="mm-role-help">Set up learners, follow lessons, and see progress</div></button></div>'+
      '<button class="mm-login-submit" onclick="window.mmV55ContinueRole()">Continue</button>'+
      '<div class="mm-login-note">Each browser tab has its own signed-in session, so different users can work at the same time.</div>';
  }
  function loginScreen(){
    var u=savedUser(), teacher=role==='teacher';
    return '<div class="mm-login-brand"><div class="logo">'+(teacher?'👩‍🏫':'🎒')+'</div><h1>Money Matters</h1><p>Sign in on this device</p></div>'+
      '<div style="text-align:center"><span class="mm-login-indicator">'+(teacher?'👩‍🏫 Teacher':'🎒 Student')+'</span></div>'+
      '<div class="mm-login-title">'+(teacher?'Teacher Login':'Student Login')+'</div>'+ 
      '<div class="mm-login-field"><span class="field-icon">👤</span><input id="mm55-user" autocomplete="username" value="'+esc55(u)+'" placeholder="Student name" aria-label="Student name"></div>'+ 
      '<div class="mm-login-field"><span class="field-icon">🔒</span><input id="mm55-pass" type="password" autocomplete="current-password" placeholder="'+(teacher?'Password':'Verification code (optional)')+'" aria-label="Password or optional verification code"><button class="eye" type="button" onclick="window.mmV55Eye()" aria-label="Show password">◉</button></div>'+ 
      '<div class="mm-login-row"><label><input id="mm55-remember" type="checkbox"> Remember me</label><button type="button" onclick="window.mmV55Forgot()">'+(teacher?'Forgot password?':'Need your code?')+'</button></div>'+ 
      '<div id="mm55-error" class="mm-login-error" role="alert"></div><button class="mm-login-submit" onclick="window.mmV55Login()">LOGIN</button>'+ 
      '<button class="mm-login-back" onclick="window.mmV55Back()">← Change user type</button>'+ 
      (!teacher?'<div class="mm-login-new">New student? <button onclick="window.mmV55NewStudent()">Create a student profile</button></div>':(!((typeof _hasPin==='function')&&_hasPin())?'<div class="mm-login-new">First time here? <button onclick="window.mmV55SetupTeacher()">Set up Teacher access</button></div>':''))+
      '<div class="mm-login-note">Your session stays in this browser tab. Student data remains stored locally on this device.</div>';
  }
  function render(){
    if(!gate)return; gate.innerHTML='<div class="mm-login-shell">'+(selectedUser?loginScreen():roleScreen())+'</div>';
  }
  function show(){
    ensureCodes(); if(!gate){gate=document.createElement('div');gate.id='mm-login-gate';document.body.appendChild(gate);} gate.classList.remove('mm-hidden'); selectedUser=false; try{role=(sessionStorage.getItem('mmLoginRole')||'student');}catch(e){role='student';} render();}
  function hide(){if(gate)gate.classList.add('mm-hidden'); updateIndicator();}
  function continueRole(){selectedUser=true;try{sessionStorage.setItem('mmLoginRole',role)}catch(e){}render();setTimeout(function(){var u=document.getElementById('mm55-user');if(u)u.focus()},50);}
  function setError(msg){var e=document.getElementById('mm55-error');if(e)e.textContent=msg;}
  function login(){
    var u=(document.getElementById('mm55-user')||{}).value||'', p=(document.getElementById('mm55-pass')||{}).value||'', remember=document.getElementById('mm55-remember');
    u=u.trim();p=p.trim();setError('');
    if(!u){setError(role==='student'?'Enter the student name.':'Enter your username.');return;}
    if(role==='teacher'&&!p){setError('Enter your teacher password.');return;}
    if(remember&&remember.checked)saveUser(u);else saveUser('');
    if(role==='student'){
      var st=null, ss=store(), ids=Object.keys(ss.list||{}), nm=u.toLowerCase(), code=p.toUpperCase();
      for(var si=0;si<ids.length;si++){
        var cand=ss.list[ids[si]];
        if(cand&&String(cand.name||'').trim().toLowerCase()===nm){
          if(!p || String(cand.verifyCode||'').trim().toUpperCase()===code){st=cand;break;}
        }
      }
      if(!st){setError(p?'Student not found. Check the name and 6-character verification code.':'Student not found. Check the student name.');return;}
      try{sessionStorage.setItem('mmRole','student')}catch(e){}
      try{switchStudent(st.id)}catch(e){setTabActive(st.id);}
      setAuth('student',st.name,st.id); hide(); applyRole(); infoToast('✓ Signed in as '+st.name,2500); return;
    }
    if(typeof _hasPin==='function'&&!_hasPin()){setError('A teacher passcode has not been set. Use the Teacher setup from the Student desk.');return;}
    if(typeof _verifyPin!=='function'){setError('Teacher sign-in is temporarily unavailable.');return;}
    _verifyPin(p).then(function(ok){if(!ok){setError('Incorrect teacher password.');return;} try{sessionStorage.setItem('mmRole','teacher')}catch(e){};setAuth('teacher',u,'teacher');if(typeof addTeacherName==='function')addTeacherName(u);hide();applyRole();infoToast('✓ Teacher signed in',2500);});
  }
  function newStudent(){
    hide(); try{openPanel('login');renderLogin();}catch(e){}; setTimeout(function(){var x=document.getElementById('newStudentName');if(x)x.focus();},120);
  }
  function forgot(){if(role==='teacher'&&typeof forgotPin==='function')forgotPin();else alert('Ask your teacher for your student verification code.');}
  function setupTeacher(){
    if(role!=='teacher')return;
    if(typeof mmInput!=='function'){alert('Teacher setup is temporarily unavailable.');return;}
    mmInput('Set a teacher password','At least 3 characters',{icon:'🔐',password:true,okLabel:'Continue',subtext:'Create a private password for Teacher/Parent mode. Keep it away from students.'}).then(function(np){
      if(np===null)return; var v=String(np||'').trim(); if(v.length<3){alert('Password must be at least 3 characters.');return;}
      if(typeof _storePin==='function')_storePin(v).then(function(){setError('');alert('Teacher password created. Sign in with it now.');render();});
    });
  }
  function back(){selectedUser=false;render();}
  function eye(){var p=document.getElementById('mm55-pass');if(p)p.type=p.type==='password'?'text':'password';}
  function updateIndicator(){
    var a=auth(),el=document.getElementById('mm-session-indicator'); if(!el){el=document.createElement('button');el.id='mm-session-indicator';document.body.appendChild(el);}
    if(!a){el.style.display='none';return;} el.style.display='block';el.className=a.role==='teacher'?'teacher':'';el.textContent=(a.role==='teacher'?'👤 ':'🎒 ')+(a.name||'Active');el.onclick=function(){try{openPanel('login');renderLogin()}catch(e){}};
  }
  window.mmV55Role=setRole;window.mmV55ContinueRole=continueRole;window.mmV55Login=login;window.mmV55Forgot=forgot;window.mmV55SetupTeacher=setupTeacher;window.mmV55Back=back;window.mmV55Eye=eye;window.mmV55NewStudent=newStudent;
  window.mmV55Show=show;window.mmV55Hide=hide;window.mmV55Update=updateIndicator;
  function intercept(){
    ensureCodes(); updateIndicator();
    if(!auth())show();
    if(typeof openPanel==='function'&&!openPanel.__v55){
      var old=openPanel; function wrapped(id){if(id==='login'&&!auth()){show();return;} old(id); if(id==='login')renderLogin();updateIndicator();} wrapped.__v55=true;openPanel=wrapped;
    }
    if(typeof signOut==='function'&&!signOut.__v55){
      var oldSign=signOut; function ws(){clearAuth();oldSign();show();} ws.__v55=true;signOut=ws;
    }
    document.addEventListener('keydown',function(e){if(gate&&!gate.classList.contains('mm-hidden')&&e.key==='Enter'&&document.activeElement&&document.activeElement.closest&&document.activeElement.closest('.mm-login-field'))login();});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',intercept);else intercept();
})();
