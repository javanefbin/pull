/* =====================================================================
   V21 · PHONE FIXES
   · The phone tour (MM.coach) never shows over the sign-in screen, and
     closes if the sign-in screen appears (it used to cover "Sign in").
   · Sponsor cards (698) also have a place on the phone home screen.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
function gated(){var g=document.getElementById('mm-auth');return !!(g&&!g.classList.contains('mm-hidden'));}
function hideCoach(){var c=document.getElementById('mm-coach');if(c)c.classList.remove('on');}
function fixCoach(){var C=MM.coach;if(!C||!C.start||C.start.__v21)return;var o=C.start;C.start=function(){if(gated())return;return o.apply(this,arguments);};C.start.__v21=1;}
fixCoach();document.addEventListener('DOMContentLoaded',function(){setTimeout(fixCoach,1500);});
if(MM.gate&&MM.gate.show&&!MM.gate.show.__v21){var os=MM.gate.show;MM.gate.show=function(){hideCoach();return os.apply(this,arguments);};MM.gate.show.__v21=1;}
/* V22: on a phone, the home cards get the whole space under the chalkboard. The row of
   station icons is hidden there (the tab bar already goes to the same places), instead of
   squeezing the cards into the strip between the stations and the tab bar. */
var S=MM.shell;
function phoneHome(){return innerWidth<=640&&document.documentElement.classList.contains('mm-tabs-on');}
if(S&&S.placeHome&&!S.placeHome.__v22){var op=S.placeHome;S.placeHome=function(){var ph=phoneHome();document.documentElement.classList.toggle('mm-phone-home',ph);if(!ph)return op.apply(this,arguments);
  var el=document.getElementById('mm-home'),room=document.querySelector('#scene .room'),chalk=document.querySelector('.chalkboard');if(!el||!room||!chalk)return op.apply(this,arguments);
  var R=room.getBoundingClientRect(),C=chalk.getBoundingClientRect(),limit=innerHeight;
  ['nav','mm-tabbar'].forEach(function(id){var n=document.getElementById(id);if(!n)return;var cs=getComputedStyle(n);if(cs.display==='none'||cs.visibility==='hidden')return;var r=n.getBoundingClientRect();if(r.height>0&&r.top<limit)limit=r.top;});
  var top=C.bottom+12,h=limit-10-top;if(h<140)return op.apply(this,arguments);
  el.classList.remove('hidden');el.style.top=(top-R.top)+'px';el.style.height=h+'px';el.classList.toggle('compact',h<320);
  var grid=el.querySelector('.mm-home-grid');if(grid){grid.style.maxHeight=h+'px';grid.style.gridAutoRows='auto';}
  el.querySelectorAll('.mm-home-card').forEach(function(c){c.style.display='';});};S.placeHome.__v22=1;
  window.addEventListener('resize',function(){try{S.placeHome();}catch(e){}});}
/* (a document-wide class observer used to live here; it looped with the phone layout
   observer during sign-out and froze the page, so the two guards above do the job alone) */
})();
