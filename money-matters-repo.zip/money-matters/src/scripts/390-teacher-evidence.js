(function(){'use strict';
if(typeof renderTeacher!=='function'||renderTeacher.__mm80)return;
var rt=renderTeacher;
var w=function(){rt.apply(this,arguments);try{var el=document.getElementById('teacherBody'),s=loadStore();if(!el)return;
 var id=(typeof teacherStudentFilter!=='undefined'&&teacherStudentFilter)||s.active,st=id&&s.list[id];if(!st)return;
 var g=st.grade||'K',ev=[];try{ev=JSON.parse(localStorage.getItem('mmStoryEvidence_v1_'+id+'_'+g)||'[]')||[];}catch(e){}
 var E=function(x){return String(x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});};
 var d=document.createElement('div');d.className='card story-evidence';
 if(!ev[0]){d.innerHTML='<div class="card-title">\uD83C\uDFAD Story Mode evidence</div><div class="card-body">No Story Mode attempt has been recorded for '+E(st.name)+'.</div>';}
 else{var x=ev[0],sk=Object.keys(x.skills||{}).map(function(k){var q=x.skills[k];return '<div><b>'+E(k)+'</b>: '+q.correct+' of '+q.total+' \u00B7 '+E(q.choice||'')+'</div>';}).join('');
  d.innerHTML='<div class="card-title">\uD83C\uDFAD Story Mode evidence \u00B7 '+E(st.name)+'</div><div class="card-body"><div class="story-evidence-grid"><div class="story-stat"><b>'+x.score+'%</b><small>Latest score</small></div><div class="story-stat"><b>'+E(x.difficulty||'')+'</b><small>Path</small></div><div class="story-stat"><b>$'+(x.saved||0)+'</b><small>In the jar</small></div><div class="story-stat"><b>$'+(x.wallet||0)+'</b><small>In the wallet</small></div></div><div style="margin-top:10px"><b>Skill evidence</b>'+sk+'</div>'+(x.reflection?'<div class="st-note" style="margin-top:8px"><b>Reflection:</b> '+E(x.reflection)+'</div>':'')+'<div class="st-note" style="margin-top:8px">'+E(x.date||'')+'</div></div>';}
 el.appendChild(d);}catch(e){}};
w.__mm80=1;window.renderTeacher=w;
})();
