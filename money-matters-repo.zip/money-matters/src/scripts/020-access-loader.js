/* Licensed content loader (runs in <head>, before the curriculum data).
   Hosted public build: week 1 of every grade ships in the page; weeks 2-36,
   section tests, Spanish/Portuguese lessons and workshops come from
   /api/content when this device has a valid school access code
   (localStorage mmAccess_v1: an access code, or a device token from Google,
   Microsoft or Facebook sign-in, which the server renews via X-MM-Token). The request is versioned (?v=) and cached by the
   browser for up to 7 days, so pages load instantly and keep working offline.
   mmContent(key, freePart) returns the licensed pack when it loaded, else the
   free part that the public build embeds. */
/* a random id for this browser (no personal data); the server counts devices per license */
window.mmDeviceId=function(){var K='mmDevice_v1',d='';try{d=localStorage.getItem(K)||'';}catch(e){}
  if(!/^[A-Za-z0-9_-]{16,64}$/.test(d)){var a=new Uint8Array(16);try{crypto.getRandomValues(a);}catch(e){for(var i=0;i<16;i++)a[i]=Math.random()*256|0;}d=[].map.call(a,function(b){return ('0'+b.toString(16)).slice(-2);}).join('');try{localStorage.setItem(K,d);}catch(e){}}return d;};
window.mmContent=function(k,free){var f=window.__MM_FULL;return f&&f[k]!=null?f[k]:free;};
(function(){var K='mmAccess_v1',c='';try{c=localStorage.getItem(K)||'';}catch(e){}
if(!c||!/^https?:$/.test(location.protocol))return;
var v=window.MM_CONTENT_VERSION||'';
try{var x=new XMLHttpRequest();x.open('GET','/api/content'+(v?'?v='+encodeURIComponent(v):''),false);x.setRequestHeader('Authorization','Bearer '+c);try{x.setRequestHeader('X-MM-Device',mmDeviceId());}catch(e){}x.send();
if(x.status===200){try{var nt=x.getResponseHeader('X-MM-Token');if(nt&&/^MMD1\./.test(nt))localStorage.setItem(K,nt);}catch(e){}var f=JSON.parse(x.responseText);window.__MM_LICENSE=f.__label||'';window.__MM_LICENSE_EXPIRES=f.__expires||'';delete f.__label;delete f.__expires;delete f.__version;window.__MM_FULL=f;}
else if(x.status===401||x.status===403){try{localStorage.removeItem(K);}catch(e){}window.__MM_ACCESS_ERR=/^MMD1\./.test(c)?'signin':1;}
else if(x.status===429)window.__MM_ACCESS_LIMIT=1;
else window.__MM_ACCESS_OFFLINE=1;}catch(e){window.__MM_ACCESS_OFFLINE=1;}})();
