(function(){'use strict';
function auth(){try{return JSON.parse(sessionStorage.getItem('mmAuth_v1')||'null');}catch(e){return null;}}
if(typeof switchStudent==='function'&&!switchStudent.__mm72){
  var o=switchStudent;
  var w=function(id){var a=auth();
    if(!window.__mmLogin&&a&&a.role==='student'&&a.id&&id!==a.id){
      try{infoToast('To switch students, sign in with that student\u2019s name and code.',4000);}catch(e){}
      try{signOut();}catch(e){}
      return;}
    var r=o.apply(this,arguments);
    try{var b=auth();if(b&&b.role==='student'){var st=activeStudent();if(st&&st.id!==b.id)sessionStorage.setItem('mmAuth_v1',JSON.stringify({role:'student',name:st.name,id:st.id,at:Date.now()}));}
      if(window.mmV55Update)window.mmV55Update();}catch(e){}
    return r;};
  w.__mm72=1;switchStudent=w;}
if(typeof signOut==='function'&&!signOut.__mm72){
  var so=signOut;
  var w2=function(){try{localStorage.removeItem('mmLoginUser_v1');}catch(e){}return so.apply(this,arguments);};
  w2.__mm72=1;signOut=w2;}
})();
