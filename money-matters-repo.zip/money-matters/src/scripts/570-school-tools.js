(function(){
'use strict';
var GR=['K','1','2','3','4','5','6','7','8'];
function $(i){return document.getElementById(i);}
function esc(x){return String(x==null?'':x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function say(m,ms){try{infoToast(m,ms||4500);}catch(e){alert(m);}}
function A(){var m=window.MM91||{};return m.accounts||null;}
function DD(){return window.MM91&&MM91.data;}
function isAdmin(){try{return MM91.auth.isAdmin();}catch(e){return false;}}
function jget(k,d){try{return JSON.parse(localStorage.getItem(k)||'null')||d;}catch(e){return d;}}
function jset(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function dlg(t,b,btns){return window.mmDlg(t,b,btns);}
function gOrder(g){return g==='K'?0:parseInt(g,10);}
function av(n){return '<span style="width:38px;height:38px;border-radius:50%;background:#2e7d57;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:700;flex:none">'+esc(String(n||'?').trim().charAt(0).toUpperCase())+'</span>';}
function refreshAll(){try{refreshStudentUI();buildGradeNav();}catch(e){}try{var ad=MM91.admin;if(openPanelId==='admin'){ad.scheduleRender?ad.scheduleRender():ad.render();}}catch(e){}}
function download(name,text,type){try{var b=new Blob([text],{type:type||'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},800);}catch(e){}}
var st=document.createElement('style');
st.textContent='html.a11y-motion *,html.a11y-motion *::before,html.a11y-motion *::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;scroll-behavior:auto!important}html.a11y-space body,html.a11y-space p,html.a11y-space li,html.a11y-space .mm-muted{line-height:1.85!important;letter-spacing:.01em}html.a11y-focus :focus-visible{outline:4px solid #ffbf00!important;outline-offset:3px!important}html.mm-key-view #quizForm .q-item{display:block!important}html.mm-key-view #mm-pg-quizForm{display:none!important}.mm-fbnote{font-size:12px;opacity:.8;margin:6px 0}';
document.head.appendChild(st);
/* ===== 1. Archive tab ===== */
function archList(){var s=loadStore();return s.archived||[];}
function vArchive(){
 var arr=archList(),by={};arr.forEach(function(x){var y=x.archivedYear||'Earlier';(by[y]=by[y]||[]).push(x);});
 var years=Object.keys(by).sort().reverse();
 var h='<div class="mm-admin-head"><div><h2>Archive</h2><p>Students archived at year end. Restore anyone archived by mistake, or remove them for good.</p></div></div>';
 if(!arr.length)return h+'<div class="mm-empty"><b>Nothing archived yet</b>Grade 8 students move here when you run the year-end rollover from Roster tools.</div>';
 h+='<div class="mm-card" style="margin-bottom:12px"><div class="mm-row" style="gap:8px;flex-wrap:wrap"><input class="mm-input" id="mmar-q" placeholder="Search archived students" style="flex:1 1 180px"><button type="button" class="mm-btn sm secondary" data-arx="csv">\u2B07 Export CSV</button></div></div>';
 years.forEach(function(y){h+='<div class="mm-label" style="margin:12px 0 6px">'+esc(y)+' ('+by[y].length+')</div>';
  by[y].slice().sort(function(a,b){return String(a.name).localeCompare(String(b.name));}).forEach(function(x){
   h+='<div class="mm-card mmar-row" data-q="'+esc((x.name+' '+(x.teacher||'')).toLowerCase())+'" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:8px;padding:10px 12px">'+av(x.name)+'<div style="flex:1 1 150px"><b>'+esc(x.name)+'</b><div class="mm-muted" style="font-size:13px">Last grade '+esc(x.grade||'8')+(x.teacher?' \u00B7 '+esc(x.teacher):'')+(x.archivedOn?' \u00B7 archived '+esc(new Date(x.archivedOn).toLocaleDateString()):'')+'</div></div><button type="button" class="mm-btn sm primary" data-ar="'+esc(x.id)+'">Restore</button><button type="button" class="mm-btn sm secondary" data-ad="'+esc(x.id)+'">Remove</button></div>';});});
 return h;}
function installArchiveTab(){var ad=window.MM91&&MM91.admin;if(!ad||!ad.TABS||!ad.VIEWS||ad.VIEWS.archive)return;
 var T=ad.TABS,i=-1,k;for(k=0;k<T.length;k++)if(T[k].id==='school')i=k;if(i<0)for(k=0;k<T.length;k++)if(T[k].id==='teachers')i=k;
 T.splice(i+1,0,{id:'archive',ic:'\uD83D\uDDC4\uFE0F',l:'Archive',adminOnly:true,cnt:function(){try{return archList().length;}catch(e){return 0;}}});
 ad.VIEWS.archive=vArchive;}
function restoreArch(id){var s=loadStore(),i=(s.archived||[]).findIndex(function(x){return x.id===id;});if(i<0)return;
 var x=s.archived[i];if(s.list[x.id]){say('That student is already on the roster.');return;}
 var r=JSON.parse(JSON.stringify(x));delete r.archivedOn;delete r.archivedYear;s.list[r.id]=r;s.archived.splice(i,1);
 if(r.teacher){if(!s.teachers)s.teachers=[];if(s.teachers.indexOf(r.teacher)<0)s.teachers.push(r.teacher);}
 saveStore(s);try{A().ensureStudents();}catch(e){}refreshAll();say('Restored '+r.name+' to Grade '+(r.grade||'8')+'.');}
async function removeArch(id){var s=loadStore(),x=(s.archived||[]).filter(function(y){return y.id===id;})[0];if(!x)return;
 var d=dlg('Remove from archive','<p>Permanently remove <b>'+esc(x.name)+'</b> and their progress? This cannot be undone.</p>',[{id:'x',label:'Keep'},{id:'go',label:'Remove for good',primary:true}]);
 var r=await d.promise;d.close();if(r!=='go')return;s=loadStore();s.archived=(s.archived||[]).filter(function(y){return y.id!==id;});saveStore(s);refreshAll();say('Removed from the archive.');}
/* ===== 3. Printable sign-in cards ===== */
function cardList(teacher,grade){var D=DD();try{A().ensureStudents();}catch(e){}
 return D.list().filter(function(s){return (teacher==='*'||(teacher==='__none'?!s.teacher:s.teacher===teacher))&&(!grade||(s.grade||'K')===grade);}).sort(function(a,b){return gOrder(a.grade||'K')-gOrder(b.grade||'K')||String(a.name).localeCompare(String(b.name));});}
window.mmCardsHtml=function(teacher,grade){var D=DD(),ac=A(),url=(location.protocol==='http:'||location.protocol==='https:')?location.origin+location.pathname.replace(/index\.html$/,''):'';
 var cards=cardList(teacher,grade).map(function(s){var a=null;try{a=ac.forStudent(s.id);}catch(e){}var code='';try{code=D.codeOf(s);}catch(e){}
  return '<div class="c"><b>'+esc(s.name)+'</b><div class="s">'+(s.grade==='K'||!s.grade?'Kindergarten':'Grade '+esc(s.grade))+(s.teacher?' \u00B7 '+esc(s.teacher):'')+'</div><div>Username: <b>'+esc(a?a.u:'')+'</b></div><div>Sign-in code:</div><div class="k">'+esc(code)+'</div><div class="s">1. Open Money Matters. 2. Tap Sign in. 3. Type your username and code.'+(url?'<br>'+esc(url):'')+'</div></div>';}).join('');
 return '<!doctype html><html><head><meta charset="utf-8"><title>Money Matters sign-in cards</title><style>body{font:14px/1.4 system-ui,sans-serif;margin:16px;color:#111}h1{font-size:16px;margin:0 0 10px}.g{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.c{border:2px dashed #888;border-radius:10px;padding:12px;break-inside:avoid;page-break-inside:avoid}.c b{font-size:16px}.k{font:700 22px ui-monospace,monospace;letter-spacing:.12em;margin:4px 0}.s{color:#555;font-size:12px}@media print{body{margin:8mm}}</style></head><body><h1>Money Matters sign-in cards</h1><div class="g">'+cards+'</div></body></html>';};
window.mmPrintCards=function(){var D=DD(),list=D.list();if(!list.length){say('There are no students yet.');return;}
 var ts=[];list.forEach(function(s){if(s.teacher&&ts.indexOf(s.teacher)<0)ts.push(s.teacher);});ts.sort();
 var body='<label for="mmpc-t">Teacher</label><select id="mmpc-t"><option value="*">All teachers</option>'+ts.map(function(t){return '<option value="'+esc(t)+'">'+esc(t)+'</option>';}).join('')+(list.some(function(s){return !s.teacher;})?'<option value="__none">No teacher assigned</option>':'')+'</select><label for="mmpc-g">Grade</label><select id="mmpc-g"><option value="">All grades</option>'+GR.map(function(g){return '<option value="'+g+'">'+(g==='K'?'Kindergarten':'Grade '+g)+'</option>';}).join('')+'</select><div id="mmpc-n" class="mmrt-warn"></div><div style="font-size:13px">Each card shows the username and sign-in code. Hand them out privately and keep the printout secure.</div>';
 var d=dlg('\uD83D\uDDA8 Print sign-in cards',body,[{id:'x',label:'Cancel'},{id:'dl',label:'\u2B07 Download'},{id:'pr',label:'Print',primary:true}]);
 function upd(){d.el.querySelector('#mmpc-n').textContent=cardList(d.el.querySelector('#mmpc-t').value,d.el.querySelector('#mmpc-g').value).length+' cards will be created.';}
 d.el.addEventListener('change',upd);upd();
 d.el.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-id]');if(!b)return;var id=b.getAttribute('data-id');
  if(id==='x'){d.close();return;}
  var t=d.el.querySelector('#mmpc-t').value,g=d.el.querySelector('#mmpc-g').value;if(!cardList(t,g).length){say('No students match that choice.');return;}
  var html=window.mmCardsHtml(t,g);
  if(id==='dl'){download('sign-in-cards.html',html,'text/html');return;}
  var w=null;try{w=window.open('','_blank');}catch(x){}
  if(w){w.document.write(html);w.document.close();setTimeout(function(){try{w.print();}catch(x){}},400);}else{download('sign-in-cards.html',html,'text/html');say('Pop-ups are blocked, so the cards were downloaded. Open the file and print it.',6000);}});};
/* ===== 7. Bulk tools ===== */
function bulkSnap(note){var s=loadStore();jset('mmLastBulk',{t:Date.now(),note:note,list:JSON.parse(JSON.stringify(s.list||{})),teachers:(s.teachers||[]).slice()});}
function dupGroups(){var by={};DD().list().forEach(function(s){var k=String(s.name).trim().toLowerCase()+'|'+(s.grade||'K');(by[k]=by[k]||[]).push(s);});return Object.keys(by).map(function(k){return by[k];}).filter(function(g){return g.length>1;});}
window.mmBulkTools=function(){var D=DD(),list=D.list(),ts=[];list.forEach(function(s){if(s.teacher&&ts.indexOf(s.teacher)<0)ts.push(s.teacher);});try{D.teachers().forEach(function(t){if(ts.indexOf(t)<0)ts.push(t);});}catch(e){}ts.sort();
 var tOpts=ts.map(function(t){return '<option value="'+esc(t)+'">'+esc(t)+'</option>';}).join('');
 var body='<div style="font-weight:700;margin-top:4px">Reassign a class</div><label for="mmb-f">From</label><select id="mmb-f"><option value="*">All students</option><option value="__none">Students with no teacher</option>'+tOpts+'</select><label for="mmb-g">Grade</label><select id="mmb-g"><option value="">All grades</option>'+GR.map(function(g){return '<option value="'+g+'">'+(g==='K'?'Kindergarten':'Grade '+g)+'</option>';}).join('')+'</select><label for="mmb-t">Move to</label><select id="mmb-t"><option value="__none">No teacher</option>'+tOpts+'</select><label for="mmb-n">Or a new teacher name</label><input type="text" id="mmb-n" maxlength="60" placeholder="Optional"><div id="mmb-c" class="mmrt-warn"></div><div style="font-weight:700;margin-top:10px">Duplicate students</div><div id="mmb-d" style="font-size:14px"></div>';
 var d=dlg('\uD83E\uDDF0 Bulk tools',body,[{id:'x',label:'Close'},{id:'un',label:'\u21A9 Undo last change'},{id:'mg',label:'Merge duplicates'},{id:'mv',label:'Move students',primary:true}]);
 function sel(){var f=d.el.querySelector('#mmb-f').value,g=d.el.querySelector('#mmb-g').value;return D.list().filter(function(s){return (f==='*'||(f==='__none'?!s.teacher:s.teacher===f))&&(!g||(s.grade||'K')===g);});}
 function upd(){d.el.querySelector('#mmb-c').textContent=sel().length+' students match.';var g=dupGroups();d.el.querySelector('#mmb-d').textContent=g.length?(g.length+' duplicate group'+(g.length===1?'':'s')+': '+g.slice(0,4).map(function(x){return x[0].name+' ('+x.length+')';}).join(', ')+(g.length>4?'\u2026':'')):'No duplicates found.';
  var u=d.el.querySelector('button[data-id="un"]');if(u)u.style.display=jget('mmLastBulk',null)?'':'none';var m=d.el.querySelector('button[data-id="mg"]');if(m)m.style.display=g.length?'':'none';}
 d.el.addEventListener('change',upd);d.el.addEventListener('input',upd);upd();
 d.el.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-id]');if(!b)return;var id=b.getAttribute('data-id');
  if(id==='x'){d.close();return;}
  if(id==='mv'){var m=sel();if(!m.length){say('No students match.');return;}var nn=d.el.querySelector('#mmb-n').value.replace(/\s+/g,' ').trim().slice(0,60),to=nn||d.el.querySelector('#mmb-t').value;
   bulkSnap('move');var s=loadStore(),ids={};m.forEach(function(x){ids[x.id]=1;});
   Object.keys(s.list).forEach(function(k){if(ids[k]){if(to&&to!=='__none')s.list[k].teacher=to;else delete s.list[k].teacher;}});
   if(to&&to!=='__none'){s.teachers=s.teachers||[];if(s.teachers.indexOf(to)<0)s.teachers.push(to);}
   saveStore(s);refreshAll();upd();say('Moved '+m.length+' students'+(to&&to!=='__none'?' to '+to:' to no teacher')+'.');return;}
  if(id==='mg'){var gs=dupGroups();if(!gs.length)return;bulkSnap('merge');var s2=loadStore(),n=0;
   gs.forEach(function(g){var rank=g.map(function(x){return {x:x,p:Object.keys((s2.list[x.id]||{}).prog||{}).length};}).sort(function(a,b){return b.p-a.p||String(a.x.created||'').localeCompare(String(b.x.created||''));});
    var keep=s2.list[rank[0].x.id];rank.slice(1).forEach(function(r){var o=s2.list[r.x.id];if(!o||!keep)return;keep.prog=keep.prog||{};Object.keys(o.prog||{}).forEach(function(k){if(!(k in keep.prog))keep.prog[k]=o.prog[k];});if(!keep.teacher&&o.teacher)keep.teacher=o.teacher;delete s2.list[r.x.id];n++;});});
   saveStore(s2);try{A().ensureStudents();}catch(x){}refreshAll();upd();say('Merged '+n+' duplicate records.');return;}
  if(id==='un'){var sn=jget('mmLastBulk',null);if(!sn)return;var s3=loadStore();s3.list=sn.list;s3.teachers=sn.teachers;saveStore(s3);try{A().ensureStudents();}catch(x){}try{localStorage.removeItem('mmLastBulk');}catch(x){}refreshAll();upd();say('Last bulk change undone.');}});};
/* ===== 4. Storage health ===== */
var persisted=null;
function lsBytes(){var n=0;try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);n+=(k.length+(localStorage.getItem(k)||'').length)*2;}}catch(e){}return n;}
window.mmHealth=function(){var b=lsBytes(),days=null;try{var f=(MM91.admin&&MM91.admin.lastBackupDays)||(MM91.data&&MM91.data.lastBackupDays);if(typeof f==='function')days=f();}catch(e){}
 return {bytes:b,pct:Math.min(100,Math.round(b/(5*1048576)*100)),persisted:persisted,days:days};};
function askPersist(){try{if(navigator.storage&&navigator.storage.persisted){navigator.storage.persisted().then(function(v){persisted=v;if(!v&&navigator.storage.persist)navigator.storage.persist().then(function(g){persisted=g;});});}}catch(e){}}
window.mmEnablePersist=function(){if(navigator.storage&&navigator.storage.persist){navigator.storage.persist().then(function(g){persisted=g;say(g?'Your data is now protected from automatic clearing.':'The browser did not allow it. Install the app to the home screen and keep regular backups.',6500);});}else say('This browser does not support protected storage. Keep regular backups.',6000);};
function healthToast(){try{var today=new Date().toDateString();if(localStorage.getItem('mmHealthDay')===today)return;var h=window.mmHealth();
 var m=h.pct>=75?('Storage is '+h.pct+'% full. Download a backup and remove old data.'):(h.days==null||h.days>7)?'Your last backup is more than a week old. Open Data and Backup to download one.':'';
 if(m){say(m,8000);localStorage.setItem('mmHealthDay',today);}}catch(e){}}
/* ===== 5. Install app ===== */
var deferred=null;
window.addEventListener('beforeinstallprompt',function(e){deferred=e;});
window.addEventListener('appinstalled',function(){deferred=null;});
window.mmInstalled=function(){try{return !!(matchMedia('(display-mode: standalone)').matches||navigator.standalone);}catch(e){return false;}};
window.mmInstall=async function(){
 if(window.mmInstalled()){say('Money Matters is already installed on this device.');return;}
 if(deferred){try{deferred.prompt();await deferred.userChoice;}catch(e){}deferred=null;return;}
 var ios=/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),web=(location.protocol==='http:'||location.protocol==='https:');
 var steps=ios?'<ol><li>Open this page in Safari.</li><li>Tap the Share button.</li><li>Choose Add to Home Screen.</li></ol>':'<ol><li>Open this page in Chrome or Edge.</li><li>On a phone, tap the menu (three dots) and choose Install app or Add to Home screen.</li><li>On a computer, click the install icon in the address bar.</li></ol>';
 var d=dlg('\uD83D\uDCF2 Install Money Matters',steps+(web?'':'<div class="mmrt-warn">Installing needs the app to be opened from its web address (https), not from a downloaded file.</div>'),[{id:'ok',label:'Got it',primary:true}]);d.promise.then(d.close);};
/* ===== 6. Setup wizard ===== */
window.mmSetupWizard=function(){var i=0;
 var steps=[
  {t:'Welcome',b:function(){return '<p>Let us get your school ready in a few short steps. You can skip any step and reopen this from the Home screen.</p>';}},
  {t:'School name',b:function(){var v='';try{v=localStorage.getItem('mmSchoolName')||'';}catch(e){}return '<label for="mmw-s">School or program name</label><input type="text" id="mmw-s" maxlength="80" value="'+esc(v)+'" placeholder="For example Lincoln Elementary"><p style="font-size:13px">It appears on certificates and reports.</p>';}},
  {t:'Add people',b:function(){return '<p>Import a roster (CSV, Word or JSON), or add users one at a time.</p><div class="mmrt-btns"><button type="button" data-w="imp">\uD83D\uDCE5 Import a roster</button><button type="button" data-w="add">\u2795 Add a user</button></div>';}},
  {t:'Weekly lesson',b:function(){return '<p>Open Lessons and choose the week students should start with.</p><div class="mmrt-btns"><button type="button" data-w="les">\uD83D\uDCDA Open Lessons</button></div>';}},
  {t:'Back up',b:function(){return '<p>Download a backup now so your setup is safe.</p><div class="mmrt-btns"><button type="button" data-w="bk">\uD83D\uDCBE Download backup</button></div>';}}];
 var d=dlg('\uD83D\uDE80 Setup',' ',[{id:'back',label:'Back'},{id:'next',label:'Next',primary:true},{id:'x',label:'Close'}]);
 var bodyEl=d.el.querySelector('.mmrt-body');
 function save(){if(i===1){var e=d.el.querySelector('#mmw-s');if(e){var v=e.value.trim().slice(0,80);try{if(v)localStorage.setItem('mmSchoolName',v);else localStorage.removeItem('mmSchoolName');}catch(x){}try{MM91.shell.topbar();}catch(x){}}}}
 function render(){d.el.querySelector('h2').textContent='\uD83D\uDE80 Setup \u00B7 Step '+(i+1)+' of '+steps.length+': '+steps[i].t;bodyEl.innerHTML=steps[i].b();
  d.el.querySelector('button[data-id="back"]').style.visibility=i?'visible':'hidden';d.el.querySelector('button[data-id="next"]').textContent=i===steps.length-1?'Finish':'Next';}
 render();
 d.el.addEventListener('click',function(e){var w=e.target.closest&&e.target.closest('button[data-w]');
  if(w){var a=w.getAttribute('data-w');save();if(a==='imp'){d.close();window.mmPickRoster&&window.mmPickRoster();}else if(a==='add'){d.close();try{MM91.admin.open('users',{add:true});}catch(x){}}else if(a==='les'){d.close();try{openPanel('lessons');}catch(x){}}else if(a==='bk'){try{backupData();}catch(x){say('Use Data and Backup to download a backup.');}}return;}
  var b=e.target.closest&&e.target.closest('button[data-id]');if(!b)return;var id=b.getAttribute('data-id');
  if(id==='x'){save();d.close();return;}
  if(id==='back'){save();i=Math.max(0,i-1);render();return;}
  if(id==='next'){save();if(i>=steps.length-1){try{localStorage.setItem('mmSetupDone','1');}catch(x){}d.close();say('Setup complete.');return;}i++;render();}});};
/* ===== 8. Support email and feedback ===== */
(function(){try{var em=localStorage.getItem('mmSupportEmail');if(em)window.MM_SUPPORT_EMAIL=em;}catch(e){}})();
window.mmSupportEmail=async function(){var cur=window.MM_SUPPORT_EMAIL||'';
 var d=dlg('\u2709 Support email','<p style="margin:0 0 6px">Feedback sent from the app opens an email to this address. Leave it empty to keep feedback on this device only.</p><label for="mmse">Email address</label><input type="text" id="mmse" inputmode="email" autocomplete="off" value="'+esc(cur)+'" placeholder="support@yourschool.org"><div class="mmrt-warn" id="mmse-m" style="display:none"></div>',[{id:'x',label:'Cancel'},{id:'ok',label:'Save',primary:true}]);
 d.el.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-id]');if(!b)return;var id=b.getAttribute('data-id');if(id==='x'){d.close();return;}
  var v=d.el.querySelector('#mmse').value.trim();if(v&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)){var m=d.el.querySelector('#mmse-m');m.textContent='Please enter a valid email address.';m.style.display='block';return;}
  try{if(v)localStorage.setItem('mmSupportEmail',v);else localStorage.removeItem('mmSupportEmail');}catch(x){}window.MM_SUPPORT_EMAIL=v;d.close();say(v?'Support email saved.':'Support email cleared.');});};
function feedbackNote(){var t=$('feedbackText');if(!t||$('mm-fbnote'))return;var n=document.createElement('div');n.id='mm-fbnote';n.className='mm-fbnote';
 n.textContent='Please do not include student names or other personal details. '+(window.MM_SUPPORT_EMAIL?'Your note opens an email to '+window.MM_SUPPORT_EMAIL+'.':'Your note is saved on this device. An administrator can export it.');t.parentNode.insertBefore(n,t.nextSibling);}
/* ===== 10. Accessibility extras ===== */
function applyExtra(){var a=jget('mmA11y',{}),r=document.documentElement,os=false;try{os=matchMedia('(prefers-reduced-motion: reduce)').matches;}catch(e){}
 var motion=a.motion===undefined?os:!!a.motion;r.classList.toggle('a11y-motion',motion);r.classList.toggle('a11y-space',!!a.space);r.classList.toggle('a11y-focus',!!a.focus);
 [['a11yMotion',motion],['a11ySpace',!!a.space],['a11yFocus',!!a.focus]].forEach(function(p){var el=$(p[0]);if(el)el.checked=p[1];});}
function injectA11y(){var c=$('a11yContrast');if(!c||$('a11yMotion'))return;var row=c.closest('.a11y-row');if(!row)return;
 var h='<label class="a11y-row"><input type="checkbox" id="a11yMotion" data-x="motion"><span class="t"><b>Reduce motion</b><span>Turn off animations and smooth scrolling.</span></span></label><label class="a11y-row"><input type="checkbox" id="a11ySpace" data-x="space"><span class="t"><b>Extra line spacing</b><span>More room between lines of text.</span></span></label><label class="a11y-row"><input type="checkbox" id="a11yFocus" data-x="focus"><span class="t"><b>Strong focus outlines</b><span>Make the selected button or field easy to see.</span></span></label>';
 row.insertAdjacentHTML('afterend',h);applyExtra();}
document.addEventListener('change',function(e){var x=e.target&&e.target.getAttribute&&e.target.getAttribute('data-x');if(!x)return;var a=jget('mmA11y',{});a[x]=!!e.target.checked;jset('mmA11y',a);applyExtra();},true);
/* ===== click handling for archive, resets, install link ===== */
document.addEventListener('click',function(e){var t=e.target.closest&&e.target.closest('[data-ar],[data-ad],[data-arx],[data-mmi]');if(!t)return;e.preventDefault();e.stopPropagation();
 if(t.hasAttribute('data-ar'))restoreArch(t.getAttribute('data-ar'));
 else if(t.hasAttribute('data-ad'))removeArch(t.getAttribute('data-ad'));
 else if(t.hasAttribute('data-mmi'))window.mmInstall();
 else{var rows=archList().map(function(x){return [x.name,x.grade||'8',x.teacher||'',x.archivedYear||'',x.archivedOn||''].map(function(v){return '"'+String(v).replace(/"/g,'""')+'"';}).join(',');});download('archive.csv','Name,Last grade,Teacher,School year,Archived on\n'+rows.join('\n'));}},true);
document.addEventListener('input',function(e){if(e.target&&e.target.id==='mmar-q'){var q=e.target.value.toLowerCase().trim();[].forEach.call(document.querySelectorAll('.mmar-row'),function(r){r.style.display=!q||r.getAttribute('data-q').indexOf(q)>-1?'':'none';});}},true);
window.mmUninstallLink=null;
/* ===== init ===== */
function injectInstallLink(){var a=$('mm-auth');if(!a||window.mmInstalled()||a.querySelector('[data-mmi]'))return;var l=a.querySelector('.links');if(!l)return;var b=document.createElement('button');b.type='button';b.setAttribute('data-mmi','1');b.textContent='\uD83D\uDCF2 Install app';l.appendChild(b);}
function staffReal(){try{var a=MM91.auth.get();return !!(a&&!a.sample&&MM91.auth.roleKey()!=='student');}catch(e){return false;}}
function init(){var tm;function go(){clearTimeout(tm);tm=setTimeout(function(){try{installArchiveTab();injectA11y();feedbackNote();injectInstallLink();}catch(e){}},80);}
 try{new MutationObserver(go).observe(document.body,{childList:true,subtree:true});}catch(e){}go();applyExtra();
 var started=false;setInterval(function(){try{if(staffReal()){if(!started){started=true;askPersist();setTimeout(healthToast,2500);}
  if(isAdmin()&&!localStorage.getItem('mmSetupDone')&&!sessionStorage.getItem('mmSetupAsked')&&DD().list().length===0&&document.getElementById('mm-staff-home')&&document.getElementById('mm-staff-home').classList.contains('on')&&!document.querySelector('.mmrt-ov')){sessionStorage.setItem('mmSetupAsked','1');window.mmSetupWizard();}}}catch(e){}},1500);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
