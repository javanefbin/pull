/* =====================================================================
   V19 · TRANSLATION FOR NEW FEATURES  (window.MMI18N)
   Spanish and Portuguese for the Game Show, live play, Workshops,
   Resource Guide, notices and printouts. Content (questions, workshop
   plans, banks) is translated at the data level; this layer translates
   interface text.
     MMI18N.t(s)        exact string → translation (falls back to s)
     MMI18N.apply(root) translates text nodes and placeholder / title /
                        aria-label attributes under root, including
                        strings with numbers via {0}-style patterns
   Dictionary: data/UI_L.json  {es:{exact:{}, patterns:[[en,tr]…]}, pt:{…}}
   ===================================================================== */
var UI_L=/*@include data/UI_L.json*/;
(function(){
'use strict';
function lang(){try{return loadLang()||'en';}catch(e){return 'en';}}
var cache={};
function dict(){var l=lang();if(l==='en'||!UI_L[l])return null;if(cache[l])return cache[l];var d=UI_L[l],pats=(d.patterns||[]).map(function(p){var keys=[],src=p[0].replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/\\\{(\w+)\\\}/g,function(_,k){keys.push(k);return '(.+?)';});return {re:new RegExp('^'+src+'$'),keys:keys,out:p[1]};});
  return (cache[l]={exact:d.exact||{},pats:pats});}
function one(s){var d=dict();if(!d||s==null)return s;var k=String(s);if(d.exact[k]!=null)return d.exact[k];var tk=k.trim();if(!tk)return k;
  if(d.exact[tk]!=null)return k.replace(tk,d.exact[tk]);
  for(var i=0;i<d.pats.length;i++){var p=d.pats[i],m=p.re.exec(tk);if(m){var o=p.out;p.keys.forEach(function(kk,j){var v=m[j+1];o=o.split('{'+kk+'}').join(d.exact[v]!=null?d.exact[v]:v);});return k.replace(tk,o);}}
  return k;}
function apply(root){var d=dict();if(!d||!root)return;var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:function(n){var p=n.parentNode;return p&&/^(SCRIPT|STYLE|TEXTAREA)$/.test(p.nodeName)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT;}}),nodes=[];
  while(w.nextNode())nodes.push(w.currentNode);
  nodes.forEach(function(n){var v=n.nodeValue;if(!v||!/[A-Za-z]/.test(v))return;var t=one(v);if(t!==v)n.nodeValue=t;});
  if(root.querySelectorAll)root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(function(x){['placeholder','title','aria-label'].forEach(function(a){var v=x.getAttribute(a);if(v){var t=one(v);if(t!==v)x.setAttribute(a,t);}});});}
function applyHTML(html){if(!dict())return html;try{var doc=new DOMParser().parseFromString(html,'text/html');apply(doc.body);apply(doc.head.querySelector('title')||doc.head);return '<!DOCTYPE html>'+doc.documentElement.outerHTML;}catch(e){return html;}}
window.MMI18N={t:one,apply:apply,applyHTML:applyHTML,lang:lang};
/* translate the new surfaces whenever they re-render */
function watch(id){var el=document.getElementById(id);if(!el||el.__i18n)return;el.__i18n=1;var busy=false;try{apply(el);}catch(e){}new MutationObserver(function(){if(busy||!dict())return;busy=true;try{apply(el);}catch(e){}setTimeout(function(){busy=false;},0);}).observe(el,{childList:true,subtree:true});}
function boot(){['panel-workshops','panel-resources','panel-games','mm-gs','mm-lp','v19-notices','mm-topbar','ws-run','materialsBody'].forEach(watch);}
setInterval(boot,700);if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
