/* =====================================================================
   V21 · PHONE FIXES
   · The phone tour (MM.coach) never shows over the sign-in screen, and
     closes if the sign-in screen appears (it used to cover "Sign in").
   · Sponsor cards (698) also have a place on the phone home screen.
   ===================================================================== */
(function(){
'use strict';
var MM=window.MM91;if(!MM)return;
function gated(){var g=document.getElementById('mm-auth');return !!(g&&!g.classList.contains('mm-hidden'));}
function hideCoach(){var c=document.getElementById('mm-coach');if(c)c.classList.remove('on');}
function fixCoach(){var C=MM.coach;if(!C||!C.start||C.start.__v21)return;var o=C.start;C.start=function(){if(gated())return;return o.apply(this,arguments);};C.start.__v21=1;}
fixCoach();document.addEventListener('DOMContentLoaded',function(){setTimeout(fixCoach,1500);});
if(MM.gate&&MM.gate.show&&!MM.gate.show.__v21){var os=MM.gate.show;MM.gate.show=function(){hideCoach();return os.apply(this,arguments);};MM.gate.show.__v21=1;}
/* (a document-wide class observer used to live here; it looped with the phone layout
   observer during sign-out and froze the page, so the two guards above do the job alone) */
})();
