(function(){'use strict';
function $(i){return document.getElementById(i);}
function esc(x){return String(x==null?'':x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function role(){try{return String(loadRole()||'student').toLowerCase();}catch(e){return 'student';}}
function isStaff(){return role()!=='student';}
function isFamily(){try{var a=MM91.auth.get();return !!(a&&a.acctRole==='guardian');}catch(e){return false;}}
function arr(x){return Array.isArray(x)?x:(x?[x]:[]);}
function sec(t,ic,body){return '<section class="mmtv-sec"><h3><span aria-hidden="true">'+ic+'</span>'+t+'</h3>'+body+'</section>';}
function ul(a,o){return '<'+(o||'ul')+'>'+arr(a).map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</'+(o||'ul')+'>';}
function vocab(l){var v=arr(l.vocab);if(!v.length)return '';return '<dl class="mmtv-vocab">'+v.map(function(x){return typeof x==='string'?'<dt>'+esc(x)+'</dt><dd></dd>':'<dt>'+esc(x.term)+'</dt><dd>'+esc(x.def)+'</dd>';}).join('')+'</dl>';}
function split(ck){var m=String(ck||'').match(/^([\s\S]*?)\s*\(Answer:\s*([\s\S]*?)\)\s*$/);return m?{q:m[1],a:m[2]}:{q:String(ck||''),a:''};}
function step(n,t,b){return '<li class="mmtv-step"><span class="mmtv-n">'+n+'</span><div><div class="mmtv-st">'+t+'</div>'+b+'</div></li>';}
function wsKey(l){var it=(l.worksheet&&l.worksheet.items)||[];if(!it.length)return '';return '<details class="mmtv-det"><summary>Worksheet answer key ('+it.length+' items)</summary><ol>'+it.map(function(x){return '<li>'+esc(x.q)+' <b>'+esc(x.answer)+'</b></li>';}).join('')+'</ol></details>';}
function buttons(list){return '<div class="mmtv-btns">'+list.map(function(b){return '<button type="button" class="mm-btn sm secondary" data-tv="'+b[0]+'">'+b[1]+'</button>';}).join('')+'</div>';}
function teacher(l){var ck=split(l.check),d=l.differentiation||{};
 var h='<div class="mmtv-wrap"><div class="mmtv-top"><span class="mmtv-badge">Teacher view</span><p>Everything you need to teach this lesson, in teaching order. Student activities are on the worksheet, quiz, story and games.</p></div>';
 h+=sec('At a glance','\uD83C\uDFAF','<p class="mmtv-obj">'+esc(l.objective)+'</p><div class="mmtv-chips"><span>\u23F1 '+esc(l.duration)+'</span>'+arr(l.standards).map(function(s){return '<span>'+esc(s)+'</span>';}).join('')+'</div>');
 h+=sec('Prepare','\uD83E\uDDF0',(l.prep?'<p>'+esc(l.prep)+'</p>':'')+(arr(l.materials).length?'<div class="mmtv-lbl">Materials</div><ul class="mmtv-check">'+arr(l.materials).map(function(m){return '<li><label><input type="checkbox"> '+esc(m)+'</label></li>';}).join('')+'</ul>':''));
 if(arr(l.vocab).length)h+=sec('Vocabulary to pre-teach','\uD83D\uDD24',vocab(l));
 h+=sec('Teach it','\uD83D\uDCCB','<ol class="mmtv-steps">'
  +step(1,'Warm-up','<p>'+esc(l.warmUp)+'</p>')
  +step(2,'Model the idea','<p class="mmtv-say">'+esc(l.mini)+'</p>')
  +step(3,'Guided practice',ul(l.guidedPractice,'ol'))
  +step(4,'Independent practice','<p>'+esc(l.independent)+'</p>')
  +step(5,'Discuss',ul(l.discussion))
  +step(6,'Check for understanding','<p>'+esc(ck.q)+'</p>'+(ck.a?'<div class="mmtv-ans">Expected answer: '+esc(ck.a)+'</div>':''))
  +step(7,'Exit ticket','<p>'+esc(l.exit)+'</p>')+'</ol>');
 if(d.support||d.challenge)h+=sec('Differentiate','\uD83E\uDDED','<div class="mmtv-2">'+(d.support?'<div class="mmtv-box"><b>Support</b>'+esc(d.support)+'</div>':'')+(d.challenge?'<div class="mmtv-box"><b>Challenge</b>'+esc(d.challenge)+'</div>':'')+'</div>');
 h+=sec('Assess and print','\uD83D\uDCDD',buttons([['worksheet','Worksheet (teacher copy)'],['quiz','Quiz answer key'],['test','Section test key'],['plan','Lesson plan'],['guide','Teacher\u2019s guide'],['workbook','Workbook']])+wsKey(l));
 if(l.homeExtension)h+=sec('Family connection','\uD83C\uDFE0','<p>'+esc(l.homeExtension)+'</p>');
 return h+'</div>';}
function family(l){var ck=split(l.check),obj=String(l.objective||'').replace(/^Students will/i,'Your child will');
 var h='<div class="mmtv-wrap"><div class="mmtv-top"><span class="mmtv-badge">Family guide</span><p>A short guide to help you support this week\u2019s learning at home.</p></div>';
 h+=sec('What your child is learning','\uD83C\uDF31','<p class="mmtv-obj">'+esc(l.sub)+'</p><p>'+esc(obj)+'</p>');
 if(arr(l.vocab).length)h+=sec('Words to know','\uD83D\uDD24',vocab(l));
 h+=sec('Start the conversation','\uD83D\uDCAC',ul(l.discussion));
 if(l.homeExtension)h+=sec('Try it together','\uD83E\uDD1D','<p>'+esc(l.homeExtension)+'</p>');
 h+=sec('Check understanding','\u2705','<p>'+esc(ck.q)+'</p>'+(ck.a?'<div class="mmtv-ans">Answer: '+esc(ck.a)+'</div>':''));
 h+=sec('Check their work','\uD83D\uDCDD',buttons([['worksheet','Worksheet with answers'],['quiz','Quiz answers']])+wsKey(l));
 return h+'</div>';}
var last='';
function sync(){var r=document.documentElement,staff=isStaff();r.classList.toggle('mm-staff-view',staff);
 var host=$('mm-teach-view');if(!staff){if(host)host.remove();last='';return;}
 var t=$('lessonTitle');if(!t)return;var l;try{l=L();}catch(e){}if(!l)return;
 var sig=role()+'|'+(isFamily()?'f':'t')+'|'+l.week+'|'+l.title+'|'+(typeof currentGrade!=='undefined'?currentGrade:'')+'|'+(typeof loadLang==='function'?loadLang():'');
 if(!host){host=document.createElement('section');host.id='mm-teach-view';var a=$('lessonMeta')||$('lessonSub')||t;a.parentNode.insertBefore(host,a.nextSibling);last='';}
 if(last!==sig||!host.innerHTML){host.innerHTML=isFamily()?family(l):teacher(l);last=sig;}
 wsTools(l);}
function relabel(a){[].forEach.call(a.querySelectorAll('.doc-kicker')||[],function(k){if(/Student Worksheet/.test(k.textContent))k.textContent=k.textContent.replace('Student Worksheet','Teacher Copy');});
 var pt=document.querySelector('#panel-doc .panel-title');if(pt&&/Student Worksheet/.test(pt.textContent))pt.textContent=pt.textContent.replace('Student Worksheet','Worksheet \u00B7 Teacher Copy');}
function wsTools(l){var a=$('printArea'),b=a&&a.querySelector('.mm-key-banner');if(a)relabel(a);if(!b||b.getAttribute('data-tv'))return;b.setAttribute('data-tv','1');
 var n=document.createElement('div');n.className='mm-tv-note';n.innerHTML='<b>Objective:</b> '+esc(l.objective)+' \u00B7 '+esc(l.duration);b.parentNode.insertBefore(n,b.nextSibling);
 var t=document.createElement('div');t.className='mm-tv-tools';t.innerHTML='<button type="button" data-tvh="1">Hide answers (student copy)</button><button type="button" data-tvp="1">Print</button>';n.parentNode.insertBefore(t,n.nextSibling);}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-tv],[data-tvh],[data-tvp]');if(!b)return;
 if(b.hasAttribute('data-tvh')){var a=$('printArea');if(a){var on=a.classList.toggle('mm-key-hide');b.textContent=on?'Show answers (teacher copy)':'Hide answers (student copy)';}return;}
 if(b.hasAttribute('data-tvp')){try{window.print();}catch(x){}return;}
 var k=b.getAttribute('data-tv');try{if(k==='quiz'||k==='test')openPanel(k);else openDoc(k);}catch(x){}},true);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync);else sync();
try{new MutationObserver(function(){clearTimeout(window.__tvT);window.__tvT=setTimeout(sync,60);}).observe(document.body,{childList:true,subtree:true});}catch(e){}
setInterval(sync,1200);
})();
