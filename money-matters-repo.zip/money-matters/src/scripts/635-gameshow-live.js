/* =====================================================================
   MONEY GAME SHOW · LIVE PLAY  (window.MMGameShowLive)
   Students answer on their own phone, tablet or laptop while the host
   screen shows the questions. No student accounts: players join with a
   6-character PIN (or QR code) and a first name or nickname.

   Connections (one interface: emit / on / sendUp / onUp / leave)
     device    BroadcastChannel between tabs of this browser. For trying
               it out and for one-computer demos. Nothing leaves the device.
     supabase  The school's own Supabase project (Realtime broadcast only,
               no tables). Configured once in "Live server settings".
               Public MQTT brokers are deliberately NOT used: anyone can
               subscribe to them, which is not acceptable for K–8 data.

   Privacy: messages carry only a random player id, the nickname, and
   answers. Correct answers are sent to devices only after the reveal.
   Live modes: Quiz Rush · True or False Blitz · What Am I? · Closest Guess
   Store: mmLive_v1 (server settings) · mmLiveNick_v1 (player's nickname)
   ===================================================================== */
(function(){
'use strict';
var CFG_KEY='mmLive_v1',MAX_PLAYERS=200,WHO_CL=6,WHO_PTS=[1000,750,500,250];
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function money(n){n=Number(n)||0;var neg=n<0,v=Math.abs(n),d=Math.abs(v-Math.round(v))>0.001;return (neg?'−':'')+'$'+v.toLocaleString('en-US',{minimumFractionDigits:d?2:0,maximumFractionDigits:d?2:0});}
function load(k,d){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?d:v;}catch(e){return d;}}
function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function tr(root){try{if(window.MMI18N)window.MMI18N.apply(root);}catch(e){}}
function T(s,vars){var out=s;try{if(window.MMI18N)out=window.MMI18N.t(s);}catch(e){}if(vars)Object.keys(vars).forEach(function(k){out=out.split('{'+k+'}').join(vars[k]);});return out;}
function pidMake(){var p='';try{p=sessionStorage.getItem('mmLivePid')||'';}catch(e){}if(!/^p[a-z0-9]{10,24}$/.test(p)){p='p'+Math.random().toString(36).slice(2,10)+Date.now().toString(36);try{sessionStorage.setItem('mmLivePid',p);}catch(e){}}return p;}
function pinMake(){var a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',s='';for(var i=0;i<6;i++)s+=a[Math.floor(Math.random()*a.length)];return s;}
function cleanNick(n){return String(n||'').replace(/[<>\u0000-\u001f]/g,'').replace(/\s+/g,' ').trim().slice(0,20);}
function okCfg(c){return !!(c&&/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(c.url||'')&&String(c.key||'').length>20);}
function savedCfg(){var c=load(CFG_KEY,null);return okCfg(c)?{url:c.url.replace(/\/$/,''),key:c.key}:null;}
function linkCfg(){try{var q=new URLSearchParams(location.search),c={url:q.get('sb')||'',key:q.get('sk')||''};return okCfg(c)?{url:c.url.replace(/\/$/,''),key:c.key}:null;}catch(e){return null;}}
function webPage(){return /^https?:$/.test(location.protocol);}

/* ---------- transports ---------- */
function deviceRoom(pin,role){var ch=new BroadcastChannel('mmgs-'+pin),cbs={},ups=[];
  ch.onmessage=function(e){var m=e.data||{};if(role==='host'&&m.d==='up')ups.forEach(function(f){try{f(m.p);}catch(x){}});if(role!=='host'&&m.d==='down')(cbs[m.t]||[]).forEach(function(f){try{f(m.p);}catch(x){}});};
  return Promise.resolve({kind:'device',emit:function(t,p){ch.postMessage({d:'down',t:t,p:p});return Promise.resolve();},sendUp:function(p){ch.postMessage({d:'up',p:p});return Promise.resolve();},
    on:function(t,f){(cbs[t]=cbs[t]||[]).push(f);},onUp:function(f){ups.push(f);},leave:function(){try{ch.close();}catch(e){}},ok:function(){return true;}});}
var SB=null;
function sbClient(c){if(!window.supabase||!window.supabase.createClient)return null;if(SB&&SB.url===c.url)return SB.client;SB={url:c.url,client:window.supabase.createClient(c.url,c.key,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},realtime:{params:{eventsPerSecond:20}}})};return SB.client;}
function supaRoom(pin,role,c){var sb=sbClient(c);if(!sb)return Promise.resolve(null);
  var base='mmgs-'+pin.toLowerCase(),chan=sb.channel(base,{config:{broadcast:{self:false}}}),inbox=sb.channel(base+'-in',{config:{broadcast:{self:false}}}),cbs={},ups=[],joined=false;
  if(role==='host')inbox.on('broadcast',{event:'up'},function(m){ups.forEach(function(f){try{f(m.payload);}catch(e){}});});
  else chan.on('broadcast',{event:'state'},function(m){(cbs.state||[]).forEach(function(f){try{f(m.payload);}catch(e){}});});
  var room={kind:'supabase',emit:function(t,p){return chan.send({type:'broadcast',event:t,payload:p}).then(function(){},function(){});},
    sendUp:function(p){return inbox.send({type:'broadcast',event:'up',payload:p}).then(function(){},function(){});},
    on:function(t,f){(cbs[t]=cbs[t]||[]).push(f);},onUp:function(f){ups.push(f);},
    leave:function(){try{sb.removeChannel(chan);}catch(e){}try{sb.removeChannel(inbox);}catch(e){}},ok:function(){return joined;}};
  return new Promise(function(res){var done=false,n=0,subs=role==='host'?[chan,inbox]:[chan];function fin(v){if(!done){done=true;res(v);}}
    subs.forEach(function(ch){ch.subscribe(function(st){if(st==='SUBSCRIBED'){if(++n===subs.length){joined=true;fin(room);}}else if(st==='CHANNEL_ERROR'||st==='TIMED_OUT')fin(null);});});
    setTimeout(function(){fin(joined?room:null);},10000);});}
function openRoom(pin,role,kind,c){return kind==='supabase'?supaRoom(pin,role,c):deviceRoom(pin,role);}

/* ---------- QR code (inline SVG) ---------- */
function qrSVG(text){try{if(typeof qrcode!=='function')return '';var q=qrcode(0,'M');q.addData(text);q.make();var n=q.getModuleCount(),d='';for(var r=0;r<n;r++)for(var c=0;c<n;c++)if(q.isDark(r,c))d+='M'+c+' '+r+'h1v1h-1z';
  return '<svg viewBox="-2 -2 '+(n+4)+' '+(n+4)+'" role="img" aria-label="QR code to join the game" shape-rendering="crispEdges"><rect x="-2" y="-2" width="'+(n+4)+'" height="'+(n+4)+'" fill="#fff"/><path d="'+d+'" fill="#111"/></svg>';}catch(e){return '';}}

/* =====================================================================
   HOST (big screen) — runs inside the Game Show overlay
   ===================================================================== */
var H=null;
function I(){return window.MMGameShow._;}
var LIVE_MODES=[['rush','Quiz Rush'],['tf','True or False Blitz'],['who','What Am I?'],['guess','Closest Guess']];
function joinLink(){if(!H)return '';var base=location.href.split('#')[0].split('?')[0];
  if(H.kind==='supabase')return base+'?sb='+encodeURIComponent(H.cfg.url)+'&sk='+encodeURIComponent(H.cfg.key)+'#join-'+H.pin;
  return base+'#join-'+H.pin+'-d';}
function hostStart(){var gs=window.MMGameShow;if(!gs||!gs._)return;var x=I();if(!x.isOpen())gs.open();
  if(H)hostEnd(true);var c=savedCfg(),kind=c&&window.supabase?'supabase':'device';
  H={pin:pinMake(),kind:kind,cfg:c,room:null,players:{},order:[],kicked:{},phase:'connecting',mode:'rush',count:null,game:null,timer:null,beat:null};
  x.setMode('live','Live game');x.onLeave(function(){hostEnd(false);});
  render();
  openRoom(H.pin,'host',kind,c).then(function(room){if(!H)return;if(!room){H.phase='error';render();return;}H.room=room;H.phase='lobby';room.onUp(onUp);H.beat=setInterval(push,3000);push();render();});}
function hostEnd(silent){if(!H)return;clearInterval(H.beat);try{I().stopClock();}catch(e){}if(H.room){try{H.room.emit('state',{pin:H.pin,phase:'ended'});}catch(e){}var r=H.room;setTimeout(function(){r.leave();},300);}if(H.clueIv)clearInterval(H.clueIv);H=null;}
function onUp(m){if(!H||!m||typeof m.pid!=='string'||m.pid.length>40)return;if(H.kicked[m.pid])return;var p=H.players[m.pid];
  if(m.t==='hi'){var nick=cleanNick(m.nick);if(!nick)return;if(!p){if(H.order.length>=MAX_PLAYERS)return;p=H.players[m.pid]={pid:m.pid,nick:nick,score:0,streak:0,last:0};H.order.push(m.pid);I().sfx('select');}else p.nick=nick;p.seen=Date.now();
    if(H.phase==='lobby')renderPlayers();push();return;}
  if(m.t==='bye'){if(p&&H.phase==='lobby'){delete H.players[m.pid];H.order=H.order.filter(function(x){return x!==m.pid;});renderPlayers();}return;}
  if(m.t==='ans'&&p&&H.game&&H.game.phase==='answer'&&m.i===H.game.i&&!H.game.ans[m.pid]){var it=H.game.items[H.game.i],a={s:(performance.now()-H.game.t0)/1000};
    if(it.u){var v=parseFloat(m.v);if(!isFinite(v))return;a.v=v;}else{var k=+m.k;if(!(k>=0&&k<it.opts.length))return;a.k=k;}
    H.game.ans[m.pid]=a;var n=Object.keys(H.game.ans).length,el=document.getElementById('gl-count');if(el)el.textContent=T('{n} of {m} answered',{n:n,m:H.order.length});
    if(n>=H.order.length)hostReveal();}}
function rankList(){return H.order.map(function(id){return H.players[id];}).filter(Boolean).sort(function(a,b){return b.score-a.score||a.nick.localeCompare(b.nick);});}
/* what every device sees; correct answers only after the reveal */
function push(){if(!H||!H.room)return;var g=H.game,st={pin:H.pin,phase:H.phase,n:H.order.length,title:LIVE_MODES.filter(function(m){return m[0]===H.mode;})[0][1]};
  if(g&&g.i>=0&&g.items[g.i]){var it=g.items[g.i];st.i=g.i;st.of=g.items.length;st.q={cat:it.cat,q:it.q,opts:it.opts||[],u:it.u||'',clues:it.clues?it.clues.slice(0,g.clueN||0):null};st.gp=g.phase;
    if(g.phase==='answer'){st.left=Math.max(0,Math.round(g.T*1000-(performance.now()-g.t0)));st.T=g.T;}
    if(g.phase!=='answer'){st.correct=it.u?null:it.correct;st.answer=it.u?I().fmtU(it.a,it.u):it.opts[it.correct];var ranks={};rankList().forEach(function(p,ix){ranks[p.pid]=[p.score,ix+1,p.last,p.ok?1:0];});st.ranks=ranks;}}
  if(H.phase==='end'){var rk={};rankList().forEach(function(p,ix){rk[p.pid]=[p.score,ix+1,p.last,0];});st.ranks=rk;}
  H.room.emit('state',st);}
function render(){if(!H)return;var x=I(),h='';
  if(H.phase==='connecting'){x.main('<div class="gs-q"><h2 class="gs-qtext">'+esc(T('Opening the live game…'))+'</h2></div>');return;}
  if(H.phase==='error'){x.main('<div class="gs-q"><h2 class="gs-qtext">'+esc(T('Could not reach the live server.'))+'</h2><p>'+esc(T('Check the server settings and the internet connection, or play on this device instead.'))+'</p></div><div class="gs-actions"><button class="gs-btn" data-gl="settings">'+esc(T('Live server settings'))+'</button><button class="gs-btn ghost" data-gl="device">'+esc(T('Play on this device'))+'</button></div>');tr(x.root());return;}
  if(H.phase==='lobby'){var link=joinLink(),phones=H.kind==='supabase'&&webPage();
    h='<div class="gl-lobby"><section class="gl-join"><div class="gs-k">'+esc(T('Join at'))+'</div><div class="gl-pin" aria-label="Game PIN">'+H.pin.split('').join('<i></i>')+'</div>'
      +(phones?'<div class="gl-qr">'+qrSVG(link)+'</div><p class="gs-note">'+esc(T('Scan with a phone camera, or open the link and enter the PIN.'))+'</p>':'<p class="gl-mode">'+esc(T('Practice mode: players join from other tabs or windows on this computer.'))+'</p>')
      +'<div class="gs-row"><input class="gl-link" readonly value="'+esc(link)+'" aria-label="'+esc(T('Join link'))+'"><button class="gs-btn sm" data-gl="copy">'+esc(T('Copy link'))+'</button>'+(phones?'':'<button class="gs-btn sm ghost" data-gl="tab">'+esc(T('Open a player tab'))+'</button>')+'</div>'
      +'<p class="gs-note">'+esc(phones?T('Connected to your school’s live server.'):webPage()?T('To play on phones, add your school’s live server in Live server settings.'):T('To play on phones, put this file on your school website and add a live server in Live server settings.'))+' <button class="gl-linkbtn" data-gl="settings">'+esc(T('Live server settings'))+'</button></p></section>'
      +'<section class="gl-setup"><div class="gs-head"><h2>'+esc(T('Players'))+' <span id="gl-n">'+H.order.length+'</span></h2></div><div class="gl-players" id="gl-players"></div>'
      +'<div class="gs-k" style="margin-top:14px">'+esc(T('Game'))+'</div><div class="gs-seg" role="group" aria-label="'+esc(T('Game'))+'">'+LIVE_MODES.map(function(m){return '<button data-gl="mode" data-m="'+m[0]+'" aria-pressed="'+(H.mode===m[0])+'">'+esc(T(m[1]))+'</button>';}).join('')+'</div>'
      +'<div class="gs-actions" style="justify-content:flex-start;margin-top:14px"><button class="gs-btn" data-gl="go" id="gl-go"'+(H.order.length?'':' disabled')+'>'+esc(T('Start the game'))+'</button></div><p class="gs-note">'+esc(T('Players see only their own score and rank. Remove anyone with a name that isn’t appropriate.'))+'</p></section></div>';
    x.main(h);renderPlayers();x.progress(H.kind==='supabase'?T('Live · school server'):T('Live · this device'));tr(x.root());return;}}
function renderPlayers(){var el=document.getElementById('gl-players');if(!el||!H)return;var n=document.getElementById('gl-n');if(n)n.textContent=H.order.length;var go=document.getElementById('gl-go');if(go)go.disabled=!H.order.length;
  el.innerHTML=H.order.length?H.order.map(function(id){var p=H.players[id];return '<span class="gl-chip">'+esc(p.nick)+'<button data-gl="kick" data-p="'+esc(id)+'" aria-label="'+esc(T('Remove'))+' '+esc(p.nick)+'">×</button></span>';}).join(''):'<p class="gs-muted">'+esc(T('Waiting for players to join…'))+'</p>';}
function buildItems(){var x=I(),m=H.mode;if(m==='guess'){var gens=(window.MMGameShow.bank?window.MMGameShow.bank('GS_GUESS'):GS_GUESS)[x.band(x.grade())],n=x.opt('guess','count'),out=[],ord=x.shuffle(gens);for(var i=0;i<n;i++){var g=ord[i%ord.length]();out.push({cat:T('Closest Guess'),q:g.q,a:g.a,u:g.u,x:g.x,fact:g.x});}return out;}
  return x.quizItems(m);}
function hostGo(){if(!H||!H.order.length)return;var items=buildItems();if(!items.length)return;H.order.forEach(function(id){var p=H.players[id];p.score=0;p.streak=0;p.last=0;});
  H.game={items:items,i:-1,T:H.mode==='tf'?10:H.mode==='who'?WHO_CL*4:H.mode==='guess'?40:I().opt('rush','time'),recap:[]};H.phase='play';hostNext();}
function hostNext(){var g=H.game;g.i++;if(g.i>=g.items.length)return hostPodium();g.ans={};g.phase='answer';g.clueN=0;var it=g.items[g.i],x=I();
  x.progress(T('Question {n} of {m}',{n:g.i+1,m:g.items.length}));
  var cls=it.opts&&it.opts.length===2?['c2','c3']:['c0','c1','c2','c3'],let_=it.opts&&it.opts.length===2?['T','F']:['A','B','C','D'];
  x.main('<div class="gs-q"><div class="gs-eyebrow">'+esc(it.cat)+'</div><div class="gs-timer" id="gs-timer"><span>'+g.T+'</span></div><h2 class="gs-qtext">'+esc(it.q)+'</h2>'+(it.clues?'<ol class="gs-clues" id="gl-clues"></ol>':'')+'</div>'
    +(it.u?'<p class="gs-result">'+esc(T('Type your answer on your device.'))+'</p>':'<div class="gs-answers" id="gl-answers">'+it.opts.map(function(o,k){return '<div class="gs-ans '+cls[k]+'"><b>'+let_[k]+'</b><span>'+esc(o)+'</span><em class="gl-bar" id="gl-b-'+k+'"></em></div>';}).join('')+'</div>')
    +'<div class="gs-fact" id="gl-fact" hidden></div><div class="gs-actions"><span class="gs-pill" id="gl-count">'+esc(T('{n} of {m} answered',{n:0,m:H.order.length}))+'</span><button class="gs-btn ghost" data-gl="reveal" id="gl-reveal">'+esc(T('Reveal answer now'))+'</button><button class="gs-btn" data-gl="next" id="gl-next" hidden>'+esc(T('Leaderboard'))+'</button></div>');
  x.sfx('whoosh');tr(x.root());g.t0=performance.now();
  if(it.clues){var add=function(){if(!H||!H.game||H.game.phase!=='answer')return;if(g.clueN<it.clues.length){var cl=document.getElementById('gl-clues');if(cl)cl.insertAdjacentHTML('beforeend','<li>'+esc(it.clues[g.clueN])+'</li>');g.clueN++;push();}};add();H.clueIv=setInterval(add,WHO_CL*1000);}
  x.startClock(g.T,'gs-timer',function(){x.sfx('timesup');hostReveal();});push();}
function hostReveal(){var g=H&&H.game;if(!g||g.phase!=='answer')return;g.phase='reveal';var x=I();x.stopClock();clearInterval(H.clueIv);var it=g.items[g.i],counts=[0,0,0,0],tol=it.u?Math.max(Math.abs(it.a)*.5,it.u==='¢'?10:2):0,any=false;
  H.order.forEach(function(id){var p=H.players[id],a=g.ans[id],gain=0;p.ok=false;
    if(a&&!it.u){counts[a.k]++;if(a.k===it.correct){p.streak++;p.ok=true;gain=it.clues?WHO_PTS[Math.min(3,Math.floor(a.s/WHO_CL))]:Math.round((1000*(1-Math.min(1,a.s/g.T)/2))/10)*10+Math.min(500,(p.streak-1)*100);}else p.streak=0;}
    else if(a&&it.u){var e=Math.abs(a.v-it.a);gain=e<1e-9?1000:Math.max(0,Math.round(1000*(1-e/tol)/10)*10);p.ok=gain>0;}
    else p.streak=0;
    if(gain)any=true;p.score+=gain;p.last=gain;});
  if(!it.u){var tot=Math.max(1,Object.keys(g.ans).length);document.querySelectorAll('#gl-answers .gs-ans').forEach(function(el,k){el.classList.toggle('right',k===it.correct);var b=document.getElementById('gl-b-'+k);if(b)b.textContent=counts[k]+' · '+Math.round(counts[k]/tot*100)+'%';});var A=document.getElementById('gl-answers');if(A)A.classList.add('revealed');}
  var f=document.getElementById('gl-fact');if(f){f.hidden=false;f.innerHTML='<span class="gs-k">'+esc(T('Answer'))+': '+esc(it.u?x.fmtU(it.a,it.u):it.opts[it.correct])+'</span>'+(it.fact?'<span>'+esc(it.fact)+'</span>':'');}
  g.recap.push({c:it.cat,q:it.clues?it.clues.join(' '):it.q,a:it.u?x.fmtU(it.a,it.u):it.opts[it.correct],f:it.fact||''});
  document.getElementById('gl-reveal').hidden=true;var nx=document.getElementById('gl-next');nx.hidden=false;nx.textContent=T(g.i+1>=g.items.length?'See final results':'Leaderboard');tr(nx.parentNode);
  x.sfx(any?'correct':'wrong');push();}
function hostBoard(){var x=I(),r=rankList(),max=Math.max(1,r.length?r[0].score:1);H.game.phase='board';
  x.main('<div class="gs-head"><h2>'+esc(T('Leaderboard'))+'</h2><button class="gs-btn" data-gl="next2">'+esc(T('Next question'))+'</button></div><div class="gs-lb">'+r.slice(0,10).map(function(p,ix){return '<div class="gs-lbrow" style="--tc:#e0b24a;--w:'+Math.max(0,p.score)/max*100+'%;animation-delay:'+ix*50+'ms"><span class="bar"></span><span class="rk">'+(ix+1)+'</span><span class="nm">'+esc(p.nick)+'</span><span class="dl">'+(p.last?'+'+money(p.last):'')+'</span><span class="sc">'+money(p.score)+'</span></div>';}).join('')+'</div>'+(r.length>10?'<p class="gs-note gs-center">'+esc(T('{n} more players are checking their rank on their devices.',{n:r.length-10}))+'</p>':''));tr(x.root());push();}
function hostPodium(){var x=I(),r=rankList();H.phase='end';x.stopClock();x.recap(H.game.recap);
  x.main('<div class="gs-pod"><h2>'+(r[0]?esc(T('{name} wins!',{name:r[0].nick})):'')+'</h2><div class="gs-stands">'+[1,0,2].filter(function(i){return r[i];}).map(function(i){var p=r[i];return '<div class="gs-stand p'+(i+1)+'" style="--tc:'+['#e0b24a','#8796a6','#c47a3a'][i]+'"><div class="n">'+esc(p.nick)+'</div><div class="s">'+money(p.score)+'</div><div class="blk">'+(i+1)+'</div></div>';}).join('')+'</div>'
    +'<div class="gs-row c"><button class="gs-btn" data-gl="again">'+esc(T('Play again with the same players'))+'</button><button class="gs-btn ghost" data-gs="recap">'+esc(T('What we learned'))+'</button><button class="gs-btn ghost" data-gl="end">'+esc(T('End the live game'))+'</button></div></div>');
  tr(x.root());x.sfx('fanfare');x.confetti();push();}
function settings(){var x=I(),c=load(CFG_KEY,{})||{};
  x.modal('<div class="gs-mhead"><div><div class="gs-k">'+esc(T('Live play'))+'</div><h2 style="font:700 24px Georgia,serif">'+esc(T('Live server settings'))+'</h2></div><button class="gs-x" data-gs="m-close" aria-label="Close">×</button></div>'
    +'<p>'+esc(T('Phones need a small realtime server to talk to this screen. Money Matters uses your school’s own free Supabase project, so game messages never pass through a public server.'))+'</p>'
    +'<ol class="gl-steps"><li>'+esc(T('Create a free project at supabase.com. No tables are needed.'))+'</li><li>'+esc(T('In Project Settings → API, copy the Project URL and the anon (public) key.'))+'</li><li>'+esc(T('Paste them below and save. Put this file on your school website so phones can open the join link.'))+'</li></ol>'
    +'<label class="gs-k" for="gl-url">'+esc(T('Project URL'))+'</label><input id="gl-url" class="gl-in" placeholder="https://your-project.supabase.co" value="'+esc(c.url||'')+'" autocomplete="off" spellcheck="false">'
    +'<label class="gs-k" for="gl-key">'+esc(T('Anon (public) key'))+'</label><input id="gl-key" class="gl-in" value="'+esc(c.key||'')+'" autocomplete="off" spellcheck="false">'
    +'<p class="gs-note" id="gl-err" role="alert"></p><div class="gs-actions"><button class="gs-btn" data-gl="save">'+esc(T('Save and reconnect'))+'</button><button class="gs-btn ghost" data-gl="clear">'+esc(T('Use this device only'))+'</button></div>'
    +'<p class="gs-note">'+esc(T('The anon key is designed to be public. Messages carry only a random player id, a nickname, and answers; nothing is stored on the server.'))+'</p>',T('Live server settings'));tr(document.getElementById('gs-mc'));}
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#mm-gs [data-gl]');if(!b||b.disabled)return;var a=b.getAttribute('data-gl');
  if(a==='settings')return settings();
  if(a==='save'){var u=(document.getElementById('gl-url').value||'').trim().replace(/\/$/,''),k=(document.getElementById('gl-key').value||'').trim();if(!okCfg({url:u,key:k})){document.getElementById('gl-err').textContent=T('Enter a URL like https://your-project.supabase.co and the full anon key.');return;}save(CFG_KEY,{url:u,key:k});I().closeModal();hostStart();return;}
  if(a==='clear'){try{localStorage.removeItem(CFG_KEY);}catch(x){}I().closeModal();hostStart();return;}
  if(!H)return;
  if(a==='device'){H.cfg=null;var x=I();hostEnd(true);try{localStorage.removeItem(CFG_KEY);}catch(z){}hostStart();return;}
  if(a==='copy'){var l=joinLink();try{navigator.clipboard.writeText(l);b.textContent=T('Copied');}catch(z){var i=document.querySelector('.gl-link');if(i){i.select();document.execCommand('copy');}}return;}
  if(a==='tab'){window.open(joinLink(),'_blank');return;}
  if(a==='kick'){var id=b.getAttribute('data-p');H.kicked[id]=1;delete H.players[id];H.order=H.order.filter(function(x){return x!==id;});renderPlayers();push();return;}
  if(a==='mode'){H.mode=b.getAttribute('data-m');document.querySelectorAll('#mm-gs [data-gl=mode]').forEach(function(x){x.setAttribute('aria-pressed',String(x===b));});push();return;}
  if(a==='go')return hostGo();
  if(a==='reveal')return hostReveal();
  if(a==='next'){if(H.game.i+1>=H.game.items.length)return hostPodium();return hostBoard();}
  if(a==='next2')return hostNext();
  if(a==='again'){H.phase='lobby';H.game=null;render();push();return;}
  if(a==='end'){I().lobby();return;}});

/* =====================================================================
   PLAYER (phone) — opened with #join-PIN (school server) or #join-PIN-d (this device)
   ===================================================================== */
var P=null;
function playerBoot(){var m=/^#join-([A-Za-z0-9]{6})(-d)?$/.exec(location.hash||'');if(!m)return false;
  var c=linkCfg(),kind=m[2]?'device':(c?'supabase':'device');P={pin:m[1].toUpperCase(),kind:kind,cfg:c,pid:pidMake(),nick:load('mmLiveNick_v1',''),room:null,st:null,answered:-1,timer:null,joined:false};
  document.documentElement.classList.add('mm-lp-on');var el=document.createElement('div');el.id='mm-lp';el.setAttribute('role','main');el.setAttribute('aria-label','Money Game Show player');document.body.appendChild(el);
  [].forEach.call(document.body.children,function(x){if(x!==el&&x.tagName!=='SCRIPT'&&x.tagName!=='STYLE')x.setAttribute('inert','');});
  el.addEventListener('click',pClick);el.addEventListener('submit',function(e){e.preventDefault();var f=e.target;if(f.id==='lp-join')pJoin();if(f.id==='lp-num')pNum();});
  pRender();return true;}
function pShell(body){return '<div class="lp-top"><span class="gs-mark" aria-hidden="true">$</span><b>'+esc(T('Money Game Show'))+'</b><span class="lp-sp"></span>'+(P.joined?'<span class="lp-me">'+esc(P.nick)+'</span>':'')+'</div><div class="lp-body" aria-live="polite">'+body+'</div>';}
function pRender(){var el=document.getElementById('mm-lp');if(!el)return;var s=P.st,h='';
  if(!P.joined){h='<form id="lp-join" class="lp-card"><h1>'+esc(T('Join the game'))+'</h1><label for="lp-pin">'+esc(T('Game PIN'))+'</label><input id="lp-pin" value="'+esc(P.pin)+'" maxlength="6" autocapitalize="characters" autocomplete="off" spellcheck="false"><label for="lp-nick">'+esc(T('Your first name or nickname'))+'</label><input id="lp-nick" value="'+esc(P.nick)+'" maxlength="20" autocomplete="off"><button class="lp-go" type="submit">'+esc(T('Join'))+'</button><p class="lp-note">'+esc(T('Use only your first name or a nickname. Your teacher can see it on the big screen.'))+'</p><p class="lp-msg" id="lp-msg" role="alert"></p></form>';}
  else if(!s||s.phase==='lobby'||s.phase==='connecting'){h='<div class="lp-card lp-center"><h1>'+esc(T('You’re in!'))+'</h1><p>'+esc(T('Look at the big screen. The game starts soon.'))+'</p>'+(s?'<p class="lp-note">'+esc(T('{n} players have joined',{n:s.n}))+'</p>':'')+'</div>';}
  else if(s.phase==='ended'){h='<div class="lp-card lp-center"><h1>'+esc(T('The game has ended'))+'</h1><p>'+esc(T('Thanks for playing!'))+'</p></div>';}
  else if(s.phase==='end'){var r=s.ranks&&s.ranks[P.pid];h='<div class="lp-card lp-center"><h1>'+esc(T('Final results'))+'</h1>'+(r?'<div class="lp-big">'+money(r[0])+'</div><p>'+esc(T('You finished #{r} of {n}',{r:r[1],n:s.n}))+'</p>':'')+'<p class="lp-note">'+esc(T('Wait for your teacher to start another game.'))+'</p></div>';}
  else if(s.q){var q=s.q,mine=s.ranks&&s.ranks[P.pid];
    if(s.gp==='answer'&&P.answered!==s.i){h='<div class="lp-q"><div class="lp-k">'+esc(T('Question {n} of {m}',{n:s.i+1,m:s.of}))+' · '+esc(q.cat)+'</div><div class="lp-timer"><i id="lp-tbar"></i></div><h2>'+esc(q.q)+'</h2>'+(q.clues&&q.clues.length?'<ol class="lp-clues">'+q.clues.map(function(c){return '<li>'+esc(c)+'</li>';}).join('')+'</ol>':'')+'</div>';
      if(q.u)h+='<form id="lp-num" class="lp-card"><label for="lp-v">'+esc(T('Your answer'))+' ('+esc(q.u==='$'?T('dollars'):q.u==='¢'?T('cents'):T(q.u))+')</label><input id="lp-v" type="number" inputmode="decimal" step="any"><button class="lp-go" type="submit">'+esc(T('Lock in'))+'</button></form>';
      else{var two=q.opts.length===2,cls=two?['c2','c3']:['c0','c1','c2','c3'],L=two?['T','F']:['A','B','C','D'];h+='<div class="lp-ans'+(two?' two':'')+'">'+q.opts.map(function(o,k){return '<button class="gs-ans '+cls[k]+'" data-lp="ans" data-k="'+k+'"><b>'+L[k]+'</b><span>'+esc(o)+'</span></button>';}).join('')+'</div>';}}
    else if(s.gp==='answer'){h='<div class="lp-card lp-center"><h1>'+esc(T('Locked in'))+'</h1><p>'+esc(T('Waiting for everyone else…'))+'</p></div>';}
    else{var ok=mine&&mine[3];h='<div class="lp-card lp-center lp-res '+(ok?'ok':'no')+'"><h1>'+esc(ok?T('Correct!'):P.answered===s.i?T('Not this time'):T('Time’s up'))+'</h1>'+(mine?'<div class="lp-big">'+(mine[2]?'+'+money(mine[2]):money(0))+'</div><p>'+esc(T('Total {s} · #{r} of {n}',{s:money(mine[0]),r:mine[1],n:s.n}))+'</p>':'')+'<p class="lp-note">'+esc(T('Answer'))+': '+esc(s.answer||'')+'</p></div>';}}
  el.innerHTML=pShell(h);tr(el);clearInterval(P.timer);
  if(s&&s.gp==='answer'&&s.left!=null&&P.answered!==s.i){var end=Date.now()+s.left,T0=(s.T||20)*1000;P.timer=setInterval(function(){var b=document.getElementById('lp-tbar');if(!b){clearInterval(P.timer);return;}b.style.width=Math.max(0,(end-Date.now())/T0*100)+'%';},200);}}
function pJoin(){var pin=(document.getElementById('lp-pin').value||'').trim().toUpperCase(),nick=cleanNick(document.getElementById('lp-nick').value);var msg=document.getElementById('lp-msg');
  if(!/^[A-Z0-9]{6}$/.test(pin)){msg.textContent=T('Enter the 6-character game PIN.');return;}if(!nick){msg.textContent=T('Enter your first name or a nickname.');return;}
  P.pin=pin;P.nick=nick;save('mmLiveNick_v1',nick);msg.textContent=T('Connecting…');
  openRoom(pin,'player',P.kind,P.cfg).then(function(room){if(!room){msg.textContent=T('Could not connect. Check the PIN and your internet connection.');return;}P.room=room;P.joined=true;
    room.on('state',function(st){if(!st||st.pin!==P.pin)return;var changed=!P.st||P.st.phase!==st.phase||P.st.i!==st.i||P.st.gp!==st.gp||(st.q&&P.st.q&&(st.q.clues||[]).length!==(P.st.q.clues||[]).length)||P.st.n!==st.n;P.st=st;if(changed)pRender();});
    var hi=function(){room.sendUp({pid:P.pid,t:'hi',nick:P.nick});};hi();setInterval(hi,10000);pRender();});}
function pAnswer(k,v){var s=P.st;if(!s||s.gp!=='answer'||P.answered===s.i)return;P.answered=s.i;P.room.sendUp(v!=null?{pid:P.pid,t:'ans',i:s.i,v:v}:{pid:P.pid,t:'ans',i:s.i,k:k});try{navigator.vibrate&&navigator.vibrate(30);}catch(e){}pRender();}
function pNum(){var v=parseFloat(document.getElementById('lp-v').value);if(!isFinite(v))return;pAnswer(null,v);}
function pClick(e){var b=e.target.closest('[data-lp]');if(!b)return;if(b.getAttribute('data-lp')==='ans')pAnswer(+b.getAttribute('data-k'));}
window.addEventListener('pagehide',function(){if(P&&P.room)try{P.room.sendUp({pid:P.pid,t:'bye'});}catch(e){}});

window.MMGameShowLive={host:hostStart,settings:settings,isPlayer:function(){return !!P;}};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',playerBoot);else playerBoot();
})();
