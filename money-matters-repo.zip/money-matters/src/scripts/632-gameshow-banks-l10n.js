/* Spanish and Portuguese game-show banks (same shapes as GS_TF / GS_WHO / GS_ORDER / GS_GUESS). */
var GS_TF_L=window.GS_TF_L||{},GS_WHO_L=window.GS_WHO_L||{},GS_ORDER_L=window.GS_ORDER_L||{},GS_GUESS_L=window.GS_GUESS_L||{};
/* ---------- Game Show content banks, SPANISH (es) ----------
   Same shape as GS_TF, GS_WHO, GS_ORDER and GS_GUESS in gs-data.js. Load after gs-data.js. */
GS_TF_L.es={
k2:[
["Las monedas y los billetes son dos tipos de dinero.",1,"Las monedas y los billetes son dinero que usamos para comprar cosas."],
["Un dime vale más que un nickel.",1,"Un dime vale 10 centavos. Un nickel vale 5 centavos."],
["Un nickel vale más que un dime porque es más grande.",0,"El tamaño no dice el valor. Un dime (10¢) vale más que un nickel (5¢)."],
["Un quarter vale 25 centavos.",1,"Cuatro quarters hacen un dólar: 25 + 25 + 25 + 25 = 100 centavos."],
["Una necesidad es algo que debes tener para vivir, como la comida.",1,"Las necesidades son cosas como comida, agua, ropa y un hogar."],
["Un videojuego es una necesidad.",0,"Es un deseo: es lindo tenerlo, pero puedes vivir sin él."],
["Ahorrar es guardar dinero para usarlo después.",1,"Cuando ahorras, guardas dinero para una meta."],
["Cuatro quarters hacen un dólar.",1,"25¢ × 4 = 100¢, y 100¢ es un dólar."],
["Un penny vale 10 centavos.",0,"Un penny vale 1 centavo. Un dime vale 10 centavos."],
["Cuando compras algo, cambias dinero por eso.",1,"Comprar es un intercambio: tu dinero por la cosa."],
["Cuando gastas tu dinero, puedes gastar ese mismo dinero otra vez.",0,"El dinero gastado ya no está. Ahorrar un poco te ayuda después."],
["Las personas ganan dinero trabajando.",1,"El trabajo da dinero que se llama pago o ingreso."],
["Dar dinero o cosas para ayudar a otros se llama donar.",1,"Donar y compartir ayudan a las personas de tu comunidad."],
["Diez dimes hacen un dólar.",1,"10¢ × 10 = 100¢, que es un dólar."],
["Un banco guarda el dinero de las personas de forma segura.",1,"Los bancos cuidan el dinero y te dejan sacarlo cuando lo necesitas."],
["Siempre debes comprar lo primero que ves.",0,"Comparar antes te ayuda a gastar bien."],
["Dos nickels valen lo mismo que un dime.",1,"5¢ + 5¢ = 10¢, lo mismo que un dime."],
["Una meta es algo que planeas y por lo que trabajas.",1,"Una meta de ahorro puede ser un libro, un juguete o un regalo."],
["El dinero crece en los árboles.",0,"Las personas ganan dinero trabajando. ¡No crece en los árboles!"],
["El cambio es el dinero que te devuelven cuando pagas más que el precio.",1,"Pagas $1 por un bocadillo de 75¢ y te dan 25¢ de cambio."],
["Un billete de cinco dólares vale más que un billete de un dólar.",1,"$5 es cinco veces más que $1."],
["Un deseo es algo que debes tener para seguir vivo.",0,"Eso es una necesidad. Un deseo es algo lindo de tener."]
],
"35":[
["Un presupuesto es un plan para gastar y ahorrar dinero.",1,"Un presupuesto te ayuda a no gastar más de lo que tienes."],
["El interés es dinero que el banco te paga por guardar tus ahorros allí.",1,"Los que ahorran ganan interés. Los que piden prestado pagan interés."],
["El impuesto sobre las ventas se suma al precio de muchas cosas que compras.",1,"El impuesto sobre las ventas ayuda a pagar cosas como calles y escuelas."],
["El costo de oportunidad es la siguiente mejor opción a la que renuncias.",1,"Cada decisión tiene una compensación: lo que no elegiste."],
["Una tarjeta de débito gasta dinero que pediste prestado.",0,"Una tarjeta de débito usa dinero de tu propia cuenta bancaria. Una tarjeta de crédito pide prestado."],
["Una tarjeta de crédito te permite pedir prestado dinero que debes devolver.",1,"Si no pagas la factura completa, se suma interés."],
["El ingreso es el dinero que gastas.",0,"El ingreso es el dinero que recibes. Los gastos son lo que gastas."],
["Comparar precios por unidad te ayuda a encontrar la mejor oferta.",1,"El precio por unidad es el costo de un artículo o de una onza."],
["Un depósito es dinero que sacas del banco.",0,"Eso es un retiro. Un depósito es dinero que pones en el banco."],
["Un emprendedor es alguien que empieza un negocio.",1,"Los emprendedores toman riesgos para convertir una idea en un negocio."],
["La ganancia es el dinero que queda después de que un negocio paga sus costos.",1,"Ganancia = dinero ganado − costos."],
["Comprar algo en oferta siempre te ahorra dinero.",0,"Solo ahorras si de todos modos lo necesitabas."],
["Escasez significa que las personas no pueden tener todo lo que quieren.",1,"Los recursos son limitados, así que debemos tomar decisiones."],
["Un fondo de emergencia son ahorros para gastos inesperados.",1,"Una llanta ponchada o unos lentes rotos son buenas razones para tener uno."],
["Los anuncios están hechos para que quieras comprar cosas.",1,"Los anuncios usan música, colores y famosos para llamar tu atención."],
["Ahorrar un poco cada semana puede sumar mucho con el tiempo.",1,"$5 por semana durante un año son $260."],
["Los bienes son cosas que puedes tocar; los servicios son trabajos que alguien hace por ti.",1,"Los zapatos son bienes. Un corte de pelo es un servicio."],
["Pedir dinero prestado es gratis si lo devuelves.",0,"Los prestamistas casi siempre cobran interés, así que pedir prestado cuesta más."],
["Un cheque le dice al banco que pague dinero de tu cuenta.",1,"Los cheques tienen un número de ruta bancaria y un número de cuenta."],
["Los precios pueden subir cuando mucha gente quiere algo y no hay mucho.",1,"Eso es la oferta y la demanda."],
["Un recibo es un cupón para tu próxima compra.",0,"Un recibo es la prueba de lo que compraste y de lo que pagaste."],
["El pago bruto es lo que recibes después de impuestos.",0,"Ese es el pago neto. El pago bruto es antes de impuestos y deducciones."]
],
"68":[
["El interés compuesto gana interés sobre tu interés.",1,"Por eso el dinero que se ahorra temprano puede crecer mucho más rápido."],
["Un puntaje de crédito ayuda a los prestamistas a decidir qué tan riesgoso es prestarte.",1,"Pagar a tiempo es el factor más importante en la mayoría de los puntajes."],
["Pagar solo el mínimo de una tarjeta de crédito evita todo el interés.",0,"Se cobra interés sobre cualquier saldo que no pagues por completo."],
["Diversificar significa repartir el dinero entre diferentes inversiones.",1,"Reduce el riesgo de que una mala inversión te perjudique mucho."],
["El pago neto es tu pago después de impuestos y deducciones.",1,"Es la cantidad que realmente se deposita en tu cuenta."],
["Las acciones siempre suben de valor.",0,"Los precios de las acciones suben y bajan. Invertir implica riesgo."],
["La inflación significa que los precios suben con el tiempo, así que cada dólar compra menos.",1,"La inflación reduce el poder de compra del dinero."],
["La Regla del 72 estima cuántos años tarda el dinero en duplicarse.",1,"Divide 72 entre la tasa de interés: al 6%, unos 12 años."],
["Una tasa de interés más alta hace que un préstamo sea más barato.",0,"Una tasa más alta significa más interés, así que el préstamo cuesta más."],
["El seguro de la FDIC (agencia federal que asegura depósitos) protege los depósitos hasta $250,000 por depositante, por banco asegurado, por categoría de propiedad.",1,"El seguro de la FDIC cubre cuentas de depósito, no inversiones como las acciones."],
["El robo de identidad es cuando alguien usa tu información personal sin permiso.",1,"Protege tu número de Social Security (Seguro Social), tus contraseñas y tus números de cuenta."],
["Revisar tu estado de cuenta bancario te ayuda a detectar errores y fraudes.",1,"Revisa cada transacción que no reconozcas."],
["El formulario W-4 le dice a tu empleador cuánto impuesto federal sobre la renta debe retener.",1,"Lo llenas cuando empiezas un trabajo nuevo."],
["Invertir temprano le da a tu dinero más tiempo para crecer.",1,"El tiempo deja que el interés compuesto haga más del trabajo."],
["Un bono es una parte de la propiedad de una empresa.",0,"Un bono es un préstamo a una empresa o a un gobierno. Una acción es propiedad."],
["El seguro te ayuda a protegerte de grandes pérdidas de dinero.",1,"Pagas una prima para que una gran pérdida no caiga toda sobre ti."],
["La renta normalmente es un gasto fijo.",1,"Los gastos fijos se mantienen más o menos iguales cada mes."],
["Comprar un carro con un préstamo cuesta más que el precio cuando se suma el interés.",1,"El costo total es el precio más todo el interés pagado."],
["Los bancos de verdad te piden tu contraseña por correo electrónico o mensaje de texto.",0,"Eso es phishing (estafa por mensaje). Los bancos no piden contraseñas así."],
["Los impuestos de Social Security (Seguro Social) y Medicare se llaman FICA.",1,"Los empleados pagan 6.2% para Social Security y 1.45% para Medicare."],
["Un fondo indexado tiene muchas empresas, lo que reparte el riesgo.",1,"Ser dueño de muchas empresas es una forma sencilla de diversificar."],
["Tu reporte de crédito muestra tu historial de préstamos y pagos.",1,"Puedes revisarlo gratis y disputar los errores."]
]};

GS_WHO_L.es={
k2:[
{a:"Quarter",w:["Penny","Dime","Nickel"],c:["Soy redondo y de metal.","Tengo rayitas en mi borde.","Cuatro como yo hacen un dólar.","Valgo 25 centavos."],f:"El quarter es la moneda más grande que se usa todos los días en EE. UU."},
{a:"Penny",w:["Nickel","Dime","Quarter"],c:["Soy una moneda con Abraham Lincoln al frente.","Soy de color cobre.","Cien como yo hacen un dólar.","Valgo 1 centavo."],f:"El penny es la moneda de EE. UU. que vale menos. EE. UU. dejó de fabricar pennies nuevos en 2025, pero los viejos todavía sirven."},
{a:"Dime",w:["Penny","Nickel","Quarter"],c:["Soy la moneda más pequeña de EE. UU.","Tengo rayitas en mi borde.","Diez como yo hacen un dólar.","Valgo 10 centavos."],f:"Pequeño pero poderoso: un dime vale más que un nickel, que es más grande."},
{a:"Nickel",w:["Penny","Dime","Quarter"],c:["Soy una moneda plateada con el borde liso.","Thomas Jefferson está en mi frente.","Veinte como yo hacen un dólar.","Valgo 5 centavos."],f:"Un nickel vale 5 pennies."},
{a:"Banco",w:["Tienda","Biblioteca","Parque"],c:["Soy un edificio que hay en muchos pueblos.","La gente me confía algo valioso.","Conmigo puedes hacer depósitos y retiros.","Guardo tu dinero seguro."],f:"Los bancos guardan el dinero seguro y lo ayudan a crecer."},
{a:"Necesidad",w:["Deseo","Regalo","Juguete"],c:["Todos me tienen.","Sin mí, no puedes estar sano y seguro.","La comida, el agua y un hogar son ejemplos de mí.","Soy algo que debes tener para vivir."],f:"Primero las necesidades, después los deseos."},
{a:"Deseo",w:["Necesidad","Billete","Trabajo"],c:["Es divertido soñar conmigo.","Puedes vivir sin mí.","Los juguetes y los dulces son ejemplos de mí.","Soy lindo de tener, pero no necesario."],f:"Está bien tener deseos. Planea y ahorra para ellos."},
{a:"Ahorrar",w:["Gastar","Pedir prestado","Intercambiar"],c:["Necesito paciencia.","Te ayudo a comprar cosas más grandes después.","Una alcancía te ayuda a hacerme.","Soy guardar dinero para usarlo después."],f:"Ahorrar un poco a la vez suma mucho."},
{a:"Trabajo",w:["Regalo","Deseo","Cambio"],c:["Muchos adultos van a mí casi todos los días.","Ayudo a las personas a ganar dinero.","Los maestros, los doctores y los panaderos tienen uno.","Soy lo que haces para ganar dinero."],f:"Los trabajos ayudan a ganar dinero y a ayudar a otros."},
{a:"Precio",w:["Cambio","Ahorros","Meta"],c:["Las tiendas me ponen en etiquetas y letreros.","Puedo subir o bajar.","Soy un número con el signo de dólar o de centavo.","Te digo cuánto cuesta algo."],f:"Siempre mira el precio antes de comprar."},
{a:"Cambio",w:["Precio","Regalo","Ahorros"],c:["Regreso a ti en la tienda.","Aparezco cuando pagas más de lo necesario.","Si un bocadillo cuesta 75¢ y pagas $1, yo soy 25¢.","Soy el dinero que te devuelven después de pagar."],f:"Cuenta tu cambio para ver que esté bien."},
{a:"Meta",w:["Deseo","Moneda","Billete"],c:["Estoy en el futuro.","Haces un plan para llegar a mí.","Ahorrar $10 para un libro puede ser yo.","Soy algo por lo que trabajas."],f:"Escribir tu meta te ayuda a lograrla."},
{a:"Donar",w:["Gastar","Ahorrar","Pedir prestado"],c:["Hago sonreír a otras personas.","A los bancos de comida y a los refugios les alegra recibirme.","Algunos niños guardan parte de su dinero para mí.","Soy dar dinero o cosas para ayudar a otros."],f:"Gastar, ahorrar y compartir: tres buenos usos del dinero."}
],
"35":[
{a:"Presupuesto",w:["Recibo","Préstamo","Ganancia"],c:["Soy un plan, no una tienda.","Muestro ingresos y gastos.","Te ayudo a decidir a dónde va cada dólar.","Soy un plan para gastar y ahorrar dinero."],f:"Un presupuesto te ayuda a no gastar más de lo que ganas."},
{a:"Interés",w:["Impuesto","Ganancia","Mesada"],c:["A los bancos y a quienes piden prestado les importo.","Muchas veces me escriben como porcentaje.","Los que ahorran me ganan; los que piden prestado me pagan.","Soy el dinero extra que se paga por usar dinero."],f:"Un 5% de interés sobre $100 durante un año son $5."},
{a:"Impuesto sobre las ventas",w:["Descuento","Interés","Cupón"],c:["Los gobiernos me cobran.","Ayudo a pagar calles, escuelas y parques.","Me suman en la caja.","Soy un porcentaje que se suma al precio de lo que compras."],f:"La tasa del impuesto sobre las ventas cambia de un lugar a otro."},
{a:"Costo de oportunidad",w:["Impuesto sobre las ventas","Ganancia","Descuento"],c:["Toda decisión me tiene.","No me verás en un recibo.","Soy lo que dejas ir.","Soy la siguiente mejor opción que no elegiste."],f:"Elegir el campamento de fútbol puede significar dejar la clase de arte."},
{a:"Ganancia",w:["Precio","Préstamo","Presupuesto"],c:["Los negocios esperan tenerme.","Un puesto de limonada puede tenerme.","Soy lo que queda después de los costos.","Soy igual al dinero ganado menos los costos."],f:"Vendes $30 de limonada con $12 de costos: $18 de ganancia."},
{a:"Emprendedor",w:["Consumidor","Empleado","Banquero"],c:["Tomo riesgos.","Tengo una idea de negocio.","Puedo empezar en pequeño, como un servicio de paseo de perros.","Soy una persona que empieza un negocio."],f:"Los emprendedores crean empleos y productos nuevos."},
{a:"Tarjeta de débito",w:["Tarjeta de crédito","Cupón","Recibo"],c:["Soy una tarjeta pequeña de plástico.","Estoy conectada a una cuenta de cheques.","Cuando me usas, el dinero sale de tu cuenta enseguida.","Te dejo pagar con dinero que ya tienes."],f:"Lleva la cuenta de tu saldo cuando uses una tarjeta de débito."},
{a:"Tarjeta de crédito",w:["Tarjeta de débito","Cupón","Recibo"],c:["Soy una tarjeta pequeña de plástico.","Soy un préstamo en tu cartera.","Si no me pagas completa, el interés se acumula.","Te dejo comprar ahora y pagar después."],f:"Pagar el saldo completo cada mes evita el interés."},
{a:"Fondo de emergencia",w:["Mesada","Lista de deseos","Cheque de pago"],c:["Me guardan para las sorpresas.","Una llanta ponchada podría usarme.","Es inteligente formarme antes de necesitarme.","Soy ahorros para gastos inesperados."],f:"Hasta un fondo de emergencia pequeño ayuda."},
{a:"Recibo",w:["Cupón","Cheque","Presupuesto"],c:["Casi siempre soy de papel, o a veces un correo electrónico.","Pruebo lo que compraste.","Puedes necesitarme para devolver algo.","Muestro lo que pagaste y cuándo."],f:"Revisa tu recibo antes de irte para ver si hay errores."},
{a:"Cupón",w:["Recibo","Impuesto","Cheque"],c:["Puedo ser de papel o digital.","Puedo vencer.","Bajo el precio de algo.","Soy un boleto para un descuento."],f:"Un cupón solo ahorra dinero en cosas que ya pensabas comprar."},
{a:"Depósito",w:["Retiro","Préstamo","Gasto"],c:["A los bancos les gusta recibirme.","Hago que tu saldo suba.","Soy lo contrario de un retiro.","Soy dinero que pones en una cuenta."],f:"Los depósitos pueden ser efectivo, cheques o depósitos directos de un trabajo."},
{a:"Escasez",w:["Excedente","Ganancia","Interés"],c:["Los economistas hablan mucho de mí.","Por mí debemos tomar decisiones.","Nunca hay suficiente de todo para todos.","Soy recursos limitados y deseos ilimitados."],f:"La escasez es la razón por la que cada decisión tiene una compensación."}
],
"68":[
{a:"Interés compuesto",w:["Interés simple","Inflación","Dividendo"],c:["El tiempo es mi mejor amigo.","Muchas veces me comparan con una bola de nieve.","La Regla del 72 estima qué tan rápido duplico el dinero.","Soy el interés que se gana sobre tus ahorros y sobre el interés anterior."],f:"$1,000 al 6% compuesto cada año son unos $1,791 después de 10 años."},
{a:"Puntaje de crédito",w:["Tasa de interés","Número de cuenta","Límite de crédito"],c:["Soy un número de tres dígitos.","Los prestamistas y los arrendadores me revisan.","Pagar las cuentas a tiempo me hace subir.","Califico qué tan probable es que devuelvas el dinero prestado."],f:"El historial de pagos es la parte más grande de la mayoría de los puntajes de crédito."},
{a:"Inflación",w:["Deflación","Depreciación","Dividendo"],c:["El Índice de Precios al Consumidor me mide.","La Reserva Federal busca mantenerme cerca del 2% al año.","Hago que los mismos $20 compren menos comida con el tiempo.","Soy el aumento general de los precios con el tiempo."],f:"Los ahorros que ganan menos que la inflación pierden poder de compra."},
{a:"Acción",w:["Bono","Certificado de depósito","Cuenta de ahorros"],c:["Me compran y venden en las bolsas de valores.","Mi precio puede cambiar cada segundo que el mercado está abierto.","Tenerme te hace dueño de una parte.","Soy una parte de la propiedad de una empresa."],f:"Las acciones tienen más riesgo y más potencial de crecimiento a largo plazo."},
{a:"Bono",w:["Acción","Dividendo","Tarjeta de crédito"],c:["Los gobiernos y las empresas me emiten.","Normalmente pago una cantidad fija de interés.","Normalmente tengo menos riesgo que las acciones.","Soy un préstamo que le haces a una empresa o a un gobierno."],f:"Los bonos del Tesoro de EE. UU. están respaldados por el gobierno federal."},
{a:"Diversificación",w:["Especulación","Inflación","Capitalización"],c:["Soy una estrategia, no un producto.","Los fondos indexados me hacen más fácil.","Soy lo contrario de poner todos los huevos en una sola canasta.","Reparto el dinero entre inversiones para reducir el riesgo."],f:"Diversificar no elimina el riesgo, pero lo reduce."},
{a:"Pago neto",w:["Pago bruto","Salario","Bonificación"],c:["Soy más pequeño que el pago bruto.","Los impuestos y las deducciones salen antes de que me recibas.","Soy lo que llega a tu cuenta bancaria.","Soy el dinero que te llevas a casa."],f:"Haz tu presupuesto con el pago neto, no con el bruto."},
{a:"APR",w:["ATM","FDIC","IRA"],c:["Soy tres letras.","Las ofertas de tarjetas de crédito deben mostrarme.","Muestro el costo anual de pedir prestado como porcentaje.","Significo Annual Percentage Rate (tasa de porcentaje anual)."],f:"Un APR más bajo significa que pedir prestado cuesta menos."},
{a:"Seguro",w:["Inversión","Préstamo","Presupuesto"],c:["Tengo primas y deducibles.","Esperas no necesitarme nunca.","Puedo cubrir un carro, una casa o tu salud.","Te protejo de grandes pérdidas a cambio de un pago regular."],f:"El deducible es lo que pagas antes de que pague el seguro."},
{a:"FDIC",w:["IRS","SEC","APR"],c:["Me crearon en 1933.","Soy una agencia independiente del gobierno de EE. UU.","Busca mi letrero en los bancos.","Aseguro los depósitos bancarios hasta $250,000 por depositante, por banco, por categoría de propiedad."],f:"Ningún depositante ha perdido ni un centavo de fondos asegurados por la FDIC desde 1934."},
{a:"Robo de identidad",w:["Inflación","Bancarrota","Sobregiro"],c:["Muchas veces empiezo con un mensaje de phishing.","Triturar papeles ayuda a detenerme.","Congelar tu crédito puede bloquearme.","Soy cuando alguien usa tu información personal para cometer fraude."],f:"Repórtalo en IdentityTheft.gov."},
{a:"Sobregiro",w:["Depósito","Dividendo","Reembolso"],c:["Los bancos pueden cobrar una comisión por mí.","Paso en las cuentas de cheques.","Llevar la cuenta de tu saldo te ayuda a evitarme.","Paso cuando gastas más de lo que tiene tu cuenta."],f:"Activar alertas de saldo ayuda a evitar sobregiros."},
{a:"Dividendo",w:["Interés","Prima","Deducible"],c:["No todas las empresas me pagan.","Muchas veces me pagan cada tres meses.","Los accionistas me reciben.","Soy una parte de las ganancias de una empresa que se paga a los inversionistas."],f:"Algunos inversionistas reinvierten los dividendos para comprar más acciones."},
{a:"Hipoteca",w:["Arrendamiento","Seguro","Bono"],c:["Muchas veces duro 15 o 30 años.","La casa es mi garantía.","Normalmente primero se da un pago inicial.","Soy un préstamo para comprar una casa."],f:"Un pago inicial más grande significa una hipoteca más pequeña."},
{a:"401(k)",w:["W-2","Hipoteca","Bono de ahorro"],c:["Me llamo como una sección del código de impuestos.","A veces los empleadores igualan lo que pones en mí.","Estoy hecho para el largo plazo.","Soy un plan de ahorro para la jubilación que se ofrece en el trabajo."],f:"La aportación igualada del empleador es como un aumento que solo recibes si ahorras."}
]};

/* ordering sets: [card text, sort key, label shown on reveal] */
GS_ORDER_L.es={
k2:[
{t:"Monedas de menor a mayor valor",items:[["Penny",1,"1¢"],["Nickel",5,"5¢"],["Dime",10,"10¢"],["Quarter",25,"25¢"]]},
{t:"Billetes de menor a mayor valor",items:[["Billete de un dólar",1,"$1"],["Billete de cinco dólares",5,"$5"],["Billete de diez dólares",10,"$10"],["Billete de veinte dólares",20,"$20"]]},
{t:"Comprar algo en una tienda, el primer paso primero",items:[["Elige lo que quieres",1,"Paso 1"],["Mira el precio",2,"Paso 2"],["Paga al cajero",3,"Paso 3"],["Recibe tu cambio y tu recibo",4,"Paso 4"]]},
{t:"Ahorrar para un juguete, el primer paso primero",items:[["Elige una meta",1,"Paso 1"],["Averigua el precio",2,"Paso 2"],["Ahorra un poco cada semana",3,"Paso 3"],["Cómpralo cuando tengas suficiente",4,"Paso 4"]]},
{t:"Cantidades de menor a mayor",items:[["3 pennies",3,"3¢"],["1 nickel",5,"5¢"],["2 nickels",10,"10¢"],["1 quarter",25,"25¢"]]},
{t:"Cantidades de menor a mayor",items:[["2 dimes",20,"20¢"],["1 quarter",25,"25¢"],["3 dimes",30,"30¢"],["2 quarters",50,"50¢"]]},
{t:"Tener un puesto de limonada, el primer paso primero",items:[["Planea qué vas a vender",1,"Paso 1"],["Compra limones y vasos",2,"Paso 2"],["Vende limonada a los clientes",3,"Paso 3"],["Cuenta el dinero que ganaste",4,"Paso 4"]]}
],
"35":[
{t:"Hacer un presupuesto, el primer paso primero",items:[["Anota tus ingresos",1,"Paso 1"],["Haz una lista de tus gastos",2,"Paso 2"],["Resta los gastos de los ingresos",3,"Paso 3"],["Ajusta tus gastos para ahorrar más",4,"Paso 4"]]},
{t:"Cantidades de menor a mayor",items:[["10% de $50",5,"$5"],["25% de $40",10,"$10"],["La mitad de $30",15,"$15"],["4 × $5",20,"$20"]]},
{t:"Cantidades de menor a mayor",items:[["$0.75",75,"$0.75"],["4 quarters",100,"$1.00"],["$1.10",110,"$1.10"],["12 dimes",120,"$1.20"]]},
{t:"Historia del dinero en EE. UU., lo más antiguo primero",items:[["Se crea la Casa de la Moneda de EE. UU. (U.S. Mint)",1792,"1792"],["El gobierno federal emite su primer papel moneda nacional (los Demand Notes)",1861,"1861"],["Se crea la Reserva Federal",1913,"1913"],["Abre el primer cajero automático (ATM) en EE. UU.",1969,"1969"]]},
{t:"Empezar un negocio, el primer paso primero",items:[["Piensa en una idea de negocio",1,"Paso 1"],["Calcula tus costos",2,"Paso 2"],["Vende tu producto",3,"Paso 3"],["Resta los costos de las ventas para hallar la ganancia",4,"Paso 4"]]},
{t:"Del precio más bajo al más alto por pluma",items:[["10 plumas por $5",50,"50¢ cada una"],["4 plumas por $3",75,"75¢ cada una"],["2 plumas por $2",100,"$1.00 cada una"],["1 pluma por $1.25",125,"$1.25 cada una"]]},
{t:"Ahorrar para una bicicleta, el primer paso primero",items:[["Averigua el precio de la bicicleta",1,"Paso 1"],["Decide cuánto ahorrar cada semana",2,"Paso 2"],["Deposita tus ahorros cada semana",3,"Paso 3"],["Compra la bicicleta cuando llegues a tu meta",4,"Paso 4"]]}
],
"68":[
{t:"Momentos clave del dinero en EE. UU., lo más antiguo primero",items:[["Se crea la Casa de la Moneda de EE. UU. (U.S. Mint)",1792,"1792"],["Se crea el Sistema de la Reserva Federal",1913,"1913"],["Se crea la FDIC",1933,"1933"],["Social Security (Seguro Social) se vuelve ley",1935,"1935"]]},
{t:"Herramientas modernas del dinero, lo más antiguo primero",items:[["La primera tarjeta de cargo de uso amplio (Diners Club)",1950,"1950"],["Abre el primer cajero automático (ATM) en EE. UU.",1969,"1969"],["Una ley crea el plan 401(k)",1978,"1978"],["Se crea la Roth IRA",1997,"1997"]]},
{t:"El dinero a través de la historia, lo más antiguo primero",items:[["Lidia acuña algunas de las primeras monedas",-600,"c. 600 a. e. c."],["China empieza a usar papel moneda",1000,"c. siglo XI"],["Se crea la Casa de la Moneda de EE. UU. (U.S. Mint)",1792,"1792"],["Abre el primer cajero automático (ATM) en EE. UU.",1969,"1969"]]},
{t:"Del cheque de pago al presupuesto, el primer paso primero",items:[["Ganas el pago bruto",1,"Paso 1"],["Se retienen impuestos y deducciones",2,"Paso 2"],["Se deposita el pago neto",3,"Paso 3"],["Gastas y ahorras según tu presupuesto",4,"Paso 4"]]},
{t:"Del menor al mayor interés ganado en un año",items:[["$1,000 al 2%",20,"$20"],["$500 al 6%",30,"$30"],["$2,000 al 2.5%",50,"$50"],["$800 al 10%",80,"$80"]]},
{t:"Conseguir tu primer trabajo, el primer paso primero",items:[["Encuentra una vacante",1,"Paso 1"],["Envía tu currículum y tu solicitud",2,"Paso 2"],["Ten una entrevista con el empleador",3,"Paso 3"],["Llena un W-4 en tu primer día",4,"Paso 4"]]},
{t:"En general, del menor al mayor riesgo",items:[["Cuenta de ahorros asegurada",1,"El más bajo"],["Bono del Tesoro de EE. UU.",2,"Bajo"],["Fondo indexado amplio de acciones",3,"Más alto"],["Acciones de una sola empresa",4,"El más alto"]]}
]};

/* word-problem generators for Closest Guess: return {q,a,u,x} (u: '$','¢','weeks','years') */
GS_GUESS_L.es=(function(){
function ri(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function pick(a){return a[Math.floor(Math.random()*a.length)];}
function m(n){return '$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2});}
return {
k2:[
function(){var q=ri(0,3),d=ri(1,4),p=ri(0,5),a=q*25+d*10+p;return {q:'Tienes '+q+' quarter'+(q===1?'':'s')+', '+d+' dime'+(d===1?'':'s')+' y '+p+' penn'+(p===1?'y':'ies')+'. ¿Cuántos centavos son?',a:a,u:'¢',x:q+' × 25¢ + '+d+' × 10¢ + '+p+' × 1¢ = '+a+'¢'};},
function(){var h=ri(8,20),c=ri(2,h-1);return {q:'Tienes $'+h+'. Compras un libro de $'+c+'. ¿Cuántos dólares te quedan?',a:h-c,u:'$',x:'$'+h+' − $'+c+' = $'+(h-c)};},
function(){var s=pick([1,2,3]),w=ri(3,8),p=s*w;return {q:'Un juguete cuesta $'+p+'. Ahorras $'+s+' cada semana. ¿Cuántas semanas faltan para poder comprarlo?',a:w,u:'weeks',x:'$'+p+' ÷ $'+s+' por semana = '+w+' semanas'};},
function(){var c=pick([5,10]),n=ri(3,9);return {q:'Cada calcomanía cuesta '+c+'¢. ¿Cuántos centavos cuestan '+n+' calcomanías?',a:c*n,u:'¢',x:n+' × '+c+'¢ = '+(c*n)+'¢'};},
function(){var a=pick([15,20,25,30,35,40]),b=pick([10,15,20,25,30]);return {q:'Un lápiz cuesta '+a+'¢ y un borrador cuesta '+b+'¢. ¿Cuántos centavos cuestan los dos?',a:a+b,u:'¢',x:a+'¢ + '+b+'¢ = '+(a+b)+'¢'};},
function(){var p=pick([35,40,55,60,65,80,85,90]);return {q:'Un bocadillo cuesta '+p+'¢. Pagas con $1 (100¢). ¿Cuántos centavos de cambio te dan?',a:100-p,u:'¢',x:'100¢ − '+p+'¢ = '+(100-p)+'¢'};}
],
"35":[
function(){var s=ri(3,12),w=ri(4,15);return {q:'Ahorras $'+s+' cada semana durante '+w+' semanas. ¿Cuánto ahorras en total?',a:s*w,u:'$',x:'$'+s+' × '+w+' = '+m(s*w)};},
function(){var p=pick([20,30,40,50,60,80,100,120]),r=pick([10,20,25,50]),a=p*(100-r)/100;return {q:'Una chaqueta de $'+p+' tiene '+r+'% de descuento. ¿Cuál es el precio de oferta?',a:a,u:'$',x:'El '+r+'% de $'+p+' es '+m(p*r/100)+', así que $'+p+' − '+m(p*r/100)+' = '+m(a)};},
function(){var p=pick([25,50,75,100]),r=8,a=p*1.08;return {q:'A un juego de $'+p+' se le suma 8% de impuesto sobre las ventas. ¿Cuál es el costo total?',a:Math.round(a*100)/100,u:'$',x:'El 8% de $'+p+' es '+m(p*.08)+', así que el total es '+m(a)};},
function(){var inc=ri(16,40)*5,e1=ri(4,12)*5,e2=ri(2,6)*5,e3=ri(1,4)*5;if(e1+e2+e3>=inc)inc=e1+e2+e3+ri(2,8)*5;return {q:'Ganas $'+inc+' este mes. Gastas $'+e1+' en comida, $'+e2+' en diversión y $'+e3+' en un regalo. ¿Cuánto te queda para ahorrar?',a:inc-e1-e2-e3,u:'$',x:'$'+inc+' − $'+e1+' − $'+e2+' − $'+e3+' = '+m(inc-e1-e2-e3)};},
function(){var n=pick([4,5,6,8,10,12]),e=pick([25,30,40,50,60,75]),p=n*e/100;return {q:'Un paquete de '+n+' cajitas de jugo cuesta '+m(p)+'. ¿Cuántos centavos cuesta cada cajita?',a:e,u:'¢',x:m(p)+' ÷ '+n+' = '+e+'¢ cada una'};},
function(){var p=pick([100,200,300,400,500]),r=pick([2,3,4,5]);return {q:'Tienes $'+p+' en una cuenta de ahorros que paga '+r+'% de interés al año. ¿Cuánto interés ganas en un año?',a:p*r/100,u:'$',x:'El '+r+'% de $'+p+' = '+m(p*r/100)};},
function(){var w=pick([10,12,15]),h=ri(3,8);return {q:'Ganas $'+w+' por hora paseando perros y trabajas '+h+' horas. ¿Cuánto ganas?',a:w*h,u:'$',x:'$'+w+' × '+h+' horas = '+m(w*h)};}
],
"68":[
function(){var P=ri(1,10)*500,r=pick([2,3,4,5,6]),t=ri(2,5),I=P*r*t/100;return {q:'Inviertes $'+P.toLocaleString()+' al '+r+'% de interés simple durante '+t+' años. ¿Cuánto interés ganas?',a:I,u:'$',x:'I = P × r × t = $'+P.toLocaleString()+' × '+(r/100)+' × '+t+' = '+m(I)};},
function(){var P=pick([1000,2000,5000]),r=pick([4,5,6,8,10]),t=pick([2,3]),A=Math.round(P*Math.pow(1+r/100,t));return {q:'$'+P.toLocaleString()+' gana '+r+'% de interés compuesto cada año durante '+t+' años. ¿Más o menos cuál es el saldo final, redondeado al dólar?',a:A,u:'$',x:'$'+P.toLocaleString()+' × '+(1+r/100)+'^'+t+' ≈ '+m(A)};},
function(){var r=pick([3,4,6,8,9,12]);return {q:'Con la Regla del 72, ¿más o menos cuántos años tarda el dinero en duplicarse al '+r+'% anual?',a:72/r,u:'years',x:'72 ÷ '+r+' = '+(72/r)+' años'};},
function(){var g=ri(12,30)*50,w=pick([15,18,20,22,25]),n=g*(100-w)/100;return {q:'Tu pago bruto es $'+g.toLocaleString()+'. Se retiene el '+w+'% para impuestos y deducciones. ¿Cuál es tu pago neto?',a:n,u:'$',x:'$'+g.toLocaleString()+' × '+((100-w)/100)+' = '+m(n)};},
function(){var b=ri(4,20)*100,r=pick([15,18,20,24]);return {q:'Un saldo de $'+b.toLocaleString()+' en una tarjeta de crédito con '+r+'% de APR (tasa de porcentaje anual) queda sin pagar durante un año. Usando interés simple, ¿más o menos cuánto interés es?',a:b*r/100,u:'$',x:'$'+b.toLocaleString()+' × '+(r/100)+' = '+m(b*r/100)};},
function(){var inc=ri(8,20)*250;return {q:'Con la regla 50/30/20, ¿cuánto de un pago neto mensual de $'+inc.toLocaleString()+' va a los ahorros?',a:inc*.2,u:'$',x:'El 20% de $'+inc.toLocaleString()+' = '+m(inc*.2)};},
function(){var g=ri(20,60)*50;return {q:'¿Cuánto impuesto FICA (6.2% de Social Security + 1.45% de Medicare) sale de un cheque de pago de $'+g.toLocaleString()+'?',a:Math.round(g*7.65)/100,u:'$',x:'El 7.65% de $'+g.toLocaleString()+' = '+m(Math.round(g*7.65)/100)};}
]};})();

var GS_TF_L=window.GS_TF_L||{},GS_WHO_L=window.GS_WHO_L||{},GS_ORDER_L=window.GS_ORDER_L||{},GS_GUESS_L=window.GS_GUESS_L||{};
/* ---------- Game Show content banks: Brazilian Portuguese (pt-BR) ----------
   Same shape as GS_TF / GS_WHO / GS_ORDER / GS_GUESS in gs-data.js. Load after gs-data.js. */

GS_TF_L.pt={
k2:[
["Moedas e notas são dois tipos de dinheiro.",1,"Moedas e notas são dinheiro que usamos para comprar coisas."],
["Um dime vale mais que um nickel.",1,"Um dime vale 10 centavos. Um nickel vale 5 centavos."],
["Um nickel vale mais que um dime porque é maior.",0,"O tamanho não mostra o valor. Um dime (10¢) vale mais que um nickel (5¢)."],
["Um quarter vale 25 centavos.",1,"Quatro quarters fazem um dólar: 25 + 25 + 25 + 25 = 100 centavos."],
["Uma necessidade é algo que você precisa ter para viver, como comida.",1,"Necessidades são coisas como comida, água, roupas e uma casa."],
["Um videogame é uma necessidade.",0,"É um desejo: é legal ter, mas dá para viver sem ele."],
["Poupar quer dizer guardar dinheiro para usar depois.",1,"Quando você poupa, você guarda dinheiro para uma meta."],
["Quatro quarters fazem um dólar.",1,"25¢ × 4 = 100¢, e 100¢ é um dólar."],
["Um penny vale 10 centavos.",0,"Um penny vale 1 centavo. Um dime vale 10 centavos."],
["Quando você compra algo, você troca dinheiro por ele.",1,"Comprar é uma troca: o seu dinheiro pelo item."],
["Depois de gastar o seu dinheiro, você pode gastar esse mesmo dinheiro de novo.",0,"Dinheiro gasto acabou. Guardar um pouco ajuda você depois."],
["As pessoas ganham dinheiro trabalhando.",1,"O trabalho rende dinheiro, chamado de pagamento ou renda."],
["Dar dinheiro ou coisas para ajudar os outros se chama doar.",1,"Doar e compartilhar ajudam as pessoas da sua comunidade."],
["Dez dimes fazem um dólar.",1,"10¢ × 10 = 100¢, que é um dólar."],
["Um banco guarda o dinheiro das pessoas com segurança.",1,"Os bancos guardam o dinheiro com segurança e deixam você tirar quando precisar."],
["Você deve sempre comprar a primeira coisa que vê.",0,"Comparar as opções antes ajuda você a gastar bem."],
["Dois nickels valem o mesmo que um dime.",1,"5¢ + 5¢ = 10¢, o mesmo que um dime."],
["Uma meta é algo que você planeja e pelo qual se esforça.",1,"Uma meta de poupança pode ser um livro, um brinquedo ou um presente."],
["Dinheiro dá em árvore.",0,"As pessoas ganham dinheiro trabalhando. Ele não dá em árvore!"],
["Troco é o dinheiro que você recebe de volta quando paga mais do que o preço.",1,"Pague $1 por um lanche de 75¢ e você recebe 25¢ de troco."],
["Uma nota de cinco dólares vale mais que uma nota de um dólar.",1,"$5 é cinco vezes mais que $1."],
["Um desejo é algo que você precisa ter para continuar vivo.",0,"Isso é uma necessidade. Um desejo é algo legal de ter."]
],
"35":[
["Um orçamento é um plano de como gastar e poupar dinheiro.",1,"Um orçamento ajuda você a não gastar mais do que tem."],
["Juros são o dinheiro que o banco paga a você por deixar a sua poupança lá.",1,"Quem poupa ganha juros. Quem pega emprestado paga juros."],
["O imposto sobre vendas é somado ao preço de muitas coisas que você compra.",1,"O imposto sobre vendas ajuda a pagar coisas como ruas e escolas."],
["Custo de oportunidade é a melhor escolha seguinte da qual você abre mão.",1,"Toda escolha tem uma troca: aquilo que você não escolheu."],
["Um cartão de débito gasta dinheiro que você pegou emprestado.",0,"Um cartão de débito tira dinheiro da sua própria conta no banco. Um cartão de crédito pega emprestado."],
["Um cartão de crédito permite pegar dinheiro emprestado que você precisa devolver.",1,"Se você não pagar a fatura inteira, juros são acrescentados."],
["Renda é o dinheiro que você gasta.",0,"Renda é o dinheiro que você recebe. Despesas são o que você gasta."],
["Comparar preços por unidade pode ajudar você a achar a melhor oferta.",1,"Preço por unidade é o custo de um item ou de uma onça (cerca de 28 gramas)."],
["Um depósito é dinheiro que você tira do banco.",0,"Isso é um saque. Um depósito é dinheiro que você coloca."],
["Um empreendedor é alguém que começa um negócio.",1,"Os empreendedores correm riscos para transformar uma ideia em um negócio."],
["Lucro é o dinheiro que sobra depois que um negócio paga os seus custos.",1,"Lucro = dinheiro ganho − custos."],
["Comprar algo em promoção sempre faz você economizar.",0,"Você só economiza se já precisava daquilo."],
["Escassez quer dizer que as pessoas não podem ter tudo o que querem.",1,"Os recursos são limitados, então precisamos fazer escolhas."],
["Uma reserva de emergência é uma poupança para despesas surpresa.",1,"Um pneu furado ou óculos quebrados são bons motivos para ter uma."],
["As propagandas são feitas para fazer você querer comprar coisas.",1,"As propagandas usam música, cores e famosos para chamar a sua atenção."],
["Guardar um pouco toda semana pode somar bastante com o tempo.",1,"$5 por semana durante um ano são $260."],
["Bens são coisas que você pode tocar; serviços são trabalhos feitos para você.",1,"Sapatos são bens. Um corte de cabelo é um serviço."],
["Pegar dinheiro emprestado é de graça, desde que você devolva.",0,"Quem empresta geralmente cobra juros, então pegar emprestado custa mais."],
["Um cheque manda o banco pagar um dinheiro da sua conta.",1,"Os cheques têm um número de roteamento do banco e um número de conta."],
["Os preços podem subir quando muitas pessoas querem algo e não tem muito dele.",1,"Isso é oferta e demanda."],
["Um recibo é um cupom para a sua próxima compra.",0,"Um recibo é a prova do que você comprou e de quanto pagou."],
["Salário bruto é o valor que você leva para casa depois dos impostos.",0,"Esse é o salário líquido. O salário bruto é antes dos impostos e descontos."]
],
"68":[
["Juros compostos rendem juros sobre os seus juros.",1,"É por isso que o dinheiro poupado cedo pode crescer muito mais rápido."],
["Uma pontuação de crédito ajuda quem empresta a decidir o quanto é arriscado emprestar a você.",1,"Pagar em dia é o fator mais importante na maioria das pontuações."],
["Pagar só o mínimo do cartão de crédito evita todos os juros.",0,"São cobrados juros sobre qualquer saldo que você não pague por inteiro."],
["Diversificação é espalhar o dinheiro entre investimentos diferentes.",1,"Ela diminui o risco de um investimento ruim prejudicar muito você."],
["Salário líquido é o seu pagamento depois dos impostos e descontos.",1,"É o valor que realmente cai na sua conta."],
["As ações sempre sobem de valor.",0,"Os preços das ações sobem e descem. Investir envolve risco."],
["Inflação quer dizer que os preços sobem com o tempo, então cada dólar compra menos.",1,"A inflação diminui o poder de compra do dinheiro."],
["A Regra do 72 estima em quantos anos o dinheiro dobra.",1,"Divida 72 pela taxa de juros: a 6%, cerca de 12 anos."],
["Uma taxa de juros mais alta deixa um empréstimo mais barato.",0,"Uma taxa mais alta significa mais juros, então o empréstimo custa mais."],
["O seguro da FDIC (agência dos EUA que garante depósitos) protege depósitos de até $250,000 por depositante, por banco segurado, por categoria de titularidade.",1,"O seguro da FDIC cobre contas de depósito, não investimentos como ações."],
["Roubo de identidade é quando alguém usa as suas informações pessoais sem permissão.",1,"Proteja o seu número do Social Security (o número de identificação da previdência dos EUA), as suas senhas e os números das suas contas."],
["Conferir o extrato bancário ajuda você a encontrar erros e fraudes.",1,"Verifique toda transação que você não reconhecer."],
["O W-4 informa ao seu empregador quanto imposto de renda federal reter.",1,"Você preenche esse formulário quando começa em um emprego novo."],
["Investir cedo dá ao seu dinheiro mais tempo para crescer.",1,"O tempo deixa os juros compostos fazerem mais do trabalho."],
["Um título de dívida (bond) é uma parte da propriedade de uma empresa.",0,"Um título de dívida é um empréstimo a uma empresa ou governo. Uma ação é propriedade."],
["O seguro ajuda a proteger você de grandes perdas financeiras.",1,"Você paga um prêmio para que uma grande perda não caia inteira sobre você."],
["O aluguel geralmente é uma despesa fixa.",1,"As despesas fixas ficam mais ou menos iguais todo mês."],
["Comprar um carro com um empréstimo custa mais do que o preço depois que os juros são somados.",1,"O custo total é o preço mais todos os juros pagos."],
["Os bancos de verdade pedem a sua senha por e-mail ou mensagem.",0,"Isso é phishing (golpe por mensagem falsa). Os bancos não pedem senhas desse jeito."],
["Os impostos do Social Security e do Medicare se chamam FICA.",1,"Os empregados pagam 6.2% para o Social Security (previdência) e 1.45% para o Medicare (saúde)."],
["Um fundo de índice tem muitas empresas, o que espalha o risco.",1,"Ter muitas empresas é um jeito simples de diversificar."],
["O seu relatório de crédito lista o seu histórico de empréstimos e pagamentos.",1,"Você pode conferi-lo de graça e contestar erros."]
]};

GS_WHO_L.pt={
k2:[
{a:"Quarter",w:["Penny","Dime","Nickel"],c:["Eu sou uma moeda redonda de metal.","Eu tenho risquinhos na borda.","Quatro de mim fazem um dólar.","Eu valho 25 centavos."],f:"O quarter é a maior moeda do dia a dia nos EUA."},
{a:"Penny",w:["Nickel","Dime","Quarter"],c:["Eu sou uma moeda com Abraham Lincoln na frente.","Eu tenho a cor do cobre.","Cem de mim fazem um dólar.","Eu valho 1 centavo."],f:"O penny é a moeda dos EUA que vale menos. Os EUA pararam de fabricar pennies novos em 2025, mas os antigos ainda valem."},
{a:"Dime",w:["Penny","Nickel","Quarter"],c:["Eu sou a menor moeda dos EUA em tamanho.","Eu tenho risquinhos na borda.","Dez de mim fazem um dólar.","Eu valho 10 centavos."],f:"Pequeno, mas poderoso: um dime vale mais que um nickel, que é maior."},
{a:"Nickel",w:["Penny","Dime","Quarter"],c:["Eu sou uma moeda prateada com a borda lisa.","Thomas Jefferson está na minha frente.","Vinte de mim fazem um dólar.","Eu valho 5 centavos."],f:"Um nickel vale 5 pennies."},
{a:"Banco",w:["Loja","Biblioteca","Parque"],c:["Eu sou um prédio que existe em muitas cidades.","As pessoas confiam em mim para guardar algo valioso.","Comigo você pode fazer depósitos e saques.","Eu guardo o seu dinheiro com segurança."],f:"Os bancos guardam o dinheiro com segurança e ajudam ele a crescer."},
{a:"Necessidade",w:["Desejo","Presente","Brinquedo"],c:["Todo mundo tem a mim.","Sem mim, você não fica saudável e seguro.","Comida, água e uma casa são exemplos de mim.","Eu sou algo que você precisa ter para viver."],f:"Cuide das necessidades antes dos desejos."},
{a:"Desejo",w:["Necessidade","Nota","Trabalho"],c:["É divertido sonhar comigo.","Você pode viver sem mim.","Brinquedos e doces são exemplos de mim.","Eu sou legal de ter, mas não sou necessário."],f:"Tudo bem ter desejos. Planeje e poupe para eles."},
{a:"Poupar",w:["Gastar","Pegar emprestado","Trocar"],c:["Eu preciso de paciência.","Eu ajudo você a comprar coisas maiores depois.","Um cofrinho ajuda você a me fazer.","Eu quero dizer guardar dinheiro para usar depois."],f:"Guardar um pouquinho de cada vez vai somando."},
{a:"Trabalho",w:["Presente","Desejo","Troco"],c:["Muitos adultos vão até mim quase todo dia.","Eu ajudo as pessoas a ganhar dinheiro.","Professores, médicos e padeiros têm um.","Eu sou o que você faz para ganhar dinheiro."],f:"O trabalho deixa as pessoas ganharem dinheiro e ajudarem os outros."},
{a:"Preço",w:["Troco","Poupança","Meta"],c:["As lojas me colocam em etiquetas e placas.","Eu posso subir ou descer.","Eu sou um número com o sinal de dólar ou de centavo.","Eu digo quanto uma coisa custa."],f:"Sempre olhe o preço antes de comprar."},
{a:"Troco",w:["Preço","Presente","Poupança"],c:["Eu volto para você na loja.","Eu apareço quando você paga mais do que precisa.","Se um lanche custa 75¢ e você paga $1, eu sou 25¢.","Eu sou o dinheiro que você recebe de volta depois de pagar."],f:"Conte o seu troco para ver se está certo."},
{a:"Meta",w:["Desejo","Moeda","Nota"],c:["Eu estou no futuro.","Você faz um plano para chegar até mim.","Juntar $10 para um livro pode ser eu.","Eu sou algo pelo qual você se esforça."],f:"Escrever uma meta deixa mais fácil chegar até ela."},
{a:"Doar",w:["Gastar","Poupar","Pegar emprestado"],c:["Eu faço outras pessoas sorrirem.","Bancos de alimentos e abrigos ficam felizes em me receber.","Algumas crianças separam parte do dinheiro para mim.","Eu quero dizer dar dinheiro ou coisas para ajudar os outros."],f:"Gastar, poupar e doar: três boas tarefas para o dinheiro."}
],
"35":[
{a:"Orçamento",w:["Recibo","Empréstimo","Lucro"],c:["Eu sou um plano, não uma loja.","Eu listo a renda e as despesas.","Eu ajudo você a decidir para onde vai cada dólar.","Eu sou um plano para gastar e poupar dinheiro."],f:"Um orçamento ajuda você a não gastar mais do que ganha."},
{a:"Juros",w:["Imposto","Lucro","Mesada"],c:["Os bancos e quem pega emprestado se importam comigo.","Eu costumo ser escrito como porcentagem.","Quem poupa me ganha; quem pega emprestado me paga.","Eu sou o dinheiro extra pago pelo uso do dinheiro."],f:"5% de juros sobre $100 por um ano são $5."},
{a:"Imposto sobre vendas",w:["Desconto","Juros","Cupom"],c:["Os governos me cobram.","Eu ajudo a pagar ruas, escolas e parques.","Eu sou somado no caixa.","Eu sou uma porcentagem somada ao preço das coisas que você compra."],f:"As taxas do imposto sobre vendas mudam de lugar para lugar."},
{a:"Custo de oportunidade",w:["Imposto sobre vendas","Lucro","Desconto"],c:["Toda escolha tem a mim.","Você não vai me ver em um recibo.","Eu sou aquilo de que você abre mão.","Eu sou a melhor escolha seguinte que você não escolheu."],f:"Escolher o acampamento de futebol pode significar abrir mão da aula de arte."},
{a:"Lucro",w:["Preço","Empréstimo","Orçamento"],c:["Os negócios esperam me ter.","Uma barraca de limonada pode me ter.","Eu sou o que sobra depois dos custos.","Eu sou igual ao dinheiro ganho menos os custos."],f:"Venda $30 de limonada com $12 de custos: $18 de lucro."},
{a:"Empreendedor",w:["Consumidor","Empregado","Banqueiro"],c:["Eu corro riscos.","Eu tenho uma ideia de negócio.","Eu posso começar pequeno, como um serviço de passear com cachorros.","Eu sou uma pessoa que começa um negócio."],f:"Os empreendedores criam empregos e novos produtos."},
{a:"Cartão de débito",w:["Cartão de crédito","Cupom","Recibo"],c:["Eu sou um cartãozinho de plástico.","Eu estou ligado a uma conta corrente.","Quando você me usa, o dinheiro sai da sua conta na hora.","Eu deixo você pagar com o dinheiro que você já tem."],f:"Acompanhe o seu saldo quando usar um cartão de débito."},
{a:"Cartão de crédito",w:["Cartão de débito","Cupom","Recibo"],c:["Eu sou um cartãozinho de plástico.","Eu sou um empréstimo na sua carteira.","Se você não me pagar, os juros se acumulam.","Eu deixo você comprar agora e pagar depois."],f:"Pagar a fatura inteira todo mês evita juros."},
{a:"Reserva de emergência",w:["Mesada","Lista de desejos","Salário"],c:["Eu sou guardada para surpresas.","Um pneu furado pode me usar.","É inteligente me construir antes de precisar de mim.","Eu sou uma poupança para despesas inesperadas."],f:"Até uma pequena reserva de emergência ajuda."},
{a:"Recibo",w:["Cupom","Cheque","Orçamento"],c:["Eu costumo ser de papel, ou às vezes um e-mail.","Eu provo o que você comprou.","Você pode precisar de mim para trocar um item.","Eu mostro quanto você pagou e quando."],f:"Confira o seu recibo para achar erros antes de sair."},
{a:"Cupom",w:["Recibo","Imposto","Cheque"],c:["Eu posso ser de papel ou digital.","Eu posso vencer.","Eu baixo o preço de alguma coisa.","Eu sou um vale-desconto."],f:"Um cupom só economiza dinheiro em coisas que você já planejava comprar."},
{a:"Depósito",w:["Saque","Empréstimo","Despesa"],c:["Os bancos ficam felizes em me receber.","Eu faço o seu saldo subir.","Eu sou o contrário de um saque.","Eu sou o dinheiro que você coloca em uma conta."],f:"Os depósitos podem ser em dinheiro, cheques ou depósitos diretos do salário."},
{a:"Escassez",w:["Excedente","Lucro","Juros"],c:["Os economistas falam muito de mim.","Eu sou o motivo de precisarmos fazer escolhas.","Nunca tem o bastante de tudo para todo mundo.","Eu quero dizer recursos limitados e desejos ilimitados."],f:"A escassez é o motivo de toda escolha ter uma troca."}
],
"68":[
{a:"Juros compostos",w:["Juros simples","Inflação","Dividendo"],c:["O tempo é o meu melhor amigo.","Muitas vezes me comparam a uma bola de neve.","A Regra do 72 estima a rapidez com que eu dobro o dinheiro.","Eu sou os juros ganhos sobre a sua poupança e sobre os juros anteriores."],f:"$1,000 a 6% com juros compostos anuais viram cerca de $1,791 depois de 10 anos."},
{a:"Pontuação de crédito",w:["Taxa de juros","Número da conta","Limite de crédito"],c:["Eu sou um número de três dígitos.","Quem empresta e quem aluga imóveis me consulta.","Pagar as contas em dia me faz subir.","Eu mostro a chance de você devolver o dinheiro emprestado."],f:"O histórico de pagamentos é a maior parte da maioria das pontuações de crédito."},
{a:"Inflação",w:["Deflação","Depreciação","Dividendo"],c:["O Índice de Preços ao Consumidor (CPI) me mede.","O Federal Reserve (banco central dos EUA) busca me manter perto de 2% ao ano.","Eu faço os mesmos $20 comprarem menos coisas no mercado com o tempo.","Eu sou o aumento geral dos preços ao longo do tempo."],f:"Uma poupança que rende menos que a inflação perde poder de compra."},
{a:"Ação",w:["Título de dívida","Certificado de depósito","Conta poupança"],c:["Eu sou negociada em bolsas de valores.","O meu preço pode mudar a cada segundo enquanto o mercado está aberto.","Ter a mim faz de você um dos donos.","Eu sou uma parte da propriedade de uma empresa."],f:"As ações têm risco maior e potencial de crescimento maior no longo prazo."},
{a:"Título de dívida",w:["Ação","Dividendo","Cartão de crédito"],c:["Governos e empresas me emitem.","Eu costumo pagar um valor fixo de juros.","Eu costumo ter menos risco do que as ações.","Eu sou um empréstimo que você faz a uma empresa ou governo."],f:"Os títulos do Tesouro dos EUA (Treasury bonds) são garantidos pelo governo federal."},
{a:"Diversificação",w:["Especulação","Inflação","Capitalização"],c:["Eu sou uma estratégia, não um produto.","Os fundos de índice me deixam mais fácil.","Eu sou o contrário de colocar todos os ovos na mesma cesta.","Eu espalho o dinheiro entre investimentos para diminuir o risco."],f:"Diversificar não elimina o risco, mas o diminui."},
{a:"Salário líquido",w:["Salário bruto","Salário anual","Bônus"],c:["Eu sou menor que o salário bruto.","Os impostos e descontos saem antes de você me receber.","Eu sou o que cai na sua conta no banco.","Eu sou o pagamento que você leva para casa."],f:"Faça o orçamento com o salário líquido, não com o bruto."},
{a:"APR",w:["ATM","FDIC","IRA"],c:["Eu sou três letras.","As ofertas de cartão de crédito precisam me mostrar.","Eu mostro o custo anual de pegar emprestado como porcentagem.","Eu sou a sigla de Annual Percentage Rate (taxa percentual anual)."],f:"Um APR menor significa que pegar emprestado custa menos."},
{a:"Seguro",w:["Investimento","Empréstimo","Orçamento"],c:["Eu tenho prêmios e franquias.","Você torce para nunca precisar de mim.","Eu posso cobrir um carro, uma casa ou a sua saúde.","Eu protejo você de grandes perdas em troca de um pagamento regular."],f:"A franquia é o que você paga antes de o seguro pagar."},
{a:"FDIC",w:["IRS","SEC","APR"],c:["Eu fui criada em 1933.","Eu sou uma agência independente do governo dos EUA.","Procure a minha placa nos bancos.","Eu seguro depósitos bancários de até $250,000 por depositante, por banco, por categoria de titularidade."],f:"Nenhum depositante perdeu um centavo sequer de fundos segurados pela FDIC desde 1934."},
{a:"Roubo de identidade",w:["Inflação","Falência","Saldo negativo"],c:["Eu muitas vezes começo com uma mensagem de phishing.","Picotar papéis ajuda a me impedir.","Congelar o seu crédito pode me bloquear.","Eu sou quando alguém usa as suas informações pessoais para cometer fraude."],f:"Denuncie em IdentityTheft.gov (o site oficial dos EUA)."},
{a:"Saldo negativo",w:["Depósito","Dividendo","Reembolso"],c:["Os bancos podem cobrar uma tarifa por mim.","Eu aconteço em contas correntes.","Acompanhar o seu saldo ajuda você a me evitar.","Eu aconteço quando você gasta mais do que tem na conta."],f:"Ativar alertas de saldo ajuda a evitar o saldo negativo."},
{a:"Dividendo",w:["Juros","Prêmio do seguro","Franquia"],c:["Nem toda empresa me paga.","Eu costumo ser pago a cada três meses.","Os acionistas me recebem.","Eu sou uma parte do lucro de uma empresa paga aos investidores."],f:"Alguns investidores reinvestem os dividendos para comprar mais ações."},
{a:"Financiamento imobiliário",w:["Contrato de aluguel","Seguro","Título de dívida"],c:["Eu muitas vezes duro 15 ou 30 anos.","A casa é a garantia para mim.","Geralmente vem primeiro uma entrada.","Eu sou um empréstimo usado para comprar uma casa."],f:"Uma entrada maior significa um financiamento menor."},
{a:"401(k)",w:["W-2","Financiamento imobiliário","Título de poupança"],c:["O meu nome vem de uma seção do código tributário dos EUA.","Às vezes os empregadores igualam o que você coloca em mim.","Eu sou feito para o longo prazo.","Eu sou um plano de aposentadoria oferecido pelo trabalho."],f:"A contrapartida do empregador é como um aumento que você só ganha se poupar."}
]};

/* ordering sets: [card text, sort key, label shown on reveal] */
GS_ORDER_L.pt={
k2:[
{t:"Moedas do menor para o maior valor",items:[["Penny",1,"1¢"],["Nickel",5,"5¢"],["Dime",10,"10¢"],["Quarter",25,"25¢"]]},
{t:"Notas do menor para o maior valor",items:[["Nota de um dólar",1,"$1"],["Nota de cinco dólares",5,"$5"],["Nota de dez dólares",10,"$10"],["Nota de vinte dólares",20,"$20"]]},
{t:"Comprar algo na loja, primeiro passo primeiro",items:[["Escolha o que você quer",1,"Passo 1"],["Olhe o preço",2,"Passo 2"],["Pague no caixa",3,"Passo 3"],["Pegue o troco e o recibo",4,"Passo 4"]]},
{t:"Juntar dinheiro para um brinquedo, primeiro passo primeiro",items:[["Escolha uma meta",1,"Passo 1"],["Descubra o preço",2,"Passo 2"],["Guarde um pouco toda semana",3,"Passo 3"],["Compre quando tiver o bastante",4,"Passo 4"]]},
{t:"Valores do menor para o maior",items:[["3 pennies",3,"3¢"],["1 nickel",5,"5¢"],["2 nickels",10,"10¢"],["1 quarter",25,"25¢"]]},
{t:"Valores do menor para o maior",items:[["2 dimes",20,"20¢"],["1 quarter",25,"25¢"],["3 dimes",30,"30¢"],["2 quarters",50,"50¢"]]},
{t:"Cuidar de uma barraca de limonada, primeiro passo primeiro",items:[["Planeje o que você vai vender",1,"Passo 1"],["Compre limões e copos",2,"Passo 2"],["Venda limonada para os clientes",3,"Passo 3"],["Conte o dinheiro que você ganhou",4,"Passo 4"]]}
],
"35":[
{t:"Fazer um orçamento, primeiro passo primeiro",items:[["Anote a sua renda",1,"Passo 1"],["Liste as suas despesas",2,"Passo 2"],["Tire as despesas da renda",3,"Passo 3"],["Ajuste os gastos para poupar mais",4,"Passo 4"]]},
{t:"Valores do menor para o maior",items:[["10% de $50",5,"$5"],["25% de $40",10,"$10"],["Metade de $30",15,"$15"],["4 × $5",20,"$20"]]},
{t:"Valores do menor para o maior",items:[["$0.75",75,"$0.75"],["4 quarters",100,"$1.00"],["$1.10",110,"$1.10"],["12 dimes",120,"$1.20"]]},
{t:"História do dinheiro nos EUA, do mais antigo para o mais recente",items:[["A Casa da Moeda dos EUA (U.S. Mint) é criada",1792,"1792"],["O governo federal emite o seu primeiro papel-moeda nacional (as Demand Notes)",1861,"1861"],["O Federal Reserve (banco central dos EUA) é criado",1913,"1913"],["O primeiro caixa eletrônico (ATM) é inaugurado nos EUA",1969,"1969"]]},
{t:"Começar um negócio, primeiro passo primeiro",items:[["Tenha uma ideia de negócio",1,"Passo 1"],["Calcule os seus custos",2,"Passo 2"],["Venda o seu produto",3,"Passo 3"],["Tire os custos das vendas para achar o lucro",4,"Passo 4"]]},
{t:"Do menor para o maior preço por caneta",items:[["10 canetas por $5",50,"50¢ cada"],["4 canetas por $3",75,"75¢ cada"],["2 canetas por $2",100,"$1.00 cada"],["1 caneta por $1.25",125,"$1.25 cada"]]},
{t:"Juntar dinheiro para uma bicicleta, primeiro passo primeiro",items:[["Descubra o preço da bicicleta",1,"Passo 1"],["Decida quanto guardar por semana",2,"Passo 2"],["Deposite a sua poupança toda semana",3,"Passo 3"],["Compre a bicicleta quando chegar à sua meta",4,"Passo 4"]]}
],
"68":[
{t:"Marcos do dinheiro nos EUA, do mais antigo para o mais recente",items:[["A Casa da Moeda dos EUA (U.S. Mint) é criada",1792,"1792"],["O Sistema da Reserva Federal (Federal Reserve) é criado",1913,"1913"],["A FDIC (agência que garante depósitos) é criada",1933,"1933"],["O Social Security (previdência social) vira lei",1935,"1935"]]},
{t:"Ferramentas modernas de dinheiro, da mais antiga para a mais recente",items:[["O primeiro cartão de pagamento amplamente usado (Diners Club)",1950,"1950"],["O primeiro caixa eletrônico (ATM) é inaugurado nos EUA",1969,"1969"],["O plano 401(k) é criado por lei",1978,"1978"],["A Roth IRA é criada",1997,"1997"]]},
{t:"O dinheiro ao longo da história, do mais antigo para o mais recente",items:[["A Lídia cunha algumas das primeiras moedas",-600,"c. 600 a.C."],["A China começa a usar papel-moeda",1000,"c. século XI"],["A Casa da Moeda dos EUA (U.S. Mint) é criada",1792,"1792"],["O primeiro caixa eletrônico (ATM) é inaugurado nos EUA",1969,"1969"]]},
{t:"Do contracheque ao orçamento, primeiro passo primeiro",items:[["Ganhe o salário bruto",1,"Passo 1"],["Os impostos e descontos são retidos",2,"Passo 2"],["O salário líquido é depositado",3,"Passo 3"],["Gaste e poupe usando o seu orçamento",4,"Passo 4"]]},
{t:"Do menor para o maior rendimento de juros em um ano",items:[["$1,000 a 2%",20,"$20"],["$500 a 6%",30,"$30"],["$2,000 a 2.5%",50,"$50"],["$800 a 10%",80,"$80"]]},
{t:"Conseguir o primeiro emprego, primeiro passo primeiro",items:[["Encontre uma vaga de emprego",1,"Passo 1"],["Envie um currículo e uma candidatura",2,"Passo 2"],["Faça a entrevista com o empregador",3,"Passo 3"],["Preencha um W-4 no seu primeiro dia",4,"Passo 4"]]},
{t:"Em geral, do menor para o maior risco",items:[["Conta poupança segurada",1,"Menor"],["Título do Tesouro dos EUA",2,"Baixo"],["Fundo de índice amplo de ações",3,"Mais alto"],["Ação de uma única empresa",4,"Maior"]]}
]};

/* word-problem generators for Closest Guess: return {q,a,u,x} (u: '$','¢','weeks','years') */
GS_GUESS_L.pt=(function(){
function ri(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function pick(a){return a[Math.floor(Math.random()*a.length)];}
function m(n){return '$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2});}
return {
k2:[
function(){var q=ri(0,3),d=ri(1,4),p=ri(0,5),a=q*25+d*10+p;return {q:'Você tem '+q+' quarter'+(q===1?'':'s')+', '+d+' dime'+(d===1?'':'s')+' e '+p+' penn'+(p===1?'y':'ies')+'. Quantos centavos são?',a:a,u:'¢',x:q+' × 25¢ + '+d+' × 10¢ + '+p+' × 1¢ = '+a+'¢'};},
function(){var h=ri(8,20),c=ri(2,h-1);return {q:'Você tem $'+h+'. Você compra um livro por $'+c+'. Quantos dólares sobram?',a:h-c,u:'$',x:'$'+h+' − $'+c+' = $'+(h-c)};},
function(){var s=pick([1,2,3]),w=ri(3,8),p=s*w;return {q:'Um brinquedo custa $'+p+'. Você guarda $'+s+' por semana. Em quantas semanas você consegue comprá-lo?',a:w,u:'weeks',x:'$'+p+' ÷ $'+s+' por semana = '+w+' semanas'};},
function(){var c=pick([5,10]),n=ri(3,9);return {q:'Cada adesivo custa '+c+'¢. Quantos centavos custam '+n+' adesivos?',a:c*n,u:'¢',x:n+' × '+c+'¢ = '+(c*n)+'¢'};},
function(){var a=pick([15,20,25,30,35,40]),b=pick([10,15,20,25,30]);return {q:'Um lápis custa '+a+'¢ e uma borracha custa '+b+'¢. Quantos centavos custam os dois?',a:a+b,u:'¢',x:a+'¢ + '+b+'¢ = '+(a+b)+'¢'};},
function(){var p=pick([35,40,55,60,65,80,85,90]);return {q:'Um lanche custa '+p+'¢. Você paga com $1 (100¢). Quantos centavos de troco você recebe?',a:100-p,u:'¢',x:'100¢ − '+p+'¢ = '+(100-p)+'¢'};}
],
"35":[
function(){var s=ri(3,12),w=ri(4,15);return {q:'Você guarda $'+s+' toda semana durante '+w+' semanas. Quanto você guarda no total?',a:s*w,u:'$',x:'$'+s+' × '+w+' = '+m(s*w)};},
function(){var p=pick([20,30,40,50,60,80,100,120]),r=pick([10,20,25,50]),a=p*(100-r)/100;return {q:'Uma jaqueta de $'+p+' está com '+r+'% de desconto. Qual é o preço na promoção?',a:a,u:'$',x:r+'% de $'+p+' é '+m(p*r/100)+', então $'+p+' − '+m(p*r/100)+' = '+m(a)};},
function(){var p=pick([25,50,75,100]),r=8,a=p*1.08;return {q:'Um jogo de $'+p+' tem 8% de imposto sobre vendas somado ao preço. Qual é o custo total?',a:Math.round(a*100)/100,u:'$',x:'8% de $'+p+' é '+m(p*.08)+', então o total é '+m(a)};},
function(){var inc=ri(16,40)*5,e1=ri(4,12)*5,e2=ri(2,6)*5,e3=ri(1,4)*5;if(e1+e2+e3>=inc)inc=e1+e2+e3+ri(2,8)*5;return {q:'Você ganha $'+inc+' este mês. Você gasta $'+e1+' com comida, $'+e2+' com diversão e $'+e3+' com um presente. Quanto sobra para poupar?',a:inc-e1-e2-e3,u:'$',x:'$'+inc+' − $'+e1+' − $'+e2+' − $'+e3+' = '+m(inc-e1-e2-e3)};},
function(){var n=pick([4,5,6,8,10,12]),e=pick([25,30,40,50,60,75]),p=n*e/100;return {q:'Um pacote com '+n+' caixinhas de suco custa '+m(p)+'. Quantos centavos custa cada caixinha?',a:e,u:'¢',x:m(p)+' ÷ '+n+' = '+e+'¢ cada'};},
function(){var p=pick([100,200,300,400,500]),r=pick([2,3,4,5]);return {q:'Você deixa $'+p+' em uma conta poupança que paga '+r+'% de juros ao ano. Quanto de juros você ganha em um ano?',a:p*r/100,u:'$',x:r+'% de $'+p+' = '+m(p*r/100)};},
function(){var w=pick([10,12,15]),h=ri(3,8);return {q:'Você ganha $'+w+' por hora passeando com cachorros e trabalha '+h+' horas. Quanto você ganha?',a:w*h,u:'$',x:'$'+w+' × '+h+' horas = '+m(w*h)};}
],
"68":[
function(){var P=ri(1,10)*500,r=pick([2,3,4,5,6]),t=ri(2,5),I=P*r*t/100;return {q:'Você investe $'+P.toLocaleString()+' a '+r+'% de juros simples por '+t+' anos. Quanto de juros você ganha?',a:I,u:'$',x:'J = P × r × t = $'+P.toLocaleString()+' × '+(r/100)+' × '+t+' = '+m(I)};},
function(){var P=pick([1000,2000,5000]),r=pick([4,5,6,8,10]),t=pick([2,3]),A=Math.round(P*Math.pow(1+r/100,t));return {q:'$'+P.toLocaleString()+' rendem '+r+'% de juros compostos por ano durante '+t+' anos. Qual é o saldo final aproximado, arredondado para o dólar mais próximo?',a:A,u:'$',x:'$'+P.toLocaleString()+' × '+(1+r/100)+'^'+t+' ≈ '+m(A)};},
function(){var r=pick([3,4,6,8,9,12]);return {q:'Usando a Regra do 72, em cerca de quantos anos o dinheiro dobra a '+r+'% ao ano?',a:72/r,u:'years',x:'72 ÷ '+r+' = '+(72/r)+' anos'};},
function(){var g=ri(12,30)*50,w=pick([15,18,20,22,25]),n=g*(100-w)/100;return {q:'O seu salário bruto é $'+g.toLocaleString()+'. '+w+'% são retidos para impostos e descontos. Qual é o seu salário líquido?',a:n,u:'$',x:'$'+g.toLocaleString()+' × '+((100-w)/100)+' = '+m(n)};},
function(){var b=ri(4,20)*100,r=pick([15,18,20,24]);return {q:'Um saldo de $'+b.toLocaleString()+' no cartão de crédito, a '+r+'% de APR (taxa anual), fica sem pagar por um ano. Usando juros simples, quanto de juros isso dá, aproximadamente?',a:b*r/100,u:'$',x:'$'+b.toLocaleString()+' × '+(r/100)+' = '+m(b*r/100)};},
function(){var inc=ri(8,20)*250;return {q:'Pela regra 50/30/20, quanto de um salário líquido mensal de $'+inc.toLocaleString()+' vai para a poupança?',a:inc*.2,u:'$',x:'20% de $'+inc.toLocaleString()+' = '+m(inc*.2)};},
function(){var g=ri(20,60)*50;return {q:'Quanto de imposto FICA (6.2% de Social Security + 1.45% de Medicare) sai de um contracheque de $'+g.toLocaleString()+'?',a:Math.round(g*7.65)/100,u:'$',x:'7.65% de $'+g.toLocaleString()+' = '+m(Math.round(g*7.65)/100)};}
]};})();
