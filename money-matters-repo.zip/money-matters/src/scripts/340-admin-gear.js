(function(){'use strict';
var SALT='mm7f3a91c2',N=5000,DEF='53e7cd897c97c537262d0d0ae8ea1aa9612b6bd04fb9eda075906212c1d564d0';
function $(i){return document.getElementById(i);}
function toast(m){try{infoToast(m,3500);}catch(e){alert(m);}}
function sha256(ascii){function rr(v,a){return(v>>>a)|(v<<(32-a))}var mp=Math.pow,mw=mp(2,32),i,j,result='',words=[],al=ascii.length*8,hash=sha256.h=sha256.h||[],k=sha256.k=sha256.k||[],pc=k.length,ic={};
for(var c=2;pc<64;c++){if(!ic[c]){for(i=0;i<313;i+=c)ic[i]=c;hash[pc]=(mp(c,.5)*mw)|0;k[pc++]=(mp(c,1/3)*mw)|0}}
ascii+='\x80';while(ascii.length%64-56)ascii+='\x00';
for(i=0;i<ascii.length;i++){j=ascii.charCodeAt(i);words[i>>2]|=j<<((3-i)%4)*8}
words[words.length]=((al/mw)|0);words[words.length]=al;
for(j=0;j<words.length;){var w=words.slice(j,j+=16),old=hash;hash=hash.slice(0,8);
for(i=0;i<64;i++){var w15=w[i-15],w2=w[i-2],a=hash[0],e=hash[4];
var t1=hash[7]+(rr(e,6)^rr(e,11)^rr(e,25))+((e&hash[5])^((~e)&hash[6]))+k[i]+(w[i]=(i<16)?w[i]:(w[i-16]+(rr(w15,7)^rr(w15,18)^(w15>>>3))+w[i-7]+(rr(w2,17)^rr(w2,19)^(w2>>>10))|0));
var t2=(rr(a,2)^rr(a,13)^rr(a,22))+((a&hash[1])^(a&hash[2])^(hash[1]&hash[2]));
hash=[(t1+t2)|0].concat(hash);hash[4]=(hash[4]+t1)|0}
for(i=0;i<8;i++)hash[i]=(hash[i]+old[i])|0}
for(i=0;i<8;i++)for(j=3;j+1;j--){var b=(hash[i]>>(j*8))&255;result+=((b<16)?'0':'')+b.toString(16)}
return result;}
function u8(x){return unescape(encodeURIComponent(String(x)));}
function derive(salt,user,pw){var h=sha256(salt+':'+u8(user.toLowerCase())+':'+u8(pw));for(var i=0;i<N;i++)h=sha256(h+salt);return h;}
function rec(){try{var r=JSON.parse(localStorage.getItem('mmAdmin_v1')||'null');if(r&&r.s&&r.h)return r;}catch(e){}return {s:SALT,h:DEF};}
function isAdmin(){try{var a=JSON.parse(sessionStorage.getItem('mmAuth_v1')||'null');return !!(a&&a.role==='teacher'&&a.id==='admin');}catch(e){return false;}}
window.__mmIsAdmin=isAdmin;
function fails(){try{return JSON.parse(sessionStorage.getItem('mmAdminFail')||'{"n":0,"t":0}');}catch(e){return {n:0,t:0};}}
function adminLogin(u,p){var f=fails(),now=Date.now();
if(f.n>=5&&now-f.t<30000){var m=Math.ceil((30000-(now-f.t))/1000);var el=$('mm55-error');if(el)el.textContent='Too many attempts. Wait '+m+' seconds.';return;}
var r=rec(),ok=derive(r.s,'admin',p)===r.h&&u.toLowerCase()==='admin';
if(!ok){try{sessionStorage.setItem('mmAdminFail',JSON.stringify({n:(now-f.t<30000||f.n<5?f.n:0)+1,t:now}));}catch(e){}var e2=$('mm55-error');if(e2)e2.textContent='Username or password is incorrect.';return;}
try{sessionStorage.removeItem('mmAdminFail');sessionStorage.setItem('mmRole','teacher');sessionStorage.setItem('mmLoginRole','teacher');sessionStorage.setItem('mmAuth_v1',JSON.stringify({role:'teacher',name:'Admin',id:'admin',at:Date.now()}));}catch(e){}
var g=$('mm-login-gate');if(g)g.classList.add('mm-hidden');
try{if(window.mmV55Update)window.mmV55Update();}catch(e){}
try{applyRole();}catch(e){}try{openPanel('teacher');renderTeacher();}catch(e){}
toast('Signed in as Admin.');try{if(!localStorage.getItem('mmAdmin_v1'))setTimeout(changePw,700);}catch(e){}}
function wrapLogin(){var ol=window.mmV55Login;if(!ol||ol.__mm70)return;var w=function(){var u=(($('mm55-user')||{}).value||'').trim(),p=($('mm55-pass')||{}).value||'';if(u.toLowerCase()==='admin'){adminLogin(u,p);return;}window.__mmLogin=1;try{return ol.apply(this,arguments);}finally{window.__mmLogin=0;}};w.__mm70=1;window.mmV55Login=w;}
wrapLogin();
function changePw(){var go=function(p){p=(p||'').trim();if(p.length<8){toast('Use at least 8 characters.');return;}var s='mm'+Math.random().toString(16).slice(2,10)+Date.now().toString(16);try{localStorage.setItem('mmAdmin_v1',JSON.stringify({s:s,h:derive(s,'admin',p)}));toast('Admin password changed on this device.');}catch(e){toast('Could not save the new password.');}};
try{mmInput('Set a new admin password (8+ characters). The default password should not be kept.','',{icon:'\uD83D\uDD11',okLabel:'Save'}).then(go);}catch(e){go(prompt('New admin password (8+ characters)'));}}
var css=document.createElement('style');css.textContent='#mm-modal-backdrop{z-index:6000!important}#info-toast{z-index:6001!important}#consent-banner{z-index:5500!important}#mm-set-btn{opacity:.6;touch-action:none}#mm-set-btn:hover,#mm-set-btn:focus{opacity:1}#mm-set-btn.mm-slim{width:16px;height:48px;border-radius:0 10px 10px 0;font-size:10px;left:0!important;padding:0}';
document.head.appendChild(css);
var GK='mmGear_v1',G={};try{G=JSON.parse(localStorage.getItem(GK)||'{}')||{};}catch(e){}if(G.slim===undefined)G.slim=true;
function sv(){try{localStorage.setItem(GK,JSON.stringify(G));}catch(e){}}
function gear(){var b=$('mm-set-btn'),p=$('mm-set-pop');if(!b||!p)return false;if(b.__g)return true;b.__g=1;
function place(){if(!G.slim&&G.x!=null){b.style.left=Math.max(0,Math.min(innerWidth-44,G.x))+'px';b.style.top=Math.max(0,Math.min(innerHeight-44,G.y))+'px';b.style.bottom='auto';}if(G.slim){b.style.top=(G.y!=null?Math.max(0,Math.min(innerHeight-48,G.y)):Math.round(innerHeight/2))+'px';b.style.bottom='auto';}b.classList.toggle('mm-slim',!!G.slim);}
place();
var d=null;b.addEventListener('pointerdown',function(e){d={x:e.clientX,y:e.clientY,l:b.offsetLeft,t:b.offsetTop,m:0};});
window.addEventListener('pointermove',function(e){if(!d)return;var dx=e.clientX-d.x,dy=e.clientY-d.y;if(Math.abs(dx)+Math.abs(dy)>8)d.m=1;if(d.m){var l=G.slim?0:Math.max(0,Math.min(innerWidth-44,d.l+dx)),t=Math.max(0,Math.min(innerHeight-44,d.t+dy));b.style.left=l+'px';b.style.top=t+'px';b.style.bottom='auto';}});
window.addEventListener('pointerup',function(){if(d&&d.m){G.x=b.offsetLeft;G.y=b.offsetTop;sv();b.__moved=1;setTimeout(function(){b.__moved=0;},80);}d=null;});
b.addEventListener('click',function(e){if(b.__moved){e.stopImmediatePropagation();e.preventDefault();return;}setTimeout(function(){extra();pos();},0);},true);
function pos(){if(p.style.display!=='block')return;var w=p.offsetWidth||300,l=Math.max(8,Math.min(innerWidth-w-8,b.offsetLeft));p.style.left=l+'px';if(b.offsetTop>innerHeight/2){p.style.top='auto';p.style.bottom=(innerHeight-b.offsetTop+8)+'px';}else{p.style.bottom='auto';p.style.top=(b.offsetTop+b.offsetHeight+8)+'px';}}
function extra(){if($('mm-x70'))$('mm-x70').remove();var x=document.createElement('div');x.id='mm-x70';x.innerHTML='<h3 style="margin-top:10px">Settings button</h3><div style="font-size:12px;margin-bottom:4px">Drag the gear anywhere to move it out of the way.</div><button type="button" data-x="slim">'+(G.slim?'Make button normal size':'Shrink to edge tab')+'</button>'+(isAdmin()?'<h3 style="margin-top:10px">Admin</h3><button type="button" data-x="pw">Change admin password</button>':'');p.appendChild(x);}
p.addEventListener('click',function(e){var k=e.target.dataset&&e.target.dataset.x;if(k==='slim'){G.slim=!G.slim;sv();place();extra();}if(k==='pw')changePw();});
return true;}
var tries=0;(function t(){if(!gear()&&tries++<40)setTimeout(t,150);})();
if(!window.__mm70obs){window.__mm70obs=1;new MutationObserver(function(){wrapLogin();}).observe(document.body||document.documentElement,{childList:true,subtree:false});}
})();
