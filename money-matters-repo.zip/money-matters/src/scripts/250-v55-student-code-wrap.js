(function(){
  'use strict';
  function ensureCodeFor(id){
    try{
      var s=loadStore(); if(!s.list||!s.list[id])return;
      if(s.list[id].verifyCode)return;
      var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789', used={};
      Object.keys(s.list).forEach(function(k){if(s.list[k]&&s.list[k].verifyCode)used[String(s.list[k].verifyCode).toUpperCase()]=1;});
      var c=''; do{c='';for(var i=0;i<6;i++)c+=chars[Math.floor(Math.random()*chars.length)];}while(used[c]);
      s.list[id].verifyCode=c;saveStore(s);
    }catch(e){}
  }
  function patch(){
    if(typeof createStudent==='function'&&!createStudent.__v55){
      var old=createStudent;
      function wrapped(name,grade,teacher){old(name,grade,teacher);try{var id=getTabActive();ensureCodeFor(id);}catch(e){}}
      wrapped.__v55=true;createStudent=wrapped;
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',patch);else patch();
})();
