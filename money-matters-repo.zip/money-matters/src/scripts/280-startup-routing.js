(function(){
  'use strict';
  /* V59: clean startup routing and student-first assessment entry. */
  function home(){
    try{
      if(typeof closePanel==='function')closePanel(true);
      window.scrollTo(0,0);
      var main=document.getElementById('main-content');
      if(main)main.scrollTop=0;
      if(typeof refreshBoard==='function')refreshBoard();
      if(typeof buildGradeNav==='function')buildGradeNav();
      if(typeof updateIndicator==='function')updateIndicator();
    }catch(e){console.warn('V59 home routing',e);}
  }
  function assessment(){
    try{
      if(typeof loadRole==='function'&&loadRole()==='teacher')return;
      if(typeof activeStudent==='function'&&!activeStudent())return;
      if(typeof closePanel==='function')closePanel(true);
      if(typeof openPanel==='function')openPanel('assessment');
      setTimeout(function(){
        try{
          var p=document.getElementById('panel-assessment');
          var body=p&&p.querySelector('.panel-body');
          if(body)body.scrollTop=0;
          if(p)p.scrollTop=0;
        }catch(e){}
      },30);
    }catch(e){console.warn('V59 assessment routing',e);}
  }
  window.mmV59Home=home;
  window.mmV59StudentAssessment=assessment;

  function wrapCreateStudent(){
    if(typeof window.mmV56CreateStudent==='function'&&!window.mmV56CreateStudent.__v59){
      var old56=window.mmV56CreateStudent;
      var fn56=function(){old56.apply(this,arguments);setTimeout(function(){if(typeof loadRole==='function'&&loadRole()!=='teacher')assessment();},180);};
      fn56.__v59=true;window.mmV56CreateStudent=fn56;
    }
    if(typeof createStudent==='function'&&!createStudent.__v59){
      var old=createStudent;
      var fn=function(){old.apply(this,arguments);setTimeout(function(){if(typeof loadRole==='function'&&loadRole()!=='teacher'&&typeof activeStudent==='function'&&activeStudent())assessment();},180);};
      fn.__v59=true;createStudent=fn;
    }
  }
  function wrapSwitchStudent(){
    if(typeof switchStudent==='function'&&!switchStudent.__v59){
      var old=switchStudent;
      var fn=function(){old.apply(this,arguments);setTimeout(function(){if(typeof loadRole==='function'&&loadRole()!=='teacher'&&typeof activeStudent==='function'&&activeStudent())assessment();},120);};
      fn.__v59=true;switchStudent=fn;
    }
  }
  function boot(){
    wrapCreateStudent();
    wrapSwitchStudent();
    /* The owner/private build should open on the classroom home, not the Teacher panel. */
    setTimeout(home,1450);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  setTimeout(function(){wrapCreateStudent();wrapSwitchStudent();},900);
})();
