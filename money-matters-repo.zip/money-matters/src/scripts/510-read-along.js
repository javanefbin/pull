(function(){
'use strict';
var run=0,active=false,miss=0,timer=null;
var HL=(window.CSS&&CSS.highlights&&typeof Highlight!=='undefined')?CSS.highlights:null;
var NOREAD={BUTTON:1,SELECT:1,OPTION:1,SCRIPT:1,STYLE:1,INPUT:1,TEXTAREA:1,SVG:1};
var ANSWER=/answer|rubric|teacher-note|key\b/i;
function $(i){return document.getElementById(i);}
function reduce(){return document.documentElement.classList.contains('a11y-motion')||(window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches);}
function clear(){var n=document.querySelectorAll('.mm-reading');for(var i=0;i<n.length;i++)n[i].classList.remove('mm-reading');if(HL){try{HL.delete('mm-sentence');}catch(e){}}}
function finish(){active=false;miss=0;if(timer){clearInterval(timer);timer=null;}clear();document.documentElement.classList.remove('mm-reading');}
function skipNode(n,root){for(var a=n.parentElement;a&&a!==root.parentElement;a=a.parentElement){if(NOREAD[a.tagName]||a.hasAttribute('hidden')||a.getAttribute('aria-hidden')==='true')return true;
 if(a!==root&&typeof a.className==='string'&&ANSWER.test(a.className))return true;
 var cs=getComputedStyle(a);if(cs.display==='none'||cs.visibility==='hidden')return true;}return false;}
function blockOf(n){var a=n.parentElement;while(a){var d=getComputedStyle(a).display;if(d!=='inline'&&d!=='contents')return a;a=a.parentElement;}return n.parentElement;}
function unitsOf(root){var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),n,out=[],cur=null;
 while((n=w.nextNode())){if(skipNode(n,root))continue;var b=blockOf(n);
  if(!cur||cur.blk!==b){cur={blk:b,nodes:[]};out.push(cur);}cur.nodes.push(n);}
 return out;}
function rangeIn(nodes,s,e){var pos=0,r=document.createRange(),a=false;
 for(var i=0;i<nodes.length;i++){var n=nodes[i],len=n.nodeValue.length;
  if(!a&&s<pos+len){r.setStart(n,s-pos);a=true;}
  if(a&&e<=pos+len){r.setEnd(n,e-pos);return r;}
  pos+=len;}
 return null;}
function sentences(str){return String(str||'').match(/.+?(?:[.!?]+["')\]]*(?=\s|$)|$)/gs)||[];}
function speakable(s){return s.replace(/[\u{1F000}-\u{1FFFF}\u{2190}-\u{2BFF}\u{FE0F}\u{200D}]/gu,' ').replace(/\s+/g,' ').trim();}
function collect(){
 var pb=document.querySelector('#panel-lessons .panel-body');if(!pb)return[];
 var kids=[].slice.call(pb.children),segs=[],started=false,last='';
 var skip='#lessonProgress,#lexileBarWrap,#lessonChips,.voice-wrap,#lessonKicker,#lessonMeta,.meta-pills';
 for(var i=0;i<kids.length;i++){var c=kids[i];
  if(c.id==='lessonTitle')started=true;
  if(!started||c.matches(skip))continue;
  var head=c.matches('details')?((c.querySelector('summary')||{}).textContent||''):(c.classList.contains('section-head')?c.textContent:'');
  if(/^\s*Lesson Path/i.test(head))break;
  unitsOf(c).forEach(function(u){
   var raw=u.nodes.map(function(n){return n.nodeValue;}).join(''),cur=0;
   sentences(raw).forEach(function(sn){var tr=sn.trim();if(!tr)return;var s=raw.indexOf(tr,cur);if(s>=0)cur=s+tr.length;
    var say=speakable(tr);if(!say||!/[\p{L}\p{N}]/u.test(say)||say===last)return;last=say;
    segs.push({blk:u.blk,nodes:u.nodes,say:say,s:s<0?null:s,e:s<0?null:s+tr.length});});});}
 return segs;}
function reveal(rect,el){var pb=el.closest&&el.closest('.panel-body');if(!pb)return;var pr=pb.getBoundingClientRect(),d=rect.top-(pr.top+pb.clientHeight*0.3);if(Math.abs(d)>8)pb.scrollTo({top:pb.scrollTop+d,behavior:reduce()?'auto':'smooth'});}
function show(seg){var el=seg.blk,f=el.closest&&el.closest('details');if(f&&!f.open)f.open=true;
 clear();if(!el.getClientRects().length)return;
 var r=(seg.s!=null&&HL)?rangeIn(seg.nodes,seg.s,seg.e):null;
 el.classList.add('mm-reading');
 if(r){HL.set('mm-sentence',new Highlight(r));reveal(r.getBoundingClientRect(),el);}else{reveal(el.getBoundingClientRect(),el);}}
window.readVisibleLesson=function(){
 if(!voiceOK()){vstatus('Voice reading is not available on this device or browser. Try Chrome, Safari, or Edge.');return;}
 try{window.speechSynthesis.cancel();}catch(e){}
 var l=L();if(!l)return;
 run++;var my=run;finish();
 var lg=loadLang(),code=lg==='es'?'es-ES':lg==='pt'?'pt-BR':'en-US';
 if(!_voices.length)loadVoices();
 var v=_voices.find(function(x){return x.lang&&x.lang.toLowerCase().indexOf(code.slice(0,2))===0;})||pickVoice();
 var rate=parseFloat($('voiceRate').value)||1,segs=collect();
 if(!segs.length){vstatus('Nothing to read yet. Open a lesson first.');return;}
 var pb=document.querySelector('#panel-lessons .panel-body');if(pb)pb.scrollTo({top:0,behavior:'auto'});
 active=true;document.documentElement.classList.add('mm-reading');
 segs.forEach(function(seg,i){
  var u=new SpeechSynthesisUtterance(seg.say);u.rate=rate;u.lang=code;if(v)u.voice=v;
  u.onstart=function(){if(my===run)show(seg);};
  if(i===segs.length-1)u.onend=function(){if(my!==run)return;finish();vstatus('Finished reading. Tap Read Aloud to hear it again.');};
  u.onerror=function(ev){if(my!==run)return;if(ev&&(ev.error==='canceled'||ev.error==='interrupted'))return;finish();vstatus('Voice stopped. Some school or in-app browsers block speech; open in Chrome, Safari, or Edge.');};
  try{window.speechSynthesis.speak(u);}catch(e){}});
 vstatus('Reading the '+GRADE_LABEL[currentGrade]+' lesson aloud, in order, up to the Lesson Path. Use Pause or Stop anytime.');
 timer=setInterval(function(){if(!active)return;var ss=window.speechSynthesis;if(ss.speaking||ss.pending||ss.paused){miss=0;return;}if(++miss>=2)finish();},600);
};
var os=window.stopReading;
window.stopReading=function(){run++;finish();return os.apply(this,arguments);};
})();
