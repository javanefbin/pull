(function(){
  "use strict";
  function addReflection(){
    if(document.getElementById("v46-quiz-reflection")) return;
    var quizArea=document.querySelector("#quiz, #quiz-view, .quiz-view, [data-view='quiz'], [data-section='quiz']");
    if(!quizArea) return;
    var box=document.createElement("section");
    box.id="v46-quiz-reflection";
    box.className="card quiz-reflection";
    box.setAttribute("aria-labelledby","v46-reflection-title");
    var qs=[
      "What is one thing you understand better after this quiz?",
      "Which question made you think the most, and why?",
      "How could you use today's money skill outside of school?",
      "What is one thing you would like to practice more?"
    ];
    var html="<h3 id=\"v46-reflection-title\">Reflect on Your Learning</h3>"+
      "<p>Take a moment to think about what you learned. There are no right or wrong answers here.</p>";
    qs.forEach(function(q,i){
      html+="<label for=\"v46-reflect-"+i+"\">"+q+"<textarea id=\"v46-reflect-"+i+"\" rows=\"3\" placeholder=\"Write your reflection...\"></textarea></label>";
    });
    html+="<button type=\"button\" id=\"v46-save-reflection\">Save Reflection</button><span id=\"v46-reflection-status\" role=\"status\" aria-live=\"polite\"></span>";
    box.innerHTML=html;
    quizArea.appendChild(box);
    var saved=[];
    try{ saved=JSON.parse(localStorage.getItem("mm_v46_reflection")||"[]"); }catch(e){}
    qs.forEach(function(_,i){ if(saved[i]) document.getElementById("v46-reflect-"+i).value=saved[i]; });
    document.getElementById("v46-save-reflection").addEventListener("click",function(){
      var values=qs.map(function(_,i){return document.getElementById("v46-reflect-"+i).value.trim();});
      try{localStorage.setItem("mm_v46_reflection",JSON.stringify(values));}catch(e){}
      document.getElementById("v46-reflection-status").textContent="Reflection saved.";
    });
  }
  function hideStudentMaterials(){
    if(!document.body || !document.body.classList.contains("student-mode")) return;
    document.querySelectorAll(".materials-ready-check,[data-feature='materials-check'],[data-role='materials-check'],#materials-ready-check,#materials-check,.materials-checklist,.lesson-materials,.materials-list").forEach(function(el){el.style.display="none";});
  }
  function init(){ hideStudentMaterials(); }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init); else init();
  if(window.MutationObserver) new MutationObserver(hideStudentMaterials).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener("click",function(){setTimeout(addReflection,150);},true);
})();
