(function(){
'use strict';
var root=document.documentElement;
function bannerH(){var cb=document.getElementById('consent-banner');if(!cb||cb.classList.contains('hidden'))return 0;var cs=getComputedStyle(cb);if(cs.display==='none'||cs.visibility==='hidden')return 0;var r=cb.getBoundingClientRect();return r.height>0&&r.bottom>=innerHeight-4?Math.ceil(r.height):0;}
function place(){try{var S=window.MM91&&window.MM91.shell;if(S&&S.placeHome)S.placeHome();}catch(e){}}
function sync(){var v=bannerH(),phone=innerWidth<=640&&!root.classList.contains('mm-gated');root.style.setProperty('--mm-consent-h',(phone?0:v)+'px');place();}
function wrapHome(){var S=window.MM91&&window.MM91.shell;if(!S||!S.placeHome||S.placeHome.__r)return;var o=S.placeHome;
 var w=function(){o.apply(this,arguments);try{var el=document.getElementById('mm-home'),row=document.querySelector('.station-row');if(el&&row)el.classList.toggle('wall',el.getBoundingClientRect().top<row.getBoundingClientRect().top+4);}catch(e){}};
 w.__r=1;S.placeHome=w;}
function init(){wrapHome();var cb=document.getElementById('consent-banner');
 if(cb){try{new MutationObserver(sync).observe(cb,{attributes:true,attributeFilter:['class','style']});}catch(e){}try{new ResizeObserver(sync).observe(cb);}catch(e){}}
 try{new MutationObserver(sync).observe(root,{attributes:true,attributeFilter:['class']});}catch(e){}
 window.addEventListener('resize',sync);window.addEventListener('orientationchange',function(){setTimeout(sync,250);});
 sync();setTimeout(sync,1200);setTimeout(function(){wrapHome();sync();},3800);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

