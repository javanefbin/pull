(function(){
  "use strict";
  /* The v46 "Reflect on your learning" box that used to live here never ran (its id
     matched this script tag); the quiz reflection is #quizReflection in 190-core-app.js. */
  function hideStudentMaterials(){
    if(!document.body || !document.body.classList.contains("student-mode")) return;
    document.querySelectorAll(".materials-ready-check,[data-feature='materials-check'],[data-role='materials-check'],#materials-ready-check,#materials-check,.materials-checklist,.lesson-materials,.materials-list").forEach(function(el){el.style.display="none";});
  }
  function init(){ hideStudentMaterials(); }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init); else init();
  if(window.MutationObserver) new MutationObserver(hideStudentMaterials).observe(document.documentElement,{childList:true,subtree:true});
})();
