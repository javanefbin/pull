/* Money Matters service worker (hosted build).
   Page: network first, cached copy when offline.
   /api/content: network first; the last good copy is kept so a licensed
   device keeps the full program offline. A 401/403 (revoked or expired code)
   deletes the kept copy. Version: __CONTENT_VERSION__ */
const CACHE = 'mm-__CONTENT_VERSION__';
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(CACHE).then(c => c.add('./')).catch(() => {})); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE && k.startsWith('mm-')).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  if (u.pathname === '/api/content') {
    const key = new Request(u.origin + '/api/content');
    e.respondWith(fetch(e.request).then(async r => {
      const c = await caches.open(CACHE);
      if (r.ok) await c.put(key, r.clone());
      else if (r.status === 401 || r.status === 403) await c.delete(key);
      return r;
    }).catch(async () => (await caches.match(key)) || new Response('{"error":"offline"}', { status: 503, headers: { 'Content-Type': 'application/json' } })));
    return;
  }
  if (e.request.mode === 'navigate' || u.pathname === '/' || u.pathname.endsWith('.html')) {
    e.respondWith(fetch(e.request).then(r => { if (r.ok) caches.open(CACHE).then(c => c.put('./', r.clone())); return r; }).catch(() => caches.match('./')));
  }
});
