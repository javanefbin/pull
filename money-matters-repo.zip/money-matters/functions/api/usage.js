/* Cloudflare Pages Function: POST /api/usage
   Anonymous usage counts: how often each lesson, quiz, workshop, game and panel is
   opened, per day. The page sends { d: "YYYY-MM-DD", e: { "lesson:4:3": 2, ... } }
   when it is hidden or closed (navigator.sendBeacon). Nothing identifies a person,
   a device, a school or an IP: only the day, the event name and a count are stored
   (Supabase table usage_daily, added through the usage_add function).
   Read the numbers with:  npm run usage  (scripts/usage.mjs)
   Off when MM_USAGE=off, or when Supabase is not configured.
   Optional MM_KV binding: at most 60 reports per IP per hour (the IP is used only for
   that counter, which expires after an hour, and is never stored with the counts). */
import { json, sb } from '../../lib/mm-server.mjs';

export const EVENT = /^[a-z][a-z0-9-]{0,23}(:[A-Za-z0-9_-]{1,24}){0,3}$/;
const ymd = d => d.toISOString().slice(0, 10);
/** Validates a report. Returns { day, events, counts } or null. */
export function clean(b, now) {
  now = now || new Date();
  if (!b || typeof b !== 'object' || typeof b.d !== 'string' || !b.e || typeof b.e !== 'object') return null;
  const today = ymd(now), yesterday = ymd(new Date(now.getTime() - 86400000));
  if (b.d !== today && b.d !== yesterday) return null;
  const keys = Object.keys(b.e).filter(k => EVENT.test(k)).slice(0, 60);
  const counts = keys.map(k => Math.min(1000, Math.max(0, Math.floor(+b.e[k] || 0))));
  const ok = keys.map((k, i) => [k, counts[i]]).filter(x => x[1] > 0);
  return ok.length ? { day: b.d, events: ok.map(x => x[0]), counts: ok.map(x => x[1]) } : null;
}

export async function onRequestPost({ request, env }) {
  if (!env.SUPABASE_URL || !env.SUPABASE_SECRET_KEY || env.MM_USAGE === 'off') return new Response(null, { status: 204 });
  let text = '';
  try { text = await request.text(); } catch (e) {}
  if (!text || text.length > 8192) return json({ error: 'bad report' }, 400);
  let b = null; try { b = JSON.parse(text); } catch (e) {}
  const c = clean(b);
  if (!c) return json({ error: 'bad report' }, 400);
  if (env.MM_KV) {
    const k = 'use:' + (request.headers.get('CF-Connecting-IP') || '') + ':' + new Date().toISOString().slice(0, 13);
    const n = +(await env.MM_KV.get(k) || 0);
    if (n >= 60) return new Response(null, { status: 204 });
    await env.MM_KV.put(k, String(n + 1), { expirationTtl: 3600 });
  }
  try {
    const r = await sb(env, '/rest/v1/rpc/usage_add', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ p_day: c.day, p_events: c.events, p_counts: c.counts }) });
    if (!r.ok) return json({ error: 'not saved' }, 503);
  } catch (e) { return json({ error: 'not saved' }, 503); }
  return new Response(null, { status: 204 });
}
