/* Cloudflare Pages Function: POST /api/sync
   Class sync: keeps a class's roster and progress the same on every device of
   the class, end-to-end encrypted. See lib/mm-sync.mjs for the protocol and
   src/scripts/665-class-sync.js for the page side.
   Headers:  X-MM-Room: <class id>   X-MM-Key: <teacher or student secret>
             Authorization: Bearer <access code or device token>   (only to create a class)
   Environment: SUPABASE_URL, SUPABASE_SECRET_KEY (tables sync_rooms, sync_items:
   supabase/migrations/20261027000000_school_sign_in_and_sync.sql), optional MM_KV
   (rate-limits every student-device request per class and IP). */
import { handle, supabaseStore } from '../../lib/mm-sync.mjs';
import { json } from '../../lib/mm-server.mjs';

export async function onRequestPost(ctx) {
  const { env, request } = ctx;
  if (!env.SUPABASE_URL || !env.SUPABASE_SECRET_KEY) return json({ error: 'Class sync is not set up on this site.' }, 503);
  const ip = request.headers.get('CF-Connecting-IP') || '';
  /* per IP, per class, per 10 minutes. Code guessing is also capped per username by the
     server itself (10 wrong codes lock that sign-in for 15 minutes), with or without KV. */
  const CAPS = { salt: 60, login: 60, rec: 300, recput: 300, ssoput: 20 };
  const rateLimit = env.MM_KV ? async (room, op) => {
    const cap = CAPS[op]; if (!cap) return true;
    const k = 'rl:' + op + ':' + room.slice(0, 16) + ':' + ip, n = +(await env.MM_KV.get(k) || 0);
    if (n >= cap) return false;
    await env.MM_KV.put(k, String(n + 1), { expirationTtl: 600 });
    return true;
  } : null;
  try { return await handle(ctx, supabaseStore(env), { rateLimit }); }
  catch (e) { return json({ error: 'The class server could not be reached. Your work is saved on this device and will sync later.' }, 503); }
}
