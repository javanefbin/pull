/* Cloudflare Pages Function: GET /api/sso/clever  ·  GET /api/sso/classlink
   "Sign in with Clever / ClassLink" for students, teachers and administrators.

   Register this address as the redirect URI in the provider's developer
   dashboard:   https://<your site>/api/sso/clever   (and /api/sso/classlink)

   Flow
     1. The page sends the person here with ?n=<nonce> (a random value it keeps
        in sessionStorage). We set a short, signed, HttpOnly state cookie and
        redirect to the provider.
     2. The provider sends them back here with ?code&state. We check the state,
        exchange the code server-to-server (the client secret never reaches a
        browser), and read who they are: role, name, email, district.
     3. We redirect to /#mm-sso=<signed result>. The fragment never reaches a
        server or a log. The page posts it, with its nonce, to /api/sso-verify,
        which checks it and returns the identity (and a device token when the
        district or email is licensed). The page then signs the person in to
        the matching account on that device.
   Logins that start in the Clever Portal, Clever Instant Login or ClassLink
   LaunchPad arrive with a code but no state. As Clever recommends, we ignore
   that code and restart from our own page (/#mm-sso-start=<provider>), which
   comes straight back because the person is already signed in there.
   Nothing about the person is stored on the server.

   Environment: MM_TOKEN_SECRET, SUPABASE_URL, SUPABASE_SECRET_KEY, and
     CLEVER_CLIENT_ID, CLEVER_CLIENT_SECRET          (Clever)
     CLASSLINK_CLIENT_ID, CLASSLINK_CLIENT_SECRET    (ClassLink) */
import { signBlob, verifyBlob, ssoSubject, randomId, licenseForSso, cookie } from '../../../lib/mm-server.mjs';

export const PROVIDERS = {
  clever: {
    name: 'Clever', authorize: 'https://clever.com/oauth/authorize', token: 'https://clever.com/oauth/tokens',
    id: env => env.CLEVER_CLIENT_ID, secret: env => env.CLEVER_CLIENT_SECRET,
  },
  classlink: {
    name: 'ClassLink', authorize: 'https://launchpad.classlink.com/oauth2/v2/auth', token: 'https://launchpad.classlink.com/oauth2/v2/token',
    id: env => env.CLASSLINK_CLIENT_ID, secret: env => env.CLASSLINK_CLIENT_SECRET, scope: 'profile',
  },
};
const COOKIE = 'mm_sso';
const page = (origin, frag) => origin + '/#' + frag;
function redirect(to, setCookie) {
  const h = new Headers({ Location: to, 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
  if (setCookie) h.append('Set-Cookie', setCookie);
  return new Response(null, { status: 302, headers: h });
}
const fail = (origin, msg) => redirect(page(origin, 'mm-sso-error=' + encodeURIComponent(msg)), COOKIE + '=; Path=/api/sso; Max-Age=0; HttpOnly; Secure; SameSite=Lax');

/** Normalized identity: { id, org, role: student|teacher|admin, first, last, email } */
export async function identify(provider, tok, env, fetchImpl) {
  const f = fetchImpl || fetch;
  if (provider === 'clever') {
    /* With OpenID Connect switched on, the id_token came to us directly from Clever's token
       endpoint over TLS, so its claims can be used without a signature check (OIDC Core 3.1.3.7).
       Otherwise ask the API: /me for the id and district, /users/{id} for the name and roles. */
    if (tok.id_token) {
      const c = JSON.parse(atob(tok.id_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      if (c.iss !== 'https://clever.com' || (c.aud !== env.CLEVER_CLIENT_ID && !(Array.isArray(c.aud) && c.aud.includes(env.CLEVER_CLIENT_ID))) || !(c.exp * 1000 > Date.now())) throw new Error('Clever returned an invalid identity token');
      return { id: c.multi_role_user_id || c.sub || c.user_id, org: c.district || '', role: c.user_type, first: c.given_name || '', last: c.family_name || '', email: c.email || '' };
    }
    const H = { Authorization: 'Bearer ' + tok.access_token, Accept: 'application/json' };
    const me = await f('https://api.clever.com/v3.0/me', { headers: H });
    if (!me.ok) throw new Error('Clever did not say who signed in (' + me.status + ')');
    const m = (await me.json()).data || {};
    let u = {};
    try { const r = await f('https://api.clever.com/v3.0/users/' + encodeURIComponent(m.id), { headers: H }); if (r.ok) u = (await r.json()).data || {}; } catch (e) {}
    const roles = Object.keys(u.roles || {});
    const role = roles.includes('district_admin') ? 'district_admin' : roles.includes('teacher') ? 'teacher' : roles.includes('staff') ? 'staff' : roles.includes('student') ? 'student' : (m.type || '');
    return { id: m.id, org: m.district || u.district || '', role, first: (u.name && u.name.first) || '', last: (u.name && u.name.last) || '', email: u.email || '' };
  }
  const r = await f('https://nodeapi.classlink.com/v2/my/info', { headers: { Authorization: 'Bearer ' + tok.access_token, Accept: 'application/json' } });
  if (!r.ok) throw new Error('ClassLink did not say who signed in (' + r.status + ')');
  const u = await r.json();
  return { id: String(u.UserId || u.SourcedId || ''), org: String(u.TenantId || ''), role: u.Role || '', first: u.FirstName || '', last: u.LastName || '', email: u.Email || '' };
}
export function normRole(r) {
  r = String(r || '').toLowerCase().replace(/[\s_-]+/g, ' ').trim();
  if (r === 'student') return 'student';
  if (/district admin|tenant admin|administrator/.test(r)) return 'admin';
  return 'teacher';   /* teacher, staff, and other adults */
}

export async function onRequestGet({ request, env, params }, fetchImpl) {
  const f = fetchImpl || fetch;
  const url = new URL(request.url), origin = url.origin;
  const key = String(params.provider || '').toLowerCase(), P = PROVIDERS[key];
  if (!P) return new Response('unknown sign-in provider', { status: 404 });
  if (!P.id(env) || !P.secret(env) || !env.MM_TOKEN_SECRET) return fail(origin, P.name + ' sign-in is not set up for this site yet.');
  const redirectUri = origin + '/api/sso/' + key;
  const q = url.searchParams;

  if (q.get('error')) return fail(origin, (q.get('error_description') || q.get('error') || 'Sign-in was cancelled.').slice(0, 200));

  /* 1. start: page nonce -> state cookie -> provider */
  if (!q.get('code')) {
    const n = q.get('n') || '';
    if (!/^[A-Za-z0-9_-]{16,64}$/.test(n)) return redirect(page(origin, 'mm-sso-start=' + key));
    const state = randomId(18);
    const blob = await signBlob(env, 'MMC1', { s: state, n, p: key }, 10 * 60000);
    const a = new URL(P.authorize);
    a.searchParams.set('response_type', 'code'); a.searchParams.set('client_id', P.id(env));
    a.searchParams.set('redirect_uri', redirectUri); a.searchParams.set('state', state);
    if (P.scope) a.searchParams.set('scope', P.scope);
    if (key === 'clever' && /^[a-f0-9]{24}$/.test(q.get('district') || '')) a.searchParams.set('district_id', q.get('district'));
    return redirect(a.toString(), COOKIE + '=' + blob + '; Path=/api/sso; Max-Age=600; HttpOnly; Secure; SameSite=Lax');
  }

  /* 2. back from the provider */
  const st = await verifyBlob(env, 'MMC1', cookie(request, COOKIE));
  if (!q.get('state')) return redirect(page(origin, 'mm-sso-start=' + key));         /* portal / instant login: restart from our page */
  if (!st || st.p !== key || st.s !== q.get('state')) return fail(origin, 'That sign-in link expired. Please try again.');

  let tok;
  try {
    const body = { code: q.get('code'), grant_type: 'authorization_code', redirect_uri: redirectUri };
    const r = key === 'clever'
      ? await f(P.token, { method: 'POST', headers: { Authorization: 'Basic ' + btoa(P.id(env) + ':' + P.secret(env)), 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) })
      : await f(P.token, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' }, body: new URLSearchParams(Object.assign({ client_id: P.id(env), client_secret: P.secret(env) }, body)).toString() });
    if (!r.ok) throw new Error(P.name + ' refused the sign-in (' + r.status + ')');
    tok = await r.json();
    if (!tok.access_token) throw new Error(P.name + ' returned no access token');
  } catch (e) { return fail(origin, String(e.message || e)); }

  let who;
  try { who = await identify(key, tok, env, f); } catch (e) { return fail(origin, String(e.message || e)); }
  if (!who.id) return fail(origin, P.name + ' did not say who signed in.');
  const role = normRole(who.role);
  const email = role === 'student' ? '' : String(who.email || '').trim().toLowerCase();   /* a student's email is never needed */
  const name = [who.first, who.last].filter(Boolean).join(' ').trim().slice(0, 60);
  const sub = await ssoSubject(env, key, who.id);
  let lic = { status: 404 };
  try { lic = await licenseForSso(env, who.org ? key + ':' + who.org : '', email); } catch (e) {}
  const result = await signBlob(env, 'MMA1', {
    p: key, r: role, nm: name, e: email, sub, nn: st.n,
    l: lic.status === 200 ? lic.id : null, lb: lic.status === 200 ? (lic.label || '') : '',
    why: lic.status === 200 ? '' : lic.status === 503 ? 'The license server could not be reached.' : 'No school license covers this ' + (who.org ? 'district' : 'account') + ' yet.',
  }, 2 * 60000);
  return redirect(page(origin, 'mm-sso=' + result), COOKIE + '=; Path=/api/sso; Max-Age=0; HttpOnly; Secure; SameSite=Lax');
}
