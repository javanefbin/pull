/* Cloudflare Pages Function: POST /api/sso-verify
   The page sends the signed result from /api/sso/<provider> together with the
   nonce it kept in sessionStorage when it started the sign-in:
     { "a": "MMA1.…", "n": "<nonce>" }
   We check the signature, the 2-minute expiry, that the nonce matches (so a
   result can't be replayed into another browser or planted with a link), and
   that it hasn't been used before (when the MM_KV cache is bound).
   Response 200: { provider, role, name, email, sub, licensed, label?, token?, reason? }
     role   student | teacher | admin
     sub    a private, stable id for this person at this provider (not the provider's id)
     token  a 30-day device token when a license covers the district or email */
import { json, verifyBlob, signToken, sha256, logUse, originOk } from '../../lib/mm-server.mjs';

export async function onRequestPost({ request, env, waitUntil }) {
  if (!originOk(request, env)) return json({ error: 'not allowed from another website' }, 403);   /* V23 */
  let b = {};
  try { b = await request.json(); } catch (e) {}
  const c = await verifyBlob(env, 'MMA1', b.a);
  if (!c) return json({ error: 'This sign-in expired. Please sign in again.' }, 401);
  if (!b.n || b.n !== c.nn) return json({ error: 'This sign-in was started in another browser. Please sign in again here.' }, 401);
  if (env.MM_KV) {
    const k = 'ssoa:' + (await sha256(b.a));
    if (await env.MM_KV.get(k)) return json({ error: 'This sign-in was already used. Please sign in again.' }, 409);
    await env.MM_KV.put(k, '1', { expirationTtl: 300 });
  }
  const out = { provider: c.p, role: c.r, name: c.nm || '', email: c.e || '', sub: c.sub, licensed: false };
  if (c.l) {
    try { out.token = await signToken(env, { l: c.l, e: c.e || ('sso:' + c.p + ':' + c.sub) }); out.licensed = true; out.label = c.lb || ''; }
    catch (e) { return json({ error: 'sign-in is not fully configured (MM_TOKEN_SECRET)' }, 503); }
    if (waitUntil) waitUntil(logUse(env, c.l, true, 'sign-in:' + c.p));
  } else if (c.why) out.reason = c.why;
  return json(out, 200);
}
