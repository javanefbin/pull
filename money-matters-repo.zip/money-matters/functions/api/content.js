/* Cloudflare Pages Function: GET /api/content
   Returns the licensed Money Matters content packs to a device that sends
     Authorization: Bearer <school access code>          (MM-XXXX-XXXX-XXXX), or
     Authorization: Bearer <device token from /api/link> (MMD1.…, social sign-in)
   Environment (Cloudflare Pages → Settings → Variables and secrets):
     SUPABASE_URL           https://<project>.supabase.co
     SUPABASE_SECRET_KEY    secret key (sb_secret_…) or legacy service_role key  [Secret]
     MM_TOKEN_SECRET        32+ random characters, signs device tokens          [Secret]
     MM_KV                  (optional) KV namespace binding: caches content and
                            license checks so Supabase is used rarely.
   Responses: 200 content JSON · 401 missing/unknown code or expired sign-in ·
   403 expired or disabled license · 503 Supabase unreachable and nothing cached.
   A device token in its last 10 days comes back renewed in the X-MM-Token header. */
import { normalize, sha256, json, bearer, sb, logUse, licenseByCode, licenseById, verifyToken, signToken, RENEW_DAYS } from '../../lib/mm-server.mjs';
export { normalize, sha256 };

const BROWSER_MAX_AGE = 7 * 86400;      /* browsers keep the packs 7 days (revocations apply within 7 days) */

export async function onRequestGet({ request, env, waitUntil }) {
  const raw = bearer(request);
  if (!env.SUPABASE_URL || !env.SUPABASE_SECRET_KEY) return json({ error: 'server not configured' }, 503);

  /* 1. license: device token (social sign-in) or access code */
  let lic, via = 'code', renewed = '';
  if (raw.startsWith('MMD1.')) {
    via = 'sign-in';
    const t = await verifyToken(env, raw);
    if (!t) return json({ error: 'sign-in expired; sign in again' }, 401);
    lic = await licenseById(env, waitUntil, t.l);
    if (lic.status === 200 && t.x - Date.now() < RENEW_DAYS * 86400000) {
      try { renewed = await signToken(env, { l: t.l, e: t.e }); } catch (e) {}
    }
  } else {
    const code = normalize(raw);
    if (!/^[A-Z0-9]{8,40}$/.test(code)) return json({ error: 'missing or malformed access code' }, 401);
    lic = await licenseByCode(env, waitUntil, code);
  }
  if (lic.status !== 200) {
    if (lic.status === 401) waitUntil(logUse(env, null, false, via));
    return json({ error: lic.error }, lic.status);
  }

  /* 2. content (KV first, then Supabase). The page asks for ?v=<content version>
        baked in at build time, so a new deploy reads fresh packs. */
  const want = (new URL(request.url).searchParams.get('v') || '').replace(/[^a-f0-9]/g, '').slice(0, 16);
  const kvKey = 'content:' + (want || 'current');
  let body = env.MM_KV ? await env.MM_KV.get(kvKey) : null;
  if (!body) {
    let r;
    try { r = await sb(env, '/rest/v1/content_packs?select=key,version,data'); } catch (e) { return json({ error: 'content unavailable' }, 503); }
    if (!r.ok) return json({ error: 'content unavailable' }, 503);
    const rows = await r.json();
    if (!rows.length) return json({ error: 'no content has been uploaded' }, 503);
    const packs = {}; rows.forEach(x => { packs[x.key] = x.data; });
    packs.__version = rows[0].version;
    body = JSON.stringify(packs);
    /* cache long only when Supabase holds the version this page was built with */
    const match = want && packs.__version === want;
    if (env.MM_KV) waitUntil(env.MM_KV.put(kvKey, body, { expirationTtl: match ? 30 * 86400 : 300 }));
  }
  /* add the license label without re-parsing the whole payload */
  const out = '{"__label":' + JSON.stringify(lic.label || '') + ',"__expires":' + JSON.stringify(lic.expires_at || '') + ',' + body.slice(1);
  waitUntil(logUse(env, lic.id, true, via));
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': renewed ? 'no-store' : 'private, max-age=' + BROWSER_MAX_AGE,
    'Vary': 'Authorization',
    'X-Content-Type-Options': 'nosniff'
  };
  if (renewed) headers['X-MM-Token'] = renewed;
  return new Response(out, { status: 200, headers });
}
