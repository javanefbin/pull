/* Cloudflare Pages Function: POST /api/link
   Called by the page right after a teacher, parent or administrator signs in
   with Google, Microsoft or Facebook through Supabase Auth.
     Authorization: Bearer <Supabase access token>
   The function asks Supabase who that is (so the page cannot fake an email),
   then checks the licenses table for the email or its domain. It returns the
   verified identity, and a 30-day device token when a license covers them.
   The page uses the identity to sign in to the matching account on this
   device, stores the token in place of an access code, and discards the
   Supabase session (nothing else is kept).
   Extra environment: SUPABASE_PUBLISHABLE_KEY (or the legacy anon key) and
   MM_TOKEN_SECRET (see content.js).
   Response 200: { email, name, provider, licensed, label?, expires?, token?, reason? } */
import { json, bearer, licenseForEmail, signToken, logUse } from '../../lib/mm-server.mjs';

export async function onRequestPost({ request, env, waitUntil }) {
  const jwt = bearer(request);
  if (!jwt || jwt.split('.').length !== 3) return json({ error: 'missing sign-in' }, 401);
  if (!env.SUPABASE_URL || !env.SUPABASE_SECRET_KEY) return json({ error: 'server not configured' }, 503);

  /* 1. who is this? (verified by Supabase, not by the browser) */
  let user;
  try {
    const r = await fetch(env.SUPABASE_URL.replace(/\/$/, '') + '/auth/v1/user', { headers: { apikey: env.SUPABASE_PUBLISHABLE_KEY || env.SUPABASE_SECRET_KEY, Authorization: 'Bearer ' + jwt } });
    if (r.status === 401 || r.status === 403) return json({ error: 'sign-in expired; try again' }, 401);
    if (!r.ok) return json({ error: 'sign-in server unreachable' }, 503);
    user = await r.json();
  } catch (e) { return json({ error: 'sign-in server unreachable' }, 503); }
  const email = String(user.email || '').trim().toLowerCase();
  const meta = user.user_metadata || {};
  const provider = (user.app_metadata && user.app_metadata.provider) || '';
  if (!email) return json({ error: 'Your ' + (provider || 'sign-in') + ' account did not share an email address. Use another sign-in option or an access code.' }, 400);
  const name = String(meta.full_name || meta.name || email.split('@')[0]).slice(0, 60);
  const out = { email, name, provider, licensed: false };

  /* 2. is this email or domain licensed? */
  const lic = await licenseForEmail(env, email);
  if (lic.status === 200) {
    try { out.token = await signToken(env, { l: lic.id, e: email }); }
    catch (e) { return json({ error: 'sign-in is not fully configured (MM_TOKEN_SECRET)' }, 503); }
    out.licensed = true; out.label = lic.label || ''; out.expires = lic.expires_at || '';
    waitUntil(logUse(env, lic.id, true, 'sign-in:' + provider));
  } else {
    out.reason = lic.status === 404 ? 'No school license covers ' + email + ' yet.' : lic.status === 503 ? 'The license server could not be reached.' : 'The license for ' + email + ' is ' + (lic.error || '').replace('license ', '') + '.';
  }
  return json(out, 200);
}
