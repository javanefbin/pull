/* Cloudflare Pages Function: POST /api/quote
   The "Get a quote" page (/quote) sends a school's request here. It is saved in
   Supabase (table quote_requests) with a quote number, and, when MM_QUOTE_WEBHOOK
   is set to an https:// address (Slack, Teams, Discord, Zapier, Make...), a short
   notice is posted there so you hear about it right away.
   Nothing about students is asked for or stored: only the school and the adult
   who asked.
   Response 200: { quote_no, created_at }
   Environment: SUPABASE_URL, SUPABASE_SECRET_KEY, optional MM_QUOTE_WEBHOOK, optional
   MM_KV (at most 5 requests per IP per hour). */
import { json, sb } from '../../lib/mm-server.mjs';

const str = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
const int = (v, max) => { const n = Math.floor(+v); return Number.isFinite(n) && n >= 0 && n <= max ? n : null; };
const EMAIL = /^[^\s@<>"]{1,64}@[^\s@<>"]{1,190}\.[a-z]{2,}$/i;
const WANTS = ['school', 'district', 'workshops', 'sync', 'training', 'other'];
const PAY = ['po', 'invoice', 'card'];
export function quoteNo(now) {
  const d = (now || new Date()).toISOString().slice(2, 10).replace(/-/g, '');
  const A = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ', r = new Uint8Array(4); crypto.getRandomValues(r);
  return 'Q' + d + '-' + Array.from(r, b => A[b % 32]).join('');
}
/** Validates a request. Returns { row } or { error }. */
export function clean(b) {
  if (!b || typeof b !== 'object') return { error: 'bad request' };
  if (b.website) return { error: 'bad request' };                 /* spam trap: a hidden field people never fill */
  const row = {
    school: str(b.school, 200), district: str(b.district, 200) || null, contact: str(b.contact, 120),
    email: str(b.email, 200).toLowerCase(), phone: str(b.phone, 40) || null, role: str(b.role, 80) || null,
    students: int(b.students, 1000000), teachers: int(b.teachers, 100000), grades: str(b.grades, 60) || null,
    start_date: /^\d{4}-\d{2}-\d{2}$/.test(b.start_date || '') ? b.start_date : null,
    wants: (Array.isArray(b.wants) ? b.wants : []).filter(w => WANTS.includes(w)).concat(PAY.includes(b.pay) ? ['pay:' + b.pay] : []).concat(int(b.schools, 10000) ? ['schools:' + int(b.schools, 10000)] : []),
    notes: str(b.notes, 2000) || null,
  };
  if (!row.school) return { error: 'Enter the school name.' };
  if (!row.contact) return { error: 'Enter your name.' };
  if (!EMAIL.test(row.email)) return { error: 'Enter a valid email address.' };
  return { row };
}

export async function onRequestPost({ request, env, waitUntil }) {
  if (!env.SUPABASE_URL || !env.SUPABASE_SECRET_KEY) return json({ error: 'Online quote requests are not set up yet.' }, 503);
  let b = null;
  try { const t = await request.text(); if (t.length > 8192) return json({ error: 'too long' }, 413); b = JSON.parse(t); } catch (e) {}
  const c = clean(b);
  if (c.error) return json({ error: c.error }, 400);
  if (env.MM_KV) {
    const k = 'quote:' + (request.headers.get('CF-Connecting-IP') || '') + ':' + new Date().toISOString().slice(0, 13);
    const n = +(await env.MM_KV.get(k) || 0);
    if (n >= 5) return json({ error: 'Too many requests. Try again in an hour, or email us.' }, 429);
    await env.MM_KV.put(k, String(n + 1), { expirationTtl: 3600 });
  }
  const row = Object.assign({ quote_no: quoteNo() }, c.row);
  let saved;
  try {
    const r = await sb(env, '/rest/v1/quote_requests', { method: 'POST', headers: { 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: JSON.stringify(row) });
    if (!r.ok) throw new Error('db ' + r.status);
    saved = (await r.json())[0] || row;
  } catch (e) { return json({ error: 'The request could not be saved. Please email us instead.' }, 503); }
  const hook = String(env.MM_QUOTE_WEBHOOK || '');
  if (/^https:\/\//.test(hook) && waitUntil) {
    /* what a school typed can't add lines, mentions (@channel) or formatting to your channel */
    const plain = v => String(v || '').replace(/\s+/g, ' ').replace(/[<>@*_`~|#\[\]]/g, '').slice(0, 120);
    const text = 'New quote request ' + row.quote_no + ': ' + plain(row.school) + (row.district ? ' (' + plain(row.district) + ')' : '') + ', ' + plain(row.contact) + ' (' + plain(row.email).replace(/\s/g, '') + ')' + (row.students != null ? ', about ' + row.students + ' students' : '') + (row.wants.length ? ', wants ' + row.wants.join(', ') : '');
    waitUntil(fetch(hook, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, content: text, quote: row }) }).catch(() => {}));
  }
  return json({ quote_no: saved.quote_no, created_at: saved.created_at || new Date().toISOString() });
}
