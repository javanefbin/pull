/* Cloudflare Pages Function: GET /api/config
   Public settings the page needs at run time (nothing secret):
     auth       Supabase project URL + publishable key, and which sign-in
                buttons to show. Off until SUPABASE_PUBLISHABLE_KEY is set.
     sso        school sign-in buttons: "clever", "classlink" (each appears once
                its client id and secret are set; see functions/api/sso/)
     sync       true when class sync can be used (functions/api/sync.js)
     usage      true when anonymous usage counts are collected (functions/api/usage.js)
   Environment:
     SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY (sb_publishable_… or legacy anon key)
     MM_AUTH_PROVIDERS   comma list, default "google,azure"
                         (azure = Microsoft accounts; also: facebook, apple)
     CLEVER_CLIENT_ID + CLEVER_CLIENT_SECRET, CLASSLINK_CLIENT_ID + CLASSLINK_CLIENT_SECRET
   The publishable key is safe in the browser: row-level security gives it no
   access to licenses or content. */
const ALLOWED = ['google', 'azure', 'facebook', 'apple'];
export async function onRequestGet({ env }) {
  const providers = String(env.MM_AUTH_PROVIDERS || 'google,azure').split(',').map(s => s.trim().toLowerCase()).filter(p => ALLOWED.includes(p));
  const auth = env.SUPABASE_URL && env.SUPABASE_PUBLISHABLE_KEY && providers.length ? { url: env.SUPABASE_URL.replace(/\/$/, ''), key: env.SUPABASE_PUBLISHABLE_KEY, providers } : null;
  const sso = env.MM_TOKEN_SECRET ? [['clever', 'CLEVER'], ['classlink', 'CLASSLINK']].filter(([, k]) => env[k + '_CLIENT_ID'] && env[k + '_CLIENT_SECRET']).map(([p]) => p) : [];
  const sync = !!(env.SUPABASE_URL && env.SUPABASE_SECRET_KEY);
  const usage = !!(env.SUPABASE_URL && env.SUPABASE_SECRET_KEY) && env.MM_USAGE !== 'off';
  return new Response(JSON.stringify({ auth, sso, sync, usage }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=300' } });
}
