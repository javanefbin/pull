/* Cloudflare Pages Function: GET /api/config
   Public settings the page needs at run time (nothing secret):
     auth       Supabase project URL + publishable key, and which sign-in
                buttons to show. Off until SUPABASE_PUBLISHABLE_KEY is set.
   Environment:
     SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY (sb_publishable_… or legacy anon key)
     MM_AUTH_PROVIDERS   comma list, default "google,azure,facebook"
                         (azure = Microsoft accounts; also: apple)
   The publishable key is safe in the browser: row-level security gives it no
   access to licenses or content. */
const ALLOWED = ['google', 'azure', 'facebook', 'apple'];
export async function onRequestGet({ env }) {
  const providers = String(env.MM_AUTH_PROVIDERS || 'google,azure,facebook').split(',').map(s => s.trim().toLowerCase()).filter(p => ALLOWED.includes(p));
  const auth = env.SUPABASE_URL && env.SUPABASE_PUBLISHABLE_KEY && providers.length ? { url: env.SUPABASE_URL.replace(/\/$/, ''), key: env.SUPABASE_PUBLISHABLE_KEY, providers } : null;
  return new Response(JSON.stringify({ auth }), { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=300' } });
}
