#!/usr/bin/env node
/*
 * One-time (re-runnable) extractor: splits the single-file app into src/.
 *   node tools/extract.js <input.html>
 * Writes src/index.html, src/styles, src/scripts, src/data, src/panels.
 * Every extracted piece is an exact substring of the input; build.js
 * re-inserts it verbatim, so the round trip is byte-identical.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const input = process.argv[2];
if (!input) { console.error('usage: node tools/extract.js <input.html>'); process.exit(2); }
const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');

const buf = fs.readFileSync(input);
const html = buf.toString('utf8');
if (!Buffer.from(html, 'utf8').equals(buf)) throw new Error('input is not clean UTF-8');
if (html.includes('@include')) throw new Error('directive marker "@include" already occurs in the source');

// Names for top-level blocks that have no id attribute (by document order of unnamed blocks).
const UNNAMED = {
  style: ['base'],
  script: ['consent-controls', 'core-app'],
};

// Giant data literals to move into src/data (NAME -> statement prefix regex).
const DATA_NAMES = ['LESSONS', 'SECTION_TESTS', 'LESSON_QUIZ', 'LESSONS_L', 'SECTION_TESTS_L',
  'LESSON_QUIZ_L', 'FACTS', 'MATERIAL_CARDS', 'S_DATA', 'WS_DATA'];

// ---- 1. tokenize top-level <style>/<script> blocks (skipping HTML comments) ----
const blocks = [];
let pos = 0;
while (true) {
  const re = /<!--|<script\b|<style\b/g;
  re.lastIndex = pos;
  const m = re.exec(html);
  if (!m) break;
  if (m[0] === '<!--') {
    const end = html.indexOf('-->', m.index + 4);
    if (end < 0) throw new Error('unterminated comment');
    pos = end + 3;
    continue;
  }
  const kind = m[0].slice(1); // script|style
  const tagEnd = html.indexOf('>', m.index);
  const openTag = html.slice(m.index, tagEnd + 1);
  const close = '</' + kind + '>';
  const innerStart = tagEnd + 1;
  const innerEnd = html.indexOf(close, innerStart);
  if (innerEnd < 0) throw new Error('unterminated ' + kind);
  const idm = /\bid="([^"]+)"/.exec(openTag);
  blocks.push({ kind, openTag, id: idm ? idm[1] : null, innerStart, innerEnd });
  pos = innerEnd + close.length;
}

// ---- 2. assign file names ----
const unnamedIdx = { style: 0, script: 0 };
blocks.forEach((b, i) => {
  b.num = String((i + 1) * 10).padStart(3, '0');
  const name = b.id || UNNAMED[b.kind][unnamedIdx[b.kind]++];
  if (!name) throw new Error('no name for unnamed ' + b.kind + ' #' + i);
  b.file = (b.kind === 'style' ? 'styles/' : 'scripts/') + b.num + '-' + name + (b.kind === 'style' ? '.css' : '.js');
});

// ---- 3. write block files, extracting data literals from scripts ----
for (const d of ['styles', 'scripts', 'data', 'panels']) fs.mkdirSync(path.join(SRC, d), { recursive: true });
const dataFound = {};
for (const b of blocks) {
  let inner = html.slice(b.innerStart, b.innerEnd);
  // keep a leading newline in index.html so the skeleton reads naturally
  b.lead = inner.startsWith('\n') ? '\n' : '';
  let body = inner.slice(b.lead.length);
  if (b.kind === 'script') {
    for (const name of DATA_NAMES) {
      const re = new RegExp('^(?:const|var|let) ' + name + ' ?= ?', 'm');
      const dm = re.exec(body);
      if (!dm) continue;
      const litStart = dm.index + dm[0].length;
      let litEnd;
      const lineEnd = body.indexOf('\n', litStart);
      if (body[lineEnd - 1] === ';') litEnd = lineEnd - 1;               // single-line literal
      else litEnd = body.indexOf('\n];', litStart) + 2;                   // multi-line array literal
      const literal = body.slice(litStart, litEnd);
      JSON.parse(literal); // must be plain JSON so it can live in a .json file
      const rel = 'data/' + name + '.json';
      fs.writeFileSync(path.join(SRC, rel), literal);
      body = body.slice(0, litStart) + '/*@include ' + rel + '*/' + body.slice(litEnd);
      dataFound[name] = { file: rel, block: b.file, bytes: Buffer.byteLength(literal) };
    }
  }
  fs.writeFileSync(path.join(SRC, b.file), body);
}
const missing = DATA_NAMES.filter(n => !dataFound[n]);
if (missing.length) throw new Error('data constants not found: ' + missing.join(','));

// ---- 4. build skeleton ----
let skel = '';
let last = 0;
for (const b of blocks) {
  skel += html.slice(last, b.innerStart) + b.lead + '<!--@include ' + b.file + '-->';
  last = b.innerEnd;
}
skel += html.slice(last);

// ---- 5. panels: <div class="panel" id="panel-..."> ... balanced </div> ----
const panels = [];
const pre = /^<div class="panel" id="(panel-[\w-]+)"/gm;
let pm;
const cuts = [];
while ((pm = pre.exec(skel))) {
  const start = pm.index;
  const tagRe = /<div\b|<\/div>|<!--|<script\b|<style\b/g;
  tagRe.lastIndex = start;
  let depth = 0, end = -1, t, safe = true;
  while ((t = tagRe.exec(skel))) {
    if (t[0] === '<div') depth++;
    else if (t[0] === '</div>') { depth--; if (depth === 0) { end = t.index + 6; break; } }
    else if (t[0] === '<!--') tagRe.lastIndex = skel.indexOf('-->', t.index) + 3; // comments are inert
    else { safe = false; break; } // a <script>/<style> inside a panel: leave that panel inline
  }
  if (!safe || end < 0) { console.warn('skipping ' + pm[1]); continue; }
  cuts.push({ id: pm[1], start, end });
}
let out = '', lp = 0;
cuts.forEach((c, i) => {
  const rel = 'panels/' + String(i + 1).padStart(2, '0') + '-' + c.id + '.html';
  fs.writeFileSync(path.join(SRC, rel), skel.slice(c.start, c.end));
  out += skel.slice(lp, c.start) + '<!--@include ' + rel + '-->';
  lp = c.end;
  panels.push(rel);
});
out += skel.slice(lp);
fs.writeFileSync(path.join(SRC, 'index.html'), out);

fs.writeFileSync(path.join(ROOT, 'tools', 'manifest.json'), JSON.stringify({
  blocks: blocks.map(b => ({ file: b.file, kind: b.kind, id: b.id, openTag: b.openTag,
    line: html.slice(0, b.innerStart).split('\n').length })),
  data: dataFound, panels,
}, null, 2) + '\n');
console.log(blocks.length + ' blocks, ' + Object.keys(dataFound).length + ' data files, ' + panels.length + ' panels');
