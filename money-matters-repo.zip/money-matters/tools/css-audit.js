#!/usr/bin/env node
/*
 * CSS audit for Money Matters
 *
 *   node tools/css-audit.js            report (exit 1 if anything is dead)
 *   node tools/css-audit.js --fix      remove the dead declarations in place
 *   node tools/css-audit.js --json     machine-readable report (used by tests/run.js)
 *
 * Reads the stylesheets in the order src/index.html includes them (that order
 * IS the cascade) and finds:
 *
 *   dead       a declaration that can never apply, because a LATER rule with the
 *              very same selector sets the same property, in the same @media
 *              context or at the top level, with equal or higher importance.
 *              Removing it cannot change what any browser shows. Kept on purpose:
 *                · fallbacks: the later value uses newer CSS (var(), dvh, clamp(),
 *                  min()/max(), env(), color-mix(), vendor prefixes...)
 *                · overrides by a rule a browser might drop (:has(), :is(), :where())
 *                · an !important declaration overridden by a normal one (it wins)
 *   keyframes  the same @keyframes name defined twice (only the last one is used)
 *   files      stylesheet names that carry a release number (v43-, v91-...):
 *              name a file for what it styles, not for when it was written
 *
 * No browser needed; depends only on postcss (devDependency).
 */
'use strict';
const fs = require('fs');
const path = require('path');
const postcss = require('postcss');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const args = process.argv.slice(2);
const FIX = args.includes('--fix');
const JSON_OUT = args.includes('--json');

/** Stylesheets in cascade order: every styles/*.css include, in index.html order. */
function sheetsInOrder() {
  const html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
  const re = /<!--@include (styles\/[^\s>]+?\.css)-->|\/\*@include (styles\/[^\s*]+?\.css)\*\//g;
  const out = []; let m;
  while ((m = re.exec(html))) { const rel = m[1] || m[2]; if (!out.includes(rel)) out.push(rel); }
  return out;
}

const NEWER_VALUE = /var\(|env\(|\b\d*\.?\d+(dvh|svh|lvh|dvw|svw|lvw|cqw|cqh|cqi|cqb)\b|clamp\(|\bmin\(|\bmax\(|color-mix\(|oklch\(|oklab\(|\blab\(|\blch\(|-webkit-|-moz-|-ms-|fit-content|max-content|min-content|\binset\b|light-dark\(|round\(|\bcalc-size/i;
const RISKY_SELECTOR = /:has\(|:is\(|:where\(|:modal|:popover-open|::backdrop|:user-invalid|:state\(/i;

function norm(s) { return s.replace(/\s+/g, ' ').replace(/\s*([>+~,])\s*/g, '$1').trim(); }
function splitList(sel) {
  const out = []; let depth = 0, cur = '', q = null;
  for (const ch of sel) {
    if (q) { cur += ch; if (ch === q) q = null; continue; }
    if (ch === '"' || ch === "'") { q = ch; cur += ch; continue; }
    if (ch === '(' || ch === '[') depth++;
    if (ch === ')' || ch === ']') depth--;
    if (ch === ',' && depth === 0) { out.push(norm(cur)); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) out.push(norm(cur));
  return out;
}
/** @media/@supports chain as a string; '' = top level. null = somewhere we don't analyse. */
function contextOf(node) {
  const parts = [];
  for (let p = node.parent; p && p.type !== 'root'; p = p.parent) {
    if (p.type !== 'atrule') return null;
    const n = p.name.toLowerCase();
    if (n === 'media' || n === 'supports') parts.unshift(n + ' ' + norm(p.params).toLowerCase());
    else return null;   /* @keyframes, @font-face, @page, @layer...: leave alone */
  }
  return parts.join(' / ');
}

function audit() {
  const files = sheetsInOrder();
  const roots = files.map(rel => {
    const css = fs.readFileSync(path.join(SRC, rel), 'utf8');
    return { rel, css, root: postcss.parse(css, { from: rel }) };
  });
  /* every analysable declaration, in cascade order */
  const decls = [];
  const keyframes = {};
  roots.forEach(({ rel, root }) => {
    root.walkAtRules(/keyframes$/i, a => { (keyframes[a.params.trim()] = keyframes[a.params.trim()] || []).push(rel); });
    root.walkDecls(d => {
      const rule = d.parent;
      if (!rule || rule.type !== 'rule') return;
      const ctx = contextOf(rule);
      if (ctx === null) return;
      decls.push({ rel, d, ctx, prop: d.prop.toLowerCase(), important: !!d.important,
        value: String(d.value), sels: splitList(rule.selector), riskyRule: RISKY_SELECTOR.test(rule.selector) });
    });
  });
  /* walk backwards, remembering the strongest later setter per (ctx, selector, prop) */
  const later = new Map();   /* key -> {important} for overrides that are safe to rely on */
  const dead = [];
  for (let i = decls.length - 1; i >= 0; i--) {
    const x = decls[i];
    const overridden = x.sels.every(s => {
      const hit = [later.get(x.ctx + '|' + s + '|' + x.prop), x.ctx ? later.get('|' + s + '|' + x.prop) : null];
      return hit.some(h => h && (h.important || !x.important));
    });
    if (overridden) dead.push(x);
    /* record this one as a setter later declarations... earlier ones can rely on */
    if (!x.riskyRule && !NEWER_VALUE.test(x.value)) {
      x.sels.forEach(s => {
        const k = x.ctx + '|' + s + '|' + x.prop, cur = later.get(k);
        if (!cur || (x.important && !cur.important)) later.set(k, { important: x.important });
      });
    }
  }
  const dupKeyframes = Object.keys(keyframes).filter(k => keyframes[k].length > 1).map(k => ({ name: k, files: keyframes[k] }));
  const versioned = files.filter(f => /(^|[-\/])v\d+(-\d+)?-/.test(path.basename(f)) || /-v\d+-/.test(f));
  const byFile = {};
  dead.forEach(x => { byFile[x.rel] = (byFile[x.rel] || 0) + 1; });
  return { files, roots, dead, byFile, dupKeyframes, versioned, total: decls.length };
}

const r = audit();
if (FIX && r.dead.length) {
  const touched = new Set();
  r.dead.forEach(x => { const rule = x.d.parent; x.d.remove(); touched.add(x.rel);
    if (rule && rule.nodes && !rule.nodes.some(n => n.type === 'decl')) {
      const keepComments = rule.nodes.filter(n => n.type === 'comment');
      let parent = rule.parent; rule.remove();
      while (parent && parent.type === 'atrule' && parent.nodes && parent.nodes.length === 0) { const pp = parent.parent; parent.remove(); parent = pp; }
      void keepComments;
    } });
  r.roots.forEach(({ rel, root }) => { if (touched.has(rel)) fs.writeFileSync(path.join(SRC, rel), root.toString()); });
}
if (JSON_OUT) {
  console.log(JSON.stringify({ total: r.total, dead: r.dead.length, byFile: r.byFile, dupKeyframes: r.dupKeyframes, versioned: r.versioned,
    sample: r.dead.slice(0, 20).map(x => ({ file: x.rel, selector: x.sels.join(','), prop: x.prop, value: x.value, ctx: x.ctx })) }));
} else {
  console.log(`${r.files.length} stylesheets, ${r.total} declarations`);
  console.log(`${r.dead.length} dead declarations${FIX ? ' removed' : ''}`);
  Object.keys(r.byFile).forEach(f => console.log('  ' + String(r.byFile[f]).padStart(5) + '  ' + f));
  if (r.dupKeyframes.length) console.log('duplicate @keyframes: ' + r.dupKeyframes.map(k => k.name + ' (' + k.files.join(', ') + ')').join('; '));
  if (r.versioned.length) console.log('release-numbered file names: ' + r.versioned.join(', '));
}
process.exitCode = (!FIX && (r.dead.length || r.versioned.length || r.dupKeyframes.length)) ? 1 : 0;
