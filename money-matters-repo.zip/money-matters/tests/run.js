#!/usr/bin/env node
/* =====================================================================
   Money Matters · end-to-end test suite
   One command:   npm test          (builds, then runs every test)
                  node tests/run.js [--only a,b] [--file path] [--shots dir] [--headed]
   Needs: Node 18+, Playwright with Chromium (`npx playwright install chromium`
   in CI), axe-core (devDependency) for the accessibility checks.
   Each test runs in a fresh browser context (empty storage). A test fails on
   a thrown assertion, a timeout, or any uncaught page error.
   Exit code: 0 when everything passes, 1 otherwise.
   ===================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const args = process.argv.slice(2);
const argOf = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const FILE = path.resolve(argOf('--file', path.join(__dirname, '..', 'dist', 'MoneyMatters.html')));
const URL = 'file://' + FILE;
const ONLY = (argOf('--only', '') || '').split(',').filter(Boolean);
const SHOTS = argOf('--shots', '');
const HEADED = args.includes('--headed');
const PW = 'Password123!';

/* ---------- tiny harness ---------- */
const tests = [];
const test = (name, fn, opts) => tests.push({ name, fn, timeout: (opts && opts.timeout) || 90000 });
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(a, b, msg) { if (a !== b) throw new Error((msg || 'expected equal') + ` (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`); }

/* ---------- helpers ---------- */
async function newPage(ctx, errs, vp) {
  const p = await ctx.newPage();
  if (vp) await p.setViewportSize(vp);
  p.on('pageerror', e => errs.push(e.message));
  return p;
}
async function load(p) {
  await p.goto(URL);
  await p.waitForSelector('#mm-auth', { state: 'attached', timeout: 15000 });
  await p.waitForTimeout(900);
}
/** First-run setup: creates the administrator and lands on the home screen. */
async function setupAdmin(p) {
  await load(p);
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'Test Admin');
  await p.fill('#s-p1', PW); await p.fill('#s-p2', PW);
  await p.selectOption('#s-sq1', { index: 1 });
  await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]');
  await p.waitForTimeout(1400);
  await quiet(p);
}
/** Dismiss first-run helpers so they don't cover what a test clicks. */
async function quiet(p) {
  await p.evaluate(() => {
    try { localStorage.setItem('mmSetupDone', '1'); localStorage.setItem('mmTourDone', '1'); } catch (e) {}
    try { endTour(); } catch (e) {}
    try { closePanel(true); } catch (e) {}
    document.querySelectorAll('.mmrt-ov').forEach(x => x.remove());
  });
}
async function addClass(p) {
  await p.evaluate(async (pw) => {
    const MM = window.MM91;
    await MM.accounts.add({ username: 'rivera', name: 'Ms. Rivera', role: 'teacher', scope: 'all', password: pw, by: 'test' });
    ['Ava Jones', 'Ben Lee', 'Cara Diaz', 'Dev Patel'].forEach(n => MM.data.createStudent(n, '4', 'Ms. Rivera'));
    MM.accounts.ensureStudents();
  }, PW);
}
/** Capture what MMPrint would print, instead of opening the print dialog. */
async function capture(p, fn) {
  await p.evaluate(() => { window.__printed = []; MMPrint.capture = h => { window.__printed.push(h); }; });
  await p.evaluate(fn);
  await p.waitForTimeout(150);
  return p.evaluate(() => window.__printed.slice());
}
function checkPrint(html, label) {
  assert(html && html.length > 800, `${label}: printout is empty`);
  assert(/@page/.test(html), `${label}: no @page rules (headers, footers, margins)`);
  assert(!/class="(mm-topbar|panel-header|nav-btn)/.test(html), `${label}: app chrome leaked into the printout`);
  assert(!/undefined|\[object Object\]|NaN/.test(html.replace(/<script[\s\S]*?<\/script>/g, '')), `${label}: contains undefined/NaN`);
}
async function shot(p, name) { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await p.screenshot({ path: path.join(SHOTS, name + '.png') }); } }

/* =====================================================================
   TESTS
   ===================================================================== */

test('build: single self-contained file', async () => {
  assert(fs.existsSync(FILE), 'dist file missing; run node build.js');
  const html = fs.readFileSync(FILE, 'utf8');
  assert(html.length > 3e6, 'built file is suspiciously small');
  assert(!/@include/.test(html), 'unresolved @include directive');
  assert(!/<script[^>]+src=["']https?:/i.test(html), 'external script found; the app must be self-contained');
  assert(!/<link[^>]+href=["']https?:[^>]+stylesheet/i.test(html), 'external stylesheet found');
  const csp = (html.match(/http-equiv="Content-Security-Policy"\s+content="([^"]+)"/i) || [])[1] || '';
  assert(/default-src 'self'/.test(csp), 'CSP default-src is not self');
  assert(/connect-src[^;]*supabase\.co/.test(csp), 'CSP does not allow the live-game server');
});

test('sign-in screen scales from 320px phones to 4K', async ({ ctx, errs }) => {
  const fieldAt = {};
  for (const [w, h] of [[320, 640], [390, 844], [768, 1024], [1366, 900], [1920, 1080], [3840, 2160]]) {
    const p = await newPage(ctx, errs, { width: w, height: h });
    await load(p);
    await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
    const m = await p.evaluate(() => {
      const g = document.getElementById('mm-auth'), r = g && g.getBoundingClientRect();
      const card = g && g.querySelector('input,button');
      return { shown: !!(g && !g.classList.contains('mm-hidden') && r.width > 0), over: document.documentElement.scrollWidth - innerWidth, field: card ? card.getBoundingClientRect().height : 0, font: card ? parseFloat(getComputedStyle(card).fontSize) : 0 };
    });
    assert(m.shown, `${w}px: sign-in gate not shown`);
    assert(m.over <= 1, `${w}px: page scrolls sideways by ${m.over}px`);
    assert(m.field >= 36, `${w}px: first control is only ${m.field}px tall`);
    fieldAt[w] = m.field;
    if (w >= 3840) assert(m.field >= fieldAt[1366] * 1.3, `4K: controls not scaled up (${m.field}px vs ${fieldAt[1366]}px at 1366)`);
    await shot(p, `signin-${w}`);
    await p.close();
  }
});

test('setup, teacher sign-in, teacher home', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  assert(await p.isVisible('#mm-topbar'), 'top bar missing after setup');
  await addClass(p);
  await p.evaluate(() => window.MM91.gate.signOut()); await p.waitForTimeout(500);
  await p.click('[data-a=as][data-v=staff]').catch(() => {});
  await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', PW);
  await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  const who = await p.evaluate(() => ({ name: MM91.auth.displayName(), role: MM91.auth.roleKey() }));
  eq(who.role, 'teacher', 'signed-in role');
  eq(who.name, 'Ms. Rivera', 'signed-in name');
  const home = await p.evaluate(() => { const h = document.getElementById('mm-home'); return h && h.offsetParent ? h.innerText : ''; });
  assert(/class today/i.test(home) && /students/i.test(home), 'teacher home screen (class today, students) not shown');
  assert((await p.innerText('#mm-topbar')).includes('Rivera'), 'teacher profile missing from the top bar');
  await shot(p, 'teacher-home');
});

test('wrong password locks out after the policy limit', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => window.MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=staff]').catch(() => {});
  for (let i = 0; i < 5; i++) { await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', 'wrong' + i); await p.click('[data-a=login]'); await p.waitForTimeout(250); }
  await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', PW); await p.click('[data-a=login]'); await p.waitForTimeout(600);
  assert(await p.evaluate(() => !MM91.auth.get()), 'correct password accepted during lockout');
  const stored = await p.evaluate(() => JSON.stringify(localStorage));
  assert(!stored.includes(PW), 'a password is stored in plain text');
});

test('every panel opens and closes without errors', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  const ids = await p.evaluate(() => [...document.querySelectorAll('.panel')].map(x => x.id.replace('panel-', '')).filter(x => x !== 'login'));
  assert(ids.length >= 20, 'expected 20+ panels, found ' + ids.length);
  for (const id of ids) {
    await p.evaluate(i => openPanel(i), id); await p.waitForTimeout(250);
    const st = await p.evaluate(i => { const el = document.getElementById('panel-' + i); return { open: el.classList.contains('open'), text: (el.innerText || '').trim().length }; }, id);
    /* staff-only legacy panels (teacher, students) now route to the Admin Console */
    const shown = st.open || await p.evaluate(() => !!document.querySelector('.panel.open'));
    assert(shown, `panel ${id} did not open`);
    if (st.open) assert(st.text > 20, `panel ${id} is empty`);
    await p.keyboard.press('Escape'); await p.waitForTimeout(150);
    await p.evaluate(() => { try { closePanel(true); } catch (e) {} });
  }
});

test('Game Show: every mode starts; Quiz Rush plays to the podium', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('4'); MMGameShow.open(); }); await p.waitForTimeout(400);
  assert(await p.isVisible('#mm-gs'), 'Game Show did not open');
  await shot(p, 'gs-lobby');
  for (const m of ['board', 'tf', 'order', 'cash', 'who', 'guess', 'cross', 'daily']) {
    await p.evaluate(mode => MMGameShow.open(mode), m); await p.waitForTimeout(500);
    const t = await p.evaluate(() => document.getElementById('mm-gs').innerText.length);
    assert(t > 60, `mode ${m} rendered nothing`);
    await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(150);
  }
  await p.evaluate(() => { MMGameShow.open(); }); await p.waitForTimeout(300);
  await p.selectOption('[data-gs=opt][data-m=rush][data-k=n]', { index: 0 }).catch(() => {});
  await p.click('[data-gs=start][data-m=rush]');
  /* host-paced: teams lock in, host reveals, then advances (leaderboard every few questions) */
  for (let step = 0; step < 120; step++) {
    if (await p.$('[data-gs=recap]')) break;
    const st = await p.evaluate(() => { const v = s => { const e = document.querySelector('#mm-gs ' + s); return !!(e && !e.hidden && !e.disabled && e.offsetParent); }; return { lb: v('[data-gs=lb-next]'), next: v('[data-gs=q-next]'), reveal: v('[data-gs=q-reveal]'), pick: v('[data-gs=pick]') }; });
    /* the screen moves on by itself once every team locks in, so a click can miss: retry next step */
    const tap = sel => p.click(sel, { timeout: 1500 }).catch(() => {});
    if (st.lb) await tap('[data-gs=lb-next]');
    else if (st.next) await tap('[data-gs=q-next]');
    else if (st.reveal) {
      if (st.pick) for (let t = 0; t < 2; t++) await tap(`[data-gs=pick][data-t="${t}"][data-k="${(step + t) % 4}"]`);
      await tap('#mm-gs [data-gs=q-reveal]:not([hidden])');
    }
    await p.waitForTimeout(400);
  }
  assert(await p.$('[data-gs=recap]'), 'Quiz Rush never reached the podium');
  await shot(p, 'gs-podium');
}, { timeout: 240000 });

test('Live play: host and two phones complete two questions', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('5'); MMGameShow.open(); }); await p.waitForTimeout(300);
  await p.click('[data-gs=live]'); await p.waitForTimeout(600);
  const link = await p.inputValue('.gl-link');
  assert(/#join-\w+/.test(link), 'join link has no PIN: ' + link);
  const players = [];
  for (const n of ['Ava', 'Ben']) {
    const q = await newPage(ctx, errs, { width: 390, height: 800 });
    await q.goto(link); await q.waitForSelector('#lp-nick', { timeout: 10000 });
    await q.fill('#lp-nick', n); await q.click('.lp-go'); await q.waitForTimeout(400);
    players.push(q);
  }
  await p.bringToFront(); await p.waitForTimeout(500);
  const chips = await p.$$eval('.gl-chip', x => x.map(c => c.textContent));
  assert(chips.some(c => c.includes('Ava')) && chips.some(c => c.includes('Ben')), 'players missing from the host lobby: ' + chips);
  await p.click('[data-gl=go]');
  for (let r = 0; r < 2; r++) {
    for (let i = 0; i < players.length; i++) { await players[i].waitForSelector('[data-lp=ans]', { timeout: 10000 }); await players[i].click(`[data-lp=ans][data-k="${i % 2}"]`); }
    await p.waitForSelector('#gl-next:not([hidden])', { timeout: 10000 });
    await p.click('#gl-next'); await p.waitForTimeout(300);
    if (await p.$('[data-gl=next2]')) await p.click('[data-gl=next2]');
    await p.waitForTimeout(300);
  }
  const score = await players[0].evaluate(() => document.getElementById('mm-lp').innerText);
  assert(/\$|\d/.test(score), 'player screen shows no score');
  await shot(players[0], 'live-phone');
});

test('Workshops: every grade and format renders; all printouts are well formed', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => openPanel('workshops')); await p.waitForTimeout(400);
  for (const g of ['K', '1', '2', '3', '4', '5', '6', '7', '8']) {
    await p.click(`[data-ws=grade][data-g="${g}"]`).catch(async () => { await p.evaluate(x => { const b = [...document.querySelectorAll('[data-ws=grade]')].find(b => b.textContent.trim() === x); b && b.click(); }, g); });
    await p.waitForTimeout(120);
    for (const n of [1, 2, 3, 4, 5]) {
      await p.click(`[data-ws=fmt][data-n="${n}"]`); await p.waitForTimeout(60);
      const days = await p.$$eval('[data-ws=day]', x => x.length);
      eq(days, n, `grade ${g}: ${n}-day format shows wrong number of days`);
    }
    const chips = await p.evaluate(() => document.getElementById('workshopsBody').innerText);
    assert(/Spending|Saving|Earning|Investing|Credit|Risk/.test(chips), `grade ${g}: no standards shown`);
  }
  for (const [btn, label] of [['guide', 'facilitator guide'], ['passport', 'passport']]) {
    const out = await capture(p, new Function(`document.querySelector('[data-ws=${btn}]').click()`));
    assert(out.length, label + ' did not print'); checkPrint(out[0], label);
  }
  await p.fill('#ws-cname', 'Ava Jones');
  const cert = await capture(p, () => document.querySelector('[data-ws=cert-one]').click());
  assert(cert.length && cert[0].includes('Ava Jones'), 'certificate missing the student name'); checkPrint(cert[0], 'certificate');
  await p.click('[data-ws=grade][data-g="4"]').catch(() => {}); await p.waitForTimeout(150);
  await p.click('[data-ws=tab][data-t=results]'); await p.waitForTimeout(200);
  for (const btn of ['p-check', 'p-key', 'p-results']) {
    const out = await capture(p, new Function(`document.querySelector('[data-ws=${btn}]').click()`));
    assert(out.length, btn + ' did not print'); checkPrint(out[0], btn);
  }
  await shot(p, 'workshops');
}, { timeout: 180000 });

test('Lesson printouts: plan, worksheet, key, family letter, packet, workbook, guide', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('4'); openDoc('plan'); }); await p.waitForTimeout(300);
  for (const k of ['plan', 'worksheet', 'key', 'family', 'packet', 'workbook', 'guide']) {
    const out = await capture(p, new Function(`MMPrint.doc('${k}')`));
    assert(out.length, k + ' did not print'); checkPrint(out[0], k);
    if (k === 'plan') assert(/Learning objective|Objective/i.test(out[0]), 'plan missing objective');
    if (k === 'key') assert(/answer/i.test(out[0]), 'answer key has no answers');
    if (k === 'workbook') assert((out[0].match(/class="[^"]*\bdivider\b/g) || []).length >= 6, 'workbook is missing unit dividers');
    if (k === 'guide') assert((out[0].match(/class="page"/g) || []).length >= 72, 'teacher guide does not cover all 36 weeks');
  }
  await p.evaluate(() => closePanel(true));
});

test('Resource Guide: links are valid, filters work, guide prints', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  const data = await p.evaluate(() => MMResources.data);
  assert(data.resources.length >= 50, 'fewer than 50 resources');
  const urls = data.resources.map(r => r.url);
  urls.forEach(u => assert(/^https:\/\/[^\s]+\.[a-z]{2,}/i.test(u), 'bad URL: ' + u));
  eq(new Set(urls).size, urls.length, 'duplicate resource URLs');
  await p.evaluate(() => openPanel('resources')); await p.waitForTimeout(300);
  const all = await p.$$eval('#panel-resources a[href^="https"]', x => x.length);
  assert(all >= 50, 'resource links not rendered');
  const ext = await p.$$eval('#panel-resources a[href^="https"]', x => x.every(a => a.target === '_blank' && /noopener/.test(a.rel)));
  assert(ext, 'outside links must open in a new tab with rel=noopener');
  const out = await capture(p, () => MMResources.print(false));
  checkPrint(out[0], 'resource guide');
  assert((out[0].match(/<svg/g) || []).length >= 50, 'resource guide is missing QR codes');
});

test('Spanish and Portuguese: game show, workshops and printouts translate', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  for (const [lang, title, ws, page] of [['es', 'Apréndelo', 'Talleres de dinero', 'Página'], ['pt', 'Aprenda', 'Oficinas', 'Página']]) {
    await p.evaluate(l => { setLang(l); setGrade('4'); MMGameShow.open(); }, lang); await p.waitForTimeout(500);
    const t = await p.evaluate(() => document.getElementById('mm-gs').innerText);
    assert(t.includes(title), `${lang}: game show lobby not translated`);
    await p.evaluate(() => { MMGameShow.close(); openPanel('workshops'); }); await p.waitForTimeout(500);
    const w = await p.evaluate(() => document.getElementById('panel-workshops').innerText);
    assert(w.includes(ws), `${lang}: workshops panel not translated`);
    await p.evaluate(() => { closePanel(true); openDoc('plan'); }); await p.waitForTimeout(200);
    const out = await capture(p, () => MMPrint.doc('plan'));
    assert(out[0].includes(page), `${lang}: printout footer not translated`);
    assert(!/Lesson plan<|Learning objective</.test(out[0]), `${lang}: English headings left in printout`);
    await p.evaluate(() => closePanel(true));
  }
  await p.evaluate(() => setLang('en'));
});

test('Privacy, Security, Terms and FAQ are current', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await load(p);
  const t = await p.evaluate(() => document.getElementById('panel-legal').textContent);
  assert(!/no accounts/i.test(t), 'privacy policy still says there are no accounts');
  assert(!/Teacher\/Parent\/Parent/.test(t), 'FAQ typo is back');
  assert(/Last updated: October 26, 2026/.test(t), 'last-updated date missing');
  for (const s of ['Supabase', 'Resource Guide', 'salted SHA-256', 'not strong security', 'reviewed by an attorney']) assert(t.includes(s), 'legal text missing: ' + s);
  for (const id of ['privacy', 'security', 'terms', 'faq']) assert(await p.$('#legal-' + id), 'missing legal tab ' + id);
});

test('Accessibility: no critical or serious axe violations; Escape and focus return work', async ({ ctx, errs }) => {
  const axe = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
  const p = await newPage(ctx, errs);
  const run = async (label, sel) => {
    await p.addScriptTag({ content: axe }).catch(() => {});
    const r = await p.evaluate(async s => {
      const res = await axe.run(s ? document.querySelector(s) : document, { resultTypes: ['violations'], rules: { 'color-contrast': { enabled: true } } });
      return res.violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length }));
    }, sel);
    const bad = r.filter(v => v.impact === 'critical' || v.impact === 'serious');
    assert(!bad.length, `${label}: axe violations ${JSON.stringify(bad)}`);
    return r;
  };
  await load(p); await p.click('#consent-accept-btn').catch(() => {});
  const report = { signin: await run('sign-in', '#mm-auth') };
  await setupAdmin(p);
  report.home = await run('home', null);
  await p.evaluate(() => MMGameShow.open()); await p.waitForTimeout(300);
  report.gameshow = await run('game show', '#mm-gs');
  await p.evaluate(() => MMGameShow.close());
  for (const id of ['workshops', 'resources', 'legal']) {
    await p.evaluate(i => openPanel(i), id); await p.waitForTimeout(300);
    report[id] = await run(id, '#panel-' + id);
    await p.evaluate(() => closePanel(true));
  }
  /* keyboard: open a panel from a focused control, Escape closes it, focus returns */
  await p.evaluate(() => { const b = document.createElement('button'); b.id = '__opener'; b.textContent = 'open'; b.onclick = () => openPanel('help'); document.body.appendChild(b); b.focus(); });
  await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  assert(await p.evaluate(() => document.getElementById('panel-help').classList.contains('open')), 'Enter did not open the panel');
  assert(await p.evaluate(() => document.getElementById('scene') ? document.getElementById('scene').hasAttribute('inert') : true), 'background is not inert under an open panel');
  await p.keyboard.press('Escape'); await p.waitForTimeout(400);
  assert(await p.evaluate(() => !document.querySelector('.panel.open')), 'Escape did not close the panel');
  const minor = Object.entries(report).flatMap(([k, v]) => v.map(x => `${k}:${x.id}(${x.n})`));
  if (minor.length) console.log('      note: moderate/minor axe findings: ' + minor.join(', '));
});

test('Financial Literacy Assessment: a student starts, answers every question and gets a result', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  const stu = await p.evaluate(() => { const s = Object.values(loadStore().list)[0]; return { u: MM91.accounts.forStudent(s.id).u, c: MM91.data.codeOf(s) }; });
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=student]').catch(() => {});
  await p.fill('#mm55-user', stu.u); await p.fill('#mm55-pass', stu.c); await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  eq(await p.evaluate(() => MM91.auth.roleKey()), 'student', 'student sign-in');
  await p.evaluate(() => openPanel('assessment')); await p.waitForTimeout(400);
  await p.click('#assessmentBody button:has-text("Start")');
  for (let i = 0; i < 40; i++) {
    const fin = await p.$('#assessmentBody button:has-text("Finish"):not([disabled])');
    if (fin) { await fin.click(); break; }
    const opt = await p.$('#assessmentBody .mm-assess-option'); assert(opt, 'no answer options shown (question ' + (i + 1) + ')');
    await opt.click(); await p.waitForTimeout(80);
    const next = await p.$('#assessmentBody button:has-text("Next"):not([disabled])'); if (next) await next.click();
    await p.waitForTimeout(80);
  }
  await p.waitForTimeout(400);
  const t = await p.innerText('#assessmentBody');
  assert(/level|score|%/i.test(t), 'no result after finishing: ' + t.slice(0, 120));
});

test('Dead-button fixes: quiz practice for staff, reports without data, school dialogs close with Escape', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => { setGrade('4'); openPanel('quiz'); }); await p.waitForTimeout(700);
  assert(await p.$('#quizForm .mm-key-banner .mm-key-toggle'), 'no "Try this quiz as a student" switch in the answer-key view');
  await p.click('#quizForm .mm-key-toggle'); await p.waitForTimeout(300);
  const opt = await p.$('#quizForm .mc-opt'); await opt.click({ timeout: 2000 });
  assert(await p.evaluate(() => Object.keys(quizSel).length === 1), 'practice mode: a real click on an answer did not select it');
  const before = await p.evaluate(() => JSON.stringify(loadStore().stats || {}));
  await p.evaluate(() => { quizQs.forEach((q, i) => { quizSel[i] = 0; }); submitQuiz(); }); await p.waitForTimeout(300);
  eq(await p.evaluate(() => JSON.stringify(loadStore().stats || {})), before, 'practice answers changed the class question statistics');
  assert(/%/.test(await p.innerText('#quizPrize')), 'practice quiz shows no score');
  await p.evaluate(() => closePanel(true));
  await p.evaluate(() => { openPanel('admin'); setTimeout(() => MM91.admin.open('reports'), 60); }); await p.waitForTimeout(600);
  await p.click('#adminMain [data-act=missed]'); await p.waitForTimeout(400);
  assert(await p.isVisible('#mm-modal-backdrop.open'), '"Open report" with no data showed nothing (native alert)');
  await p.click('#mm-modal-btns button'); await p.waitForTimeout(200);
  await p.evaluate(() => MM91.admin.open('students')); await p.waitForTimeout(500);
  const b = await p.$('#adminMain button:has-text("Class join codes")'); await b.focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  assert(await p.$('.mmrt-ov .mmrt-box[aria-labelledby]'), 'school dialog has no accessible name');
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  assert(!(await p.$('.mmrt-ov')), 'Escape did not close the school dialog');
  eq(await p.evaluate(() => document.activeElement && document.activeElement.textContent.trim().slice(0, 20)), '🔑 Class join codes', 'focus did not return to the opener');
  assert(await p.evaluate(() => +getComputedStyle(document.getElementById('info-toast')).zIndex > 2147483000), 'confirmations sit under school dialogs');
});

test('Every open panel takes real clicks (nothing behind it, or around it, is inert)', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => setGrade('4'));
  for (const id of ['lessons', 'overview', 'doc', 'quiz', 'path', 'glossary', 'games', 'workshops', 'resources', 'materials', 'admin', 'legal', 'feedback']) {
    await p.evaluate(i => { closePanel(true); if (i === 'doc') openDoc('plan'); else openPanel(i); }, id); await p.waitForTimeout(500);
    const r = await p.evaluate(i => { const el = document.getElementById('panel-' + i); if (!el || !el.classList.contains('open')) return 'not open';
      if (el.closest('[inert]')) return 'panel is inside an inert element';
      const b = [...el.querySelectorAll('.panel-body button, .panel-body [onclick], .panel-body a[href]')].find(x => { const r = x.getBoundingClientRect(); const pr = el.querySelector('.panel-body').getBoundingClientRect(); return r.width && r.height && r.top > pr.top && r.bottom < pr.bottom; });
      if (!b) return 'no visible button';
      const r = b.getBoundingClientRect(), hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
      return b.contains(hit) || hit === b ? 'ok' : 'blocked by ' + (hit ? (hit.id || hit.tagName) : 'nothing'); }, id);
    eq(r, 'ok', `panel ${id}`);
  }
  await p.evaluate(() => { closePanel(true); openPanel('lessons'); }); await p.waitForTimeout(500);
  const b = await p.$('#panel-lessons .panel-body button:visible'); await b.click({ timeout: 2000 });
});

test('Workshop Run mode: timer, team points, back and next, Game Show round trip, finish marks the class complete', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => { setGrade('4'); openPanel('workshops'); }); await p.waitForTimeout(500);
  await p.click('[data-ws=fmt][data-n="3"]'); await p.waitForTimeout(200);
  await p.click('[data-ws=run]'); await p.waitForTimeout(400);
  assert(await p.isVisible('#ws-run'), 'Run mode did not open');
  assert(await p.evaluate(() => !!document.querySelector('.panel.open').closest('[inert]') || document.querySelector('.panel.open').hasAttribute('inert')), 'the panel behind Run mode is still focusable');
  eq(await p.innerText('.wr-clock b'), '15:00', 'first activity timer');
  await p.keyboard.press('Space'); await p.waitForTimeout(1600);
  assert((await p.innerText('.wr-clock b')) < '15:00', 'Space did not start the timer');
  if (!(await p.$('.wr-teams[open]'))) await p.click('.wr-teams summary');
  await p.click('[data-wr=pt][data-t="1"][data-v="1"]'); await p.click('[data-wr=pt][data-t="1"][data-v="1"]');
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(300);
  assert(/2 of|2 de/.test(await p.innerText('.wr-title b')), 'ArrowRight did not advance');
  await p.click('[data-wr=prev]'); await p.waitForTimeout(200); await p.click('[data-wr=next]'); await p.waitForTimeout(200);
  const gi = await p.evaluate(() => [...document.querySelectorAll('.wr-dots button')].findIndex(b => /Game Show/.test(b.getAttribute('aria-label'))));
  assert(gi >= 0, 'no Game Show activity in the day');
  await p.click(`.wr-dots button >> nth=${gi}`); await p.waitForTimeout(200);
  await p.click('[data-wr=game]'); await p.waitForTimeout(800);
  assert(await p.evaluate(() => document.documentElement.classList.contains('mm-gs-on') && document.getElementById('ws-run').hidden), 'Game Show did not open over Run mode');
  await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(500);
  assert(await p.isVisible('#ws-run'), 'Run mode did not come back after the Game Show');
  const n = await p.$$eval('.wr-dots button', x => x.length);
  await p.click(`.wr-dots button >> nth=${n - 1}`); await p.waitForTimeout(200);
  await p.click('[data-wr=finish]'); await p.waitForTimeout(300);
  assert(/Team 2/.test(await p.innerText('#ws-run')), 'finish screen does not name the winning team');
  const out = await capture(p, () => document.querySelector('[data-wr=allcert]').click());
  await p.waitForTimeout(600);
  assert(out.length || (await p.evaluate(() => window.__printed && window.__printed.length)), 'certificates were not printed');
  const st = await p.evaluate(() => { const s = JSON.parse(localStorage.getItem('mmWorkshop_v1')); return { done: Object.values(s.done || {}).length, run: Object.keys(s.run || {}).length }; });
  assert(st.done >= 4 && st.run >= 1, 'class completion or run state not saved: ' + JSON.stringify(st));
  assert(!(await p.isVisible('#ws-run')), 'Run mode still open after printing certificates');
  assert(await p.$$eval('#workshopsBody .ws-donemark', x => x.length) > 0, 'finished activities not ticked on the plan');
});

test('Materials Center: every lesson and workshop material has a source; printables are well formed', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  const cov = await p.evaluate(() => { let n = 0, other = 0; const seen = (m) => { n++; const c = MMMaterials.classify(m); if (c.type === 'supply' && c.key === 'other') other++; };
    Object.values(LESSONS).forEach(ls => ls.forEach(l => (l.materials || []).forEach(seen))); Object.values(WS_DATA).forEach(w => w.modules.forEach(m => m.blocks.forEach(b => (b.materials || []).forEach(seen)))); return { n, other }; });
  assert(cov.n > 2000, 'material count'); assert(cov.other / cov.n < 0.05, `too many unclassified materials: ${cov.other} of ${cov.n}`);
  for (const [m, want] of [['play money bills', 'money'], ['play coins', 'coins'], ['blank pay stubs', 'paystub'], ['check registers', 'register'], ['practice W-4 forms', 'w4'], ['calculators', 'calculators'], ['whiteboard and markers', 'whiteboards'], ['Gross pay independent worksheet', 'docs'], ['need and want cards', 'needwant']]) eq(await p.evaluate(x => MMMaterials.classify(x).key, m), want, 'classify ' + m);
  await p.evaluate(() => { setGrade('4'); openPanel('lessons'); }); await p.waitForTimeout(700);
  const hook = await p.$('#panel-lessons .mtc-hook [data-mt=open]'); assert(hook, 'no "Get these materials" link in the lesson'); await hook.scrollIntoViewIfNeeded(); await hook.click(); await p.waitForTimeout(400);
  assert(await p.isVisible('#panel-materials.open'), 'Materials Center did not open'); assert(/Print it here/.test(await p.innerText('#materialsBody')), 'lesson plan has no printables section');
  await p.click('[data-mt=tab][data-t=ws]'); await p.waitForTimeout(300); assert(/Workshop day/.test(await p.innerText('#materialsBody')), 'workshop tab empty');
  for (const g of ['K', '4', '7']) {
    await p.evaluate(x => setGrade(x), g);
    for (const k of await p.evaluate(() => Object.keys(MMMaterials.GEN))) {
      const out = await capture(p, new Function(`MMMaterials.printOne('${k}','${g}')`)); assert(out.length, `${k} (${g}) did not print`); checkPrint(out[0], `printable ${k} grade ${g}`);
      if (k === 'money') { assert(/NOT REAL MONEY/.test(out[0]), 'play money is not marked as not real'); assert(!/Federal Reserve Note|In God We Trust|United States of America/i.test(out[0]), 'play money imitates real currency'); }
    }
  }
  const letter = await capture(p, () => document.querySelector('#materialsBody [data-mt=letter]').click()); checkPrint(letter[0], 'family supply letter');
  await p.click('[data-mt=tab][data-t=sources]'); await p.waitForTimeout(300);
  const links = await p.$$eval('#materialsBody a[href^="https"]', x => x.map(a => ({ h: a.href, t: a.target, r: a.rel })));
  assert(links.length >= 6 && links.every(l => l.t === '_blank' && /noopener/.test(l.r)), 'official sources missing or not opening safely');
});

test('Phone: the tour never covers sign-in; home cards and top bar have 40px targets', async ({ ctx, errs }) => {
  const c2 = await ctx.browser().newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const p = await newPage(c2, errs);
  await load(p); await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'A'); await p.fill('#s-p1', PW); await p.fill('#s-p2', PW); await p.selectOption('#s-sq1', { index: 1 }); await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]'); await p.waitForTimeout(300);
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(2500);
  assert(!(await p.$('#mm-coach.on')), 'phone tour opened over the sign-in screen');
  await p.click('[data-a=login]', { timeout: 2000 });
  await p.fill('#mm55-user', 'admin'); await p.fill('#mm55-pass', PW); await p.click('[data-a=login]'); await p.waitForTimeout(1500);
  await quiet(p); await p.evaluate(() => { localStorage.setItem('mmPhoneTourDone', '1'); const c = document.getElementById('mm-coach'); c && c.classList.remove('on'); closePanel(true); }); await p.waitForTimeout(400);
  const small = await p.evaluate(() => [...document.querySelectorAll('#mm-topbar button, #mm-home .mm-home-card button')].filter(b => { const r = b.getBoundingClientRect(); return r.width && r.height && r.height < 39.5; }).map(b => (b.innerText || b.getAttribute('aria-label') || b.title || b.className || '').trim().slice(0, 30) + ' ' + Math.round(b.getBoundingClientRect().height) + ' ' + (b.closest('#mm-topbar') ? 'top' : 'card')));
  eq(small.length, 0, 'small tap targets: ' + small.join(', '));
  /* signing out on a phone with a panel open must not freeze the page (V21 regression) */
  await p.evaluate(() => openPanel('path')); await p.waitForTimeout(400);
  const r = await Promise.race([p.evaluate(() => { const t = performance.now(); MM91.gate.signOut(); return performance.now() - t; }), new Promise(res => setTimeout(() => res('froze'), 6000))]);
  assert(r !== 'froze' && r < 2000, 'phone sign-out froze or was slow: ' + r);
  await c2.close();
});

test('Spanish: Run mode and the Materials Center translate', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setLang('es'); setGrade('4'); openPanel('workshops'); }); await p.waitForTimeout(600);
  await p.click('[data-ws=run]'); await p.waitForTimeout(900);
  const t = await p.innerText('#ws-run');
  assert(/puntos del equipo/i.test(t) && /siguiente/i.test(t), 'Run mode not translated: ' + t.slice(0, 200));
  await p.keyboard.press('Escape');
  await p.evaluate(() => { closePanel(true); MMMaterials.open({ tab: 'library' }); }); await p.waitForTimeout(900);
  assert(/Dinero de juguete/i.test(await p.innerText('#materialsBody')), 'Materials Center not translated');
  await p.evaluate(() => setLang('en'));
});

/* ---------- hosted (public) build: served from a fake origin with a mock /api/content ---------- */
const PUBLIC_FILE = path.join(__dirname, '..', 'dist', 'public', 'index.html');
const PACK_DIR = path.join(__dirname, '..', 'dist', 'content');
const ORIGIN = 'https://mm.test';
async function hosted(ctx, errs, { code, api, routes } = {}) {
  assert(fs.existsSync(PUBLIC_FILE), 'public build missing; run node build.js --public');
  const html = fs.readFileSync(PUBLIC_FILE, 'utf8');
  const calls = [];
  await ctx.route(ORIGIN + '/**', async route => {
    const u = new globalThis.URL(route.request().url());
    if (u.pathname === '/api/content') {
      calls.push({ auth: route.request().headers()['authorization'] || '', v: u.searchParams.get('v') });
      if (api) return api(route);
      return route.fulfill({ status: 401, contentType: 'application/json', body: '{"error":"unknown access code"}' });
    }
    if (routes && routes[u.pathname]) return routes[u.pathname](route, calls);
    if (u.pathname === '/' || u.pathname === '/index.html') return route.fulfill({ status: 200, contentType: 'text/html', body: html });
    /* other static files from dist/public (ads.json, ads/*, sw.js) */
    const f = path.join(path.dirname(PUBLIC_FILE), u.pathname.replace(/^\/+/, ''));
    if (f.startsWith(path.dirname(PUBLIC_FILE)) && fs.existsSync(f) && fs.statSync(f).isFile()) return route.fulfill({ status: 200, body: fs.readFileSync(f), contentType: /\.json$/.test(f) ? 'application/json' : /\.svg$/.test(f) ? 'image/svg+xml' : /\.js$/.test(f) ? 'text/javascript' : 'application/octet-stream' });
    return route.fulfill({ status: 404, body: '' });
  });
  if (code) await ctx.addInitScript(c => { try { if (!sessionStorage.getItem('__seeded')) { localStorage.setItem('mmAccess_v1', c); sessionStorage.setItem('__seeded', '1'); } } catch (e) {} }, code);
  const p = await newPage(ctx, errs);
  await p.goto(ORIGIN + '/');
  await p.waitForSelector('#mm-auth', { state: 'attached', timeout: 15000 }); await p.waitForTimeout(900);
  return { p, calls };
}
function fullPacks() {
  const man = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'manifest.json'), 'utf8'));
  let body = '{"__label":"Lincoln Elementary","__expires":"2027-07-31T23:59:59Z","__version":' + JSON.stringify(man.version);
  man.packs.forEach(k => { body += ',' + JSON.stringify(k) + ':' + fs.readFileSync(path.join(PACK_DIR, k + '.json'), 'utf8'); });
  return body + '}';
}
async function setupHosted(p) {
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'Test Admin'); await p.fill('#s-p1', PW); await p.fill('#s-p2', PW);
  await p.selectOption('#s-sq1', { index: 1 }); await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]'); await p.waitForTimeout(1400); await quiet(p);
}

test('Hosted build: page ships week 1 only; locked content is not in it', async () => {
  const html = fs.readFileSync(PUBLIC_FILE, 'utf8');
  const L = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'LESSONS.json'), 'utf8'));
  const W = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'WS_DATA.json'), 'utf8'));
  for (const g of Object.keys(L)) {
    assert(html.includes(JSON.stringify(L[g][0].objective).slice(1, -1)), `grade ${g}: week 1 missing from the free page`);
    for (const w of [1, 10, 35]) { const obj = L[g][w].objective; if (obj && obj.length > 25) assert(!html.includes(JSON.stringify(obj).slice(1, -1)), `grade ${g} week ${w + 1} objective leaked into the free page`); }
    const how = W[g].modules[0].blocks[0].how; if (how && how.length > 25) assert(!html.includes(JSON.stringify(how).slice(1, -1)), `grade ${g} workshop plan leaked into the free page`);
  }
  assert(/window\.MM_PUBLIC_BUILD=true/.test(html), 'public build flag missing');
  assert(fs.statSync(PUBLIC_FILE).size < fs.statSync(FILE).size * 0.6, 'public page is not much smaller than the full build');
  for (const f of ['sw.js', '_headers']) assert(fs.existsSync(path.join(path.dirname(PUBLIC_FILE), f)), f + ' missing from dist/public');
});

test('Hosted free edition: week 1 opens, the rest asks for an access code', async ({ ctx, errs }) => {
  const { p, calls } = await hosted(ctx, errs);
  eq(calls.length, 0, 'free edition should not call /api/content');
  await setupHosted(p);
  const st = await p.evaluate(() => ({ lic: MMLicense.licensed, n: LESSONS['4'].length, w1: !!LESSONS['4'][0].objective, w2: LESSONS['4'][1].locked === true, unlock: !!document.querySelector('[data-lic=unlock]') }));
  assert(!st.lic, 'free edition reports licensed'); eq(st.n, 36, 'week list length'); assert(st.w1 && st.w2, 'week 1 should be full and week 2 a placeholder');
  assert(st.unlock, 'staff top bar has no Unlock button');
  await p.evaluate(() => { setGrade('4'); openPanel('lessons'); }); await p.waitForTimeout(300);
  await p.evaluate(() => gotoLesson(3)); await p.waitForTimeout(300);
  assert(await p.isVisible('#mm-subscribe.open'), 'week 4 did not show the unlock dialog');
  assert((await p.innerText('#mm-subscribe')).includes('Enter access code'), 'unlock dialog has no access-code button');
  await p.evaluate(() => { document.getElementById('mm-subscribe').classList.remove('open'); closePanel(true); });
  for (const fn of ["openTestMenu()", "MMPrint.doc('workbook')", "MMPrint.doc('guide')"]) {
    await p.evaluate(f => { (new Function(f))(); }, fn); await p.waitForTimeout(250);
    assert(await p.isVisible('#mm-subscribe.open'), fn + ' was not locked');
    await p.evaluate(() => document.getElementById('mm-subscribe').classList.remove('open'));
  }
  await p.evaluate(() => openPanel('workshops')); await p.waitForTimeout(400);
  assert(await p.$('#workshopsBody .ws-lock'), 'workshops are not locked');
  await p.evaluate(() => closePanel(true));
  const out = await capture(p, () => { openDoc('plan'); MMPrint.doc('plan'); });
  checkPrint(out[0], 'free week 1 lesson plan');
  await p.evaluate(() => { closePanel(true); setLang('es'); }); await p.waitForTimeout(300);
  assert(await p.evaluate(() => !!(LESSONS_L.es['4'][0].objective && LESSONS_L.es['4'][1].locked)), 'Spanish week 1 should be free and week 2 locked');
  await p.evaluate(() => setLang('en'));
  await p.evaluate(() => MMGameShow.open('rush')); await p.waitForTimeout(3500);
  assert((await p.evaluate(() => document.getElementById('mm-gs').innerText.length)) > 60, 'Game Show did not start on week-1 content');
  await p.evaluate(() => MMGameShow.close());
});

test('Hosted licensed: a valid code loads every week, workshops and tests', async ({ ctx, errs }) => {
  const body = fullPacks();
  const { p, calls } = await hosted(ctx, errs, { code: 'MM-TEST-CODE-0001', api: r => r.fulfill({ status: 200, contentType: 'application/json', headers: { 'Cache-Control': 'private, max-age=604800' }, body }) });
  assert(calls.length >= 1, '/api/content was not called');
  eq(calls[0].auth, 'Bearer MM-TEST-CODE-0001', 'access code not sent');
  const man = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'manifest.json'), 'utf8'));
  eq(calls[0].v, man.version, 'content version not sent');
  await setupHosted(p);
  const st = await p.evaluate(() => ({ lic: MMLicense.licensed, label: MMLicense.label, w20: !!LESSONS['4'][19].objective, es: !!LESSONS_L.es['4'][19].objective, tests: SECTION_TESTS['4'][0].questions.length, unlock: !!document.querySelector('[data-lic=unlock]') }));
  assert(st.lic, 'not licensed'); eq(st.label, 'Lincoln Elementary', 'license label');
  assert(st.w20 && st.es && st.tests > 0, 'full content did not load');
  assert(!st.unlock, 'Unlock button shown while licensed');
  await p.evaluate(() => { setGrade('4'); openPanel('lessons'); gotoLesson(19); }); await p.waitForTimeout(400);
  assert(!(await p.isVisible('#mm-subscribe.open')), 'licensed week 20 still locked');
  await p.evaluate(() => { closePanel(true); openPanel('workshops'); }); await p.waitForTimeout(400);
  assert(!(await p.$('#workshopsBody .ws-lock')) && (await p.$$('[data-ws=day]')).length > 0, 'licensed workshops still locked');
});

test('Hosted: a revoked code falls back to the free edition and is forgotten', async ({ ctx, errs }) => {
  const { p } = await hosted(ctx, errs, { code: 'MM-OLD-CODE-0001', api: r => r.fulfill({ status: 403, contentType: 'application/json', body: '{"error":"access code expired"}' }) });
  const st = await p.evaluate(() => ({ lic: MMLicense.licensed, code: localStorage.getItem('mmAccess_v1'), err: !!window.__MM_ACCESS_ERR }));
  assert(!st.lic && st.err, 'revoked code not handled'); eq(st.code, null, 'revoked code still stored');
});

const AUTH_CONFIG = { auth: { url: 'https://proj.supabase.co', key: 'sb_publishable_test', providers: ['google', 'azure', 'facebook'] } };
const cfgRoute = (r) => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(AUTH_CONFIG) });

test('Sign in with Google/Microsoft/Facebook: buttons for adults only; a verified email signs in and unlocks', async ({ ctx, errs }) => {
  const body = fullPacks();
  const { p, calls } = await hosted(ctx, errs, {
    routes: { '/api/config': cfgRoute },
    api: r => /^Bearer MMD1\./.test(r.request().headers()['authorization'] || '') ? r.fulfill({ status: 200, contentType: 'application/json', body }) : r.fulfill({ status: 401, contentType: 'application/json', body: '{}' })
  });
  await setupHosted(p);
  await p.evaluate(async (pw) => { await MM91.accounts.add({ username: 'rivera', name: 'Ms. Rivera', email: 'Rivera@Lincoln.k12.us', role: 'teacher', scope: 'all', password: pw, by: 't' }); MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); MM91.accounts.ensureStudents(); }, PW);
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(600);
  await p.click('[data-a=as][data-v=student]').catch(() => {}); await p.waitForTimeout(300);
  assert(!(await p.$('#mm-auth .mm-social')), 'social sign-in shown on the student side');
  await p.click('[data-a=as][data-v=staff]'); await p.waitForTimeout(400);
  const btns = await p.$$eval('#mm-auth [data-social]', x => x.map(b => b.textContent.trim()));
  assert(btns.some(t => /Google/.test(t)) && btns.some(t => /Microsoft/.test(t)) && btns.some(t => /Facebook/.test(t)), 'provider buttons missing: ' + btns);
  await shot(p, 'social-signin');
  /* the provider round trip itself happens on Google/Supabase; test what the page does with the verified result */
  const ok = await p.evaluate(() => MMSocial._finish({ email: 'rivera@lincoln.k12.us', name: 'Ms. Rivera', provider: 'google', licensed: true, label: 'Lincoln', token: 'MMD1.eyJsIjoiTDEifQ.sig' }));
  assert(ok, 'verified email did not sign in');
  eq(await p.evaluate(() => MM91.auth.get() && MM91.auth.get().u), 'rivera', 'signed in to the matching account');
  eq(await p.evaluate(() => localStorage.getItem('mmAccess_v1')), 'MMD1.eyJsIjoiTDEifQ.sig', 'device token not stored');
  await p.waitForTimeout(2500); /* the page reloads to fetch the licensed content (signed in, so no sign-in screen) */
  await p.waitForFunction(() => window.MMLicense && window.MM91 && document.readyState === 'complete', null, { timeout: 15000 }); await p.waitForTimeout(900);
  assert(await p.evaluate(() => MMLicense.licensed && !!LESSONS['4'][19].objective), 'device token did not unlock the full program');
  assert(calls.some(c => /^Bearer MMD1\./.test(c.auth)), '/api/content was not called with the device token');
  eq(await p.evaluate(() => MM91.auth.roleKey()), 'teacher', 'still signed in after the reload');
});

test('Sign in with Google on a new device makes the administrator; an unknown email is refused', async ({ ctx, errs }) => {
  const { p } = await hosted(ctx, errs, { routes: { '/api/config': cfgRoute } });
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  assert(await p.$('#mm-auth [data-a=dosetup]'), 'first-run setup not shown');
  await p.waitForTimeout(400);
  assert(await p.$('#mm-auth .mm-social [data-social=google]'), 'Google button missing on first-run setup');
  assert(await p.evaluate(() => MMSocial._finish({ email: 'principal@lincoln.k12.us', name: 'Dr. Ames', provider: 'google', licensed: false, reason: 'No school license covers principal@lincoln.k12.us yet.' })), 'first sign-in did not create the administrator');
  eq(await p.evaluate(() => MM91.auth.roleKey()), 'admin', 'first person to sign in is the administrator');
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(500);
  const ok = await p.evaluate(() => MMSocial._finish({ email: 'stranger@gmail.com', name: 'X', provider: 'facebook', licensed: false }));
  assert(!ok, 'unknown email was signed in');
  assert(/Ask your administrator/.test(await p.innerText('#mm-auth')), 'no guidance for an unknown email');
});

test('Ads: sponsor cards for adults on the free edition only; never for students, in games, or when licensed', async ({ ctx, errs }) => {
  const ads = JSON.parse(fs.readFileSync(path.join(path.dirname(PUBLIC_FILE), 'ads.json'), 'utf8')); ads.enabled = true;
  const adsRoute = r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ads) });
  const { p } = await hosted(ctx, errs, { routes: { '/ads.json': adsRoute } });
  await setupHosted(p);
  await p.evaluate(() => closePanel(true)); await p.waitForTimeout(4500);
  assert(await p.$('#mm-staff-home [data-ad=home]'), 'no sponsor card on the adult home screen');
  assert(await p.evaluate(() => { const a = document.querySelector('[data-ad=home]'); a.scrollIntoView({ block: 'center' }); const r = a.getBoundingClientRect(); const e = document.elementFromPoint(r.x + r.width / 2, r.y + 20); return a.contains(e); }), 'sponsor card is hidden behind other content');
  const link = await p.$eval('#mm-staff-home [data-ad=home] a', a => ({ href: a.href, rel: a.rel, target: a.target }));
  assert(/^https:/.test(link.href) && /sponsored/.test(link.rel) && /noopener/.test(link.rel) && link.target === '_blank', 'sponsor link is not https / rel=sponsored noopener');
  await shot(p, 'ad-home'); if (SHOTS) { const bb = await p.evaluate(() => { const r = document.querySelector('[data-ad=home]').getBoundingClientRect(); return { x: r.x - 12, y: r.y - 12, width: r.width + 24, height: r.height + 24 }; }); await p.screenshot({ path: path.join(SHOTS, 'ad-card.png'), clip: bb }); }
  await p.evaluate(() => MMGameShow.open()); await p.waitForTimeout(600);
  assert(!(await p.$('[data-ad]:not([hidden])')) || !(await p.isVisible('[data-ad]')), 'ad visible during the Game Show');
  await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(400);
  await p.evaluate(() => openPanel('resources')); await p.waitForTimeout(4500);
  assert(await p.$('#panel-resources [data-ad=resources]'), 'no sponsor card in the Resource Guide');
  await p.click('#panel-resources [data-ad-hide=resources]'); await p.waitForTimeout(200);
  assert(!(await p.$('#panel-resources [data-ad=resources]')), 'hide did not remove the ad');
  await p.evaluate(() => closePanel(true));
  /* a student never sees one */
  await p.evaluate(async () => { MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); MM91.accounts.ensureStudents(); });
  const stu = await p.evaluate(() => { const s = Object.values(loadStore().list)[0]; return { u: MM91.accounts.forStudent(s.id).u, c: MM91.data.codeOf(s) }; });
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=student]').catch(() => {});
  await p.fill('#mm55-user', stu.u); await p.fill('#mm55-pass', stu.c); await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  await p.waitForTimeout(4500);
  eq(await p.$$eval('[data-ad]', x => x.length), 0, 'a student saw an ad');
  eq(await p.evaluate(() => MMAds.eligible('home')), false, 'ads eligible for a student');
});

test('Ads: a licensed school sees none', async ({ ctx, errs }) => {
  const ads = JSON.parse(fs.readFileSync(path.join(path.dirname(PUBLIC_FILE), 'ads.json'), 'utf8')); ads.enabled = true;
  const body = fullPacks();
  const { p } = await hosted(ctx, errs, { code: 'MM-TEST-CODE-0001', routes: { '/ads.json': r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ads) }) }, api: r => r.fulfill({ status: 200, contentType: 'application/json', body }) });
  await setupHosted(p); await p.waitForTimeout(4500);
  eq(await p.$$eval('[data-ad]', x => x.length), 0, 'licensed school saw an ad');
});

test('Cloudflare functions: social sign-in tokens (/api/link, renewal, tampering, expiry)', async () => {
  const lib = await import(path.join(__dirname, '..', 'lib', 'mm-server.mjs'));
  const link = await import(path.join(__dirname, '..', 'functions', 'api', 'link.js'));
  const content = await import(path.join(__dirname, '..', 'functions', 'api', 'content.js'));
  const config = await import(path.join(__dirname, '..', 'functions', 'api', 'config.js'));
  const db = { licenses: [{ id: 'L1', label: 'Lincoln', active: true, starts_at: '2026-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z', email_domain: 'lincoln.k12.us', emails: [] }, { id: 'L2', label: 'Home', active: false, starts_at: '2026-01-01T00:00:00Z', expires_at: null, email_domain: null, emails: ['mom@gmail.com'] }], packs: [{ key: 'LESSONS', version: 'v1', data: { K: [] } }] };
  const users = { 'jwt.teacher.x': { email: 'Rivera@Lincoln.k12.us', user_metadata: { full_name: 'Ms. Rivera' }, app_metadata: { provider: 'google' } }, 'jwt.mom.x': { email: 'mom@gmail.com', user_metadata: { name: 'Mom' }, app_metadata: { provider: 'facebook' } }, 'jwt.noemail.x': { email: '', user_metadata: {}, app_metadata: { provider: 'facebook' } } };
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    const u = new globalThis.URL(url);
    if (u.pathname === '/auth/v1/user') { const t = ((init.headers || {}).Authorization || '').replace('Bearer ', ''); return users[t] ? new Response(JSON.stringify(users[t]), { status: 200 }) : new Response('{}', { status: 401 }); }
    if (init && init.method === 'POST') return new Response(null, { status: 201 });
    if (u.pathname.endsWith('/licenses')) {
      const or = u.searchParams.get('or'), id = (u.searchParams.get('id') || '').replace('eq.', '');
      let rows = db.licenses;
      if (id) rows = rows.filter(l => l.id === id);
      else if (or) { const em = (or.match(/emails\.cs\.\{"([^"]+)"\}/) || [])[1], dm = (or.match(/email_domain\.eq\."([^"]+)"/) || [])[1]; rows = rows.filter(l => l.emails.includes(em) || l.email_domain === dm); }
      return new Response(JSON.stringify(rows), { status: 200 });
    }
    if (u.pathname.endsWith('/content_packs')) return new Response(JSON.stringify(db.packs), { status: 200 });
    return new Response('[]', { status: 404 });
  };
  const env = { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_test', SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_test', MM_TOKEN_SECRET: 'x'.repeat(40) };
  const post = async (jwt) => { const w = []; const r = await link.onRequestPost({ request: new Request('https://mm.test/api/link', { method: 'POST', headers: jwt ? { Authorization: 'Bearer ' + jwt } : {} }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  const get = async (auth) => { const w = []; const r = await content.onRequestGet({ request: new Request('https://mm.test/api/content?v=v1', { headers: { Authorization: 'Bearer ' + auth } }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  try {
    eq((await post('')).status, 401, 'no sign-in');
    eq((await post('jwt.bad.x')).status, 401, 'bad Supabase token');
    eq((await post('jwt.noemail.x')).status, 400, 'account without email');
    const t = await (await post('jwt.teacher.x')).json();
    eq(t.email, 'rivera@lincoln.k12.us', 'email lower-cased'); assert(t.licensed && /^MMD1\./.test(t.token), 'domain license did not issue a token'); eq(t.label, 'Lincoln', 'label');
    const mom = await (await post('jwt.mom.x')).json();
    assert(!mom.licensed && !mom.token && /disabled/.test(mom.reason), 'disabled license must not issue a token: ' + JSON.stringify(mom));
    eq((await get(t.token)).status, 200, 'device token loads content');
    const parts = t.token.split('.'); const forged = parts[0] + '.' + parts[1].slice(0, -2) + 'AA.' + parts[2];
    eq((await get(forged)).status, 401, 'tampered token accepted');
    const old = await lib.signToken(env, { l: 'L1', e: 'a@b', x: Date.now() - 1000 });
    eq((await get(old)).status, 401, 'expired token accepted');
    const soon = await lib.signToken(env, { l: 'L1', e: 'a@b', x: Date.now() + 2 * 86400000 });
    const rn = await get(soon); eq(rn.status, 200, 'near-expiry token');
    assert(/^MMD1\./.test(rn.headers.get('X-MM-Token') || ''), 'near-expiry token was not renewed');
    const other = Object.assign({}, env, { MM_TOKEN_SECRET: 'y'.repeat(40) });
    eq((await content.onRequestGet({ request: new Request('https://mm.test/api/content', { headers: { Authorization: 'Bearer ' + t.token } }), env: other, waitUntil: () => {} })).status, 401, 'token signed with another secret accepted');
    const cfgOff = await (await config.onRequestGet({ env: { SUPABASE_URL: 'https://x.supabase.co' } })).json();
    eq(cfgOff.auth, null, 'config should be off without a publishable key');
    const cfgOn = await (await config.onRequestGet({ env })).json();
    assert(cfgOn.auth && cfgOn.auth.providers.join() === 'google,azure,facebook' && !JSON.stringify(cfgOn).includes('sb_secret'), 'config wrong or leaks the secret key');
  } finally { globalThis.fetch = realFetch; }
});

test('Cloudflare function: codes, expiry, caching and outages', async () => {
  const mod = await import(path.join(__dirname, '..', 'functions', 'api', 'content.js'));
  const hash = await mod.sha256(mod.normalize('MM-GOOD-CODE-0001'));
  const db = { licenses: [{ id: 'L1', code_hash: hash, label: 'Lincoln', active: true, starts_at: '2026-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z' }, { id: 'L2', code_hash: await mod.sha256(mod.normalize('MM-OLD-CODE-0001')), label: 'Old', active: true, starts_at: '2020-01-01T00:00:00Z', expires_at: '2021-01-01T00:00:00Z' }], packs: [{ key: 'LESSONS', version: 'abc123', data: { K: [1] } }] };
  let up = true, sbCalls = 0;
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    sbCalls++;
    if (!up) throw new Error('down');
    const u = new globalThis.URL(url);
    if (init && init.method === 'POST') return new Response(null, { status: 201 });
    if (u.pathname.endsWith('/licenses')) { const h = (u.searchParams.get('code_hash') || '').replace('eq.', ''); return new Response(JSON.stringify(db.licenses.filter(l => l.code_hash === h)), { status: 200, headers: { 'Content-Type': 'application/json' } }); }
    if (u.pathname.endsWith('/content_packs')) return new Response(JSON.stringify(db.packs), { status: 200, headers: { 'Content-Type': 'application/json' } });
    return new Response('[]', { status: 404 });
  };
  const kv = new Map();
  const env = { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_test', MM_KV: { get: async (k, t) => kv.has(k) ? (t === 'json' ? JSON.parse(kv.get(k)) : kv.get(k)) : null, put: async (k, v) => { kv.set(k, v); } } };
  const call = async (code, v) => { const w = []; const r = await mod.onRequestGet({ request: new Request('https://mm.test/api/content' + (v ? '?v=' + v : ''), { headers: code ? { Authorization: 'Bearer ' + code } : {} }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  try {
    eq((await call('')).status, 401, 'no code');
    eq((await call('MM-NOPE-NOPE-NOPE')).status, 401, 'unknown code');
    eq((await call('MM-OLD-CODE-0001')).status, 403, 'expired code');
    const ok = await call('mm good code 0001', 'abc123');
    eq(ok.status, 200, 'good code (normalized)');
    const j = await ok.json(); eq(j.__label, 'Lincoln', 'label'); assert(j.LESSONS && j.LESSONS.K, 'packs missing');
    assert(/private, max-age=\d+/.test(ok.headers.get('Cache-Control')), 'no private cache header');
    const before = sbCalls; eq((await call('MM-GOOD-CODE-0001', 'abc123')).status, 200, 'second call');
    assert(sbCalls - before <= 1, 'second call should be served from KV (only the usage log hits Supabase)');
    up = false;
    eq((await call('MM-GOOD-CODE-0001', 'abc123')).status, 200, 'Supabase down: a recently valid code should still work from KV');
    kv.clear(); eq((await call('MM-GOOD-CODE-0001', 'abc123')).status, 503, 'Supabase down with nothing cached should be 503, not 401');
  } finally { globalThis.fetch = realFetch; }
});

/* =====================================================================
   RUNNER
   ===================================================================== */
(async () => {
  const pick = ONLY.length ? tests.filter(t => ONLY.some(o => t.name.toLowerCase().includes(o.toLowerCase()))) : tests;
  const browser = await chromium.launch({ headless: !HEADED });
  let failed = 0; const t0 = Date.now();
  console.log(`Money Matters tests · ${pick.length} of ${tests.length} · ${path.relative(process.cwd(), FILE)}\n`);
  for (const t of pick) {
    const ctx = await browser.newContext({ viewport: { width: 1366, height: 900 } });
    const errs = []; const s = Date.now();
    let err = null;
    try {
      await Promise.race([t.fn({ ctx, errs }), new Promise((_, rej) => setTimeout(() => rej(new Error(`timed out after ${t.timeout / 1000}s`)), t.timeout))]);
      if (errs.length) throw new Error('uncaught page errors: ' + JSON.stringify([...new Set(errs)].slice(0, 5)));
    } catch (e) { err = e; }
    await ctx.close().catch(() => {});
    const ms = ((Date.now() - s) / 1000).toFixed(1) + 's';
    if (err) { failed++; console.log(`  ✗ ${t.name}  (${ms})\n      ${String(err.message).split('\n')[0]}`); }
    else console.log(`  ✓ ${t.name}  (${ms})`);
  }
  await browser.close();
  console.log(`\n${pick.length - failed} passed, ${failed} failed · ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  process.exit(failed ? 1 : 0);
})();
