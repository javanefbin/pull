#!/usr/bin/env node
/* =====================================================================
   Money Matters · end-to-end test suite
   One command:   npm test          (builds, then runs every test)
                  node tests/run.js [--only a,b] [--file path] [--shots dir] [--headed]
   Needs: Node 18+, Playwright with Chromium (`npx playwright install chromium`
   in CI), axe-core (devDependency) for the accessibility checks.
   Each test runs in a fresh browser context (empty storage). A test fails on
   a thrown assertion, a timeout, or any uncaught page error.
   Exit code: 0 when everything passes, 1 otherwise.
   ===================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const args = process.argv.slice(2);
const argOf = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const FILE = path.resolve(argOf('--file', path.join(__dirname, '..', 'dist', 'MoneyMatters.html')));
const URL = 'file://' + FILE;
const ONLY = (argOf('--only', '') || '').split(',').filter(Boolean);
const SHOTS = argOf('--shots', '');
const HEADED = args.includes('--headed');
const PW = 'Password123!';

/* ---------- tiny harness ---------- */
const tests = [];
const test = (name, fn, opts) => tests.push({ name, fn, timeout: (opts && opts.timeout) || 90000 });
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(a, b, msg) { if (a !== b) throw new Error((msg || 'expected equal') + ` (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`); }

/* ---------- helpers ---------- */
async function newPage(ctx, errs, vp) {
  const p = await ctx.newPage();
  if (vp) await p.setViewportSize(vp);
  p.on('pageerror', e => errs.push(e.message));
  return p;
}
async function load(p) {
  await p.goto(URL);
  await p.waitForSelector('#mm-auth', { state: 'attached', timeout: 15000 });
  await p.waitForTimeout(900);
}
/** First-run setup: creates the administrator and lands on the home screen. */
async function setupAdmin(p) {
  await load(p);
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'Test Admin');
  await p.fill('#s-p1', PW); await p.fill('#s-p2', PW);
  await p.selectOption('#s-sq1', { index: 1 });
  await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]');
  await p.waitForTimeout(1400);
  await quiet(p);
}
/** Dismiss first-run helpers so they don't cover what a test clicks. */
async function quiet(p) {
  await p.evaluate(() => {
    try { localStorage.setItem('mmSetupDone', '1'); localStorage.setItem('mmTourDone', '1'); } catch (e) {}
    try { endTour(); } catch (e) {}
    try { closePanel(true); } catch (e) {}
    document.querySelectorAll('.mmrt-ov').forEach(x => x.remove());
  });
}
async function addClass(p) {
  await p.evaluate(async (pw) => {
    const MM = window.MM91;
    await MM.accounts.add({ username: 'rivera', name: 'Ms. Rivera', role: 'teacher', scope: 'all', password: pw, by: 'test' });
    ['Ava Jones', 'Ben Lee', 'Cara Diaz', 'Dev Patel'].forEach(n => MM.data.createStudent(n, '4', 'Ms. Rivera'));
    MM.accounts.ensureStudents();
  }, PW);
}
/** Capture what MMPrint would print, instead of opening the print dialog. */
async function capture(p, fn) {
  await p.evaluate(() => { window.__printed = []; MMPrint.capture = h => { window.__printed.push(h); }; });
  await p.evaluate(fn);
  await p.waitForTimeout(150);
  return p.evaluate(() => window.__printed.slice());
}
function checkPrint(html, label) {
  assert(html && html.length > 800, `${label}: printout is empty`);
  assert(/@page/.test(html), `${label}: no @page rules (headers, footers, margins)`);
  assert(!/class="(mm-topbar|panel-header|nav-btn)/.test(html), `${label}: app chrome leaked into the printout`);
  assert(!/undefined|\[object Object\]|NaN/.test(html.replace(/<script[\s\S]*?<\/script>/g, '')), `${label}: contains undefined/NaN`);
}
async function shot(p, name) { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await p.screenshot({ path: path.join(SHOTS, name + '.png') }); } }

/* =====================================================================
   TESTS
   ===================================================================== */

test('build: single self-contained file', async () => {
  assert(fs.existsSync(FILE), 'dist file missing; run node build.js');
  const html = fs.readFileSync(FILE, 'utf8');
  assert(html.length > 3e6, 'built file is suspiciously small');
  assert(!/@include/.test(html), 'unresolved @include directive');
  assert(!/<script[^>]+src=["']https?:/i.test(html), 'external script found; the app must be self-contained');
  assert(!/<link[^>]+href=["']https?:[^>]+stylesheet/i.test(html), 'external stylesheet found');
  const csp = (html.match(/http-equiv="Content-Security-Policy"\s+content="([^"]+)"/i) || [])[1] || '';
  assert(/default-src 'self'/.test(csp), 'CSP default-src is not self');
  assert(/connect-src[^;]*supabase\.co/.test(csp), 'CSP does not allow the live-game server');
});

test('Code health: no dead CSS, no release-numbered source files, no script looks up its own tag id', async () => {
  const r = JSON.parse(require('child_process').execFileSync(process.execPath, [path.join(__dirname, '..', 'tools', 'css-audit.js'), '--json'], { encoding: 'utf8' }).trim().split('\n').pop());
  assert(r.dead === 0, r.dead + ' CSS declarations can never apply (run node tools/css-audit.js --fix): ' + JSON.stringify(r.sample.slice(0, 3)));
  assert(!r.dupKeyframes.length, 'duplicate @keyframes: ' + JSON.stringify(r.dupKeyframes));
  const src = path.join(__dirname, '..', 'src');
  const named = ['scripts', 'styles'].flatMap(d => fs.readdirSync(path.join(src, d)).map(f => d + '/' + f)).filter(f => /(^|\/)\d+-(mm-)?v\d+/.test(f));
  assert(!named.length, 'name source files for what they do, not the release: ' + named.join(', '));
  /* a script that checks for an element with its own <script id> always finds itself (V21 found one) */
  const html = fs.readFileSync(path.join(src, 'index.html'), 'utf8'), re = /<script id="([^"]+)">\s*<!--@include (scripts\/[^\s>]+)-->/g; let m; const self = [];
  while ((m = re.exec(html))) { const code = fs.readFileSync(path.join(src, m[2]), 'utf8'); if (code.includes("'" + m[1] + "'") || code.includes('"' + m[1] + '"')) self.push(m[2]); }
  assert(!self.length, 'script looks up its own tag id: ' + self.join(', '));
});

test('sign-in screen scales from 320px phones to 4K', async ({ ctx, errs }) => {
  const fieldAt = {};
  for (const [w, h] of [[320, 640], [390, 844], [768, 1024], [1366, 900], [1920, 1080], [3840, 2160]]) {
    const p = await newPage(ctx, errs, { width: w, height: h });
    await load(p);
    await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
    const m = await p.evaluate(() => {
      const g = document.getElementById('mm-auth'), r = g && g.getBoundingClientRect();
      const card = g && g.querySelector('input,button');
      return { shown: !!(g && !g.classList.contains('mm-hidden') && r.width > 0), over: document.documentElement.scrollWidth - innerWidth, field: card ? card.getBoundingClientRect().height : 0, font: card ? parseFloat(getComputedStyle(card).fontSize) : 0 };
    });
    assert(m.shown, `${w}px: sign-in gate not shown`);
    assert(m.over <= 1, `${w}px: page scrolls sideways by ${m.over}px`);
    assert(m.field >= 36, `${w}px: first control is only ${m.field}px tall`);
    fieldAt[w] = m.field;
    if (w >= 3840) assert(m.field >= fieldAt[1366] * 1.3, `4K: controls not scaled up (${m.field}px vs ${fieldAt[1366]}px at 1366)`);
    await shot(p, `signin-${w}`);
    await p.close();
  }
});

test('setup, teacher sign-in, teacher home', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  assert(await p.isVisible('#mm-topbar'), 'top bar missing after setup');
  await addClass(p);
  await p.evaluate(() => window.MM91.gate.signOut()); await p.waitForTimeout(500);
  await p.click('[data-a=as][data-v=staff]').catch(() => {});
  await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', PW);
  await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  const who = await p.evaluate(() => ({ name: MM91.auth.displayName(), role: MM91.auth.roleKey() }));
  eq(who.role, 'teacher', 'signed-in role');
  eq(who.name, 'Ms. Rivera', 'signed-in name');
  /* V23: teachers get the staff dashboard (the classroom home is for students) */
  const home = await p.evaluate(() => { const v = id => { const h = document.getElementById(id); return h && getComputedStyle(h).display !== 'none' && getComputedStyle(h).visibility !== 'hidden' ? h.innerText : ''; }; return v('mm-staff-home') || v('mm-home'); });
  assert(/class today/i.test(home) && /students/i.test(home), 'teacher home screen (class today, students) not shown');
  assert((await p.innerText('#mm-topbar')).includes('Rivera'), 'teacher profile missing from the top bar');
  await shot(p, 'teacher-home');
});

test('wrong password locks out after the policy limit', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => window.MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=staff]').catch(() => {});
  for (let i = 0; i < 5; i++) { await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', 'wrong' + i); await p.click('[data-a=login]'); await p.waitForTimeout(250); }
  await p.fill('#mm55-user', 'rivera'); await p.fill('#mm55-pass', PW); await p.click('[data-a=login]'); await p.waitForTimeout(600);
  assert(await p.evaluate(() => !MM91.auth.get()), 'correct password accepted during lockout');
  const stored = await p.evaluate(() => JSON.stringify(localStorage));
  assert(!stored.includes(PW), 'a password is stored in plain text');
});

test('every panel opens and closes without errors', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  const ids = await p.evaluate(() => [...document.querySelectorAll('.panel')].map(x => x.id.replace('panel-', '')).filter(x => x !== 'login'));
  assert(ids.length >= 20, 'expected 20+ panels, found ' + ids.length);
  for (const id of ids) {
    await p.evaluate(i => openPanel(i), id); await p.waitForTimeout(250);
    const st = await p.evaluate(i => { const el = document.getElementById('panel-' + i); return { open: el.classList.contains('open'), text: (el.innerText || '').trim().length }; }, id);
    /* staff-only legacy panels (teacher, students) now route to the Admin Console */
    const shown = st.open || await p.evaluate(() => !!document.querySelector('.panel.open'));
    assert(shown, `panel ${id} did not open`);
    if (st.open) assert(st.text > 20, `panel ${id} is empty`);
    await p.keyboard.press('Escape'); await p.waitForTimeout(150);
    await p.evaluate(() => { try { closePanel(true); } catch (e) {} });
  }
});

test('Game Show: every mode starts; Quiz Rush plays to the podium', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('4'); MMGameShow.open(); }); await p.waitForTimeout(400);
  assert(await p.isVisible('#mm-gs'), 'Game Show did not open');
  await shot(p, 'gs-lobby');
  for (const m of ['board', 'tf', 'order', 'cash', 'who', 'guess', 'cross', 'daily']) {
    await p.evaluate(mode => MMGameShow.open(mode), m); await p.waitForTimeout(500);
    const t = await p.evaluate(() => document.getElementById('mm-gs').innerText.length);
    assert(t > 60, `mode ${m} rendered nothing`);
    await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(150);
  }
  await p.evaluate(() => { MMGameShow.open(); }); await p.waitForTimeout(300);
  await p.selectOption('[data-gs=opt][data-m=rush][data-k=n]', { index: 0 }).catch(() => {});
  await p.click('[data-gs=start][data-m=rush]');
  /* host-paced: teams lock in, host reveals, then advances (leaderboard every few questions) */
  for (let step = 0; step < 120; step++) {
    if (await p.$('[data-gs=recap]')) break;
    const st = await p.evaluate(() => { const v = s => { const e = document.querySelector('#mm-gs ' + s); return !!(e && !e.hidden && !e.disabled && e.offsetParent); }; return { lb: v('[data-gs=lb-next]'), next: v('[data-gs=q-next]'), reveal: v('[data-gs=q-reveal]'), pick: v('[data-gs=pick]') }; });
    /* the screen moves on by itself once every team locks in, so a click can miss: retry next step */
    const tap = sel => p.click(sel, { timeout: 1500 }).catch(() => {});
    if (st.lb) await tap('[data-gs=lb-next]');
    else if (st.next) await tap('[data-gs=q-next]');
    else if (st.reveal) {
      if (st.pick) for (let t = 0; t < 2; t++) await tap(`[data-gs=pick][data-t="${t}"][data-k="${(step + t) % 4}"]`);
      await tap('#mm-gs [data-gs=q-reveal]:not([hidden])');
    }
    await p.waitForTimeout(400);
  }
  assert(await p.$('[data-gs=recap]'), 'Quiz Rush never reached the podium');
  await shot(p, 'gs-podium');
}, { timeout: 240000 });

test('Live play: host and two phones complete two questions', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('5'); MMGameShow.open(); }); await p.waitForTimeout(300);
  await p.click('[data-gs=live]'); await p.waitForTimeout(600);
  const link = await p.inputValue('.gl-link');
  assert(/#join-\w+/.test(link), 'join link has no PIN: ' + link);
  const players = [];
  for (const n of ['Ava', 'Ben']) {
    const q = await newPage(ctx, errs, { width: 390, height: 800 });
    await q.goto(link); await q.waitForSelector('#lp-nick', { timeout: 10000 });
    await q.fill('#lp-nick', n); await q.click('.lp-go'); await q.waitForTimeout(400);
    players.push(q);
  }
  await p.bringToFront(); await p.waitForTimeout(500);
  const chips = await p.$$eval('.gl-chip', x => x.map(c => c.textContent));
  assert(chips.some(c => c.includes('Ava')) && chips.some(c => c.includes('Ben')), 'players missing from the host lobby: ' + chips);
  await p.click('[data-gl=go]');
  for (let r = 0; r < 2; r++) {
    for (let i = 0; i < players.length; i++) { await players[i].waitForSelector('[data-lp=ans]', { timeout: 10000 }); await players[i].click(`[data-lp=ans][data-k="${i % 2}"]`); }
    await p.waitForSelector('#gl-next:not([hidden])', { timeout: 10000 });
    await p.click('#gl-next'); await p.waitForTimeout(300);
    if (await p.$('[data-gl=next2]')) await p.click('[data-gl=next2]');
    await p.waitForTimeout(300);
  }
  const score = await players[0].evaluate(() => document.getElementById('mm-lp').innerText);
  assert(/\$|\d/.test(score), 'player screen shows no score');
  await shot(players[0], 'live-phone');
});

test('Workshops: every grade and format renders; all printouts are well formed', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => openPanel('workshops')); await p.waitForTimeout(400);
  for (const g of ['K', '1', '2', '3', '4', '5', '6', '7', '8']) {
    await p.click(`[data-ws=grade][data-g="${g}"]`).catch(async () => { await p.evaluate(x => { const b = [...document.querySelectorAll('[data-ws=grade]')].find(b => b.textContent.trim() === x); b && b.click(); }, g); });
    await p.waitForTimeout(120);
    for (const n of [1, 2, 3, 4, 5]) {
      await p.click(`[data-ws=fmt][data-n="${n}"]`); await p.waitForTimeout(60);
      const days = await p.$$eval('[data-ws=day]', x => x.length);
      eq(days, n, `grade ${g}: ${n}-day format shows wrong number of days`);
    }
    /* V23: the Express workshop is one 60–90 minute session that touches every themed day */
    await p.click('[data-ws=fmt][data-n="6"]'); await p.waitForTimeout(60);
    eq(await p.$$eval('[data-ws=day]', x => x.length), 0, `grade ${g}: Express is one session (no day tabs)`);
    assert(/express session/i.test(await p.innerText('.ws-dayhead')), `grade ${g}: Express session heading missing`);
    const ex = await p.evaluate(x => { const D = wsCompose(WS_DATA[x], x, 6, 0); return { total: D.total, mods: [...new Set(D.blocks.filter(b => b.mod != null).map(b => b.mod))].length }; }, g);
    assert(ex.total >= 60 && ex.total <= 90, `grade ${g}: Express runs ${ex.total} min`);
    eq(ex.mods, 5, `grade ${g}: Express should cover all five themed days`);
    const exGuide = await capture(p, () => document.querySelector('[data-ws=guide]').click());
    assert(exGuide.length, `grade ${g}: Express facilitator guide did not print`); checkPrint(exGuide[0], 'express guide');
    const chips = await p.evaluate(() => document.getElementById('workshopsBody').innerText);
    assert(/Spending|Saving|Earning|Investing|Credit|Risk/.test(chips), `grade ${g}: no standards shown`);
  }
  for (const [btn, label] of [['guide', 'facilitator guide'], ['passport', 'passport']]) {
    const out = await capture(p, new Function(`document.querySelector('[data-ws=${btn}]').click()`));
    assert(out.length, label + ' did not print'); checkPrint(out[0], label);
  }
  await p.fill('#ws-cname', 'Ava Jones');
  const cert = await capture(p, () => document.querySelector('[data-ws=cert-one]').click());
  assert(cert.length && cert[0].includes('Ava Jones'), 'certificate missing the student name'); checkPrint(cert[0], 'certificate');
  await p.click('[data-ws=grade][data-g="4"]').catch(() => {}); await p.waitForTimeout(150);
  await p.click('[data-ws=tab][data-t=results]'); await p.waitForTimeout(200);
  for (const btn of ['p-check', 'p-key', 'p-results']) {
    const out = await capture(p, new Function(`document.querySelector('[data-ws=${btn}]').click()`));
    assert(out.length, btn + ' did not print'); checkPrint(out[0], btn);
  }
  await shot(p, 'workshops');
}, { timeout: 180000 });

test('Lesson printouts: plan, worksheet, key, family letter, packet, workbook, guide', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setGrade('4'); openDoc('plan'); }); await p.waitForTimeout(300);
  for (const k of ['plan', 'worksheet', 'key', 'family', 'packet', 'workbook', 'guide']) {
    const out = await capture(p, new Function(`MMPrint.doc('${k}')`));
    assert(out.length, k + ' did not print'); checkPrint(out[0], k);
    if (k === 'plan') assert(/Learning objective|Objective/i.test(out[0]), 'plan missing objective');
    if (k === 'key') assert(/answer/i.test(out[0]), 'answer key has no answers');
    if (k === 'workbook') assert((out[0].match(/class="[^"]*\bdivider\b/g) || []).length >= 6, 'workbook is missing unit dividers');
    if (k === 'guide') assert((out[0].match(/class="page"/g) || []).length >= 72, 'teacher guide does not cover all 36 weeks');
  }
  await p.evaluate(() => closePanel(true));
});

test('Resource Guide: links are valid, filters work, guide prints', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  const data = await p.evaluate(() => MMResources.data);
  assert(data.resources.length >= 50, 'fewer than 50 resources');
  const urls = data.resources.map(r => r.url);
  urls.forEach(u => assert(/^https:\/\/[^\s]+\.[a-z]{2,}/i.test(u), 'bad URL: ' + u));
  eq(new Set(urls).size, urls.length, 'duplicate resource URLs');
  await p.evaluate(() => openPanel('resources')); await p.waitForTimeout(300);
  const all = await p.$$eval('#panel-resources a[href^="https"]', x => x.length);
  assert(all >= 50, 'resource links not rendered');
  const ext = await p.$$eval('#panel-resources a[href^="https"]', x => x.every(a => a.target === '_blank' && /noopener/.test(a.rel)));
  assert(ext, 'outside links must open in a new tab with rel=noopener');
  const out = await capture(p, () => MMResources.print(false));
  checkPrint(out[0], 'resource guide');
  assert((out[0].match(/<svg/g) || []).length >= 50, 'resource guide is missing QR codes');
});

test('Spanish and Portuguese: game show, workshops and printouts translate', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  for (const [lang, title, ws, page] of [['es', 'Apréndelo', 'Talleres de dinero', 'Página'], ['pt', 'Aprenda', 'Oficinas', 'Página']]) {
    await p.evaluate(l => { setLang(l); setGrade('4'); MMGameShow.open(); }, lang);
    await p.waitForFunction(x => (document.getElementById('mm-gs') || {}).innerText && document.getElementById('mm-gs').innerText.includes(x), title, { timeout: 5000 }).catch(() => {});
    const t = await p.evaluate(() => document.getElementById('mm-gs').innerText);
    assert(t.includes(title), `${lang}: game show lobby not translated`);
    await p.evaluate(() => { MMGameShow.close(); openPanel('workshops'); }); await p.waitForTimeout(500);
    const w = await p.evaluate(() => document.getElementById('panel-workshops').innerText);
    assert(w.includes(ws), `${lang}: workshops panel not translated`);
    await p.evaluate(() => { closePanel(true); openDoc('plan'); }); await p.waitForTimeout(200);
    const out = await capture(p, () => MMPrint.doc('plan'));
    assert(out[0].includes(page), `${lang}: printout footer not translated`);
    assert(!/Lesson plan<|Learning objective</.test(out[0]), `${lang}: English headings left in printout`);
    await p.evaluate(() => closePanel(true));
  }
  await p.evaluate(() => setLang('en'));
});

test('Privacy, Security, Terms and FAQ are current', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await load(p);
  const t = await p.evaluate(() => document.getElementById('panel-legal').textContent);
  assert(!/no accounts/i.test(t), 'privacy policy still says there are no accounts');
  assert(!/Teacher\/Parent\/Parent/.test(t), 'FAQ typo is back');
  assert(/Last updated: October 27, 2026/.test(t), 'last-updated date missing');
  for (const s of ['Supabase', 'Resource Guide', 'salted SHA-256', 'not strong security', 'reviewed by an attorney']) assert(t.includes(s), 'legal text missing: ' + s);
  for (const id of ['privacy', 'security', 'terms', 'faq']) assert(await p.$('#legal-' + id), 'missing legal tab ' + id);
});

test('Accessibility: no critical or serious axe violations; Escape and focus return work', async ({ ctx, errs }) => {
  const axe = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
  const p = await newPage(ctx, errs);
  const run = async (label, sel) => {
    await p.addScriptTag({ content: axe }).catch(() => {});
    const r = await p.evaluate(async s => {
      const res = await axe.run(s ? document.querySelector(s) : document, { resultTypes: ['violations'], rules: { 'color-contrast': { enabled: true } } });
      return res.violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length }));
    }, sel);
    const bad = r.filter(v => v.impact === 'critical' || v.impact === 'serious');
    assert(!bad.length, `${label}: axe violations ${JSON.stringify(bad)}`);
    return r;
  };
  await load(p); await p.click('#consent-accept-btn').catch(() => {});
  const report = { signin: await run('sign-in', '#mm-auth') };
  await setupAdmin(p);
  report.home = await run('home', null);
  await p.evaluate(() => MMGameShow.open()); await p.waitForTimeout(300);
  report.gameshow = await run('game show', '#mm-gs');
  await p.evaluate(() => MMGameShow.close());
  for (const id of ['workshops', 'resources', 'legal']) {
    await p.evaluate(i => openPanel(i), id); await p.waitForTimeout(300);
    report[id] = await run(id, '#panel-' + id);
    await p.evaluate(() => closePanel(true));
  }
  /* keyboard: open a panel from a focused control, Escape closes it, focus returns */
  await p.evaluate(() => { const b = document.createElement('button'); b.id = '__opener'; b.textContent = 'open'; b.onclick = () => openPanel('help'); document.body.appendChild(b); b.focus(); });
  await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  assert(await p.evaluate(() => document.getElementById('panel-help').classList.contains('open')), 'Enter did not open the panel');
  assert(await p.evaluate(() => document.getElementById('scene') ? document.getElementById('scene').hasAttribute('inert') : true), 'background is not inert under an open panel');
  await p.keyboard.press('Escape'); await p.waitForTimeout(400);
  assert(await p.evaluate(() => !document.querySelector('.panel.open')), 'Escape did not close the panel');
  const minor = Object.entries(report).flatMap(([k, v]) => v.map(x => `${k}:${x.id}(${x.n})`));
  if (minor.length) console.log('      note: moderate/minor axe findings: ' + minor.join(', '));
});

test('Financial Literacy Assessment: a student starts, answers every question and gets a result', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  const stu = await p.evaluate(() => { const s = Object.values(loadStore().list)[0]; return { u: MM91.accounts.forStudent(s.id).u, c: MM91.data.codeOf(s) }; });
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=student]').catch(() => {});
  await p.fill('#mm55-user', stu.u); await p.fill('#mm55-pass', stu.c); await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  eq(await p.evaluate(() => MM91.auth.roleKey()), 'student', 'student sign-in');
  await p.evaluate(() => openPanel('assessment')); await p.waitForTimeout(400);
  await p.click('#assessmentBody button:has-text("Start")');
  for (let i = 0; i < 40; i++) {
    const fin = await p.$('#assessmentBody button:has-text("Finish"):not([disabled])');
    if (fin) { await fin.click(); break; }
    const opt = await p.$('#assessmentBody .mm-assess-option'); assert(opt, 'no answer options shown (question ' + (i + 1) + ')');
    await opt.click(); await p.waitForTimeout(80);
    const next = await p.$('#assessmentBody button:has-text("Next"):not([disabled])'); if (next) await next.click();
    await p.waitForTimeout(80);
  }
  await p.waitForTimeout(400);
  const t = await p.innerText('#assessmentBody');
  assert(/level|score|%/i.test(t), 'no result after finishing: ' + t.slice(0, 120));
});

test('Dead-button fixes: quiz practice for staff, reports without data, school dialogs close with Escape', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => { setGrade('4'); openPanel('quiz'); }); await p.waitForTimeout(700);
  assert(await p.$('#quizForm .mm-key-banner .mm-key-toggle'), 'no "Try this quiz as a student" switch in the answer-key view');
  await p.click('#quizForm .mm-key-toggle'); await p.waitForTimeout(300);
  const opt = await p.$('#quizForm .mc-opt'); await opt.click({ timeout: 2000 });
  assert(await p.evaluate(() => Object.keys(quizSel).length === 1), 'practice mode: a real click on an answer did not select it');
  const before = await p.evaluate(() => JSON.stringify(loadStore().stats || {}));
  await p.evaluate(() => { quizQs.forEach((q, i) => { quizSel[i] = 0; }); submitQuiz(); }); await p.waitForTimeout(300);
  eq(await p.evaluate(() => JSON.stringify(loadStore().stats || {})), before, 'practice answers changed the class question statistics');
  assert(/%/.test(await p.innerText('#quizPrize')), 'practice quiz shows no score');
  await p.evaluate(() => closePanel(true));
  await p.evaluate(() => { openPanel('admin'); setTimeout(() => MM91.admin.open('reports'), 60); }); await p.waitForTimeout(600);
  await p.click('#adminMain [data-act=missed]'); await p.waitForTimeout(400);
  assert(await p.isVisible('#mm-modal-backdrop.open'), '"Open report" with no data showed nothing (native alert)');
  await p.click('#mm-modal-btns button'); await p.waitForTimeout(200);
  await p.evaluate(() => MM91.admin.open('students')); await p.waitForTimeout(500);
  const b = await p.$('#adminMain button:has-text("Class join codes")'); await b.focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  assert(await p.$('.mmrt-ov .mmrt-box[aria-labelledby]'), 'school dialog has no accessible name');
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  assert(!(await p.$('.mmrt-ov')), 'Escape did not close the school dialog');
  eq(await p.evaluate(() => document.activeElement && document.activeElement.textContent.trim().slice(0, 20)), '🔑 Class join codes', 'focus did not return to the opener');
  assert(await p.evaluate(() => +getComputedStyle(document.getElementById('info-toast')).zIndex > 2147483000), 'confirmations sit under school dialogs');
});

test('Every open panel takes real clicks (nothing behind it, or around it, is inert)', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => setGrade('4'));
  for (const id of ['lessons', 'overview', 'doc', 'quiz', 'path', 'glossary', 'games', 'workshops', 'resources', 'materials', 'admin', 'legal', 'feedback']) {
    await p.evaluate(i => { closePanel(true); if (i === 'doc') openDoc('plan'); else openPanel(i); }, id); await p.waitForTimeout(500);
    const r = await p.evaluate(i => { const el = document.getElementById('panel-' + i); if (!el || !el.classList.contains('open')) return 'not open';
      if (el.closest('[inert]')) return 'panel is inside an inert element';
      const b = [...el.querySelectorAll('.panel-body button, .panel-body [onclick], .panel-body a[href]')].find(x => { const r = x.getBoundingClientRect(); const pr = el.querySelector('.panel-body').getBoundingClientRect(); return r.width && r.height && r.top > pr.top && r.bottom < pr.bottom; });
      if (!b) return 'no visible button';
      const r = b.getBoundingClientRect(), hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
      return b.contains(hit) || hit === b ? 'ok' : 'blocked by ' + (hit ? (hit.id || hit.tagName) : 'nothing'); }, id);
    eq(r, 'ok', `panel ${id}`);
  }
  await p.evaluate(() => { closePanel(true); openPanel('lessons'); }); await p.waitForTimeout(500);
  const b = await p.$('#panel-lessons .panel-body button:visible'); await b.click({ timeout: 2000 });
});

test('Nothing on screen looks clickable but isn\'t: every panel, Run mode, Game Show; administrator and student; desk and phone', async ({ ctx, errs }) => {
  const { scan } = require('./deadzones');
  const found = [];
  for (const vp of [{ width: 1366, height: 900 }, { width: 390, height: 844 }]) {
    /* each size gets its own empty browser profile, so first-run setup appears again */
    const c = vp.width < 700 ? await ctx.browser().newContext({ viewport: vp, isMobile: true, hasTouch: true }) : ctx;
    const p = await newPage(c, errs, vp);
    await setupAdmin(p); await addClass(p);
    await p.evaluate(() => { try { localStorage.setItem('mmPhoneTourDone', '1'); const c = document.getElementById('mm-coach'); c && c.classList.remove('on'); setGrade('4'); } catch (e) {} });
    const tag = vp.width + 'px';
    const check = async where => { for (const d of await scan(p)) found.push(`${tag} ${where}: "${d.label}" ${d.why}`); };
    await check('admin home');
    const ids = await p.evaluate(() => [...document.querySelectorAll('.panel')].map(x => x.id.replace('panel-', '')).filter(x => x !== 'login'));
    for (const id of ids) { await p.evaluate(i => { closePanel(true); if (i === 'doc') openDoc('plan'); else openPanel(i); }, id); await p.waitForTimeout(300); await check('panel ' + id); }
    await p.evaluate(() => { closePanel(true); openPanel('workshops'); }); await p.waitForTimeout(300);
    const hasRun = await p.evaluate(() => { const b = document.querySelector('[data-ws=run]'); if (b) b.click(); return !!b; }); assert(hasRun || /V20/.test(FILE), 'no Run button'); await p.waitForTimeout(300); await check('Run mode');
    await p.keyboard.press('Escape'); await p.evaluate(() => { closePanel(true); MMGameShow.open(); }); await p.waitForTimeout(400); await check('Game Show');
    await p.evaluate(() => MMGameShow.close());
    /* a student */
    const stu = await p.evaluate(() => { const s = Object.values(loadStore().list)[0]; return { u: MM91.accounts.forStudent(s.id).u, c: MM91.data.codeOf(s) }; });
    await p.evaluate(() => { closePanel(true); MM91.gate.signOut(); }); await p.waitForTimeout(600); await check('sign-in screen');
    await p.click('[data-a=as][data-v=student]').catch(() => {});
    await p.fill('#mm55-user', stu.u); await p.fill('#mm55-pass', stu.c); await p.click('[data-a=login]'); await p.waitForTimeout(1200); await quiet(p);
    await p.evaluate(() => { try { localStorage.setItem('mmPhoneTourDone', '1'); const c = document.getElementById('mm-coach'); c && c.classList.remove('on'); } catch (e) {} });
    await check('student home');
    for (const id of ['lessons', 'quiz', 'path', 'glossary', 'games', 'story', 'assessment']) { await p.evaluate(i => { closePanel(true); openPanel(i); }, id); await p.waitForTimeout(300); await check('student panel ' + id); }
    await p.close(); if (c !== ctx) await c.close();
  }
  found.slice(0, 40).forEach(f => console.log('      ' + f));
  assert(!found.length, found.length + ' controls look clickable but are not (listed above)');
}, { timeout: 180000 });

test('Workshop Run mode: timer, team points, back and next, Game Show round trip, finish marks the class complete', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p); await addClass(p);
  await p.evaluate(() => { setGrade('4'); openPanel('workshops'); }); await p.waitForTimeout(500);
  await p.click('[data-ws=fmt][data-n="3"]'); await p.waitForTimeout(200);
  await p.click('[data-ws=run]'); await p.waitForTimeout(400);
  assert(await p.isVisible('#ws-run'), 'Run mode did not open');
  assert(await p.evaluate(() => !!document.querySelector('.panel.open').closest('[inert]') || document.querySelector('.panel.open').hasAttribute('inert')), 'the panel behind Run mode is still focusable');
  eq(await p.innerText('.wr-clock b'), '15:00', 'first activity timer');
  await p.keyboard.press('Space'); await p.waitForTimeout(1600);
  assert((await p.innerText('.wr-clock b')) < '15:00', 'Space did not start the timer');
  if (!(await p.$('.wr-teams[open]'))) await p.click('.wr-teams summary');
  await p.click('[data-wr=pt][data-t="1"][data-v="1"]'); await p.click('[data-wr=pt][data-t="1"][data-v="1"]');
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(300);
  assert(/2 of|2 de/.test(await p.innerText('.wr-title b')), 'ArrowRight did not advance');
  await p.click('[data-wr=prev]'); await p.waitForTimeout(200); await p.click('[data-wr=next]'); await p.waitForTimeout(200);
  const gi = await p.evaluate(() => [...document.querySelectorAll('.wr-dots button')].findIndex(b => /Game Show/.test(b.getAttribute('aria-label'))));
  assert(gi >= 0, 'no Game Show activity in the day');
  await p.click(`.wr-dots button >> nth=${gi}`); await p.waitForTimeout(200);
  await p.click('[data-wr=game]'); await p.waitForTimeout(800);
  assert(await p.evaluate(() => document.documentElement.classList.contains('mm-gs-on') && document.getElementById('ws-run').hidden), 'Game Show did not open over Run mode');
  await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(500);
  assert(await p.isVisible('#ws-run'), 'Run mode did not come back after the Game Show');
  const n = await p.$$eval('.wr-dots button', x => x.length);
  await p.click(`.wr-dots button >> nth=${n - 1}`); await p.waitForTimeout(200);
  await p.click('[data-wr=finish]'); await p.waitForTimeout(300);
  assert(/Team 2/.test(await p.innerText('#ws-run')), 'finish screen does not name the winning team');
  const out = await capture(p, () => document.querySelector('[data-wr=allcert]').click());
  await p.waitForTimeout(600);
  assert(out.length || (await p.evaluate(() => window.__printed && window.__printed.length)), 'certificates were not printed');
  const st = await p.evaluate(() => { const s = JSON.parse(localStorage.getItem('mmWorkshop_v1')); return { done: Object.values(s.done || {}).length, run: Object.keys(s.run || {}).length }; });
  assert(st.done >= 4 && st.run >= 1, 'class completion or run state not saved: ' + JSON.stringify(st));
  assert(!(await p.isVisible('#ws-run')), 'Run mode still open after printing certificates');
  assert(await p.$$eval('#workshopsBody .ws-donemark', x => x.length) > 0, 'finished activities not ticked on the plan');
});

test('Materials Center: every lesson and workshop material has a source; printables are well formed', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  const cov = await p.evaluate(() => { let n = 0, other = 0; const seen = (m) => { n++; const c = MMMaterials.classify(m); if (c.type === 'supply' && c.key === 'other') other++; };
    Object.values(LESSONS).forEach(ls => ls.forEach(l => (l.materials || []).forEach(seen))); Object.values(WS_DATA).forEach(w => w.modules.forEach(m => m.blocks.forEach(b => (b.materials || []).forEach(seen)))); return { n, other }; });
  assert(cov.n > 2000, 'material count'); assert(cov.other / cov.n < 0.05, `too many unclassified materials: ${cov.other} of ${cov.n}`);
  for (const [m, want] of [['play money bills', 'money'], ['play coins', 'coins'], ['blank pay stubs', 'paystub'], ['check registers', 'register'], ['practice W-4 forms', 'w4'], ['calculators', 'calculators'], ['whiteboard and markers', 'whiteboards'], ['Gross pay independent worksheet', 'docs'], ['need and want cards', 'needwant']]) eq(await p.evaluate(x => MMMaterials.classify(x).key, m), want, 'classify ' + m);
  await p.evaluate(() => { setGrade('4'); openPanel('lessons'); }); await p.waitForTimeout(700);
  const hook = await p.$('#panel-lessons .mtc-hook [data-mt=open]'); assert(hook, 'no "Get these materials" link in the lesson'); await hook.scrollIntoViewIfNeeded(); await hook.click(); await p.waitForTimeout(400);
  assert(await p.isVisible('#panel-materials.open'), 'Materials Center did not open'); assert(/Print it here/.test(await p.innerText('#materialsBody')), 'lesson plan has no printables section');
  await p.click('[data-mt=tab][data-t=ws]'); await p.waitForTimeout(300); assert(/Workshop day/.test(await p.innerText('#materialsBody')), 'workshop tab empty');
  for (const g of ['K', '4', '7']) {
    await p.evaluate(x => setGrade(x), g);
    for (const k of await p.evaluate(() => Object.keys(MMMaterials.GEN))) {
      const out = await capture(p, new Function(`MMMaterials.printOne('${k}','${g}')`)); assert(out.length, `${k} (${g}) did not print`); checkPrint(out[0], `printable ${k} grade ${g}`);
      if (k === 'money') { assert(/NOT REAL MONEY/.test(out[0]), 'play money is not marked as not real'); assert(!/Federal Reserve Note|In God We Trust|United States of America/i.test(out[0]), 'play money imitates real currency'); }
    }
  }
  const letter = await capture(p, () => document.querySelector('#materialsBody [data-mt=letter]').click()); checkPrint(letter[0], 'family supply letter');
  await p.click('[data-mt=tab][data-t=sources]'); await p.waitForTimeout(300);
  const links = await p.$$eval('#materialsBody a[href^="https"]', x => x.map(a => ({ h: a.href, t: a.target, r: a.rel })));
  assert(links.length >= 6 && links.every(l => l.t === '_blank' && /noopener/.test(l.r)), 'official sources missing or not opening safely');
});

test('Phone: the tour never covers sign-in; home cards and top bar have 40px targets', async ({ ctx, errs }) => {
  const c2 = await ctx.browser().newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const p = await newPage(c2, errs);
  await load(p); await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'A'); await p.fill('#s-p1', PW); await p.fill('#s-p2', PW); await p.selectOption('#s-sq1', { index: 1 }); await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]'); await p.waitForTimeout(300);
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(2500);
  assert(!(await p.$('#mm-coach.on')), 'phone tour opened over the sign-in screen');
  await p.click('[data-a=login]', { timeout: 2000 });
  await p.fill('#mm55-user', 'admin'); await p.fill('#mm55-pass', PW); await p.click('[data-a=login]'); await p.waitForTimeout(1500);
  await quiet(p); await p.evaluate(() => { localStorage.setItem('mmPhoneTourDone', '1'); const c = document.getElementById('mm-coach'); c && c.classList.remove('on'); closePanel(true); }); await p.waitForTimeout(400);
  const small = await p.evaluate(() => [...document.querySelectorAll('#mm-topbar button, #mm-home .mm-home-card button')].filter(b => { const r = b.getBoundingClientRect(); return r.width && r.height && r.height < 39.5; }).map(b => (b.innerText || b.getAttribute('aria-label') || b.title || b.className || '').trim().slice(0, 30) + ' ' + Math.round(b.getBoundingClientRect().height) + ' ' + (b.closest('#mm-topbar') ? 'top' : 'card')));
  eq(small.length, 0, 'small tap targets: ' + small.join(', '));
  /* the tour already showing when someone signs out must close too (V22) */
  await p.evaluate(() => { localStorage.removeItem('mmPhoneTourDone'); MM91.coach.start(); }); await p.waitForTimeout(400);
  const tourOn = await p.evaluate(() => !!document.querySelector('#mm-coach.on'));
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(600);
  assert(!(await p.$('#mm-coach.on')), 'phone tour stayed over the sign-in screen after sign-out (tour was ' + (tourOn ? 'on' : 'off') + ')');
  await p.fill('#mm55-user', 'admin'); await p.fill('#mm55-pass', PW); await p.click('[data-a=login]', { timeout: 3000 }); await p.waitForTimeout(1200);
  await quiet(p); await p.evaluate(() => { localStorage.setItem('mmPhoneTourDone', '1'); const c = document.getElementById('mm-coach'); c && c.classList.remove('on'); });
  /* signing out on a phone with a panel open must not freeze the page (V21 regression) */
  await p.evaluate(() => openPanel('path')); await p.waitForTimeout(400);
  const r = await Promise.race([p.evaluate(() => { const t = performance.now(); MM91.gate.signOut(); return performance.now() - t; }), new Promise(res => setTimeout(() => res('froze'), 6000))]);
  assert(r !== 'froze' && r < 2000, 'phone sign-out froze or was slow: ' + r);
  await c2.close();
});

test('Layout (V23): notch and offline banner never cover the top bar; account menu; dashboards; documents on phones', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs, { width: 390, height: 844 });
  await setupAdmin(p); await addClass(p);
  const geo = () => p.evaluate(() => { const tb = document.getElementById('mm-topbar').getBoundingClientRect(); const kids = [...document.querySelectorAll('#mm-topbar > *')].filter(x => getComputedStyle(x).display !== 'none').map(x => x.getBoundingClientRect()); const pn = document.querySelector('.panel.open'); return { bottom: Math.round(tb.bottom), top: Math.min(...kids.map(r => r.top)), maxBottom: Math.max(...kids.map(r => r.bottom)), panel: pn ? Math.round(pn.getBoundingClientRect().top) : null, overflow: document.getElementById('mm-topbar').scrollWidth > document.getElementById('mm-topbar').clientWidth + 1 }; });
  /* a 47px notch and the offline banner */
  await p.evaluate(() => { document.documentElement.style.setProperty('--mm-sat', '47px'); window.dispatchEvent(new Event('resize')); }); await p.waitForTimeout(300);
  await quiet(p); await p.evaluate(() => openPanel('lessons')); await p.waitForTimeout(500);
  let g = await geo();
  assert(g.top >= 47, 'top bar content sits under the notch: ' + JSON.stringify(g));
  assert(g.maxBottom <= g.bottom + 1 && !g.overflow, 'top bar content overflows: ' + JSON.stringify(g));
  assert(g.panel >= g.bottom, 'panel overlaps the top bar: ' + JSON.stringify(g));
  await p.evaluate(() => document.body.classList.add('offline-mode')); await p.waitForTimeout(400);
  const g2 = await geo(); assert(g2.panel >= g2.bottom, 'panel overlaps the top bar with the offline banner: ' + JSON.stringify(g2));
  await p.evaluate(() => { document.body.classList.remove('offline-mode'); document.documentElement.style.removeProperty('--mm-sat'); closePanel(true); window.dispatchEvent(new Event('resize')); }); await p.waitForTimeout(400);
  /* account menu: opens from the avatar, stays open, lists the hidden buttons, Escape closes it */
  assert(await p.evaluate(() => document.documentElement.classList.contains('mm-bar-compact')), 'phone top bar should be compact');
  await quiet(p); await p.evaluate(() => { try { localStorage.setItem('mmPhoneTourDone', '1'); } catch (e) {} const c = document.getElementById('mm-coach'); if (c) c.classList.remove('on'); }); await p.waitForTimeout(300);
  await p.click('#mm-topbar .user', { timeout: 4000 }); await p.waitForTimeout(900);
  const items = await p.evaluate(() => [...document.querySelectorAll('#mm-acct-menu.open [role=menuitem]')].map(x => x.textContent.trim()));
  assert(items.some(t => /My profile/.test(t)) && items.some(t => /Sign out/.test(t)), 'account menu items: ' + JSON.stringify(items));
  eq(await p.evaluate(() => (document.querySelector('.panel.open') || {}).id || ''), '', 'the avatar should open the menu, not a panel');
  await p.keyboard.press('Escape'); await p.waitForTimeout(150);
  assert(!(await p.$('#mm-acct-menu.open')), 'Escape should close the account menu');
  /* staff dashboard on the phone; Classroom view and back */
  assert(await p.evaluate(() => { const h = document.getElementById('mm-staff-home'); return !!h && getComputedStyle(h).display !== 'none'; }), 'administrator should get the dashboard on phones');
  await p.evaluate(() => MMLayout.classroomView(true)); await p.waitForTimeout(400);
  assert(await p.evaluate(() => document.documentElement.classList.contains('mm-classroom-view')), 'Classroom view did not turn on');
  await p.evaluate(() => MMLayout.classroomView(false)); await p.waitForTimeout(300);
  /* documents on a phone: no sideways scrolling, the preview is scaled to fit */
  await p.evaluate(() => { setGrade('4'); openDoc('guide'); }); await p.waitForTimeout(1200);
  const d = await p.evaluate(() => { const b = document.querySelector('#panel-doc .panel-body'); const box = document.querySelector('#printArea .mm-docscale'); return { sw: b.scrollWidth, cw: b.clientWidth, scaled: !!box && box.classList.contains('scaled'), sticky: getComputedStyle(document.querySelector('#panel-doc .doc-toolbar')).position }; });
  assert(d.sw <= d.cw + 1, 'the documents panel scrolls sideways on a phone: ' + JSON.stringify(d));
  assert(d.scaled, 'the print preview should be scaled to fit a phone');
  eq(d.sticky, 'static', 'the document toolbar should not stick over the preview on phones');
  /* tablet and desktop: a teacher gets the dashboard and the floating tab bar */
  await p.evaluate(() => closePanel(true));
  for (const vp of [{ width: 820, height: 1180 }, { width: 1366, height: 900 }]) {
    await p.setViewportSize(vp); await p.waitForTimeout(500);
    const t = await p.evaluate(() => { const tb = document.getElementById('mm-tabbar'); const top = document.getElementById('mm-topbar'); return { tabs: document.documentElement.classList.contains('mm-tabs-all'), bar: !!tb && getComputedStyle(tb).display !== 'none', overflow: top.scrollWidth > top.clientWidth + 1 }; });
    assert(t.tabs && t.bar, vp.width + 'px: staff should get the tab bar: ' + JSON.stringify(t));
    assert(!t.overflow, vp.width + 'px: top bar overflows');
  }
  await p.close();
});

test('Spanish: Run mode and the Materials Center translate', async ({ ctx, errs }) => {
  const p = await newPage(ctx, errs);
  await setupAdmin(p);
  await p.evaluate(() => { setLang('es'); setGrade('4'); openPanel('workshops'); }); await p.waitForTimeout(600);
  await p.click('[data-ws=run]'); await p.waitForTimeout(900);
  const t = await p.innerText('#ws-run');
  assert(/puntos del equipo/i.test(t) && /siguiente/i.test(t), 'Run mode not translated: ' + t.slice(0, 200));
  await p.keyboard.press('Escape');
  await p.evaluate(() => { closePanel(true); MMMaterials.open({ tab: 'library' }); }); await p.waitForTimeout(900);
  assert(/Dinero de juguete/i.test(await p.innerText('#materialsBody')), 'Materials Center not translated');
  await p.evaluate(() => { closePanel(true); openPanel('admin'); setTimeout(() => MM91.admin.open('sync'), 60); }); await p.waitForTimeout(600);
  assert(/Sincronización de la clase/.test(await p.innerText('#panel-admin')), 'Class sync not translated');
  await p.evaluate(() => setLang('en'));
});

/* ---------- hosted (public) build: served from a fake origin with a mock /api/content ---------- */
const PUBLIC_FILE = path.join(__dirname, '..', 'dist', 'public', 'index.html');
const PACK_DIR = path.join(__dirname, '..', 'dist', 'content');
const ORIGIN = 'https://mm.test';
async function hosted(ctx, errs, { code, api, routes } = {}) {
  assert(fs.existsSync(PUBLIC_FILE), 'public build missing; run node build.js --public');
  const html = fs.readFileSync(PUBLIC_FILE, 'utf8');
  const calls = [];
  await ctx.route(ORIGIN + '/**', async route => {
    const u = new globalThis.URL(route.request().url());
    if (u.pathname === '/api/content') {
      calls.push({ auth: route.request().headers()['authorization'] || '', v: u.searchParams.get('v') });
      if (api) return api(route);
      return route.fulfill({ status: 401, contentType: 'application/json', body: '{"error":"unknown access code"}' });
    }
    if (routes && routes[u.pathname]) return routes[u.pathname](route, calls);
    if (u.pathname === '/' || u.pathname === '/index.html') return route.fulfill({ status: 200, contentType: 'text/html', body: html });
    /* other static files from dist/public (ads.json, ads/*, sw.js) */
    const f = path.join(path.dirname(PUBLIC_FILE), u.pathname.replace(/^\/+/, ''));
    if (f.startsWith(path.dirname(PUBLIC_FILE)) && fs.existsSync(f) && fs.statSync(f).isFile()) return route.fulfill({ status: 200, body: fs.readFileSync(f), contentType: /\.json$/.test(f) ? 'application/json' : /\.svg$/.test(f) ? 'image/svg+xml' : /\.js$/.test(f) ? 'text/javascript' : /\.html$/.test(f) ? 'text/html' : 'application/octet-stream' });
    return route.fulfill({ status: 404, body: '' });
  });
  if (code) await ctx.addInitScript(c => { try { if (!sessionStorage.getItem('__seeded')) { localStorage.setItem('mmAccess_v1', c); sessionStorage.setItem('__seeded', '1'); } } catch (e) {} }, code);
  const p = await newPage(ctx, errs);
  await p.goto(ORIGIN + '/');
  await p.waitForSelector('#mm-auth', { state: 'attached', timeout: 15000 }); await p.waitForTimeout(900);
  return { p, calls };
}
function fullPacks() {
  const man = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'manifest.json'), 'utf8'));
  let body = '{"__label":"Lincoln Elementary","__expires":"2027-07-31T23:59:59Z","__version":' + JSON.stringify(man.version);
  man.packs.forEach(k => { body += ',' + JSON.stringify(k) + ':' + fs.readFileSync(path.join(PACK_DIR, k + '.json'), 'utf8'); });
  return body + '}';
}
async function setupHosted(p) {
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'Test Admin'); await p.fill('#s-p1', PW); await p.fill('#s-p2', PW);
  await p.selectOption('#s-sq1', { index: 1 }); await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]'); await p.waitForTimeout(1400); await quiet(p);
}

test('Hosted build: page ships week 1 only; locked content is not in it', async () => {
  const html = fs.readFileSync(PUBLIC_FILE, 'utf8');
  const L = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'LESSONS.json'), 'utf8'));
  const W = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'WS_DATA.json'), 'utf8'));
  for (const g of Object.keys(L)) {
    assert(html.includes(JSON.stringify(L[g][0].objective).slice(1, -1)), `grade ${g}: week 1 missing from the free page`);
    for (const w of [1, 10, 35]) { const obj = L[g][w].objective; if (obj && obj.length > 25) assert(!html.includes(JSON.stringify(obj).slice(1, -1)), `grade ${g} week ${w + 1} objective leaked into the free page`); }
    const how = W[g].modules[0].blocks[0].how; if (how && how.length > 25) assert(!html.includes(JSON.stringify(how).slice(1, -1)), `grade ${g} workshop plan leaked into the free page`);
  }
  assert(/window\.MM_PUBLIC_BUILD=true/.test(html), 'public build flag missing');
  assert(fs.statSync(PUBLIC_FILE).size < fs.statSync(FILE).size * 0.6, 'public page is not much smaller than the full build');
  for (const f of ['sw.js', '_headers']) assert(fs.existsSync(path.join(path.dirname(PUBLIC_FILE), f)), f + ' missing from dist/public');
});

test('Hosted free edition: week 1 opens, the rest asks for an access code', async ({ ctx, errs }) => {
  const { p, calls } = await hosted(ctx, errs);
  eq(calls.length, 0, 'free edition should not call /api/content');
  await setupHosted(p);
  const st = await p.evaluate(() => ({ lic: MMLicense.licensed, n: LESSONS['4'].length, w1: !!LESSONS['4'][0].objective, w2: LESSONS['4'][1].locked === true, unlock: !!document.querySelector('[data-lic=unlock]') }));
  assert(!st.lic, 'free edition reports licensed'); eq(st.n, 36, 'week list length'); assert(st.w1 && st.w2, 'week 1 should be full and week 2 a placeholder');
  assert(st.unlock, 'staff top bar has no Unlock button');
  await p.evaluate(() => { setGrade('4'); openPanel('lessons'); }); await p.waitForTimeout(300);
  await p.evaluate(() => gotoLesson(3)); await p.waitForTimeout(300);
  assert(await p.isVisible('#mm-subscribe.open'), 'week 4 did not show the unlock dialog');
  assert((await p.innerText('#mm-subscribe')).includes('Enter access code'), 'unlock dialog has no access-code button');
  await p.evaluate(() => { document.getElementById('mm-subscribe').classList.remove('open'); closePanel(true); });
  /* V23: the workbook and teacher's guide open in the free edition, limited to Lesson 1 */
  for (const k of ['workbook', 'guide']) {
    const o = await capture(p, k === 'workbook' ? () => { MMPrint.doc('workbook'); } : () => { MMPrint.doc('guide'); });
    assert(!(await p.isVisible('#mm-subscribe.open')), k + ' should open (Lesson 1) instead of asking to subscribe');
    assert(o[0] && o[0].includes('This sample includes Lesson 1'), k + ' has no Lesson 1 sample note');
    assert(!/Week<\/td><td>2<|>2<\/b><\/td>|Week 2\b/.test(o[0]), k + ' should not include week 2');
  }
  for (const fn of ["openTestMenu()"]) {
    await p.evaluate(f => { (new Function(f))(); }, fn); await p.waitForTimeout(250);
    assert(await p.isVisible('#mm-subscribe.open'), fn + ' was not locked');
    await p.evaluate(() => document.getElementById('mm-subscribe').classList.remove('open'));
  }
  await p.evaluate(() => openPanel('workshops')); await p.waitForTimeout(400);
  assert(await p.$('#workshopsBody .ws-lock'), 'workshops are not locked');
  await p.evaluate(() => closePanel(true));
  const out = await capture(p, () => { openDoc('plan'); MMPrint.doc('plan'); });
  checkPrint(out[0], 'free week 1 lesson plan');
  await p.evaluate(() => { closePanel(true); setLang('es'); }); await p.waitForTimeout(300);
  assert(await p.evaluate(() => !!(LESSONS_L.es['4'][0].objective && LESSONS_L.es['4'][1].locked)), 'Spanish week 1 should be free and week 2 locked');
  await p.evaluate(() => setLang('en'));
  await p.evaluate(() => MMGameShow.open('rush')); await p.waitForTimeout(3500);
  assert((await p.evaluate(() => document.getElementById('mm-gs').innerText.length)) > 60, 'Game Show did not start on week-1 content');
  await p.evaluate(() => MMGameShow.close());
});

test('Hosted licensed: a valid code loads every week, workshops and tests', async ({ ctx, errs }) => {
  const body = fullPacks();
  const { p, calls } = await hosted(ctx, errs, { code: 'MM-TEST-CODE-0001', api: r => r.fulfill({ status: 200, contentType: 'application/json', headers: { 'Cache-Control': 'private, max-age=604800' }, body }) });
  assert(calls.length >= 1, '/api/content was not called');
  eq(calls[0].auth, 'Bearer MM-TEST-CODE-0001', 'access code not sent');
  const man = JSON.parse(fs.readFileSync(path.join(PACK_DIR, 'manifest.json'), 'utf8'));
  eq(calls[0].v, man.version, 'content version not sent');
  await setupHosted(p);
  const st = await p.evaluate(() => ({ lic: MMLicense.licensed, label: MMLicense.label, w20: !!LESSONS['4'][19].objective, es: !!LESSONS_L.es['4'][19].objective, tests: SECTION_TESTS['4'][0].questions.length, unlock: !!document.querySelector('[data-lic=unlock]') }));
  assert(st.lic, 'not licensed'); eq(st.label, 'Lincoln Elementary', 'license label');
  assert(st.w20 && st.es && st.tests > 0, 'full content did not load');
  assert(!st.unlock, 'Unlock button shown while licensed');
  await p.evaluate(() => { setGrade('4'); openPanel('lessons'); gotoLesson(19); }); await p.waitForTimeout(400);
  assert(!(await p.isVisible('#mm-subscribe.open')), 'licensed week 20 still locked');
  await p.evaluate(() => { closePanel(true); openPanel('workshops'); }); await p.waitForTimeout(400);
  assert(!(await p.$('#workshopsBody .ws-lock')) && (await p.$$('[data-ws=day]')).length > 0, 'licensed workshops still locked');
});

test('Hosted: a revoked code falls back to the free edition and is forgotten', async ({ ctx, errs }) => {
  const { p } = await hosted(ctx, errs, { code: 'MM-OLD-CODE-0001', api: r => r.fulfill({ status: 403, contentType: 'application/json', body: '{"error":"access code expired"}' }) });
  const st = await p.evaluate(() => ({ lic: MMLicense.licensed, code: localStorage.getItem('mmAccess_v1'), err: !!window.__MM_ACCESS_ERR }));
  assert(!st.lic && st.err, 'revoked code not handled'); eq(st.code, null, 'revoked code still stored');
});

const AUTH_CONFIG = { auth: { url: 'https://proj.supabase.co', key: 'sb_publishable_test', providers: ['google', 'azure', 'facebook'] } };
const cfgRoute = (r) => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(AUTH_CONFIG) });

test('Sign in with Google/Microsoft/Facebook: buttons for adults only; a verified email signs in and unlocks', async ({ ctx, errs }) => {
  const body = fullPacks();
  const { p, calls } = await hosted(ctx, errs, {
    routes: { '/api/config': cfgRoute },
    api: r => /^Bearer MMD1\./.test(r.request().headers()['authorization'] || '') ? r.fulfill({ status: 200, contentType: 'application/json', body }) : r.fulfill({ status: 401, contentType: 'application/json', body: '{}' })
  });
  await setupHosted(p);
  await p.evaluate(async (pw) => { await MM91.accounts.add({ username: 'rivera', name: 'Ms. Rivera', email: 'Rivera@Lincoln.k12.us', role: 'teacher', scope: 'all', password: pw, by: 't' }); MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); MM91.accounts.ensureStudents(); }, PW);
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(600);
  await p.click('[data-a=as][data-v=student]').catch(() => {}); await p.waitForTimeout(300);
  assert(!(await p.$('#mm-auth .mm-social')), 'social sign-in shown on the student side');
  await p.click('[data-a=as][data-v=staff]'); await p.waitForTimeout(400);
  const btns = await p.$$eval('#mm-auth [data-social]', x => x.map(b => b.textContent.trim()));
  assert(btns.some(t => /Google/.test(t)) && btns.some(t => /Microsoft/.test(t)) && btns.some(t => /Facebook/.test(t)), 'provider buttons missing: ' + btns);
  await shot(p, 'social-signin');
  /* the provider round trip itself happens on Google/Supabase; test what the page does with the verified result */
  const ok = await p.evaluate(() => MMSocial._finish({ email: 'rivera@lincoln.k12.us', name: 'Ms. Rivera', provider: 'google', licensed: true, label: 'Lincoln', token: 'MMD1.eyJsIjoiTDEifQ.sig' }));
  assert(ok, 'verified email did not sign in');
  eq(await p.evaluate(() => MM91.auth.get() && MM91.auth.get().u), 'rivera', 'signed in to the matching account');
  eq(await p.evaluate(() => localStorage.getItem('mmAccess_v1')), 'MMD1.eyJsIjoiTDEifQ.sig', 'device token not stored');
  await p.waitForTimeout(2500); /* the page reloads to fetch the licensed content (signed in, so no sign-in screen) */
  await p.waitForFunction(() => window.MMLicense && window.MM91 && document.readyState === 'complete', null, { timeout: 15000 }); await p.waitForTimeout(900);
  assert(await p.evaluate(() => MMLicense.licensed && !!LESSONS['4'][19].objective), 'device token did not unlock the full program');
  assert(calls.some(c => /^Bearer MMD1\./.test(c.auth)), '/api/content was not called with the device token');
  eq(await p.evaluate(() => MM91.auth.roleKey()), 'teacher', 'still signed in after the reload');
});

test('Sign in with Google on a new device makes the administrator; an unknown email is refused', async ({ ctx, errs }) => {
  const { p } = await hosted(ctx, errs, { routes: { '/api/config': cfgRoute } });
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  assert(await p.$('#mm-auth [data-a=dosetup]'), 'first-run setup not shown');
  await p.waitForTimeout(400);
  assert(await p.$('#mm-auth .mm-social [data-social=google]'), 'Google button missing on first-run setup');
  assert(await p.evaluate(() => MMSocial._finish({ email: 'principal@lincoln.k12.us', name: 'Dr. Ames', provider: 'google', licensed: false, reason: 'No school license covers principal@lincoln.k12.us yet.' })), 'first sign-in did not create the administrator');
  eq(await p.evaluate(() => MM91.auth.roleKey()), 'admin', 'first person to sign in is the administrator');
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(500);
  const ok = await p.evaluate(() => MMSocial._finish({ email: 'stranger@gmail.com', name: 'X', provider: 'facebook', licensed: false }));
  assert(!ok, 'unknown email was signed in');
  assert(/Ask your administrator/.test(await p.innerText('#mm-auth')), 'no guidance for an unknown email');
});

test('Ads: sponsor cards for adults on the free edition only; never for students, in games, or when licensed', async ({ ctx, errs }) => {
  const ads = JSON.parse(fs.readFileSync(path.join(path.dirname(PUBLIC_FILE), 'ads.json'), 'utf8')); ads.enabled = true;
  const adsRoute = r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ads) });
  const { p } = await hosted(ctx, errs, { routes: { '/ads.json': adsRoute } });
  await setupHosted(p);
  await p.evaluate(() => closePanel(true)); await p.waitForTimeout(4500);
  assert(await p.$('#mm-staff-home [data-ad=home]'), 'no sponsor card on the adult home screen');
  assert(await p.evaluate(() => { const a = document.querySelector('[data-ad=home]'); a.scrollIntoView({ block: 'center' }); const r = a.getBoundingClientRect(); const e = document.elementFromPoint(r.x + r.width / 2, r.y + 20); return a.contains(e); }), 'sponsor card is hidden behind other content');
  const link = await p.$eval('#mm-staff-home [data-ad=home] a', a => ({ href: a.href, rel: a.rel, target: a.target }));
  assert(/^https:/.test(link.href) && /sponsored/.test(link.rel) && /noopener/.test(link.rel) && link.target === '_blank', 'sponsor link is not https / rel=sponsored noopener');
  await shot(p, 'ad-home'); if (SHOTS) { const bb = await p.evaluate(() => { const r = document.querySelector('[data-ad=home]').getBoundingClientRect(); return { x: r.x - 12, y: r.y - 12, width: r.width + 24, height: r.height + 24 }; }); await p.screenshot({ path: path.join(SHOTS, 'ad-card.png'), clip: bb }); }
  await p.evaluate(() => MMGameShow.open()); await p.waitForTimeout(600);
  assert(!(await p.$('[data-ad]:not([hidden])')) || !(await p.isVisible('[data-ad]')), 'ad visible during the Game Show');
  await p.evaluate(() => MMGameShow.close()); await p.waitForTimeout(400);
  await p.evaluate(() => openPanel('resources')); await p.waitForTimeout(4500);
  assert(await p.$('#panel-resources [data-ad=resources]'), 'no sponsor card in the Resource Guide');
  await p.click('#panel-resources [data-ad-hide=resources]'); await p.waitForTimeout(200);
  assert(!(await p.$('#panel-resources [data-ad=resources]')), 'hide did not remove the ad');
  await p.evaluate(() => closePanel(true));
  /* a student never sees one */
  await p.evaluate(async () => { MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); MM91.accounts.ensureStudents(); });
  const stu = await p.evaluate(() => { const s = Object.values(loadStore().list)[0]; return { u: MM91.accounts.forStudent(s.id).u, c: MM91.data.codeOf(s) }; });
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.click('[data-a=as][data-v=student]').catch(() => {});
  await p.fill('#mm55-user', stu.u); await p.fill('#mm55-pass', stu.c); await p.click('[data-a=login]'); await p.waitForTimeout(1400); await quiet(p);
  await p.waitForTimeout(4500);
  eq(await p.$$eval('[data-ad]', x => x.length), 0, 'a student saw an ad');
  eq(await p.evaluate(() => MMAds.eligible('home')), false, 'ads eligible for a student');
});

test('Ads: a licensed school sees none', async ({ ctx, errs }) => {
  const ads = JSON.parse(fs.readFileSync(path.join(path.dirname(PUBLIC_FILE), 'ads.json'), 'utf8')); ads.enabled = true;
  const body = fullPacks();
  const { p } = await hosted(ctx, errs, { code: 'MM-TEST-CODE-0001', routes: { '/ads.json': r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ads) }) }, api: r => r.fulfill({ status: 200, contentType: 'application/json', body }) });
  await setupHosted(p); await p.waitForTimeout(4500);
  eq(await p.$$eval('[data-ad]', x => x.length), 0, 'licensed school saw an ad');
});

test('Cloudflare functions: social sign-in tokens (/api/link, renewal, tampering, expiry)', async () => {
  const lib = await import(path.join(__dirname, '..', 'lib', 'mm-server.mjs'));
  const link = await import(path.join(__dirname, '..', 'functions', 'api', 'link.js'));
  const content = await import(path.join(__dirname, '..', 'functions', 'api', 'content.js'));
  const config = await import(path.join(__dirname, '..', 'functions', 'api', 'config.js'));
  const db = { licenses: [{ id: 'L1', label: 'Lincoln', active: true, starts_at: '2026-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z', email_domain: 'lincoln.k12.us', emails: [] }, { id: 'L2', label: 'Home', active: false, starts_at: '2026-01-01T00:00:00Z', expires_at: null, email_domain: null, emails: ['mom@gmail.com'] }], packs: [{ key: 'LESSONS', version: 'v1', data: { K: [] } }] };
  const users = { 'jwt.teacher.x': { email: 'Rivera@Lincoln.k12.us', user_metadata: { full_name: 'Ms. Rivera' }, app_metadata: { provider: 'google' } }, 'jwt.mom.x': { email: 'mom@gmail.com', user_metadata: { name: 'Mom' }, app_metadata: { provider: 'facebook' } }, 'jwt.noemail.x': { email: '', user_metadata: {}, app_metadata: { provider: 'facebook' } } };
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    const u = new globalThis.URL(url);
    if (u.pathname === '/auth/v1/user') { const t = ((init.headers || {}).Authorization || '').replace('Bearer ', ''); return users[t] ? new Response(JSON.stringify(users[t]), { status: 200 }) : new Response('{}', { status: 401 }); }
    if (init && init.method === 'POST') return new Response(null, { status: 201 });
    if (u.pathname.endsWith('/licenses')) {
      const or = u.searchParams.get('or'), id = (u.searchParams.get('id') || '').replace('eq.', '');
      let rows = db.licenses;
      if (id) rows = rows.filter(l => l.id === id);
      else if (or) { const em = (or.match(/emails\.cs\.\{"([^"]+)"\}/) || [])[1], dm = (or.match(/email_domain\.eq\."([^"]+)"/) || [])[1]; rows = rows.filter(l => l.emails.includes(em) || l.email_domain === dm); }
      return new Response(JSON.stringify(rows), { status: 200 });
    }
    if (u.pathname.endsWith('/content_packs')) return new Response(JSON.stringify(db.packs), { status: 200 });
    return new Response('[]', { status: 404 });
  };
  const env = { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_test', SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_test', MM_TOKEN_SECRET: 'x'.repeat(40) };
  const post = async (jwt) => { const w = []; const r = await link.onRequestPost({ request: new Request('https://mm.test/api/link', { method: 'POST', headers: jwt ? { Authorization: 'Bearer ' + jwt } : {} }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  const get = async (auth) => { const w = []; const r = await content.onRequestGet({ request: new Request('https://mm.test/api/content?v=v1', { headers: { Authorization: 'Bearer ' + auth } }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  try {
    eq((await post('')).status, 401, 'no sign-in');
    eq((await post('jwt.bad.x')).status, 401, 'bad Supabase token');
    eq((await post('jwt.noemail.x')).status, 400, 'account without email');
    const t = await (await post('jwt.teacher.x')).json();
    eq(t.email, 'rivera@lincoln.k12.us', 'email lower-cased'); assert(t.licensed && /^MMD1\./.test(t.token), 'domain license did not issue a token'); eq(t.label, 'Lincoln', 'label');
    const mom = await (await post('jwt.mom.x')).json();
    assert(!mom.licensed && !mom.token && /disabled/.test(mom.reason), 'disabled license must not issue a token: ' + JSON.stringify(mom));
    eq((await get(t.token)).status, 200, 'device token loads content');
    const parts = t.token.split('.'); const forged = parts[0] + '.' + parts[1].slice(0, -2) + 'AA.' + parts[2];
    eq((await get(forged)).status, 401, 'tampered token accepted');
    const old = await lib.signToken(env, { l: 'L1', e: 'a@b', x: Date.now() - 1000 });
    eq((await get(old)).status, 401, 'expired token accepted');
    const soon = await lib.signToken(env, { l: 'L1', e: 'a@b', x: Date.now() + 2 * 86400000 });
    const rn = await get(soon); eq(rn.status, 200, 'near-expiry token');
    assert(/^MMD1\./.test(rn.headers.get('X-MM-Token') || ''), 'near-expiry token was not renewed');
    const other = Object.assign({}, env, { MM_TOKEN_SECRET: 'y'.repeat(40) });
    eq((await content.onRequestGet({ request: new Request('https://mm.test/api/content', { headers: { Authorization: 'Bearer ' + t.token } }), env: other, waitUntil: () => {} })).status, 401, 'token signed with another secret accepted');
    const cfgOff = await (await config.onRequestGet({ env: { SUPABASE_URL: 'https://x.supabase.co' } })).json();
    eq(cfgOff.auth, null, 'config should be off without a publishable key');
    const cfgOn = await (await config.onRequestGet({ env })).json();
    assert(cfgOn.auth && cfgOn.auth.providers.join() === 'google,azure' && !JSON.stringify(cfgOn).includes('sb_secret'), 'config wrong or leaks the secret key (Facebook is off unless MM_AUTH_PROVIDERS names it)');
    const cfgFb = await (await config.onRequestGet({ env: Object.assign({}, env, { MM_AUTH_PROVIDERS: 'google,azure,facebook' }) })).json();
    eq(cfgFb.auth.providers.join(), 'google,azure,facebook', 'Facebook can still be turned on');
    const cfgSso = await (await config.onRequestGet({ env: Object.assign({}, env, { CLEVER_CLIENT_ID: 'cid', CLEVER_CLIENT_SECRET: 'csec' }) })).json();
    assert(cfgSso.sso.join() === 'clever' && cfgSso.sync === true && !JSON.stringify(cfgSso).includes('csec'), 'config: school sign-in list wrong or leaks the client secret');
  } finally { globalThis.fetch = realFetch; }
});

test('Cloudflare function: codes, expiry, caching and outages', async () => {
  const mod = await import(path.join(__dirname, '..', 'functions', 'api', 'content.js'));
  const hash = await mod.sha256(mod.normalize('MM-GOOD-CODE-0001'));
  const db = { licenses: [{ id: 'L1', code_hash: hash, label: 'Lincoln', active: true, starts_at: '2026-01-01T00:00:00Z', expires_at: '2099-01-01T00:00:00Z' }, { id: 'L2', code_hash: await mod.sha256(mod.normalize('MM-OLD-CODE-0001')), label: 'Old', active: true, starts_at: '2020-01-01T00:00:00Z', expires_at: '2021-01-01T00:00:00Z' }], packs: [{ key: 'LESSONS', version: 'abc123', data: { K: [1] } }] };
  let up = true, sbCalls = 0;
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    sbCalls++;
    if (!up) throw new Error('down');
    const u = new globalThis.URL(url);
    if (init && init.method === 'POST') return new Response(null, { status: 201 });
    if (u.pathname.endsWith('/licenses')) { const h = (u.searchParams.get('code_hash') || '').replace('eq.', ''); return new Response(JSON.stringify(db.licenses.filter(l => l.code_hash === h)), { status: 200, headers: { 'Content-Type': 'application/json' } }); }
    if (u.pathname.endsWith('/content_packs')) return new Response(JSON.stringify(db.packs), { status: 200, headers: { 'Content-Type': 'application/json' } });
    return new Response('[]', { status: 404 });
  };
  const kv = new Map();
  const env = { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_test', MM_KV: { get: async (k, t) => kv.has(k) ? (t === 'json' ? JSON.parse(kv.get(k)) : kv.get(k)) : null, put: async (k, v) => { kv.set(k, v); } } };
  const call = async (code, v) => { const w = []; const r = await mod.onRequestGet({ request: new Request('https://mm.test/api/content' + (v ? '?v=' + v : ''), { headers: code ? { Authorization: 'Bearer ' + code } : {} }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  try {
    eq((await call('')).status, 401, 'no code');
    eq((await call('MM-NOPE-NOPE-NOPE')).status, 401, 'unknown code');
    eq((await call('MM-OLD-CODE-0001')).status, 403, 'expired code');
    const ok = await call('mm good code 0001', 'abc123');
    eq(ok.status, 200, 'good code (normalized)');
    const j = await ok.json(); eq(j.__label, 'Lincoln', 'label'); assert(j.LESSONS && j.LESSONS.K, 'packs missing');
    assert(/private, max-age=\d+/.test(ok.headers.get('Cache-Control')), 'no private cache header');
    const before = sbCalls; eq((await call('MM-GOOD-CODE-0001', 'abc123')).status, 200, 'second call');
    assert(sbCalls - before <= 1, 'second call should be served from KV (only the usage log hits Supabase)');
    up = false;
    eq((await call('MM-GOOD-CODE-0001', 'abc123')).status, 200, 'Supabase down: a recently valid code should still work from KV');
    kv.clear(); eq((await call('MM-GOOD-CODE-0001', 'abc123')).status, 503, 'Supabase down with nothing cached should be 503, not 401');
    /* V23: other websites, too many devices, too many requests a day */
    up = true; kv.clear();
    const req = (h) => { const w = []; return mod.onRequestGet({ request: new Request('https://mm.test/api/content?v=abc123', { headers: Object.assign({ Authorization: 'Bearer MM-GOOD-CODE-0001' }, h) }), env: Object.assign({}, env, { MM_DEVICE_LIMIT: '2', MM_DAILY_LIMIT: '5' }), waitUntil: x => w.push(x) }).then(async r => { await Promise.all(w); return r; }); };
    eq((await req({ Origin: 'https://copycat.example' })).status, 403, 'another website should be refused');
    eq((await req({ 'Sec-Fetch-Site': 'cross-site' })).status, 403, 'a cross-site request should be refused');
    eq((await req({ Origin: 'https://mm.test', 'X-MM-Device': 'a'.repeat(32) })).status, 200, 'device 1');
    eq((await req({ 'X-MM-Device': 'b'.repeat(32) })).status, 200, 'device 2');
    eq((await req({ 'X-MM-Device': 'c'.repeat(32) })).status, 429, 'a third device should be over the limit');
    eq((await req({ 'X-MM-Device': 'a'.repeat(32) })).status, 200, 'a known device still works');
    eq((await req({ 'X-MM-Device': 'b'.repeat(32) })).status, 200, 'request 4');
    eq((await req({ 'X-MM-Device': 'a'.repeat(32) })).status, 200, 'request 5');
    eq((await req({ 'X-MM-Device': 'a'.repeat(32) })).status, 429, 'over the daily limit');
  } finally { globalThis.fetch = realFetch; }
});

/* =====================================================================
   RUNNER
   ===================================================================== */
/* ---------- V22: school sign-in, class sync, Google Classroom ---------- */
async function syncRoute(store) {
  const { handle } = await import(path.join(__dirname, '..', 'lib', 'mm-sync.mjs'));
  return async route => {
    const rq = route.request(), h = rq.headers();
    const r = await handle({ request: new Request(ORIGIN + '/api/sync', { method: 'POST', headers: { 'X-MM-Room': h['x-mm-room'] || '', 'X-MM-Key': h['x-mm-key'] || '', Authorization: h['authorization'] || '' }, body: rq.postData() }), env: {} }, store, { skipLicense: /^Bearer .{8,}/.test(h['authorization'] || '') });
    return route.fulfill({ status: r.status, contentType: 'application/json', body: await r.text() });
  };
}
const SYNC_CONFIG = r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ auth: null, sso: [], sync: true }) });

test('Class sync: a teacher turns it on, a student signs in on a new device, progress follows them, a second teacher device joins; the server sees no names', async ({ ctx, errs }) => {
  const { memoryStore } = await import(path.join(__dirname, '..', 'lib', 'mm-sync.mjs'));
  const store = memoryStore(), route = await syncRoute(store), body = fullPacks();
  const licensedApi = r => r.fulfill({ status: 200, contentType: 'application/json', body });
  const routes = { '/api/config': SYNC_CONFIG, '/api/sync': route };
  const dev = async (code) => { const c = await ctx.browser().newContext({ viewport: { width: 1280, height: 860 } }); const h = await hosted(c, errs, { code, api: code ? licensedApi : null, routes }); return Object.assign(h, { c }); };
  /* device A: administrator, licensed */
  const A = await dev('MM-TEST-CODE-0001'); await setupHosted(A.p);
  await A.p.evaluate(() => { ['Ava Jones', 'Ben Lee'].forEach(n => MM91.data.createStudent(n, '4', 'Ms. Rivera')); MM91.accounts.ensureStudents(); const s = loadStore(); const ava = Object.values(s.list).find(x => x.name === 'Ava Jones'); ava.prog['quiz|4|1'] = 80; saveStore(s); });
  await A.p.evaluate(() => { openPanel('admin'); setTimeout(() => MM91.admin.open('sync'), 60); }); await A.p.waitForTimeout(500);
  assert(/Turn on class sync/.test(await A.p.innerText('#panel-admin')), 'Class sync tab missing');
  await A.p.click('[data-act=syncOn]'); await A.p.waitForFunction(() => MMSync.status().at > 0 && MMSync.mode() === 'teacher', null, { timeout: 30000 });
  await shot(A.p, 'class-sync-on');
  const L = await A.p.evaluate(() => MMSync.links());
  const ava = await A.p.evaluate(() => { const st = Object.values(loadStore().list).find(x => x.name === 'Ava Jones'); return { u: MM91.accounts.forStudent(st.id).u, c: MM91.data.codeOf(st), id: st.id }; });
  /* the server holds ciphertext only */
  const dump = JSON.stringify([...store._dump().items.values()].map(m => [...m.values()]));
  assert(!/Ava|Jones|Ben Lee|Rivera/.test(dump) && !dump.includes(ava.c) && !dump.includes(ava.u), 'a name, username or code reached the server');
  /* device B: a student's fresh device (free edition), opens the student link */
  const B = await dev(null);
  await B.p.goto(L.student); await B.p.waitForTimeout(1200);
  eq(await B.p.evaluate(() => MMSync.mode()), 'student', 'student link did not connect the device');
  assert(!(await B.p.evaluate(() => location.hash)), 'student link left the secret in the address bar');
  await B.p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await B.p.click('[data-a=as][data-v=student]').catch(() => {});
  await B.p.fill('#mm55-user', ava.u); await B.p.fill('#mm55-pass', 'WRONG1'); await B.p.click('[data-a=login]'); await B.p.waitForTimeout(2500);
  eq(await B.p.evaluate(() => !!MM91.auth.get()), false, 'wrong code signed in');
  await B.p.fill('#mm55-user', ava.u); await B.p.fill('#mm55-pass', ava.c); await B.p.click('[data-a=login]');
  await B.p.waitForFunction(() => MM91.auth.get() && MM91.auth.get().role === 'student', null, { timeout: 20000 }); await quiet(B.p);
  const onB = await B.p.evaluate(() => { const s = loadStore(); return { n: Object.keys(s.list).length, prog: (s.list[MM91.auth.get().id] || {}).prog }; });
  eq(onB.n, 1, 'a student device must receive only that student'); eq(onB.prog['quiz|4|1'], 80, 'progress from device A did not follow the student');
  /* Ava works on device B (and tries to rename herself and change her code: teacher devices must ignore that) */
  await B.p.evaluate(() => { const s = loadStore(), me = s.list[MM91.auth.get().id]; me.prog['quiz|4|2'] = 90; me.name = 'Hacker'; me.verifyCode = 'ZZZZZZ'; saveStore(s); });
  await B.p.evaluate(() => MMSync.sync());
  /* device C: a second teacher device opens the teacher link */
  const C = await dev('MM-TEST-CODE-0001'); await setupHosted(C.p);
  await C.p.goto(L.teacher); await C.p.waitForTimeout(800);
  await C.p.click('#consent-accept-btn', { timeout: 1000 }).catch(() => {});
  if (await C.p.isVisible('#mm55-user').catch(() => false)) { await C.p.click('[data-a=as][data-v=staff]').catch(() => {}); await C.p.fill('#mm55-user', 'admin'); }
  /* signed in already (same session) or after sign-in: the confirm dialog appears */
  await C.p.waitForSelector('#mm-modal-backdrop.open', { timeout: 8000 });
  assert(/Connect this device/.test(await C.p.innerText('#mm-modal-backdrop')), 'teacher link should ask before connecting');
  await C.p.click('#mm-modal-backdrop .btn-calc:not(.ghost)');
  await C.p.waitForFunction(() => MMSync.mode() === 'teacher' && Object.keys(loadStore().list).length >= 2, null, { timeout: 30000 });
  const onC = await C.p.evaluate(id => { const s = loadStore(), st = s.list[id]; return { names: Object.values(s.list).map(x => x.name).sort().join(), prog: st && st.prog, u: MM91.accounts.forStudent(id) && MM91.accounts.forStudent(id).u }; }, ava.id);
  eq(onC.names, 'Ava Jones,Ben Lee', 'roster on the second teacher device');
  assert(onC.prog && onC.prog['quiz|4|1'] === 80 && onC.prog['quiz|4|2'] === 90, 'progress from both devices did not merge: ' + JSON.stringify(onC.prog));
  eq(onC.u, ava.u, 'username must be the same on every device');
  eq(await C.p.evaluate(id => loadStore().list[id].name + '|' + MM91.data.codeOf(loadStore().list[id]), ava.id), 'Ava Jones|' + ava.c, 'a student device changed teacher-managed fields');
  /* device A catches up */
  await A.p.evaluate(() => MMSync.sync()); await A.p.waitForTimeout(300);
  eq(await A.p.evaluate(id => loadStore().list[id].prog['quiz|4|2'], ava.id), 90, 'device A did not receive the student\'s new work');
  /* removing a student on A removes it from C */
  await A.p.evaluate(() => { const s = loadStore(); const ben = Object.values(s.list).find(x => x.name === 'Ben Lee'); delete s.list[ben.id]; saveStore(s); });
  await A.p.evaluate(() => MMSync.sync()); await C.p.evaluate(() => MMSync.sync()); await C.p.waitForTimeout(300);
  eq(await C.p.evaluate(() => Object.values(loadStore().list).map(x => x.name).join()), 'Ava Jones', 'a removed student should be removed on other teacher devices');
  /* delete the class */
  await A.p.evaluate(() => { openPanel('admin'); setTimeout(() => MM91.admin.open('sync'), 60); }); await A.p.waitForTimeout(400);
  await A.p.click('[data-act=syncDrop]'); await A.p.click('#mm-modal-backdrop .btn-calc:not(.ghost)'); await A.p.waitForTimeout(800);
  eq(await A.p.evaluate(() => MMSync.mode()), 'off', 'device A still syncing after delete'); eq(store._dump().rooms.size, 0, 'class not deleted on the server');
  for (const d of [A, B, C]) await d.c.close();
}, { timeout: 180000 });

test('Class sync needs the school license; the free edition explains it', async ({ ctx, errs }) => {
  const { memoryStore } = await import(path.join(__dirname, '..', 'lib', 'mm-sync.mjs'));
  const { p } = await hosted(ctx, errs, { routes: { '/api/config': SYNC_CONFIG, '/api/sync': await syncRoute(memoryStore()) } });
  await setupHosted(p);
  await p.evaluate(() => { openPanel('admin'); setTimeout(() => MM91.admin.open('sync'), 60); }); await p.waitForTimeout(500);
  const t = await p.innerText('#panel-admin');
  assert(/part of the school license/i.test(t) && !(await p.$('[data-act=syncOn]')), 'free edition should not offer class sync');
  const r = await p.evaluate(() => MMSync.turnOn()); eq(r, false, 'turnOn without a license');
});

test('School sign-in: Clever/ClassLink buttons for students and adults; a teacher and a student sign in; a portal launch restarts the flow', async ({ ctx, errs }) => {
  const lib = await import(path.join(__dirname, '..', 'lib', 'mm-server.mjs'));
  const verify = await import(path.join(__dirname, '..', 'functions', 'api', 'sso-verify.js'));
  const env = { MM_TOKEN_SECRET: 'q'.repeat(40) };
  let who = null; const starts = [];
  const routes = {
    '/api/config': r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ auth: null, sso: ['clever', 'classlink'], sync: false }) }),
    '/api/sso/clever': async r => { const n = new globalThis.URL(r.request().url()).searchParams.get('n'); starts.push(n); const a = await lib.signBlob(env, 'MMA1', Object.assign({ p: 'clever', nn: n }, who), 120000); return r.fulfill({ status: 302, headers: { Location: ORIGIN + '/#mm-sso=' + a } }); },
    '/api/sso-verify': async r => { const res = await verify.onRequestPost({ request: new Request(ORIGIN + '/api/sso-verify', { method: 'POST', body: r.request().postData() }), env, waitUntil: () => {} }); return r.fulfill({ status: res.status, contentType: 'application/json', body: await res.text() }); },
  };
  const { p } = await hosted(ctx, errs, { routes });
  await setupHosted(p);
  await p.evaluate(async (pw) => { await MM91.accounts.add({ username: 'rivera', name: 'Ms. Rivera', email: 'rivera@lincoln.org', role: 'teacher', scope: 'all', password: pw, by: 't' }); MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); MM91.accounts.ensureStudents(); }, PW);
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(600);
  await p.click('[data-a=as][data-v=student]').catch(() => {}); await p.waitForTimeout(300);
  const sb = await p.$$eval('#mm-auth [data-sso]', x => x.map(b => b.textContent.trim()));
  assert(sb.join() === 'CClever,CLClassLink', 'school sign-in buttons on the student side: ' + sb);
  await shot(p, 'school-signin-student');
  await p.click('[data-a=as][data-v=staff]'); await p.waitForTimeout(300);
  assert(await p.$('#mm-auth [data-sso=clever]'), 'school sign-in buttons on the adult side');
  /* a teacher */
  who = { r: 'teacher', nm: 'Maria Rivera', e: 'rivera@lincoln.org', sub: 'SUBteacher00000000000000000' };
  await p.click('#mm-auth [data-sso=clever]');
  await p.waitForFunction(() => window.MM91 && MM91.auth.get() && MM91.auth.get().u === 'rivera', null, { timeout: 15000 });
  assert(!(await p.evaluate(() => location.hash)), 'the sign-in result was left in the address bar');
  eq(await p.evaluate(() => (MM91.accounts.get('rivera').sso || []).join()), 'clever:SUBteacher00000000000000000', 'teacher account not linked');
  /* a student, matched by name and linked */
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(500);
  who = { r: 'student', nm: 'Ava Jones', e: '', sub: 'SUBstudent00000000000000000' };
  await p.click('#mm-auth [data-sso=clever]');
  await p.waitForFunction(() => window.MM91 && MM91.auth.get() && MM91.auth.get().role === 'student', null, { timeout: 15000 });
  eq(await p.evaluate(() => (loadStore().list[MM91.auth.get().id].sso || []).join()), 'clever:SUBstudent00000000000000000', 'student record not linked');
  /* a student this device doesn't know */
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(500);
  who = { r: 'student', nm: 'Zed Unknown', e: '', sub: 'SUBnobody000000000000000000' };
  await p.click('#mm-auth [data-sso=clever]'); await p.waitForTimeout(2500);
  assert(!(await p.evaluate(() => !!MM91.auth.get())) && /not on this device yet/.test(await p.innerText('#mm-auth')), 'unknown student should be asked to use their code once');
  /* a result replayed in another tab is refused (nonce) */
  const replay = await lib.signBlob(env, 'MMA1', { p: 'clever', nn: 'not-this-tab-nonce-000000', r: 'teacher', nm: 'X', e: 'rivera@lincoln.org', sub: 'S' }, 120000);
  await p.goto(ORIGIN + '/#mm-sso=' + replay); await p.waitForTimeout(1500);
  assert(!(await p.evaluate(() => !!MM91.auth.get())), 'a result from another browser signed in');
  /* a Clever Portal launch arrives as #mm-sso-start=clever and goes straight through */
  who = { r: 'teacher', nm: 'Maria Rivera', e: 'rivera@lincoln.org', sub: 'SUBteacher00000000000000000' };
  const n0 = starts.length;
  await p.goto(ORIGIN + '/#mm-sso-start=clever');
  await p.waitForFunction(() => window.MM91 && MM91.auth.get() && MM91.auth.get().u === 'rivera', null, { timeout: 15000 });
  assert(starts.length === n0 + 1 && /^[A-Za-z0-9_-]{24,}$/.test(starts[n0]), 'portal launch should start with a fresh nonce');
}, { timeout: 120000 });

test('Google Classroom: share buttons on the teacher view and the live-game lobby; a shared lesson link opens after sign-in', async ({ ctx, errs }) => {
  const body = fullPacks();
  const { p } = await hosted(ctx, errs, { code: 'MM-TEST-CODE-0001', api: r => r.fulfill({ status: 200, contentType: 'application/json', body }), routes: { '/api/config': SYNC_CONFIG } });
  await setupHosted(p);
  await p.evaluate(() => { window.__opened = []; window.open = (u) => { window.__opened.push(u); return {}; }; setGrade('4'); gotoLesson(2); }); await p.waitForTimeout(900);
  await p.waitForSelector('#panel-lessons .mm-share [data-share-url]', { timeout: 5000 });
  await p.click('#panel-lessons .mm-share [data-share-url] >> nth=1');
  const u = await p.evaluate(() => window.__opened[0]);
  assert(u && u.startsWith('https://classroom.google.com/share?url='), 'Classroom share link: ' + u);
  const shared = decodeURIComponent(u.split('url=')[1]);
  eq(shared, ORIGIN + '/?open=quiz&grade=4&week=3', 'shared link');
  /* live-game lobby: only a join link through the school's live server is worth sharing */
  await p.evaluate(() => { closePanel(true); MMGameShow.open(); }); await p.waitForTimeout(500);
  await p.evaluate(() => { const g = document.getElementById('mm-gs'), d = document.createElement('div'); d.className = 'gs-row'; d.innerHTML = '<input class="gl-link" readonly value="https://mm.test/?sb=https%3A%2F%2Fx.supabase.co&sk=k#join-ABC123">'; g.appendChild(d); }); await p.waitForTimeout(400);
  assert(await p.$('#mm-gs .gl-link + .mm-share-btn, #mm-gs .gs-row .mm-share-btn'), 'no Share to Classroom in the live lobby');
  await p.evaluate(() => MMGameShow.close());
  /* a student opens the shared link on a fresh device: after signing in, the quiz opens */
  const stu = await p.evaluate(() => { const st = MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); MM91.accounts.ensureStudents(); return { u: MM91.accounts.forStudent(st.id).u, c: MM91.data.codeOf(st) }; });
  await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(400);
  await p.goto(shared); await p.waitForTimeout(1000);
  assert(!/open=/.test(await p.evaluate(() => location.search)), 'link left in the address bar');
  await p.click('[data-a=as][data-v=student]').catch(() => {});
  await p.fill('#mm55-user', stu.u); await p.fill('#mm55-pass', stu.c); await p.click('[data-a=login]'); await p.waitForTimeout(3500);
  /* a new student takes the Financial Literacy Assessment first (school policy); the link waits for it */
  assert(await p.evaluate(() => !!MMLinks._pending() && !!document.querySelector('#panel-assessment.open')), 'the link should wait for the first assessment');
  /* the school turns the policy off (the same release happens when the assessment is finished) */
  await p.evaluate(() => { MM91.accounts.setPolicy(Object.assign({}, MM91.accounts.policy(), { assessFirst: false })); closePanel(true); });
  await p.waitForFunction(() => document.querySelector('#panel-quiz.open'), null, { timeout: 8000 });
  eq(await p.evaluate(() => currentIndex), 2, 'the shared week did not open');
});

test('Get a quote: a school gets a numbered quote request to print; with prices it totals; offline it still works; the endpoint validates', async ({ ctx, errs }) => {
  const q = await import(path.join(__dirname, '..', 'functions', 'api', 'quote.js'));
  assert(/^Q\d{6}-[2-9A-HJ-NP-Z]{4}$/.test(q.quoteNo()), 'quote number format: ' + q.quoteNo());
  eq(q.clean({ school: 'X', contact: 'Y', email: 'bad' }).error, 'Enter a valid email address.', 'email check');
  eq(q.clean({ school: 'X', contact: 'Y', email: 'a@b.org', website: 'spam' }).error, 'bad request', 'spam trap');
  const ok = q.clean({ school: ' Lincoln ', contact: 'Ana', email: 'Ana@Lincoln.org', students: '420', wants: ['school', 'hack'], pay: 'po', schools: 3 });
  assert(ok.row && ok.row.email === 'ana@lincoln.org' && ok.row.students === 420 && ok.row.wants.join() === 'school,pay:po,schools:3', 'clean: ' + JSON.stringify(ok));
  let mode = 'ok', posted = null;
  const routes = { '/api/quote': r => { posted = JSON.parse(r.request().postData()); return mode === 'ok' ? r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ quote_no: 'Q261027-ABCD', created_at: '2026-10-27T15:00:00Z' }) }) : r.fulfill({ status: 503, contentType: 'application/json', body: '{"error":"Online quote requests are not set up yet."}' }); } };
  const { p } = await hosted(ctx, errs, { routes });
  await p.goto(ORIGIN + '/quote.html'); await p.waitForTimeout(600);
  assert(await p.$('#wants input[value=school]:checked'), 'items from pricing.json');
  await p.fill('[name=school]', 'Lincoln Elementary'); await p.fill('[name=contact]', 'Ana Ruiz'); await p.fill('[name=email]', 'not-an-email');
  await p.click('#go'); await p.waitForTimeout(200);
  assert(/valid email/.test(await p.innerText('#msg')), 'bad email accepted');
  await p.fill('[name=email]', 'ana@lincoln.org'); await p.fill('[name=students]', '420'); await p.check('#grades input[value="4"]'); await p.check('#grades input[value="5"]');
  await p.click('#go'); await p.waitForSelector('#doc .doc h2', { timeout: 5000 });
  const t = await p.innerText('#docbody');
  assert(/Quote request/.test(t) && /Q261027-ABCD/.test(t) && /Lincoln Elementary/.test(t) && /To be confirmed/.test(t) && /Grades 4, 5/.test(t), 'quote document: ' + t.slice(0, 300));
  assert(posted && posted.school === 'Lincoln Elementary' && !('website' in posted && posted.website), 'request body');
  await shot(p, 'quote-request');
  const ax = await p.evaluate(fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8') + ';axe.run(document).then(r=>r.violations.filter(v=>v.impact==="critical"||v.impact==="serious").map(v=>v.id))');
  eq(ax.length, 0, 'quote page accessibility: ' + ax.join(', '));
  /* with prices */
  await ctx.route(ORIGIN + '/pricing.json', r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ seller: { name: 'Money Matters', email: 'sales@example.org' }, currency: 'USD', showPrices: true, items: [{ id: 'school', label: 'School license', per: 'school', price: 1200 }, { id: 'sync', label: 'Class sync', included: 'school' }], terms: ['Valid 30 days.'] }) }));
  await p.goto(ORIGIN + '/quote.html'); await p.waitForTimeout(600);
  await p.fill('[name=school]', 'Lincoln'); await p.fill('[name=contact]', 'Ana'); await p.fill('[name=email]', 'ana@lincoln.org'); await p.fill('[name=schools]', '3'); await p.check('#wants input[value=sync]');
  await p.click('#go'); await p.waitForSelector('#doc .doc h2', { timeout: 5000 });
  const t2 = await p.innerText('#docbody');
  eq(await p.innerText('#docbody h2'), 'Quote', 'a fully priced document is a quote, not a request');
  assert(/\$3,600\.00/.test(t2) && /Included/.test(t2), 'priced quote: ' + t2.slice(0, 400));
  /* the server is down: the school still gets a document and can email it */
  mode = 'down';
  await p.click('#edit'); await p.click('#go'); await p.waitForSelector('#doc .doc h2', { timeout: 5000 });
  assert(/could not send this online/.test(await p.innerText('#docbody')) && /^R\d{6}-/m.test((await p.innerText('.meta')).trim()), 'offline fallback');
  /* phone width */
  await p.setViewportSize({ width: 360, height: 760 }); await p.click('#edit'); await p.waitForTimeout(200);
  eq(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true, 'quote page scrolls sideways on a phone');
});

test('Usage counts: the page sends only event counts (no names, ids or codes); the endpoint validates; an administrator can turn it off', async ({ ctx, errs }) => {
  const u = await import(path.join(__dirname, '..', 'functions', 'api', 'usage.js'));
  const now = new Date('2026-10-27T12:00:00Z');
  eq(u.clean({ d: '2026-10-20', e: { gameshow: 1 } }, now), null, 'old day accepted');
  const c = u.clean({ d: '2026-10-27', e: { 'lesson:4:3': 2, 'bad event!': 4, gameshow: 5000, 'panel:x': 0 } }, now);
  assert(c && c.events.join() === 'lesson:4:3,gameshow' && c.counts.join() === '2,1000', 'clean: ' + JSON.stringify(c));
  const sent = [];
  const routes = { '/api/config': r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ auth: null, sso: [], sync: false, usage: true }) }), '/api/usage': r => { sent.push(JSON.parse(r.request().postData())); return r.fulfill({ status: 204, body: '' }); } };
  const { p } = await hosted(ctx, errs, { routes });
  await setupHosted(p);
  await p.evaluate(() => { MM91.data.createStudent('Ava Jones', '4', 'Ms. Rivera'); setGrade('4'); gotoLesson(0); }); await p.waitForTimeout(3500);
  await p.evaluate(() => { closePanel(true); MMGameShow.open(); }); await p.waitForTimeout(2000); await p.evaluate(() => MMGameShow.close());
  await p.evaluate(() => MMUsage.flush()); await p.waitForTimeout(500);
  const all = sent.reduce((o, b) => Object.assign(o, b.e), {}), keys = Object.keys(all);
  assert(keys.includes('lesson:4:1') && keys.includes('gameshow') && keys.includes('session:admin') && keys.some(k => /^edition:/.test(k)), 'usage events: ' + keys.join(', '));
  const raw = JSON.stringify(sent);
  assert(!/Ava|Jones|Admin|@|s_[0-9a-f]{6}/.test(raw), 'usage report carries personal data: ' + raw);
  await p.evaluate(() => { openPanel('admin'); setTimeout(() => MM91.admin.open('settings'), 60); }); await p.waitForTimeout(600);
  await p.uncheck('#mm-usage-on'); sent.length = 0;
  await p.evaluate(() => { closePanel(true); openPanel('glossary'); }); await p.waitForTimeout(2000); await p.evaluate(() => MMUsage.flush()); await p.waitForTimeout(400);
  eq(sent.length, 0, 'usage still sent after turning it off');
});

test('Cloudflare functions: Clever and ClassLink sign-in (state, portal launches, roles, district licenses, one-time results)', async () => {
  const lib = await import(path.join(__dirname, '..', 'lib', 'mm-server.mjs'));
  const sso = await import(path.join(__dirname, '..', 'functions', 'api', 'sso', '[provider].js'));
  const verify = await import(path.join(__dirname, '..', 'functions', 'api', 'sso-verify.js'));
  const kv = new Map();
  const env = { SUPABASE_URL: 'https://x.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_test', MM_TOKEN_SECRET: 'z'.repeat(40), CLEVER_CLIENT_ID: 'cl-id', CLEVER_CLIENT_SECRET: 'cl-secret', CLASSLINK_CLIENT_ID: 'ck-id', CLASSLINK_CLIENT_SECRET: 'ck-secret', MM_KV: { get: async k => kv.get(k) || null, put: async (k, v) => { kv.set(k, v); } } };
  const lics = [{ id: 'LD', label: 'Lincoln District', active: true, starts_at: null, expires_at: '2099-01-01T00:00:00Z', sso_orgs: ['clever:d1'], emails: [], email_domain: null }, { id: 'LE', label: 'Oak School', active: true, starts_at: null, expires_at: null, sso_orgs: [], emails: [], email_domain: 'oak.k12.us' }];
  const seen = [];
  const fake = async (url, init) => {
    const u = new globalThis.URL(url); seen.push({ url: u.origin + u.pathname, init });
    if (u.href === 'https://clever.com/oauth/tokens') { const b = JSON.parse(init.body); assert(init.headers.Authorization === 'Basic ' + btoa('cl-id:cl-secret'), 'Clever: client secret not sent with HTTP Basic'); assert(b.redirect_uri === 'https://mm.test/api/sso/clever', 'Clever: redirect_uri'); return new Response(JSON.stringify(b.code === 'stu' ? { access_token: 'at', id_token: 'h.' + btoa(JSON.stringify({ iss: 'https://clever.com', aud: 'cl-id', exp: Math.floor(Date.now() / 1000) + 600, user_type: 'student', given_name: 'Ava', family_name: 'Jones', multi_role_user_id: 'cs1', district: 'd1', email: 'ava@kids.org' })).replace(/=+$/, '') + '.sig' } : { access_token: 'at-' + b.code }), { status: 200 }); }
    if (u.href === 'https://api.clever.com/v3.0/me') return new Response(JSON.stringify({ data: { id: 'ct1', district: 'd1', type: 'user' } }), { status: 200 });
    if (u.href === 'https://api.clever.com/v3.0/users/ct1') return new Response(JSON.stringify({ data: { id: 'ct1', email: 'Rivera@Lincoln.org', name: { first: 'Maria', last: 'Rivera' }, roles: { teacher: {} } } }), { status: 200 });
    if (u.href === 'https://launchpad.classlink.com/oauth2/v2/token') { const b = new URLSearchParams(init.body); assert(b.get('client_secret') === 'ck-secret' && b.get('client_id') === 'ck-id' && b.get('grant_type') === 'authorization_code', 'ClassLink token request'); return new Response(JSON.stringify({ access_token: 'cat' }), { status: 200 }); }
    if (u.href === 'https://nodeapi.classlink.com/v2/my/info') return new Response(JSON.stringify({ UserId: 77, TenantId: 9, Email: 'Boss@Oak.k12.us', FirstName: 'Dana', LastName: 'Oak', Role: 'Tenant Administrator' }), { status: 200 });
    if (u.pathname.endsWith('/licenses')) { const org = (u.searchParams.get('sso_orgs') || '').match(/"([^"]+)"/), or = u.searchParams.get('or') || ''; const dm = (or.match(/email_domain\.eq\."([^"]+)"/) || [])[1]; return new Response(JSON.stringify(lics.filter(l => (org && l.sso_orgs.includes(org[1])) || (dm && l.email_domain === dm))), { status: 200 }); }
    if (init && init.method === 'POST') return new Response(null, { status: 201 });
    return new Response('{}', { status: 404 });
  };
  const go = async (p, cookie) => sso.onRequestGet({ request: new Request('https://mm.test' + p, { headers: cookie ? { Cookie: cookie } : {} }), env, params: { provider: p.split('/')[3].split('?')[0] } }, fake);
  const frag = r => decodeURIComponent((r.headers.get('Location') || '').split('#')[1] || '');
  const ver = async (a, n) => { const w = []; const r = await verify.onRequestPost({ request: new Request('https://mm.test/api/sso-verify', { method: 'POST', body: JSON.stringify({ a, n }) }), env, waitUntil: x => w.push(x) }); await Promise.all(w); return r; };
  const realFetch = globalThis.fetch; globalThis.fetch = fake;
  try {
    eq((await go('/api/sso/nope')).status, 404, 'unknown provider');
    eq(frag(await go('/api/sso/clever')), 'mm-sso-start=clever', 'no nonce: back to the page to start properly');
    const nonce = 'n'.repeat(24);
    const st = await go('/api/sso/clever?n=' + nonce);
    const loc = new globalThis.URL(st.headers.get('Location'));
    eq(loc.origin + loc.pathname, 'https://clever.com/oauth/authorize', 'goes to Clever'); eq(loc.searchParams.get('client_id'), 'cl-id', 'client id');
    const state = loc.searchParams.get('state'), ck = (st.headers.get('Set-Cookie') || '').split(';')[0];
    assert(/HttpOnly/.test(st.headers.get('Set-Cookie')) && /Secure/.test(st.headers.get('Set-Cookie')), 'state cookie must be HttpOnly and Secure');
    eq(frag(await go('/api/sso/clever?code=teach', ck)), 'mm-sso-start=clever', 'portal launch (no state) must restart from our page');
    assert(/^mm-sso-error=/.test(frag(await go('/api/sso/clever?code=teach&state=wrong', ck))), 'wrong state accepted');
    assert(/^mm-sso-error=/.test(frag(await go('/api/sso/clever?code=teach&state=' + state))), 'missing cookie accepted');
    const back = frag(await go('/api/sso/clever?code=teach&state=' + state, ck));
    assert(/^mm-sso=MMA1\./.test(back), 'no signed result: ' + back);
    const a = back.slice('mm-sso='.length);
    eq((await ver(a, 'x'.repeat(24))).status, 401, 'result accepted with another nonce');
    const t = await (await ver(a, nonce)).json();
    eq(t.role, 'teacher', 'Clever teacher role'); eq(t.email, 'rivera@lincoln.org', 'email'); eq(t.name, 'Maria Rivera', 'name');
    assert(t.licensed && /^MMD1\./.test(t.token) && t.label === 'Lincoln District', 'district license (clever:d1) did not unlock: ' + JSON.stringify(t));
    assert(!JSON.stringify(t).includes('ct1'), 'the Clever user id must not reach the page');
    eq((await ver(a, nonce)).status, 409, 'a result can be used once');
    /* student via OIDC id_token; no email kept */
    const st2 = await go('/api/sso/clever?n=' + nonce); const s2 = new globalThis.URL(st2.headers.get('Location')).searchParams.get('state');
    const b2 = frag(await go('/api/sso/clever?code=stu&state=' + s2, (st2.headers.get('Set-Cookie') || '').split(';')[0]));
    const s = await (await ver(b2.slice(7), nonce)).json();
    assert(s.role === 'student' && s.name === 'Ava Jones' && s.email === '' && s.licensed, 'Clever student: ' + JSON.stringify(s));
    /* ClassLink administrator, licensed by email domain */
    const st3 = await go('/api/sso/classlink?n=' + nonce); const l3 = new globalThis.URL(st3.headers.get('Location'));
    eq(l3.origin, 'https://launchpad.classlink.com', 'goes to ClassLink'); eq(l3.searchParams.get('scope'), 'profile', 'ClassLink scope');
    const b3 = frag(await go('/api/sso/classlink?code=c&state=' + l3.searchParams.get('state'), (st3.headers.get('Set-Cookie') || '').split(';')[0]));
    const c = await (await ver(b3.slice(7), nonce)).json();
    assert(c.role === 'admin' && c.email === 'boss@oak.k12.us' && c.licensed && c.label === 'Oak School', 'ClassLink admin: ' + JSON.stringify(c));
    eq(c.sub === t.sub, false, 'different people get different ids');
    /* expiry */
    const old = await lib.signBlob(env, 'MMA1', { p: 'clever', r: 'teacher', sub: 'x', nn: nonce, x: Date.now() - 1 }, 0);
    eq((await ver(old, nonce)).status, 401, 'expired result accepted');
    /* not configured */
    const off = await sso.onRequestGet({ request: new Request('https://mm.test/api/sso/clever?n=' + nonce), env: Object.assign({}, env, { CLEVER_CLIENT_SECRET: '' }), params: { provider: 'clever' } }, fake);
    assert(/not set up/.test(frag(off)), 'unconfigured provider should say so');
  } finally { globalThis.fetch = realFetch; }
});

test('Cloudflare function: class sync (school license, teacher and student access, owner proofs, conflicts)', async () => {
  const { handle, memoryStore } = await import(path.join(__dirname, '..', 'lib', 'mm-sync.mjs'));
  const { sha256 } = await import(path.join(__dirname, '..', 'lib', 'mm-server.mjs'));
  const store = memoryStore(), room = 'a'.repeat(64), W = 'teacher-secret-'.padEnd(43, 'w'), S = 'student-secret-'.padEnd(43, 's');
  const call = async (key, body, opts) => { const r = await handle({ request: new Request('https://mm.test/api/sync', { method: 'POST', headers: { 'X-MM-Room': room, 'X-MM-Key': key }, body: JSON.stringify(body) }), env: {} }, store, opts); return { status: r.status, j: await r.json() }; };
  const wh = await sha256(W), shh = await sha256(S);
  eq((await call(W, { op: 'create', w_hash: wh, s_hash: shh })).status, 402, 'a class needs a school license');
  eq((await call(W, { op: 'create', w_hash: wh, s_hash: shh }, { skipLicense: true })).status, 200, 'create');
  eq((await call(W, { op: 'create', w_hash: wh, s_hash: shh }, { skipLicense: true })).j.existed, true, 'create again is harmless');
  eq((await call('x'.repeat(43), { op: 'list' })).status, 403, 'wrong key');
  const proof = 'owner-proof-'.padEnd(43, 'p'), rid = 'r'.repeat(24), lid = 'l'.repeat(32), codeProof = 'code-proof-'.padEnd(43, 'c');
  const loginBody = Buffer.from(JSON.stringify({ s: 'SALTsaltSALT', c: 'v1.xx.yy' })).toString('base64url');
  const put = await call(W, { op: 'put', items: [{ id: 'roster', kind: 'roster', body: 'v1.aa.bb', ver: 0 }, { id: rid, kind: 'student', body: 'v1.cc.dd', ver: 0, owner_hash: await sha256(proof) }, { id: lid, kind: 'login', body: loginBody, ver: 0, owner_hash: await sha256(codeProof) }, { id: 'bad id', kind: 'student', body: 'x', ver: 0 }] });
  assert(put.j.results[0].ok && put.j.results[1].ok && put.j.results[2].ok && put.j.results[3].error, 'teacher put: ' + JSON.stringify(put.j));
  eq((await call(W, { op: 'list', since: 0 })).j.items.length, 3, 'teacher lists everything');
  /* student devices */
  eq((await call(S, { op: 'list', since: 0 })).status, 403, 'student devices cannot list');
  eq((await call(S, { op: 'salt', id: lid })).j.s, 'SALTsaltSALT', 'salt of a sign-in entry');
  assert((await call(S, { op: 'salt', id: 'n'.repeat(32) })).j.s.length === 22, 'unknown usernames get a stand-in salt');
  eq((await call(S, { op: 'login', id: lid })).status, 404, 'a sign-in entry must not be released without the code proof (offline guessing)');
  eq((await call(S, { op: 'login', id: lid, proof: codeProof })).j.body, loginBody, 'sign-in entry with the right proof');
  for (let i = 0; i < 9; i++) eq((await call(S, { op: 'login', id: lid, proof: 'wrong'.padEnd(43, String(i)) })).status, 404, 'wrong proof');
  eq((await call(S, { op: 'login', id: lid, proof: codeProof })).status, 200, 'nine wrong codes do not lock; a right one resets the count');
  for (let i = 0; i < 10; i++) await call(S, { op: 'login', id: lid, proof: 'wrong'.padEnd(43, String(i)) });
  const locked = await call(S, { op: 'login', id: lid, proof: codeProof });
  assert(locked.status === 429 && /15 minutes/.test(locked.j.error), 'ten wrong codes in a row must lock the sign-in: ' + JSON.stringify(locked));
  eq((await call(S, { op: 'login', id: rid })).status, 404, 'student device cannot read a record as a sign-in entry');
  eq((await call(S, { op: 'get', ids: [rid] })).status, 403, 'student device cannot use teacher reads');
  eq((await call(S, { op: 'rec', id: rid, proof: 'wrong-proof'.padEnd(43, 'x') })).status, 404, 'record without the owner proof');
  const rec = await call(S, { op: 'rec', id: rid, proof }); eq(rec.j.body, 'v1.cc.dd', 'record with the owner proof');
  eq((await call(S, { op: 'recput', id: rid, proof, ver: 1, body: 'v1.ee.ff' })).j.ver, 2, 'student device updates its own record');
  eq((await call(W, { op: 'get', ids: [rid] })).j.items[0].by, 's', 'teacher devices must see that a student device wrote it');
  const stale = await call(S, { op: 'recput', id: rid, proof, ver: 1, body: 'v1.gg.hh' });
  assert(stale.status === 409 && stale.j.conflict && stale.j.body === 'v1.ee.ff', 'stale write must conflict and return the current record');
  const t2 = await call(W, { op: 'put', items: [{ id: rid, kind: 'student', body: 'v1.ii.jj', ver: 1 }] });
  assert(t2.j.results[0].conflict && t2.j.results[0].ver === 2, 'teacher stale write must conflict');
  eq((await call(S, { op: 'ssoput', id: 's'.repeat(32), body: 'v1.kk.ll' })).j.ok, true, 'student device adds a school-account entry');
  eq((await call(S, { op: 'ssoput', id: lid, body: 'v1.evil' })).j.existed, true, 'a student device cannot overwrite an entry');
  eq((await call(W, { op: 'get', ids: [lid] })).j.items[0].body, loginBody, 'entry unchanged after an overwrite attempt');
  eq((await call(S, { op: 'ssoput', id: 'z'.repeat(32), body: 'v1.' + 'a'.repeat(9000) })).status, 400, 'school-account entries are small');
  eq((await call(S, { op: 'drop' })).status, 403, 'students cannot delete the class');
  eq((await call(W, { op: 'drop' })).status, 200, 'teacher deletes the class');
  eq((await call(S, { op: 'salt', id: lid })).status, 404, 'deleted class is gone');
});

(async () => {
  const pick = ONLY.length ? tests.filter(t => ONLY.some(o => t.name.toLowerCase().includes(o.toLowerCase()))) : tests;
  const browser = await chromium.launch({ headless: !HEADED });
  let failed = 0; const t0 = Date.now();
  console.log(`Money Matters tests · ${pick.length} of ${tests.length} · ${path.relative(process.cwd(), FILE)}\n`);
  for (const t of pick) {
    const ctx = await browser.newContext({ viewport: { width: 1366, height: 900 } });
    const errs = []; const s = Date.now();
    let err = null;
    try {
      await Promise.race([t.fn({ ctx, errs }), new Promise((_, rej) => setTimeout(() => rej(new Error(`timed out after ${t.timeout / 1000}s`)), t.timeout))]);
      if (errs.length) throw new Error('uncaught page errors: ' + JSON.stringify([...new Set(errs)].slice(0, 5)));
    } catch (e) { err = e; }
    await ctx.close().catch(() => {});
    const ms = ((Date.now() - s) / 1000).toFixed(1) + 's';
    if (err) { failed++; console.log(`  ✗ ${t.name}  (${ms})\n      ${String(err.message).split('\n')[0]}`); }
    else console.log(`  ✓ ${t.name}  (${ms})`);
  }
  await browser.close();
  console.log(`\n${pick.length - failed} passed, ${failed} failed · ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  process.exit(failed ? 1 : 0);
})();
