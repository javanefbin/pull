/* =====================================================================
   "Looks clickable but isn't" scan, shared by tests/run.js and
   tests/dead-buttons.js.

   For every visible, enabled control in the viewport, the browser is asked
   what a click at its center would hit (document.elementFromPoint). Hit
   testing skips inert content and pointer-events:none, so when the answer is
   one of the control's own containers, nothing is drawn over the control and
   yet a click can't reach it. That is exactly how V19's inert bug disabled
   the Lessons panel while every button still looked fine. Controls covered by
   something else (a dialog, a backdrop) are not reported: that is expected.
   ===================================================================== */
'use strict';
const CLICKABLE = 'button, [role=button], [onclick], a[href], summary, input:not([type=hidden]), select, textarea, [data-act], [data-gs], [data-ws], [data-gl], [data-a]';

/** Runs in the page. Returns [{label, why, where}] */
function scanInPage(C) {
  const out = [], seen = new Set();
  const vw = innerWidth, vh = innerHeight;
  const label = el => (el.getAttribute('aria-label') || el.innerText || el.title || el.value || el.placeholder || el.getAttribute('data-act') || el.id || el.tagName).replace(/\s+/g, ' ').trim().slice(0, 60);
  const path = el => { const a = []; for (let n = el; n && n !== document.body && a.length < 4; n = n.parentElement) a.unshift(n.tagName.toLowerCase() + (n.id ? '#' + n.id : n.classList[0] ? '.' + n.classList[0] : '')); return a.join(' > '); };
  /* A dimming backdrop can be skipped by hit testing too (pointer-events:none, or it sits
     in the same inert region as the controls it dims). Count it as covering a control
     when it is painted above it: compare the outermost z-index each one sits in. */
  const rootZ = n => { let z = 0; for (let m = n; m && m !== document.documentElement; m = m.parentElement) { const cs = getComputedStyle(m); if (cs.position !== 'static' && cs.zIndex !== 'auto') z = +cs.zIndex; } return z; };
  const overlays = [];
  document.querySelectorAll('body *').forEach(n => {
    const cs = getComputedStyle(n);
    if (cs.position !== 'fixed' || cs.display === 'none' || cs.visibility === 'hidden' || +cs.opacity < 0.05) return;
    const r = n.getBoundingClientRect(); if (r.width * r.height < 0.2 * vw * vh) return;
    const bg = cs.backgroundColor.match(/rgba?\(([^)]+)\)/), alpha = bg ? +(bg[1].split(',')[3] || 1) : 0;
    if (alpha > 0.05 || cs.backdropFilter !== 'none') overlays.push({ n, r, z: rootZ(n) });
  });
  const dimmed = (el, x, y) => { const z = rootZ(el); return overlays.some(o => !o.n.contains(el) && o.z > z && x >= o.r.left && x <= o.r.right && y >= o.r.top && y <= o.r.bottom); };
  document.querySelectorAll(C).forEach(el => {
    if (seen.has(el)) return; seen.add(el);
    if (el.disabled || el.getAttribute('aria-disabled') === 'true' || el.closest('[aria-hidden=true]')) return;
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return;
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    if (x < 1 || y < 1 || x > vw - 1 || y > vh - 1) return;
    for (let n = el; n; n = n.parentElement) { const cs = getComputedStyle(n); if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) return; }
    /* clipped away by an overflow:hidden ancestor? then it is not really visible */
    for (let n = el.parentElement; n && n !== document.body; n = n.parentElement) { const cs = getComputedStyle(n); if (cs.overflow !== 'visible') { const pr = n.getBoundingClientRect(); if (x < pr.left || x > pr.right || y < pr.top || y > pr.bottom) return; } }
    const hit = document.elementFromPoint(x, y);
    if (!hit || hit === el || el.contains(hit)) return;
    if (!hit.contains(el)) return;               /* covered by something else: a dialog, a backdrop */
    if (dimmed(el, x, y)) return;                /* behind a dimming backdrop: unavailable, and it looks it */
    const inert = el.closest('[inert]');
    const why = inert ? 'inside an inert ' + path(inert) : getComputedStyle(el).pointerEvents === 'none' ? 'pointer-events: none' : 'a click lands on its container ' + path(hit);
    out.push({ label: label(el), why, where: path(el) });
  });
  return out;
}

async function scan(page) {
  /* let fades finish first (a backdrop fading in is not yet "covering") */
  await page.waitForFunction(() => !document.getAnimations().some(a => a instanceof CSSTransition && a.playState === 'running'), null, { timeout: 2000 }).catch(() => {});
  return page.evaluate(scanInPage, CLICKABLE);
}
module.exports = { scan, CLICKABLE };
