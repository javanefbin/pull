#!/usr/bin/env node
/* =====================================================================
   Dead-button crawler
     node tests/dead-buttons.js [admin|teacher|student] [--out file.json]
   Signs in as the role, visits every surface (home, top bar, dock, every
   panel, every Admin Console tab, Game Show lobby, workshops), and clicks
   every visible button one at a time. A click "works" when something
   observable happens within 900 ms: the screen changes, a panel or dialog
   opens or closes, something prints or downloads, data is saved, focus
   moves, a file picker or new tab opens, or a sound or speech plays.
   Clicks that throw a page error, or do nothing at all, are reported.
   Destructive buttons (sign out, delete, remove, reset, restore) are skipped.
   On every surface it also runs tests/deadzones.js: any visible control that
   looks clickable but can't be clicked (inert, pointer-events:none, or a
   click that lands on its container) is reported as "unclickable", even if
   the crawler itself would skip it.
   Known, by-design results live in tests/dead-buttons-allow.json. Anything
   else makes the run exit with code 1 (CI: .github/workflows/buttons.yml).
   ===================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { scan } = require('./deadzones');
const ALLOW = JSON.parse(fs.readFileSync(path.join(__dirname, 'dead-buttons-allow.json'), 'utf8')).allow.map(a => ({ re: new RegExp(a.match, 'i'), why: a.why }));
const ROLE = process.argv[2] || 'admin';
const OUT = (process.argv.indexOf('--out') > -1) ? process.argv[process.argv.indexOf('--out') + 1] : '';
const URL = 'file://' + path.resolve(__dirname, '..', 'dist', 'MoneyMatters.html');
const PW = 'Password123!';
const SKIP = /sign ?out|log ?out|delete|remove|reset|erase|wipe|restore|clear all|archive all|danger|year-end|rollover|revoke|lock now|exit sample|cerrar sesi|sign in as|switch to|view as|open as|español|português|english|^es$|^pt$|^en$|setlang|uninstall/i;

const CLICKABLE = 'button, [role=button], [onclick], a[href], summary, [data-act], [data-gs], [data-ws], [data-gl], [data-a]';

(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  let chooser = 0, popup = 0, download = 0;
  p.on('filechooser', () => chooser++);
  ctx.on('page', () => popup++);
  p.on('download', () => download++);

  await p.goto(URL); await p.waitForTimeout(1500);
  await p.click('#consent-accept-btn', { timeout: 1500 }).catch(() => {});
  await p.fill('#s-n', 'Test Admin'); await p.fill('#s-p1', PW); await p.fill('#s-p2', PW);
  await p.selectOption('#s-sq1', { index: 1 }); await p.fill('#s-sa0', 'a'); await p.fill('#s-sa1', 'b');
  await p.click('[data-a=dosetup]'); await p.waitForTimeout(1500);
  const stu = await p.evaluate(async (pw) => {
    localStorage.setItem('mmSetupDone', '1'); localStorage.setItem('mmTourDone', '1');
    try { endTour(); } catch (e) {} try { closePanel(true); } catch (e) {}
    document.querySelectorAll('.mmrt-ov').forEach(x => x.remove());
    await MM91.accounts.add({ username: 'rivera', name: 'Ms. Rivera', role: 'teacher', scope: 'all', password: pw, by: 't' });
    const s = ['Ava Jones', 'Ben Lee', 'Cara Diaz'].map(n => MM91.data.createStudent(n, '4', 'Ms. Rivera'));
    MM91.accounts.ensureStudents();
    return { u: MM91.accounts.forStudent(s[0].id).u, c: MM91.data.codeOf(s[0]) };
  }, PW);
  if (ROLE !== 'admin') {
    await p.evaluate(() => MM91.gate.signOut()); await p.waitForTimeout(400);
    await p.click(`[data-a=as][data-v=${ROLE === 'student' ? 'student' : 'staff'}]`).catch(() => {});
    await p.fill('#mm55-user', ROLE === 'student' ? stu.u : 'rivera');
    await p.fill('#mm55-pass', ROLE === 'student' ? stu.c : PW);
    await p.click('[data-a=login]'); await p.waitForTimeout(1500);
  }
  await p.evaluate(() => { try { endTour(); } catch (e) {} try { closePanel(true); } catch (e) {} try { setGrade('4'); } catch (e) {} document.querySelectorAll('.mmrt-ov').forEach(x => x.remove()); });
  const who = await p.evaluate(() => MM91.auth.roleKey());
  console.log('signed in as', who);

  /* instrument effects (again after any reload) */
  const instrument = () => p.evaluate(() => {
    if (window.__fx) return;
    const E = window.__fx = { mut: 0, store: 0, print: 0, open: 0, dl: 0, speak: 0, sound: 0, clip: 0 };
    new MutationObserver(l => { E.mut += l.length; }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
    const ls = Storage.prototype.setItem; Storage.prototype.setItem = function () { E.store++; return ls.apply(this, arguments); };
    const lr = Storage.prototype.removeItem; Storage.prototype.removeItem = function () { E.store++; return lr.apply(this, arguments); };
    window.MMPrint && (MMPrint.capture = () => { E.print++; });
    window.print = () => { E.print++; };
    window.open = () => { E.open++; return null; };
    const ac = HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click = function () { if (this.download || /^blob:|^data:/.test(this.href)) { E.dl++; return; } return ac.apply(this, arguments); };
    try { speechSynthesis.speak = () => { E.speak++; }; } catch (e) {}
    try { const AC = window.AudioContext || window.webkitAudioContext; if (AC) { const o = AC.prototype.createOscillator; AC.prototype.createOscillator = function () { E.sound++; return o.apply(this, arguments); }; } } catch (e) {}
    try { navigator.clipboard.writeText = () => { E.clip++; return Promise.resolve(); }; } catch (e) {}
    try { document.execCommand = () => { E.clip++; return true; }; } catch (e) {}
  });
  await instrument();

  /* surfaces: [name, open code, root selector] */
  const surfaces = [['home', '', '#mm-topbar, #mm-home, #nav, #mm-tabbar']];
  const panels = await p.evaluate(() => [...document.querySelectorAll('.panel')].map(x => x.id.replace('panel-', '')).filter(x => x !== 'login'));
  for (const id of panels) surfaces.push(['panel:' + id, `openPanel('${id}')`, '#panel-' + id]);
  if (who !== 'student') {
    const tabs = await p.evaluate(async () => { openPanel('admin'); await new Promise(r => setTimeout(r, 300)); const t = [...document.querySelectorAll('#panel-admin [data-act=tab][data-id]')].map(x => x.getAttribute('data-id')); closePanel(true); return [...new Set(t)]; });
    for (const t of tabs) surfaces.push(['admin:' + t, `openPanel('admin');setTimeout(()=>MM91.admin.open('${t}'),60)`, '#panel-admin']);
    surfaces.push(['workshops:results', `openPanel('workshops');setTimeout(()=>{const b=document.querySelector('[data-ws=tab][data-t=results]');b&&b.click()},60)`, '#panel-workshops']);
  }
  surfaces.push(['doc:plan', `openDoc('plan')`, '#panel-doc']);
  surfaces.push(['gameshow', `MMGameShow.open()`, '#mm-gs']);

  const reset = async () => {
    await p.evaluate(() => {
      try { if (typeof _closeModal === 'function') _closeModal(false); } catch (e) {}
      const bd = document.getElementById('mm-modal-backdrop'); if (bd) bd.classList.remove('open');
      ['mm-subscribe'].forEach(id => { const e = document.getElementById(id); e && e.classList.remove('open'); });
      try { sessionStorage.setItem('mmSetupAsked', '1'); localStorage.setItem('mmSetupDone', '1'); const t = document.getElementById('tour'); if (t) t.classList.remove('on'); } catch (e) {}
      try { if (typeof loadLang === 'function' && loadLang() !== 'en' && typeof setLang === 'function') setLang('en'); } catch (e) {}
      document.querySelectorAll('#v19-notices, .mmrt-ov, .mm-pop, #mm-set-pop').forEach(x => { if (x.id === 'mm-set-pop') x.style.display = 'none'; else x.remove(); });
      try { if (window.MMGameShow && MMGameShow._.isOpen && MMGameShow._.isOpen()) MMGameShow.close(); } catch (e) {}
      try { const lp = document.getElementById('mm-lp'); if (lp) lp.remove(); document.documentElement.classList.remove('mm-lp-on'); } catch (e) {}
      try { endTour(); } catch (e) {}
      try { closePanel(true); } catch (e) {}
      /* the sign-in screen (e.g. after "Change password") while still signed in */
      try { if (MM91.auth.get() && MM91.gate.visible()) MM91.gate.hide(); } catch (e) {}
      /* any other full-screen dialog left open */
      document.querySelectorAll('body > div, body > aside, body > section').forEach(d => { const cs = getComputedStyle(d); if (cs.position !== 'fixed' || cs.display === 'none' || /^(scene|backdrop|mm-topbar|nav|mm-tabbar|mm-auth|mm-modal-backdrop|info-toast|autosave-toast|offline-banner|tab-count-badge|consent-banner|mm-set-btn|mm-gs|mm-lp)$/.test(d.id) || d.classList.contains('panel')) return; const r = d.getBoundingClientRect(); if (r.width * r.height > 0.4 * innerWidth * innerHeight) d.remove(); });
      try { MM91.auth.get() || 0; } catch (e) {}
    });
    await p.waitForTimeout(120);
  };
  const listIn = (sel) => p.evaluate(({ sel, C }) => {
    const roots = [...document.querySelectorAll(sel)];
    const seen = new Set(); const out = [];
    roots.forEach(r => r.querySelectorAll(C).forEach(el => {
      if (seen.has(el)) return; seen.add(el);
      const rc = el.getBoundingClientRect(); const cs = getComputedStyle(el);
      if (!rc.width || !rc.height || cs.visibility === 'hidden' || cs.display === 'none' || el.disabled || el.getAttribute('aria-disabled') === 'true' || el.closest('[inert]')) return;
      if (el.parentElement && el.parentElement.closest(C) && el.tagName !== 'BUTTON' && el.tagName !== 'A') return; /* nested */
      const label = (el.getAttribute('aria-label') || el.innerText || el.title || el.value || el.getAttribute('data-act') || el.getAttribute('data-gs') || el.getAttribute('data-ws') || '').replace(/\s+/g, ' ').trim().slice(0, 70);
      out.push({ i: out.length, label, tag: el.tagName.toLowerCase(), act: el.getAttribute('data-act') || el.getAttribute('data-gs') || el.getAttribute('data-ws') || el.getAttribute('data-a') || '', onclick: (el.getAttribute('onclick') || '').slice(0, 80), href: el.tagName === 'A' ? el.getAttribute('href') : '' });
    }));
    return out;
  }, { sel, C: CLICKABLE });
  const openSurface = async (code) => { await reset(); if (code) { await p.evaluate(c => { try { (new Function(c))(); } catch (e) { window.__openErr = String(e); } }, code); await p.waitForTimeout(450); } };

  const report = [];
  let clicked = 0;
  for (const [name, code, sel] of surfaces) {
    await openSurface(code);
    for (const d of await scan(p)) report.push({ surface: name, label: d.label, act: '', problem: 'unclickable', detail: d.why + ' (' + d.where + ')' });
    const items = await listIn(sel);
    const done = new Set();
    for (const it of items) {
      const key = it.label + '|' + it.act + '|' + it.onclick + '|' + it.href;
      if (done.has(key)) continue; done.add(key);
      if (SKIP.test(it.label) || SKIP.test(it.act) || SKIP.test(it.onclick)) continue;
      if (it.href && /^https?:/.test(it.href)) continue; /* outside links */
      await openSurface(code);
      const now = await listIn(sel);
      const target = now.find(x => x.label === it.label && x.act === it.act && x.onclick === it.onclick && x.href === it.href);
      if (!target) continue;
      /* baseline noise */
      await instrument().catch(() => {});
      const before = await p.evaluate(() => Object.assign({}, window.__fx));
      await p.waitForTimeout(500);
      const noise = await p.evaluate(b => window.__fx.mut - b.mut, before);
      const s0 = await p.evaluate(() => ({ fx: Object.assign({}, window.__fx), panel: (document.querySelector('.panel.open') || {}).id || '', modal: !!document.querySelector('#mm-modal-backdrop.open, #mm-subscribe.open'), focus: document.activeElement ? (document.activeElement.id || document.activeElement.className) : '', scroll: scrollY, hash: location.hash, len: document.body.innerText.length, gs: document.documentElement.classList.contains('mm-gs-on') }));
      const e0 = errs.length, c0 = chooser, pp0 = popup, d0 = download;
      const handle = await p.evaluateHandle(({ sel, C, i }) => {
        const roots = [...document.querySelectorAll(sel)]; const seen = new Set(); const out = [];
        roots.forEach(r => r.querySelectorAll(C).forEach(el => { if (seen.has(el)) return; seen.add(el); const rc = el.getBoundingClientRect(); const cs = getComputedStyle(el); if (!rc.width || !rc.height || cs.visibility === 'hidden' || cs.display === 'none' || el.disabled || el.getAttribute('aria-disabled') === 'true' || el.closest('[inert]')) return; if (el.parentElement && el.parentElement.closest(C) && el.tagName !== 'BUTTON' && el.tagName !== 'A') return; out.push(el); }));
        return out[i];
      }, { sel, C: CLICKABLE, i: target.i });
      let how = 'click', blocker = '';
      if (!handle.asElement()) continue;   /* re-drawn between listing and clicking: not a dead button */
      try { await handle.asElement().click({ timeout: 2000 }); }
      catch (e) { how = 'js'; blocker = ((e.message.match(/<[^>]{0,120}> (?:from <[^>]{0,80}> subtree )?intercepts pointer events/) || [e.message.split('\n')[0]])[0]).slice(0, 160); await p.evaluate(el => el && el.click(), handle).catch(() => {}); }
      clicked++;
      await p.waitForTimeout(900);
      if (!(await p.evaluate(() => !!window.__fx).catch(() => false))) {   /* the click reloaded the page */
        await p.waitForTimeout(1500); await instrument().catch(() => {});
        report.push({ surface: name, label: it.label, act: it.act, onclick: it.onclick, problem: 'note', detail: 'reloaded the page' });
        await openSurface(code); continue;
      }
      const s1 = await p.evaluate(() => ({ fx: Object.assign({}, window.__fx), panel: (document.querySelector('.panel.open') || {}).id || '', modal: !!document.querySelector('#mm-modal-backdrop.open, #mm-subscribe.open'), focus: document.activeElement ? (document.activeElement.id || document.activeElement.className) : '', scroll: scrollY, hash: location.hash, len: document.body.innerText.length, gs: document.documentElement.classList.contains('mm-gs-on'), lp: document.documentElement.classList.contains('mm-lp-on') }));
      const fx = Object.keys(s1.fx).filter(k => k !== 'mut' && s1.fx[k] > s0.fx[k]);
      const mut = (s1.fx.mut - s0.fx.mut) - noise * 2;
      const changed = fx.length || mut > 2 || s1.panel !== s0.panel || s1.modal !== s0.modal || s1.focus !== s0.focus || s1.scroll !== s0.scroll || s1.hash !== s0.hash || s1.len !== s0.len || s1.gs !== s0.gs || s1.lp || chooser > c0 || popup > pp0 || download > d0;
      const newErr = errs.slice(e0);
      if (newErr.length) report.push({ surface: name, label: it.label, act: it.act, onclick: it.onclick, problem: 'error', detail: [...new Set(newErr)].slice(0, 2).join(' | ') });
      else if (!changed) report.push({ surface: name, label: it.label, act: it.act, onclick: it.onclick, problem: 'no effect', detail: how === 'js' ? 'not clickable (' + blocker + '); JS click also did nothing' : '' });
      else if (how === 'js') report.push({ surface: name, label: it.label, act: it.act, onclick: it.onclick, problem: 'covered', detail: 'a real click could not reach it: ' + blocker });
      if (s1.lp) { await p.evaluate(() => { const lp = document.getElementById('mm-lp'); lp && lp.remove(); document.documentElement.classList.remove('mm-lp-on'); }); }
      /* role can change (e.g. "switch profile"); restore */
      const still = await p.evaluate(() => { try { return MM91.auth.roleKey(); } catch (e) { return ''; } });
      if (still !== who) { report.push({ surface: name, label: it.label, act: it.act, problem: 'note', detail: 'changed the signed-in role to ' + still }); break; }
    }
  }
  const line = r => `[${r.problem}] ${r.surface} · "${r.label}"${r.act ? ' (' + r.act + ')' : ''}${r.onclick ? ' onclick=' + r.onclick : ''}${r.detail ? ' — ' + r.detail : ''}`;
  report.forEach(r => { const a = ALLOW.find(x => x.re.test(line(r))); if (a) r.allowed = a.why; });
  const real = report.filter(r => r.problem !== 'note' && !r.allowed);
  console.log(`clicked ${clicked} buttons; ${real.length} problems; ${report.filter(r => r.allowed).length} known and allowed`);
  report.forEach(r => console.log('  ' + (r.allowed ? '(allowed: ' + r.allowed + ') ' : '') + line(r)));
  process.exitCode = real.length ? 1 : 0;
  if (OUT) fs.writeFileSync(OUT, JSON.stringify({ role: who, clicked, report }, null, 1));
  await b.close();
})();
