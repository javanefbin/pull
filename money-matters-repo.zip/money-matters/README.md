# Money Matters — source tree

Money Matters (K–8 financial literacy) ships as **one self-contained HTML file**
(about 7.2 MB). This directory holds that file split into readable sources, a
dependency-free build that puts it back together, and an end-to-end test suite.

The tree was first extracted from V18.html, and the build reproduced it byte-for-byte.
V19 work (October 2026) was then done in `src/`, so `--check` against V18.html now
reports the first difference, which is expected. Use `--check` against the last
released file instead.

```
app/
  build.js              build + byte-for-byte check (Node, no dependencies)
  src/
    index.html          document skeleton: <head>, body chrome, and include directives
    styles/NNN-*.css    inner text of every top-level <style> block
    scripts/NNN-*.js    inner text of every top-level <script> block
    data/*.json         giant data literals cut out of the scripts (stored raw)
    panels/NN-*.html    the 22 <div class="panel" id="panel-…"> dialogs
  tools/
    extract.js          the splitter that produced src/ from V18.html (re-runnable)
    manifest.json       what extract.js produced (block → file, original line, open tag)
  tests/run.js          end-to-end suite (Playwright + axe-core)
  package.json          npm scripts: build, test, test:quick
  .github/workflows/test.yml  CI: build + full suite on every push / pull request
  dist/MoneyMatters.html  build output (generated)
```

## Test

```sh
npm ci                                   # once: Playwright and axe-core
npx playwright install chromium          # once per machine (CI does this too)
npm test                                 # both builds, then all 25 tests (about 5 minutes)
npm run test:quick                       # build check, sign-in sizes, legal, translations
node tests/run.js --only workshops --shots shots/   # one area, with screenshots
```

Every test runs in a fresh browser profile and fails on any uncaught page error. The
suite covers: the single-file build and CSP; the sign-in screen from 320 px to 4K;
setup, teacher sign-in and the teacher home; password lockout and no plain-text
passwords; every panel; every Game Show mode and a full Quiz Rush; live play with a
host and two phones; workshops for every grade and format plus all workshop
printouts; all lesson printouts; the Resource Guide's links and print; Spanish and
Portuguese; the legal pages; and accessibility (axe-core, no critical or serious
violations, Escape and focus return). The hosted edition is tested from a fake https origin with a mocked API: week 1 only in the free page, locked content never leaking, access codes (valid, revoked), Google/Microsoft/Facebook sign-in results, sponsor cards (adults only, never licensed), and the Cloudflare functions themselves (codes, device tokens, tampering, renewal, outages). `npm run buttons` crawls every button as an administrator, a teacher and a student and reports any that do nothing.

## Build

```sh
node build.js                                   # writes dist/MoneyMatters.html
node build.js --check /home/claude/work/V18.html  # build, then compare byte-for-byte
```

`--check` exits 0 when the output is byte-identical, and exits 1 otherwise (it also prints
the first differing byte, its line number, and the text on each side). Node 14 or later.

To split a new single-file release again: `node tools/extract.js <file.html>` (it
overwrites `src/`). It refuses to run if the input already contains `@include`.

## Directive syntax

| Context | Directive |
|---|---|
| HTML (`index.html`, panels) | `<!--@include path/relative/to/src-->` |
| JS / CSS | `/*@include path/relative/to/src*/` |

* The build replaces each directive with the **exact bytes** of the named file. Nothing
  is trimmed or re-serialized, and no newline is added.
* Includes resolve recursively, so a script file can include a data file. Files ending in
  `.json` are inserted raw and are never scanned for more directives. Cycles, missing
  files, and paths that leave `src/` are errors.
* Collision check: the string `@include` does not occur anywhere in V18.html, so no
  original text can be mistaken for a directive (`extract.js` checks this).
* Only the **inner text** of each block is extracted. The `<style …>`/`<script …>` open
  and close tags stay in `index.html`, so their attributes are kept exactly. When the
  original inner text started with a newline, that newline stays in `index.html`, so a
  block reads as:
  ```html
  <script id="v91-core">
  <!--@include scripts/400-v91-core.js--></script>
  ```
* In a script, a data constant looks like `const LESSONS = /*@include data/LESSONS.json*/;`.
  The JSON is the original literal, character for character. To edit it you can
  pretty-print it, but the built file will then differ from V18.html. That is expected,
  but `--check` will fail.
* Panels with an inline `<script>`/`<style>` inside would stay inline. None do today, so
  all 22 panels are extracted.

## Load order: every style and script block

The `NNN` prefix is the **global document order** (gaps of 10) across `styles/` and
`scripts/`. Within each group below, the rows are in load order. Later layers override
or wrap earlier ones, so **order matters**. Do not renumber without rebuilding and
checking.

### Data (`src/data/`, inlined into the scripts that declare them)

| File | Declared in | Size | Contents |
|---|---|---|---|
| LESSONS.json | 190-core-app.js | 669 KB | English lessons per grade K–8 (week, title, objective, sequence, worksheet) |
| SECTION_TESTS.json | 190-core-app.js | 125 KB | Unit checkpoint tests per grade |
| LESSON_QUIZ.json | 190-core-app.js | 572 KB | Per-lesson quiz questions per grade |
| LESSONS_L.json | 190-core-app.js | 1577 KB | Spanish/Portuguese lesson translations (`{es:{K:[…]},pt:…}`) |
| SECTION_TESTS_L.json | 190-core-app.js | 285 KB | Translated checkpoint tests |
| LESSON_QUIZ_L.json | 190-core-app.js | 1306 KB | Translated lesson quizzes |
| FACTS.json | 190-core-app.js | 13 KB | "Money fact" tips in en/es/pt (multi-line array) |
| MATERIAL_CARDS.json | 190-core-app.js | 193 KB | Classroom material cards (emoji, description, usage) in each language |
| S_DATA.json | 380-v80-story-mode.js | 20 KB | Story Mode scenes per grade (hero, title, acts, choices, prices) |
| WS_DATA.json | 640-mm-workshops.js | 118 KB | Workshops: 9 grades × 5 themed days (mission, outcomes, timed modules), with the 16 content corrections applied |
| WS_DATA_es.json, WS_DATA_pt.json | 640-mm-workshops.js | — | Spanish and Portuguese workshops (`WS_DATA_L`) |
| WS_STANDARDS.json | 640-mm-workshops.js | — | Jump$tart/CEE 2021 standards areas for each workshop module |
| RESOURCES.json | 680-mm-resources.js | — | Resource Guide: 60 resources in 9 sections, links checked 2026-10-26 |
| UI_L.json | 690-mm-i18n.js | — | Spanish/Portuguese interface strings for V18–V19 features: ~1,000 exact entries and ~130 `{name}` patterns per language |

### Core engine

| File | What it does |
|---|---|
| scripts/010-v68-storage-shim.js | First in `<head>`. If local/session storage are blocked (preview iframes), it installs in-memory replacements and sets `MM_NO_STORAGE`, and later shows a "progress will not be saved" toast. |
| scripts/020-v69-access-loader.js | Licensed-content loader: if an access code is stored and the page is served over http(s), it does a **synchronous** XHR to `/api/content` and exposes `__MM_FULL` / `__MM_LICENSE`. |
| styles/030-base.css | Base stylesheet (504 lines): design tokens, classroom scene (room, chalkboard, stations), nav dock, panels, lessons, quiz, certificate, print rules. |
| scripts/180-consent-controls.js | Wires the first-use consent banner right after its markup, so it still works if a later script throws. |
| scripts/190-core-app.js | Core app (3,344 lines, ~417 functions): grade constants and data, local store (`loadStore`/`saveStore`, plus cross-tab sync and quota wrappers), panels (`openPanel`/`closePanel`), lessons, worksheets, printable documents, quizzes and section tests, certificate, student profiles and PIN login, glossary, i18n (en/es/pt), tour, help, mini-games, achievements, consent/legal, changelog, and feedback. |

### Legacy layers (v43–v80)

Small additive patches, mostly IIFEs that wrap core functions or post-process the DOM.

| File | What it does |
|---|---|
| styles/040-v43-student-materials-practice-update.css | Hides the teacher "materials ready" checklist in student mode. |
| styles/060-v44-student-materials-hard-guard.css | Hides `#lessonMaterials` (and the heading before it, via `:has`) for students. |
| styles/070-v46-student-materials-fix.css | Repeats the v43 selector list (nearly identical rules). |
| styles/080-v49-role-safe-student-lesson.css | Same intent keyed on `html.role-student`: no teacher-prep checklist in student lessons. |
| styles/090-v50-holistic-ux.css | Lesson support card, support grid, status colors, and time bar used by v50. |
| styles/100-v53-progress-flow.css | Step-flow "pills" (worksheet → quiz → reflection progress). |
| styles/110-v53-final-ui.css | Printable `.v53-report` student report layout. |
| styles/120-v58-financial-profile.css | Financial Literacy Assessment UI (intro, progress bar, question cards, results). |
| styles/130-v75-story-mode.css | Story Mode hero, scene, and choice styles (one minified line). |
| scripts/200-v46-quiz-reflection.js | Adds a written-reflection box under quizzes, using a documentElement MutationObserver. |
| scripts/210-v50-holistic-enhancement.js | Lesson support card (objective, minutes, worksheet/quiz/reflection status), student-safety hiding, worksheet prompts. Wraps `submitQuiz` and `runQualityAudit`. |
| styles/220-v55-login-ui.css | Full-screen role-first sign-in gate (`#mm-login-gate`). |
| scripts/230-v55-login-system.js | v55 role-first sign-in (Student/Teacher, then username/password) with session in `mmAuth_v1`. Wraps `openPanel` and `signOut`. |
| scripts/240-v55-game-reflection-hardening.js | Wraps `mmGameWrong` to force a reflection pause after the 3rd wrong answer. |
| scripts/250-v55-student-code-wrap.js | Wraps `createStudent` so every new student gets a `verifyCode`. |
| scripts/260-v56-login-owner-create-student.js | Owner mode (admin teacher) and creating a student from the login gate. Redefines `signOut` locally. |
| scripts/270-v58-financial-literacy-profile.js | Financial Literacy Assessment: 8 domains, proficiency bands, grading, and results. Replaces `renderTeacher` and `reportHTML`. |
| scripts/280-v59-routing-and-home.js | Startup routing: opens on the classroom home, with student-first assessment entry. Wraps `switchStudent` and `createStudent`. |
| styles/290-v60-65-enhancement-css.css | Profile hero, level, and progress-track styles for the adaptive profile. |
| scripts/300-v60-65-adaptive-financial-literacy.js | Adaptive profile: stores application scores and reflections, class summary. Wraps `renderDashboard`, `renderTeacher`, `renderPath`, `reportHTML`, and `renderFinancialAssessment`. |
| styles/310-v66-clean-ui.css | One-question-at-a-time assessment shell and a cleaner teacher workspace. |
| scripts/320-v66-clean-ui.js | Paged assessment navigation. Wraps `renderTeacher` again. |
| scripts/330-v67-launch.js | "Launch" patch: merges the v55–v66 changelog, settings gear popover, data export/import, demo buttons, quiz/test pagination (body MutationObserver), and wraps `submitFeedback`. |
| scripts/340-v70-admin-gear-fixes.js | Admin password (inline SHA-256 with salt and iteration count), admin login wrapper over `mmV55Login`, change-password dialog, and gear placement. |
| scripts/350-v72-student-switch.js | Stops a signed-in student from switching to another profile. Wraps `switchStudent` and `signOut`. |
| styles/370-v76-story-enhancements.css | Story scenario picker grid and selected states. |
| scripts/380-v80-story-mode.js | Story Mode engine (v81): 4 acts, 8 scenes, events, loan, matching, finale. Scenarios, skills, evidence log. Uses `data/S_DATA.json`. |
| scripts/390-v80-teacher-evidence.js | Wraps `renderTeacher` (4th time) to append the Story Mode evidence for the selected student. |

### Professional suite (v91–v95)

| File | What it does |
|---|---|
| styles/140-v91-pro-ui.css | v91 design system: tokens and motion, global polish, component library, top bar and reorganized navigation, sign-in gate, admin console and profiles. |
| styles/150-v92-accounts-ui.css | Unified sign-in card, sparklines, users-console cards and log tables, and the native dark theme. |
| styles/160-v93-polish.css | Polish for dialogs, classroom, quiz and test, certificate redesign, and school views. |
| styles/170-v94-mobile-reader.css | Phone lesson reader, touch targets, install prompt, phone tour, share class, student packet, a11y, and smoke-test styles. |
| scripts/400-v91-core.js | `MM91` core: util, data, auth (professional sign-in gate), shell (top bar and home placement), tour. Wraps `openPanel`, `closePanel`, `setGrade`, `saveStore`, `signOut`, `renderLogin`, `switchStudent`, `startTour`, and `mmInput`. |
| scripts/410-v91-admin-console.js | `MM91.admin`: admin console in `#panel-admin` (Overview, Students and profile, Teachers and profile, Classes, Curriculum, Reports, Data & Backup, Settings, System). Wraps `saveStore`. |
| scripts/420-v91-story-and-release.js | Re-lays out Story Mode as a "Decision Lab" (stepper, tiles, debrief) and adds release notes. Wraps `renderStory`. |
| scripts/430-v92-accounts.js | `MM.accounts`/`MM.gate`: admin/teacher/guardian/student accounts, hashed passwords, lockout, temp passwords, recovery questions, sign-in log, idle timeout. Replaces the v91 gate and wraps `saveStore` and `topbar`. |
| scripts/440-v92-admin-extensions.js | Admin: Users, Roles, Security policy, Sign-in log, trends, dark mode, Google Classroom/Clever roster import, sign-in code sheet, full backup/restore. Wraps `importRosterText` and `homeCards`. |
| scripts/450-v93-features.js | Schools, admin switching into teacher profiles, certificate redesign, one-time password dialog, quiz polish, week locking. Wraps `openPanel`, `openQuiz`, `openDoc`, `openTestMenu`, `gotoLesson`, `renderDashboard`, `setGrade`, `homeCards`, and `weekUnlocked`. |
| scripts/460-v94-features.js | Phone lesson reader, rotate hint, install, phone coach marks, share class, weekly student packet, a11y pass, in-app smoke test. Wraps `openPanel` and `openGame`. |
| styles/470-v95-sample-css.css | Sample-mode CTA on sign-in, sample setup view, top-bar chip, subscription prompt. |
| scripts/480-v95-sample-mode.js | `MM.sample`: anyone can try one grade with no account, against a sandboxed store. Wraps `loadStore`, `saveStore`, `signOut`, `topbar`, and `moreItems`. |

### Responsive / accessibility

| File | What it does |
|---|---|
| styles/050-v44-a11y-enhancements.css | Skip link, `:focus-visible` ring, reduced-motion, and narrow-screen padding. |
| scripts/360-v73-a11y-labels.js | Gives unlabeled inputs an `aria-label` (from placeholder or nearby text), using a documentElement MutationObserver. |
| styles/490-responsive-layer.css | Responsive layer for sign-in, consent notice, tours, classroom scene (`100dvh`), top bar, and dock. |
| scripts/500-responsive-layer-js.js | Measures the consent banner into `--mm-consent-h`, toggles phone layout, and re-places the home. Uses attribute observers and resize. |
| scripts/510-read-along.js | Read-aloud with word highlighting (Speech Synthesis plus CSS Custom Highlights). Skips answers and teacher notes. Polls every 600 ms while active. |

### School tools

| File | What it does |
|---|---|
| scripts/520-answer-key-view.js | For teachers, shows answer keys inside quizzes and worksheets (`#quizForm`, `#printArea`) with a banner. |
| scripts/530-roster-import.js | Roster import from CSV/XLSX/DOCX (parses Office XML in the browser), filters out non-students, normalizes grades. |
| scripts/540-roster-tools.js | Undo import, year-end rollover, class join codes, sample-session cleanup, School tab (all staff and students), staff home switcher. |
| styles/550-mm-professional-teacher-view.css | `html.mm-staff-view`: professional educator layout for lessons, worksheets, quizzes, and tests. |
| scripts/560-mm-professional-teacher-view-js.js | Toggles `mm-staff-view` by role, adds the educator intro and a test key. |
| scripts/570-school-tools.js | Staff tools: archive tab, printable sign-in cards, storage health and persistence request, install app, setup wizard, bulk tools. |
| styles/580-teach-view-css.css | Lesson "teaching perspective": staff see a plan to teach from instead of the student lesson. |
| scripts/590-teach-view.js | Builds `#mm-teach-view` (teaching plan) for staff and guardians. |

### V18 modules

| File | What it does |
|---|---|
| styles/600-mm-gameshow-css.css | Money Game Show "studio" stage (scoped to `#mm-gs`), fluid from phone to projector. |
| styles/610-mm-workshops-css.css | Workshops UI (scoped to `.ws` in `#panel-workshops`) and day certificates. |
| styles/620-mm-v18-integrate-css.css | v18 sign-in that scales from 320 px to 4K, and the Games panel hero, quick-start tiles, and grid. |
| scripts/630-mm-gameshow.js | Money Game Show: 8 class game modes plus Daily 5 (Quiz Rush, Money Board, True or False Blitz, Put It in Order, Cash or Case, What Am I?, Closest Guess, Money Crossword). Content banks per grade band, synthesized sound, timers. |
| scripts/640-mm-workshops.js | 1- to 5-day workshops: fits each day's agenda into 2–4 hours, groups days, prints a certificate per day. Uses `data/WS_DATA.json`. |
| scripts/650-mm-v18-integrate.js | Wires the Game Show and Workshops into the dock, the teacher classroom home cards, and the first-run tour. |

### V19 modules

| File | What it does |
|---|---|
| styles/605-mm-gameshow-live.css | Live play: host lobby (`gl-*`, inside `#mm-gs`) and the phone player screen (`lp-*`, `#mm-lp`). |
| scripts/632-mm-gameshow-banks-l10n.js | Spanish and Portuguese Game Show banks (`GS_TF_L`, `GS_WHO_L`, `GS_ORDER_L`, `GS_GUESS_L`). |
| vendor (qrcode-generator 2.0.4, supabase-js 2.45.4 UMD) | Bundled inline for the join QR code and Supabase Realtime. supabase-js is patched to fall back to the page location for its publicPath. |
| scripts/635-mm-gameshow-live.js | `MMGameShowLive`: host a live game (PIN, QR, join link, kick, Quiz Rush / True or False / What Am I? / Closest Guess, leaderboard, podium). Transport is Supabase Realtime broadcast (channels `mmgs-<pin>` and `mmgs-<pin>-in`) or BroadcastChannel on one device. Server settings in `mmLive_v1`. |
| styles/655-mm-v19-quality.css | Notices bell, contrast fixes, toast position, print-preview frame, `@media print` hides the app. |
| scripts/660-mm-v19-quality.js | Notices bell (`mmNotify`, `mmNotices_v1`), toasts held during games, tour once per device, accessibility (inert background, focus return, Space on `role=button`, decorative emoji hidden), V19 changelog. |
| scripts/670-mm-print.js | `MMPrint`: one print engine. Prints through a hidden iframe (no pop-ups) with `@page` running headers, footers and page numbers; Word export. Templates for lesson plan, worksheet, answer key, family letter, weekly packet, workbook and teacher's guide. Previews every lesson document. Test hook: `MMPrint.capture`. |
| styles/675-mm-resources.css, scripts/680-mm-resources.js | `MMResources`: Resource Guide panel (filters by audience, grade, topic, Spanish, search), printable guide with QR codes, one-page family handout, dock entry. |
| scripts/690-mm-i18n.js | `MMI18N`: translates the V18–V19 surfaces and printouts into Spanish/Portuguese from `data/UI_L.json`, watching the new panels as they render. |

640-mm-workshops.js also gained check-in / check-out measurement (`mmWorkshop_v1.checks`),
standards chips, the rebuilt printouts on `MMPrint`, and `MMWorkshops.reportHTML()` used by
the Admin Console Reports tab. Panel 17 (legal) was rewritten and gained a Security tab;
440-v92-admin-extensions.js shows a matching security notice on Security policy.

### Hosted edition modules (free edition, licenses, sign-in, ads)

| File | What it does |
|---|---|
| scripts/020-v69-access-loader.js | In `<head>`: defines `mmContent(key, free)`; on a hosted copy with a stored access code or device token, synchronously loads `/api/content?v=<version>` into `__MM_FULL` (and stores a renewed token from `X-MM-Token`). |
| scripts/695-mm-license.js | `MMLicense`: in the public build, locks weeks 2–36, section tests, workshops, the full-year workbook and teacher's guide behind the unlock dialog; Unlock button in the top bar; License card in Admin Console → Settings. |
| scripts/697-mm-social.js | `MMSocial`: "Continue with Google / Microsoft / Facebook" for adults through Supabase Auth (PKCE), verified by `/api/link`; signs in to the device account with the same email, or makes the first administrator on a new device; stores the device token. |
| styles/696-mm-social-ads.css, scripts/698-mm-ads.js | `MMAds`: sponsor cards (and optional AdSense) for signed-in adults in the free edition only; never for students, in games, on the sign-in screen, in print, or when licensed. Reads `/ads.json`. |
| hosting/ (`_headers`, `sw.js`, `ads.json`, `ads/`) | Copied next to the page by `build.js --public`. |
| ../functions/api/content.js, link.js, config.js | Cloudflare Pages Functions (see DEPLOY.md). Shared code in `../lib/mm-server.mjs`. |
| ../supabase/migrations/*.sql | Tables: `content_packs`, `licenses` (code hash, email domain, emails), `license_events`. |
| ../scripts/*.mjs | `seed-content` (upload packs), `license` (codes, domains, emails), `keepalive`. |

`build.js --public` replaces each locked data file with `mmContent("KEY", <free part>)`:
week 1 stays whole, weeks 2–36 become typed placeholders (week, title, `locked:true`), and
workshops keep only their overview. See **DEPLOY.md** for GitHub, Cloudflare and Supabase.

## Known technical debt

This section is documentation only. Nothing here has been changed in the code.

1. **Deep wrapper chains on core functions.** Each layer saves the previous global and
   reassigns it, so how a function behaves depends on load order and on `__vNN` guard
   flags.
   * `saveStore`: **6 layers**. Core-app wraps it twice (cross-tab broadcast and change
     hash at line 447, quota guard at line 3027 of 190-core-app.js), then 400-v91-core,
     410-v91-admin-console, 430-v92-accounts, and 480-v95-sample-mode. One save goes
     through every layer.
   * `openPanel`: 230-v55-login-system, 400-v91-core, 450-v93-features, 460-v94-features.
     `closePanel`: 400-v91-core.
   * `renderTeacher`: 270-v58 (replaces it), 300-v60-65, 320-v66, 390-v80-teacher-evidence.
   * `signOut`: 230-v55, 350-v72, 400-v91-core, 480-v95. Separate local `signOut`
     functions also exist in 260-v56, 400-v91-core, and 430-v92-accounts.
   * `renderLogin`: 400-v91-core, which reroutes it to the v91 session view. 230-v55 also
     calls it from its `openPanel` wrapper, and 430-v92 replaces the whole gate.
   * `switchStudent`: 280-v59, 350-v72, 400-v91-core. `createStudent`: 250-v55, 280-v59.
   * `renderDashboard`: 300-v60-65, 450-v93. `setGrade`: 400-v91, 450-v93. `reportHTML`:
     270-v58, 300-v60-65. `topbar`: 430-v92, 480-v95. `homeCards`: 440-v92, 450-v93.
   * 450-v93-features alone wraps 9 globals (`openPanel`, `openQuiz`, `openDoc`,
     `openTestMenu`, `gotoLesson`, `renderDashboard`, `setGrade`, `homeCards`,
     `weekUnlocked`).
2. **Whole-document MutationObservers** (`childList` + `subtree`) that re-run DOM patches
   on every change. There are 9: 200-v46-quiz-reflection and 210-v50-holistic
   (documentElement), 330-v67-launch (document.body), 360-v73-a11y-labels (documentElement),
   450-v93-features (documentElement), 540-roster-tools, 560-professional-teacher-view,
   570-school-tools, and 590-teach-view (document.body). Several write to the DOM they
   observe, so they can cascade or loop. 340-v70 also watches body children
   (non-subtree).
3. **setInterval pollers that run for the life of the page:**
   * 190-core-app: active-student sync every 30 s, and `pingTabs` (tab-count badge)
     every 5 s.
   * 430-v92-accounts: `SES.idleCheck` every 20 s.
   * 520-answer-key-view: `sync` every 1 s.
   * 540-roster-tools: `shUpdate` every 600 ms, and stale-sample purge every 700 ms.
   * 560-professional-teacher-view: `sync` every 1.4 s.
   * 570-school-tools: staff check every 1.5 s.
   * 590-teach-view: `sync` every 1.2 s.

   Several of these duplicate work the MutationObservers already do. Game-only timers
   (630-mm-gameshow: 100 ms meter, 1 s countdown, What-Am-I clue reveal, and 510-read-along
   at 600 ms while speaking) are scoped to an activity.
4. **Three generations of sign-in and accounts layered together:** core PIN login, v55
   role-first gate (`mmAuth_v1`), v70 admin password, v91 professional gate, then v92
   `MM.gate`/`MM.accounts`. Each later one hides or replaces the earlier UI rather than
   removing it, and v95 sample mode wraps the store underneath all of them. There are three
   separate SHA-256 code paths (190-core-app, 340-v70 inline, 430-v92).
5. **The global namespace is reused.** `var MM=` is re-declared in several layers
   (v91-core, v91-admin-console, v91-story-and-release, v92-accounts), alongside
   `MM91.*` and `MM.*`. Helpers such as `esc`, `$`, `say`, `toast`, `role`, and `auth` are
   copy-pasted into 10+ IIFEs with small differences (for example, some escape `'` and
   others do not).
6. **Duplicate and dead CSS:** 040-v43 and 070-v46 are almost the same rule set, and
   060-v44 and 080-v49 hide the same element by different keys (`body.student-mode` and
   `html.role-student`). Story Mode is styled in three places (130-v75, 370-v76, and v91
   via 420). The heavy `!important` use in later layers (v91–v18) is there to beat these
   rules.
7. **Synchronous XHR in `<head>`** (020-v69-access-loader) blocks first paint whenever an
   access code is stored.
8. **Data and code are tangled.** About 4.8 MB of curriculum JSON (75% of the file) sits
   inside the core script, so every edit to the app touches a 6 MB file. The source tree
   now separates them, but the shipped artifact is still monolithic. Translated content
   (`*_L`) roughly doubles the payload for every user.
9. **The patch-history changelog lives in code:** 330-v67-launch `unshift`s changelog
   entries into `CHANGELOG` at runtime instead of editing the source list.
