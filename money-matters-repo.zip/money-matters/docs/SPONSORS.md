# Sponsor Money Matters: a one-page kit

*Adapt this page and send it to local credit unions, banks and community foundations.
Replace everything in [brackets]. Prices are yours to set; a simple yearly fee per
placement is easiest for both sides.*

---

## Help [City/County] kids learn how money works

Money Matters is a K–8 financial literacy program: 36 weeks of lessons for every grade,
hands-on workshops, a classroom Game Show, and family letters, in English, Spanish and
Portuguese. The free edition gives every teacher and family week 1 of every grade at no cost.
Sponsors keep it free.

**Why it fits a [credit union / bank]:** financial education is part of your mission, and
your name appears where parents and teachers are already thinking about money.

### What a sponsor gets

| | |
|---|---|
| **A sponsor card** | Your logo, a one-line message and a link, on the adult home screen and in the Resource Guide of the free edition. |
| **Audience** | Teachers, parents and school administrators in [area]. In [month]: [N] adult sessions (from the site's anonymous usage counts). |
| **Credit** | "Supported by [Sponsor]" in the free edition and on our website. |
| **Optional** | A family workshop at your branch using the program's workshop plans, with your staff as guest speakers. |

### What we never do

These rules make the program acceptable to schools, and they protect your brand:

* **Never shown to students.** Cards appear only to signed-in adults.
* **Never in class.** Not during games, live play or printouts, and never to schools that buy a license.
* **No tracking.** A card is a plain link. Nothing is recorded when it is shown, and no ad network or cookies are involved.
* **No product pitches to children.** Your message is aimed at parents and educators (for example "Open a youth savings account with your child" or "Free family money workshop, May 12").

### Sponsorship

| Level | What's included | Yearly |
|---|---|---|
| Community | Sponsor card in rotation, credit line | [$ ] |
| Lead | Sponsor card shown more often, credit line, a family workshop | [$ ] |
| Founding | All of the above, named on every family letter in [area] | [$ ] |

**To sponsor:** [name], [email], [phone]. We need your logo (square, SVG or PNG), a message
of up to 12 words, and the link.

---

### For the website operator

1. Put the sponsor's image in `src/hosting/ads/` (square, under 50 KB).
2. Add a card to `house` in `src/hosting/ads.json`:

   ```json
   { "id": "first-cu", "title": "Free family money workshop, May 12",
     "text": "Bring your 3rd–8th grader. Snacks provided.", "cta": "Sign up",
     "url": "https://example-cu.org/workshop", "image": "ads/first-cu.svg",
     "sponsor": "First Community Credit Union" }
   ```

3. Set `"enabled": true` and, if you like, `"becomeSponsor": "mailto:[you]@[domain]"`. Push.
   Cards rotate at random. Remove a card when the sponsorship ends.
4. Monthly numbers for the sponsor: `npm run usage -- --prefix session` (adult sessions) and
   `npm run usage -- --prefix edition` (free vs. licensed). Clicks are not counted; ask the
   sponsor to add a tag to their own link (for example `?utm_source=moneymatters`) if they
   want to measure visits on their side.
