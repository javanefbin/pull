# Deploying Money Matters (GitHub + Cloudflare + Supabase, all free plans)

How it fits together:

```
 Browser ──► Cloudflare Pages  (dist/public/index.html: week 1 of every grade, free)
     │
     ├─ school access code ───────────────────────► /api/content  (licensed lessons)
     ├─ "Continue with Google / Microsoft" (adults) ► Supabase Auth ► /api/link ─┐
     ├─ "Clever" / "ClassLink" (students + adults) ► /api/sso/<provider> ────────┤► device token
     ├─ Class sync (encrypted, licensed) ─────────► /api/sync                    │
     ├─ anonymous usage counts ───────────────────► /api/usage                   │
     └─ /quote page ──────────────────────────────► /api/quote                   │
                                                        │                        │
                                                   Supabase  (licenses, lessons, encrypted class data,
                                                              daily usage totals, quote requests)
```

* **Free edition** (no code): week 1 of every grade in English, Spanish and Portuguese,
  the Game Show, Story Mode and the Resource Guide.
* **Licensed** (valid code): weeks 2–36 with worksheets and quizzes, section tests,
  Spanish and Portuguese lessons, workshops, and the full-year workbook and teacher's guide.
* The locked content is **never in the public page**. It lives only in this private
  repository and in Supabase, and is sent only to devices with a valid code.
* An administrator enters the code once per device (top bar → **Unlock full program**, or
  Admin Console → Settings → License). The device keeps the content for offline use.
* Or a teacher signs in with **Google or Microsoft** and the license covers their email or
  their whole email domain (for example everyone `@lincoln.k12.us`). Facebook is available
  but off unless you turn it on.
* Or students and staff sign in with **Clever or ClassLink**, and the license covers their
  district (section 7).
* **Class sync** (licensed schools): the roster and progress follow students across the
  class's devices, end-to-end encrypted (section 8).
* **Sponsor cards** (optional, off until you turn them on): direct sponsors only, shown to
  signed-in adults in the free edition. Never to students, during games, or to licensed schools.
* **Get a quote** page at `/quote` for schools that pay by purchase order (section 10).

Total setup time is about 30 minutes, plus about 15 minutes per sign-in provider. You need a GitHub, a Cloudflare and a Supabase
account (all free).

---

## Upgrading from V20 or V21

1. Replace the files in your repository with this zip's contents (keep your `.env`), then
   commit and push. Cloudflare redeploys.
2. Supabase → SQL Editor: run `supabase/migrations/20261027000000_school_sign_in_and_sync.sql`.
3. Nothing else is required. Optional, each in its own section below: Clever / ClassLink
   (7), class sync (8, on as soon as the migration ran), usage numbers (9), the quote page (10).
4. Facebook sign-in is now off by default. To keep it, set `MM_AUTH_PROVIDERS` to
   `google,azure,facebook` in Cloudflare.
5. AdSense was removed. If you had set `MM_ADSENSE_CLIENT`, delete it; sponsor cards still work.

## 1. GitHub: private repository

1. On github.com choose **New repository**, name it (for example `money-matters`), select
   **Private**, and do **not** add a README or .gitignore.
2. On your computer, unzip `money-matters-repo.zip`, open a terminal in that folder, and run:

   ```sh
   git init -b main
   git add .
   git commit -m "Money Matters V22"
   git remote add origin https://github.com/YOUR-NAME/money-matters.git
   git push -u origin main
   ```

   `.gitignore` already keeps out `node_modules/`, `dist/`, `.env` and other local files.

## 2. Supabase: database for licenses and lessons

1. On supabase.com create a **New project** (free plan). Pick a region near your schools
   and save the database password somewhere safe.
2. Open **SQL Editor → New query**, paste the whole of
   `supabase/migrations/20261026000000_money_matters.sql`, and click **Run**. This creates
   three tables (`content_packs`, `licenses`, `license_events`) with row-level security
   on and no public access. Then do the same with
   `supabase/migrations/20261026010000_sign_in_licenses.sql` (licenses by email or domain).
   Then `supabase/migrations/20261027000000_school_sign_in_and_sync.sql` (Clever / ClassLink
   districts, class sync, anonymous usage counts and quote requests). All tables have
   row-level security on and no public access; only the server's secret key can use them.
3. Open **Project Settings → API Keys** and copy:
   * the **Project URL** (`https://xxxx.supabase.co`), and
   * a **secret key** (`sb_secret_…`). If your project only shows legacy keys, the
     `service_role` key works too.
   * the **publishable key** (`sb_publishable_…`, or the legacy `anon` key). This one is
     safe in a web page; it is only used for the sign-in buttons.

   The secret key can read and write everything, so keep it out of the page, chat,
   email and git. It goes only into `.env`, Cloudflare and GitHub secrets (below).
4. On your computer, in the repository folder, copy `.env.example` to `.env` and fill in
   both values.
5. Upload the lessons and create your first access code:

   ```sh
   npm ci
   npm run build:public       # writes dist/public and dist/content
   npm run seed               # uploads the 9 content packs (about 5 MB)
   npm run license -- new --label "Lincoln Elementary" --expires 2027-07-31
   ```

   The code (for example `MM-7KQ2-X9PD-H4TW`) is printed **once**. Only its hash is
   stored, so copy it now.

## 3. Cloudflare Pages: the website

1. In the Cloudflare dashboard go to **Workers & Pages → Create → Pages → Connect to Git**,
   authorize GitHub, and pick the private repository.
2. Build settings:

   | Setting | Value |
   |---|---|
   | Framework preset | None |
   | Build command | `node build.js --public` |
   | Build output directory | `dist/public` |
   | Root directory | *(leave empty)* |
   | Environment variable `NODE_VERSION` | `22` |
   | Environment variable `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD` | `1` (the site build doesn't need the test browser) |

   The `functions/` folder is picked up automatically and becomes `/api/content`.
3. **Settings → Variables and Secrets** (Production, and Preview if you use it):
   * `SUPABASE_URL` (plain text): your project URL
   * `SUPABASE_SECRET_KEY` (type **Secret**): your secret key
   * `MM_TOKEN_SECRET` (type **Secret**): 40 or more random characters. It signs the device
     tokens from social sign-in. Make one with `node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"`.
   * `SUPABASE_PUBLISHABLE_KEY` (plain text): turns on the sign-in buttons (step 5)
   * `MM_AUTH_PROVIDERS` (plain text, optional): which buttons to show, default
     `google,azure` (`azure` is Microsoft; `facebook` and `apple` also work)
   * `CLEVER_CLIENT_ID`, `CLEVER_CLIENT_SECRET` (Secret), `CLASSLINK_CLIENT_ID`,
     `CLASSLINK_CLIENT_SECRET` (Secret): school sign-in (section 7)
   * `MM_QUOTE_WEBHOOK` (Secret, optional): where to post a notice of each quote request (section 10)
   * `MM_USAGE` (plain text, optional): `off` stops anonymous usage counts (section 9)
   * `MM_CF_BEACON` (plain text, optional, **build** variable): Cloudflare Web Analytics site token (section 9)
4. Recommended: **KV cache** (free, keeps Supabase traffic tiny):
   **Storage & Databases → KV → Create namespace** `money-matters-cache`, then in the Pages
   project **Settings → Bindings → Add → KV namespace**, variable name `MM_KV`.
5. **Deployments → Retry deployment** (or push a commit) so the variables take effect.
6. Open `https://<project>.pages.dev`, set up the administrator, choose **Unlock full
   program**, and enter the code from step 2.5. Weeks 2–36 should open.
7. Optional: **Custom domains** → add your own domain.

Every push to `main` now redeploys the site automatically.

## 4. GitHub Actions secrets (automation)

In the GitHub repository: **Settings → Secrets and variables → Actions → New repository
secret**, add `SUPABASE_URL` and `SUPABASE_SECRET_KEY`. Three workflows then run:

| Workflow | When | What it does |
|---|---|---|
| `test` | every push and pull request | builds both editions and runs the full test suite |
| `seed-content` | when `src/data/` changes on `main`, or by hand | uploads new lesson content to Supabase |
| `supabase-keepalive` | every 3 days | one tiny query, so the free Supabase project never pauses |
| `buttons` | Mondays, or by hand | clicks every button as a student, a teacher and an administrator; fails on a button that does nothing or looks clickable but isn't |

Free GitHub plans include 2,000 Actions minutes a month for private repositories. The test
run takes about 7 minutes and the weekly button crawl about 30, so roughly 200 pushes a month fit.

## 5. Sign in with Google and Microsoft (optional, free)

Supabase Auth's free plan covers 50,000 monthly active users. Do this once per provider.

1. Supabase → **Authentication → URL Configuration**: set **Site URL** to your site
   (`https://<project>.pages.dev` or your domain) and add the same address under
   **Redirect URLs**.
2. Supabase → **Authentication → Sign In / Providers**. Each provider page shows a
   **Callback URL** (`https://<project-ref>.supabase.co/auth/v1/callback`); you paste it into
   the provider's console below, then paste the provider's client ID and secret back into
   Supabase and switch the provider on.
   * **Google**: Google Cloud Console → APIs & Services → Credentials → Create OAuth client
     ID → Web application → Authorized redirect URI = the callback URL. On the OAuth consent
     screen, add your site's privacy policy link. Only the basic `email` and `profile`
     scopes are used.
   * **Microsoft** (`azure`): Microsoft Entra admin center → App registrations → New →
     "Accounts in any organizational directory and personal Microsoft accounts" → Web
     redirect URI = the callback URL → Certificates & secrets → New client secret.
   * **Facebook**: developers.facebook.com → Create app → add Facebook Login → Valid OAuth
     Redirect URIs = the callback URL. Switch the app to **Live** (it needs a privacy policy
     URL). Some Facebook accounts have no email; those people see a message to use another
     option or an access code.
3. Cloudflare Pages: add `SUPABASE_PUBLISHABLE_KEY` (and `MM_TOKEN_SECRET` if you have
   not yet), then redeploy. The buttons appear on the staff side of the sign-in screen,
   on first-run setup, and in the unlock dialog.
4. License people by email or domain:

   ```sh
   npm run license -- new --label "Lincoln Elementary" --domain lincoln.k12.us --expires 2027-07-31
   npm run license -- new --label "Rivera family" --emails mom@gmail.com --no-code
   npm run license -- emails "Lincoln Elementary" --add sub.teacher@gmail.com
   ```

5. On each device, the administrator adds each teacher's email in Admin Console → Users
   (the email field). That teacher can then sign in with that provider. On a brand-new
   device, the first person to sign in this way becomes its administrator.

What is kept: Supabase keeps the person's name, email and provider in its `auth.users`
table. The page discards the Supabase session right away and keeps only a 30-day device
token (renewed automatically while the device is in use).

## 6. Sponsor cards (optional)

Sponsor cards are off by default. Edit `src/hosting/ads.json`, set `"enabled": true`, and push.

* **Sponsor cards** (`house`): title, text, button label, a link (`https://…`, or a page on
  your site such as `/quote`), and an image you put in `src/hosting/ads/`. Shown to signed-in
  adults on their home screen and at the bottom of the Resource Guide. Nothing is tracked;
  links use `rel="sponsored noopener"`.
* `becomeSponsor` (optional): an `https://` or `mailto:` link shown as "Sponsor this program".
* There is no ad network. Ad networks on a K–8 site raise children's-privacy issues (COPPA)
  and pay little on a small site. A local credit union or bank sponsoring financial literacy
  fits the program better: `docs/SPONSORS.md` is a one-page sponsor kit you can adapt.
* Cards never show to students, in sample mode as a student, on the sign-in screen, during
  the Game Show or live play, in printouts, or to a licensed school. Each adult can hide a
  card for the session.
* Check with your schools: many districts do not allow any sponsor messages in classroom
  software, even for staff. Licensed schools never see them.

## 7. Sign in with Clever and ClassLink (optional)

Students, teachers and administrators sign in with their school account. A student is matched
to their record on the device (or found through class sync) and linked, so the school account
is all they need afterwards.

1. **Clever**: create an app in Clever's developer dashboard (dev.clever.com). Add the
   redirect URI `https://<your site>/api/sso/clever`. Copy the client ID and secret into
   Cloudflare as `CLEVER_CLIENT_ID` and `CLEVER_CLIENT_SECRET`. The dashboard walks you through
   getting the app approved for districts; each district then adds it to their Clever portal.
2. **ClassLink**: register an SSO app with ClassLink (their partner program). Redirect URI
   `https://<your site>/api/sso/classlink`, scope `profile`. Copy the client ID and secret into
   `CLASSLINK_CLIENT_ID` and `CLASSLINK_CLIENT_SECRET`.
3. `MM_TOKEN_SECRET` must be set (it signs the short-lived sign-in results). Redeploy. The
   buttons appear on both the student and the adult side of the sign-in screen.
4. License a whole district (everyone who signs in from it, students included):

   ```sh
   npm run license -- new --label "Lincoln District" --districts clever:5f1e…,classlink:1234 --no-code --expires 2027-07-31
   npm run license -- districts "Lincoln District" --add clever:<another district id>
   ```

   The Clever district id and the ClassLink tenant id are in each provider's dashboard.
   Adults are also covered by an email or domain license, as in section 5.

Launches from the Clever Portal, Clever Instant Login and ClassLink LaunchPad work too: the
site restarts the sign-in from its own page (as Clever recommends) and finishes at once.
Nothing about the person is stored on the server. The device keeps a private link
(`clever:<code>`), not the provider's user id.

## 8. Class sync (licensed schools)

Keeps a class's roster and every student's progress the same on all the class's devices. It
needs Supabase (step 2) and a licensed device to turn it on: Admin Console → **Class sync** →
Turn on. Then:

* **Teacher link**: open it on your other teacher or administrator devices. It carries the
  class key, so send it only to staff.
* **Student link**: students open it once per device (or post it with **Share to Google
  Classroom**). By itself it opens nothing: each student still signs in with their own
  username and code, and the device then gets only that student's record.

How it is protected: everything is encrypted with AES-256-GCM on the device before it is sent.
The server (`/api/sync`, tables `sync_rooms` and `sync_items`) stores ciphertext, random ids
and times only. Each student record has its own key. A student device receives it only by
proving the username and sign-in code (PBKDF2, 150,000 rounds) to the server, which releases
the encrypted sign-in entry only for the right proof and locks that username for 15 minutes
after 10 wrong codes, so codes can't be guessed offline; or through a linked Clever/ClassLink
account. Teacher-managed fields (name, grade, sign-in code, lock) travel in the teacher-only
roster, so a student device can change only its own progress. With `MM_KV`, every
student-device request is also rate-limited per class and IP. Scores merge by keeping the best
result; other fields follow the latest change. Delete the class from the server at any time in
the same tab; every device keeps its own copy. Before connecting, a teacher link shows the
class ID (also on the Class sync tab) so staff can check it is their own class.

What it does not protect against: someone who obtains the database itself could still try to
guess 6-character codes offline, so keep the Supabase secret key private. A student who is
told a classmate's username and code can sign in as them, as on any shared device.

Storage: about 20 KB per student, so the free 500 MB Supabase database holds roughly 25,000
students' records.

## 9. Usage numbers (anonymous)

* **In-app counts** (on by default when Supabase is set up): each device adds to daily totals
  of which lessons, quizzes, workshops, games and panels are opened. Only the day, the event
  name and a count are stored (`usage_daily`); no person, device, school or IP. Read them with

  ```sh
  npm run usage                     # last 30 days
  npm run usage -- --prefix lesson  # lessons only
  npm run usage -- --csv > usage.csv
  ```

  An administrator can turn counting off per device (Admin Console → Settings), or you can
  turn it off for the whole site with `MM_USAGE=off`.
* **Cloudflare Web Analytics** (optional): page visits, countries and load times. In the
  Cloudflare dashboard, Analytics & Logs → Web Analytics → Add a site, choose to add the
  snippet yourself, and copy the token. Set it as the build variable `MM_CF_BEACON`; the build
  then adds Cloudflare's beacon and allows exactly its two hosts in the page's security policy.
  It uses no cookies or local storage. (Don't use the automatic setup: the page's security
  policy would block the injected script.)

## 10. Get a quote (`/quote`)

Schools that pay by purchase order can request a quote at `https://<your site>/quote`. They get
a numbered quote request to print or save as a PDF. Requests are saved in Supabase
(`quote_requests`; view them in Table Editor) and, if `MM_QUOTE_WEBHOOK` is an `https://` address
(a Slack, Teams or Discord incoming webhook, or Zapier/Make), a short notice is posted there.

Edit `src/hosting/pricing.json`: your business details (`seller`, including the email that
"Email it to us" uses), items and terms. While `showPrices` is `false`, or a price is `null`,
the document is a quote **request** that says prices will be confirmed. With prices filled in
and `showPrices: true`, it becomes a priced quote with a total. The unlock dialog and the
default sponsor card link to this page.

## Managing access codes

```sh
npm run license -- new --label "Roosevelt Middle" --expires 2027-07-31 --contact office@school.org
npm run license -- list                                   # who, active, expiry, loads, last used
npm run license -- districts "Roosevelt Middle" --add clever:<district id>   # Clever / ClassLink districts
npm run license -- disable "Roosevelt Middle"             # stop a code
npm run license -- enable  "Roosevelt Middle"
npm run license -- extend  "Roosevelt Middle" --expires 2028-07-31
```

Disabling or expiring a code takes effect on each device the next time it checks, which is
within 7 days (devices cache the content for offline use).

## Updating lessons

Edit files in `src/data/`, run `npm test`, then push. GitHub Actions uploads the new content
to Supabase and Cloudflare redeploys the page. Each build has a content version, so devices
fetch the new lessons automatically. To do it by hand: `npm run build:public && npm run seed`.

## Free-plan limits and how this setup stays inside them

| Service | Free limit | Typical use here |
|---|---|---|
| Cloudflare Pages | unlimited static requests; Functions 100,000 requests a day | about 1 content call per licensed device per week; class sync about 12 calls per open device per hour plus one per saved change (300 devices in use 6 hours a day: about 40,000 a day) |
| Cloudflare KV | 100,000 reads and 1,000 writes a day | a few reads per function call |
| Supabase | 500 MB database, 5 GB egress a month, pauses after 7 idle days | about 6 MB of content; with KV, content leaves Supabase about once a month; the keep-alive stops pausing |
| Supabase Auth | 50,000 monthly active users | one sign-in per teacher per device every 30 days or so |
| Supabase (class sync) | same 500 MB | about 20 KB per student |
| GitHub | private repos; 2,000 Actions minutes a month | about 5 minutes per push |

If Supabase is briefly unreachable, the function keeps honoring a code it validated in the
last 14 days and serves content from KV. Devices that already unlocked keep working offline.

## Local development

```sh
npm ci && npx playwright install chromium
npm test                      # both builds + every test
npm run buttons               # crawl every button as admin, teacher and student
npm run dev                   # serve dist/public with the function at http://localhost:8788
```

For `npm run dev`, put `SUPABASE_URL=…` and `SUPABASE_SECRET_KEY=…` in a `.dev.vars` file
(ignored by git).

## Security notes

* The access code is sent only over HTTPS in an `Authorization` header and is stored on the
  device in browser storage. Anyone with full control of that device could copy it, so give
  each school its own code and disable codes that leak.
* Codes have 60 random bits, so guessing one is not practical.
* `licenses` stores only a SHA-256 hash of each code.
* Licensed printouts carry a "Licensed to <school>" line in the footer.
