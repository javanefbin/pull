# Deploying Money Matters (GitHub + Cloudflare + Supabase, all free plans)

How it fits together:

```
 Browser ──► Cloudflare Pages  (dist/public/index.html: week 1 of every grade, free)
     │
     ├─ with a school access code ─────────────► /api/content  (Cloudflare Pages Function)
     │                                              │  checks the license, caches in KV
     └─ "Continue with Google / Microsoft /         ▼
         Facebook" (adults) ─► Supabase Auth ─► /api/link ─► device token ─► /api/content
                                                     │
                                                 Supabase  (licenses, locked content packs, sign-in)
```

* **Free edition** (no code): week 1 of every grade in English, Spanish and Portuguese,
  the Game Show, Story Mode and the Resource Guide.
* **Licensed** (valid code): weeks 2–36 with worksheets and quizzes, section tests,
  Spanish and Portuguese lessons, workshops, and the full-year workbook and teacher's guide.
* The locked content is **never in the public page**. It lives only in this private
  repository and in Supabase, and is sent only to devices with a valid code.
* An administrator enters the code once per device (top bar → **Unlock full program**, or
  Admin Console → Settings → License). The device keeps the content for offline use.
* Or a teacher signs in with **Google, Microsoft or Facebook** and the license covers their
  email or their whole email domain (for example everyone `@lincoln.k12.us`). Students never
  use these buttons; they keep their 6-character sign-in codes.
* **Ads** (optional, off until you turn them on): sponsor cards for signed-in adults in the
  free edition only. Never shown to students, during games, or to licensed schools.

Total setup time is about 30 minutes, plus about 15 minutes per sign-in provider. You need a GitHub, a Cloudflare and a Supabase
account (all free).

---

## 1. GitHub: private repository

1. On github.com choose **New repository**, name it (for example `money-matters`), select
   **Private**, and do **not** add a README or .gitignore.
2. On your computer, unzip `money-matters-repo.zip`, open a terminal in that folder, and run:

   ```sh
   git init -b main
   git add .
   git commit -m "Money Matters V19"
   git remote add origin https://github.com/YOUR-NAME/money-matters.git
   git push -u origin main
   ```

   `.gitignore` already keeps out `node_modules/`, `dist/`, `.env` and other local files.

## 2. Supabase: database for licenses and lessons

1. On supabase.com create a **New project** (free plan). Pick a region near your schools
   and save the database password somewhere safe.
2. Open **SQL Editor → New query**, paste the whole of
   `supabase/migrations/20261026000000_money_matters.sql`, and click **Run**. This creates
   three tables (`content_packs`, `licenses`, `license_events`) with row-level security
   on and no public access. Then do the same with
   `supabase/migrations/20261026010000_sign_in_licenses.sql` (licenses by email or domain).
3. Open **Project Settings → API Keys** and copy:
   * the **Project URL** (`https://xxxx.supabase.co`), and
   * a **secret key** (`sb_secret_…`). If your project only shows legacy keys, the
     `service_role` key works too.
   * the **publishable key** (`sb_publishable_…`, or the legacy `anon` key). This one is
     safe in a web page; it is only used for the sign-in buttons.

   The secret key can read and write everything, so keep it out of the page, chat,
   email and git. It goes only into `.env`, Cloudflare and GitHub secrets (below).
4. On your computer, in the repository folder, copy `.env.example` to `.env` and fill in
   both values.
5. Upload the lessons and create your first access code:

   ```sh
   npm ci
   npm run build:public       # writes dist/public and dist/content
   npm run seed               # uploads the 9 content packs (about 5 MB)
   npm run license -- new --label "Lincoln Elementary" --expires 2027-07-31
   ```

   The code (for example `MM-7KQ2-X9PD-H4TW`) is printed **once**. Only its hash is
   stored, so copy it now.

## 3. Cloudflare Pages: the website

1. In the Cloudflare dashboard go to **Workers & Pages → Create → Pages → Connect to Git**,
   authorize GitHub, and pick the private repository.
2. Build settings:

   | Setting | Value |
   |---|---|
   | Framework preset | None |
   | Build command | `node build.js --public` |
   | Build output directory | `dist/public` |
   | Root directory | *(leave empty)* |
   | Environment variable `NODE_VERSION` | `22` |
   | Environment variable `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD` | `1` (the site build doesn't need the test browser) |

   The `functions/` folder is picked up automatically and becomes `/api/content`.
3. **Settings → Variables and Secrets** (Production, and Preview if you use it):
   * `SUPABASE_URL` (plain text): your project URL
   * `SUPABASE_SECRET_KEY` (type **Secret**): your secret key
   * `MM_TOKEN_SECRET` (type **Secret**): 40 or more random characters. It signs the device
     tokens from social sign-in. Make one with `node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"`.
   * `SUPABASE_PUBLISHABLE_KEY` (plain text): turns on the sign-in buttons (step 5)
   * `MM_AUTH_PROVIDERS` (plain text, optional): which buttons to show, default
     `google,azure,facebook` (`azure` is Microsoft; `apple` also works)
4. Recommended: **KV cache** (free, keeps Supabase traffic tiny):
   **Storage & Databases → KV → Create namespace** `money-matters-cache`, then in the Pages
   project **Settings → Bindings → Add → KV namespace**, variable name `MM_KV`.
5. **Deployments → Retry deployment** (or push a commit) so the variables take effect.
6. Open `https://<project>.pages.dev`, set up the administrator, choose **Unlock full
   program**, and enter the code from step 2.5. Weeks 2–36 should open.
7. Optional: **Custom domains** → add your own domain.

Every push to `main` now redeploys the site automatically.

## 4. GitHub Actions secrets (automation)

In the GitHub repository: **Settings → Secrets and variables → Actions → New repository
secret**, add `SUPABASE_URL` and `SUPABASE_SECRET_KEY`. Three workflows then run:

| Workflow | When | What it does |
|---|---|---|
| `test` | every push and pull request | builds both editions and runs the full test suite |
| `seed-content` | when `src/data/` changes on `main`, or by hand | uploads new lesson content to Supabase |
| `supabase-keepalive` | every 3 days | one tiny query, so the free Supabase project never pauses |

Free GitHub plans include 2,000 Actions minutes a month for private repositories. The test
run takes about 5 minutes, so roughly 300 pushes a month fit.

## 5. Sign in with Google, Microsoft and Facebook (optional, free)

Supabase Auth's free plan covers 50,000 monthly active users. Do this once per provider.

1. Supabase → **Authentication → URL Configuration**: set **Site URL** to your site
   (`https://<project>.pages.dev` or your domain) and add the same address under
   **Redirect URLs**.
2. Supabase → **Authentication → Sign In / Providers**. Each provider page shows a
   **Callback URL** (`https://<project-ref>.supabase.co/auth/v1/callback`); you paste it into
   the provider's console below, then paste the provider's client ID and secret back into
   Supabase and switch the provider on.
   * **Google**: Google Cloud Console → APIs & Services → Credentials → Create OAuth client
     ID → Web application → Authorized redirect URI = the callback URL. On the OAuth consent
     screen, add your site's privacy policy link. Only the basic `email` and `profile`
     scopes are used.
   * **Microsoft** (`azure`): Microsoft Entra admin center → App registrations → New →
     "Accounts in any organizational directory and personal Microsoft accounts" → Web
     redirect URI = the callback URL → Certificates & secrets → New client secret.
   * **Facebook**: developers.facebook.com → Create app → add Facebook Login → Valid OAuth
     Redirect URIs = the callback URL. Switch the app to **Live** (it needs a privacy policy
     URL). Some Facebook accounts have no email; those people see a message to use another
     option or an access code.
3. Cloudflare Pages: add `SUPABASE_PUBLISHABLE_KEY` (and `MM_TOKEN_SECRET` if you have
   not yet), then redeploy. The buttons appear on the staff side of the sign-in screen,
   on first-run setup, and in the unlock dialog.
4. License people by email or domain:

   ```sh
   npm run license -- new --label "Lincoln Elementary" --domain lincoln.k12.us --expires 2027-07-31
   npm run license -- new --label "Rivera family" --emails mom@gmail.com --no-code
   npm run license -- emails "Lincoln Elementary" --add sub.teacher@gmail.com
   ```

5. On each device, the administrator adds each teacher's email in Admin Console → Users
   (the email field). That teacher can then sign in with that provider. On a brand-new
   device, the first person to sign in this way becomes its administrator.

What is kept: Supabase keeps the person's name, email and provider in its `auth.users`
table. The page discards the Supabase session right away and keeps only a 30-day device
token (renewed automatically while the device is in use).

## 6. Ads (optional)

Ads are off by default. Edit `src/hosting/ads.json`, set `"enabled": true`, and push.

* **Sponsor cards** (`house`): title, text, button label, an `https://` link, and an image
  you put in `src/hosting/ads/`. Shown to signed-in adults on their home screen and at the
  bottom of the Resource Guide. Nothing is tracked; links use `rel="sponsored noopener"`.
* **Google AdSense** (optional): put your publisher ID and ad unit in `adsense`, and add
  the Cloudflare build variable `MM_ADSENSE_CLIENT` = `ca-pub-…`. Only then does the build
  allow Google's ad domains in the page's security policy. Units are requested as
  non-personalized and tagged for child-directed treatment
  (`data-tag-for-age-treatment="1"`). Because this is a K–8 site, also mark the site as
  child-directed in Google Search Console, and read AdSense's policies on sites for
  children before turning it on.
* Ads never show to students, in sample mode as a student, on the sign-in screen, during
  the Game Show or live play, in printouts, or to a licensed school. Each adult can hide a
  card for the session.
* Check with your schools: many districts do not allow ads in classroom software even
  for staff. Licensed schools never see them.

## Managing access codes

```sh
npm run license -- new --label "Roosevelt Middle" --expires 2027-07-31 --contact office@school.org
npm run license -- list                                   # who, active, expiry, loads, last used
npm run license -- disable "Roosevelt Middle"             # stop a code
npm run license -- enable  "Roosevelt Middle"
npm run license -- extend  "Roosevelt Middle" --expires 2028-07-31
```

Disabling or expiring a code takes effect on each device the next time it checks, which is
within 7 days (devices cache the content for offline use).

## Updating lessons

Edit files in `src/data/`, run `npm test`, then push. GitHub Actions uploads the new content
to Supabase and Cloudflare redeploys the page. Each build has a content version, so devices
fetch the new lessons automatically. To do it by hand: `npm run build:public && npm run seed`.

## Free-plan limits and how this setup stays inside them

| Service | Free limit | Typical use here |
|---|---|---|
| Cloudflare Pages | unlimited static requests; Functions 100,000 requests a day | about 1 function call per licensed device per week |
| Cloudflare KV | 100,000 reads and 1,000 writes a day | a few reads per function call |
| Supabase | 500 MB database, 5 GB egress a month, pauses after 7 idle days | about 6 MB of content; with KV, content leaves Supabase about once a month; the keep-alive stops pausing |
| Supabase Auth | 50,000 monthly active users | one sign-in per teacher per device every 30 days or so |
| GitHub | private repos; 2,000 Actions minutes a month | about 5 minutes per push |

If Supabase is briefly unreachable, the function keeps honoring a code it validated in the
last 14 days and serves content from KV. Devices that already unlocked keep working offline.

## Local development

```sh
npm ci && npx playwright install chromium
npm test                      # both builds + every test
npm run buttons               # crawl every button as admin, teacher and student
npm run dev                   # serve dist/public with the function at http://localhost:8788
```

For `npm run dev`, put `SUPABASE_URL=…` and `SUPABASE_SECRET_KEY=…` in a `.dev.vars` file
(ignored by git).

## Security notes

* The access code is sent only over HTTPS in an `Authorization` header and is stored on the
  device in browser storage. Anyone with full control of that device could copy it, so give
  each school its own code and disable codes that leak.
* Codes have 60 random bits, so guessing one is not practical.
* `licenses` stores only a SHA-256 hash of each code.
* Licensed printouts carry a "Licensed to <school>" line in the footer.
