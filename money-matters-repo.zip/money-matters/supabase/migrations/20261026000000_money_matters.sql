-- Money Matters: licensed content and school access codes.
-- Run once in Supabase → SQL Editor (or `supabase db push`).
-- Row-level security is ON with no policies, so the public (anon) key can read
-- nothing. Only the server (Cloudflare function, seed and license scripts,
-- using the secret key) can read or write these tables.

create table if not exists public.content_packs (
  key         text primary key,            -- LESSONS, LESSON_QUIZ, SECTION_TESTS, *_L, WS_DATA*
  version     text not null,               -- content version from build.js --public
  data        jsonb not null,
  bytes       integer,
  updated_at  timestamptz not null default now()
);

create table if not exists public.licenses (
  id          uuid primary key default gen_random_uuid(),
  code_hash   text not null unique,         -- sha256 of the normalized code; the code itself is never stored
  label       text not null,                -- school or district name, printed on licensed printouts
  contact     text,
  seats       integer,
  starts_at   timestamptz not null default now(),
  expires_at  timestamptz,                  -- null = no expiry
  active      boolean not null default true,
  notes       text,
  created_at  timestamptz not null default now()
);

create table if not exists public.license_events (
  id          bigserial primary key,
  license_id  uuid references public.licenses(id) on delete set null,
  ok          boolean not null,
  at          timestamptz not null default now()
);
create index if not exists license_events_license_at on public.license_events (license_id, at desc);

alter table public.content_packs  enable row level security;
alter table public.licenses       enable row level security;
alter table public.license_events enable row level security;
revoke all on public.content_packs, public.licenses, public.license_events from anon, authenticated;

-- usage summary for the license list script
create or replace view public.license_usage with (security_invoker = true) as
  select l.id, l.label, l.active, l.expires_at,
         count(e.*) filter (where e.ok)                         as loads,
         max(e.at)  filter (where e.ok)                         as last_used
  from public.licenses l left join public.license_events e on e.license_id = l.id
  group by l.id;
revoke all on public.license_usage from anon, authenticated;

-- keep the event log small on the free plan: drop events older than a year
create or replace function public.prune_license_events() returns void language sql as $$
  delete from public.license_events where at < now() - interval '365 days';
$$;
revoke execute on function public.prune_license_events() from anon, authenticated;
