-- Money Matters V22: district licenses for Clever / ClassLink sign-in, and class sync.
-- Run after 20261026010000_sign_in_licenses.sql (SQL Editor -> New query -> Run).

-- 1. A license can cover whole districts that sign in with Clever or ClassLink:
--    sso_orgs holds "clever:<Clever district id>" and/or "classlink:<ClassLink tenant id>".
alter table public.licenses add column if not exists sso_orgs text[] not null default '{}';
create index if not exists licenses_sso_orgs on public.licenses using gin (sso_orgs);
alter table public.licenses drop constraint if exists licenses_has_a_key;
alter table public.licenses add constraint licenses_has_a_key
  check (code_hash is not null or email_domain is not null or cardinality(emails) > 0 or cardinality(sso_orgs) > 0);

-- 2. Class sync. The server stores ciphertext only: no names, codes, scores or keys.
--    sync_rooms: one row per synced class. w_hash / s_hash are SHA-256 hashes of the
--    teacher-device and student-device secrets (the secrets themselves never arrive here
--    except in requests, over TLS, and are not logged).
create table if not exists public.sync_rooms (
  room        text primary key check (room ~ '^[a-f0-9]{64}$'),
  w_hash      text not null,
  s_hash      text not null,
  license_id  uuid references public.licenses(id) on delete set null,
  created_at  timestamptz not null default now()
);
--    sync_items: encrypted roster, student records and sign-in entries.
create table if not exists public.sync_items (
  room        text not null references public.sync_rooms(room) on delete cascade,
  id          text not null,
  kind        text not null check (kind in ('roster','student','login','sso')),
  ver         integer not null default 1,
  body        text not null check (length(body) <= 262144),
  owner_hash  text,
  at          bigint not null,               -- server time in ms, for "what changed since"
  writer      text not null default 't' check (writer in ('t','s')),   -- last written by a teacher or a student device
  fails       integer not null default 0,    -- wrong sign-in codes in a row (login entries)
  lock_until  bigint not null default 0,     -- locked until (ms) after 10 wrong codes
  primary key (room, id)
);
create index if not exists sync_items_room_at on public.sync_items (room, at);

alter table public.sync_rooms enable row level security;
alter table public.sync_items enable row level security;
-- No policies: only the server's secret key (Cloudflare function) can read or write.
revoke all on public.sync_rooms from anon, authenticated;
revoke all on public.sync_items from anon, authenticated;

-- 3. Anonymous usage counts (see functions/api/usage.js): one row per day and event,
--    no user, device, IP or school.
create table if not exists public.usage_daily (
  day    date not null,
  event  text not null check (length(event) <= 60),
  n      bigint not null default 0,
  primary key (day, event)
);
alter table public.usage_daily enable row level security;
revoke all on public.usage_daily from anon, authenticated;
create or replace function public.usage_add(p_day date, p_events text[], p_counts int[])
returns void language sql security definer set search_path = public as $$
  insert into public.usage_daily (day, event, n)
  select p_day, e, c from unnest(p_events, p_counts) as t(e, c)
  where c > 0 and c <= 1000
  on conflict (day, event) do update set n = public.usage_daily.n + excluded.n;
$$;
revoke all on function public.usage_add(date, text[], int[]) from anon, authenticated;

-- 4. Quote requests from the "Get a quote" page (functions/api/quote.js).
create table if not exists public.quote_requests (
  id          uuid primary key default gen_random_uuid(),
  created_at  timestamptz not null default now(),
  school      text not null check (length(school) <= 200),
  district    text check (length(district) <= 200),
  contact     text not null check (length(contact) <= 120),
  email       text not null check (length(email) <= 200),
  phone       text check (length(phone) <= 40),
  role        text check (length(role) <= 80),
  students    integer check (students between 0 and 1000000),
  teachers    integer check (teachers between 0 and 100000),
  grades      text check (length(grades) <= 60),
  start_date  date,
  wants       text[] not null default '{}',
  notes       text check (length(notes) <= 2000),
  quote_no    text not null,
  status      text not null default 'new'
);
alter table public.quote_requests enable row level security;
revoke all on public.quote_requests from anon, authenticated;
