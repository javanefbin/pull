-- Money Matters: licenses that cover people who sign in with Google, Microsoft
-- or Facebook. Run after 20261026000000_money_matters.sql.
--   email_domain  every verified email at this domain is licensed (e.g. district.org)
--   emails        individual verified emails (homeschool families, single teachers)
-- A license can have an access code, a domain, emails, or any mix.

alter table public.licenses alter column code_hash drop not null;
alter table public.licenses add column if not exists email_domain text;
alter table public.licenses add column if not exists emails text[] not null default '{}';
create index if not exists licenses_email_domain on public.licenses (email_domain);
create index if not exists licenses_emails on public.licenses using gin (emails);

do $$ begin
  alter table public.licenses add constraint licenses_has_a_key
    check (code_hash is not null or email_domain is not null or cardinality(emails) > 0);
exception when duplicate_object then null; end $$;

-- store domains and emails in lower case
create or replace function public.licenses_lowercase() returns trigger language plpgsql as $$
begin
  new.email_domain := nullif(lower(trim(new.email_domain)), '');
  new.emails := coalesce((select array_agg(distinct lower(trim(e))) from unnest(new.emails) e where trim(e) <> ''), '{}');
  return new;
end $$;
drop trigger if exists licenses_lowercase on public.licenses;
create trigger licenses_lowercase before insert or update on public.licenses
  for each row execute function public.licenses_lowercase();

-- how each load was authorized: 'code' or 'sign-in:google' etc.
alter table public.license_events add column if not exists via text;
