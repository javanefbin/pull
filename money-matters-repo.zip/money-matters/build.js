#!/usr/bin/env node
/*
 * Money Matters build
 *
 *   node build.js                 full build: dist/MoneyMatters.html (every lesson
 *                                 inside; for local use, testing and offline copies)
 *   node build.js --public        hosted build for Cloudflare Pages:
 *                                   dist/public/index.html   week 1 of every grade only
 *                                   dist/public/sw.js        offline cache
 *                                   dist/public/_headers     security + cache headers
 *                                   dist/content/*.json      the locked content packs,
 *                                                            for scripts/seed-content.mjs
 *   node build.js --check <file>  full build, then compare byte-for-byte with <file>
 *
 * Directives (resolved recursively, paths relative to src/):
 *   <!--@include path-->   (HTML context)
 *   /*@include path*\/      (JS/CSS context)
 * A directive is replaced by the exact bytes of the named file. Files ending in
 * .json are inserted raw and never scanned for further directives.
 *
 * In the public build, each LOCKED data file is replaced by
 *   mmContent("<KEY>", <free part>)
 * where the free part keeps week 1 and turns weeks 2-36 into empty, typed
 * placeholders (week number and title only, locked:true). At run time
 * mmContent returns the licensed pack from /api/content when the school has
 * a valid access code, and the free part otherwise.
 * No dependencies; Node >= 14.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const OUT = path.join(ROOT, 'dist', 'MoneyMatters.html');
const PUB = path.join(ROOT, 'dist', 'public');
const PACKS = path.join(ROOT, 'dist', 'content');
const DIRECTIVE = /<!--@include ([^\s>]+?)-->|\/\*@include ([^\s*]+?)\*\//g;

/* Locked content: file stem -> how to make its free part */
const LOCKED = {
  LESSONS: 'weeks', LESSON_QUIZ: 'weeks', SECTION_TESTS: 'none',
  LESSONS_L: 'lang-weeks', LESSON_QUIZ_L: 'lang-weeks', SECTION_TESTS_L: 'lang-none',
  WS_DATA: 'workshop', WS_DATA_es: 'workshop', WS_DATA_pt: 'workshop'
};
const KEEP_IN_STUB = ['week', 'title', 'sub', 'unit', 'weeks'];

/** An empty value of the same type, so code that reads a placeholder never breaks. */
function blank(v) { return Array.isArray(v) ? [] : v && typeof v === 'object' ? {} : typeof v === 'number' ? v : typeof v === 'boolean' ? false : ''; }
function stub(item) {
  const o = {};
  Object.keys(item).forEach(k => { o[k] = KEEP_IN_STUB.includes(k) ? item[k] : blank(item[k]); });
  o.locked = true;
  return o;
}
const perGrade = (data, fn) => { const o = {}; Object.keys(data).forEach(g => { o[g] = fn(data[g]); }); return o; };
const freeWeeks = arr => arr.map((x, i) => (i === 0 ? x : stub(x)));
const freeNone = arr => arr.map(stub);
function freePart(kind, data) {
  switch (kind) {
    case 'weeks': return perGrade(data, freeWeeks);
    case 'none': return perGrade(data, freeNone);
    case 'lang-weeks': return perGrade(data, langData => perGrade(langData, freeWeeks));
    case 'lang-none': return perGrade(data, langData => perGrade(langData, freeNone));
    /* workshops: keep the overview (title, mission, outcomes) as a preview */
    case 'workshop': return perGrade(data, w => ({ title: w.title, mission: w.mission, outcomes: w.outcomes, modules: [], locked: true }));
    default: throw new Error('unknown lock kind ' + kind);
  }
}

function resolve(rel, stack, mode) {
  const abs = path.resolve(SRC, rel);
  if (!abs.startsWith(SRC + path.sep)) throw new Error('include escapes src/: ' + rel);
  if (stack.includes(abs)) throw new Error('include cycle: ' + stack.concat(abs).join(' -> '));
  if (!fs.existsSync(abs)) throw new Error('missing include: ' + rel + ' (from ' + path.relative(SRC, stack[stack.length - 1] || abs) + ')');
  const text = fs.readFileSync(abs, 'utf8');
  if (rel.endsWith('.json')) {
    const key = path.basename(rel, '.json');
    if (mode.public && LOCKED[key]) {
      const data = JSON.parse(text);
      mode.packs[key] = text;
      return 'mmContent(' + JSON.stringify(key) + ',' + JSON.stringify(freePart(LOCKED[key], data)) + ')';
    }
    return text;
  }
  return text.replace(DIRECTIVE, (_, a, b) => resolve(a || b, stack.concat(abs), mode));
}

function write(file, text) { fs.mkdirSync(path.dirname(file), { recursive: true }); const bytes = Buffer.from(text, 'utf8'); fs.writeFileSync(file, bytes); return bytes; }

function buildFull() { return write(OUT, resolve('index.html', [], { public: false, packs: {} })); }

function buildPublic() {
  const mode = { public: true, packs: {} };
  let html = resolve('index.html', [], mode);
  const missing = Object.keys(LOCKED).filter(k => !mode.packs[k]);
  if (missing.length) throw new Error('locked data not found in the source: ' + missing.join(', '));
  /* content version = hash of every locked pack; it versions the /api/content URL */
  const h = crypto.createHash('sha256');
  Object.keys(mode.packs).sort().forEach(k => { h.update(k); h.update(mode.packs[k]); });
  const version = h.digest('hex').slice(0, 12);
  /* optional Google AdSense (ads.json can only use it when the site is built with it) */
  const adsense = (process.env.MM_ADSENSE_CLIENT || '').trim();
  if (adsense && !/^ca-pub-\d{10,20}$/.test(adsense)) throw new Error('MM_ADSENSE_CLIENT must look like ca-pub-1234567890123456');
  const flag = '<script id="mm-public-build">window.MM_PUBLIC_BUILD=true;window.MM_CONTENT_VERSION=' + JSON.stringify(version) + ';' + (adsense ? 'window.MM_ADSENSE_CLIENT=' + JSON.stringify(adsense) + ';' : '') + '</script>';
  if (adsense) {
    /* widen the Content-Security-Policy only for Google's ad domains */
    const G = 'https://pagead2.googlesyndication.com https://*.googlesyndication.com https://*.doubleclick.net https://*.google.com https://*.gstatic.com https://*.adtrafficquality.google';
    const before = html;
    html = html.replace("script-src 'self' 'unsafe-inline';", "script-src 'self' 'unsafe-inline' " + G + ';')
      .replace("img-src 'self' blob: data:;", "img-src 'self' blob: data: " + G + ';')
      .replace(/connect-src 'self'([^;]*);/, (m, rest) => "connect-src 'self'" + rest + ' ' + G + ';')
      .replace("base-uri 'self';", "frame-src " + G + ";\n           base-uri 'self';");
    if (html === before) throw new Error('could not widen the CSP for AdSense');
  }
  if (!html.includes('<script id="v69-access-loader">')) throw new Error('access loader not found');
  html = html.replace('<script id="v69-access-loader">', flag + '\n<script id="v69-access-loader">');
  const bytes = write(path.join(PUB, 'index.html'), html);
  /* static files served next to the page */
  const hosting = path.join(SRC, 'hosting');
  const copy = (dir, rel) => fs.readdirSync(dir, { withFileTypes: true }).forEach(d => {
    const from = path.join(dir, d.name), to = path.join(rel, d.name);
    if (d.isDirectory()) return copy(from, to);
    const out = path.join(PUB, to); fs.mkdirSync(path.dirname(out), { recursive: true });
    if (/\.(js|json|txt|svg|html|css)$|^_headers$|^_redirects$/.test(d.name)) fs.writeFileSync(out, fs.readFileSync(from, 'utf8').split('__CONTENT_VERSION__').join(version));
    else fs.copyFileSync(from, out); /* images and other binary files */
  });
  if (fs.existsSync(hosting)) { fs.rmSync(PUB, { recursive: true, force: true }); write(path.join(PUB, 'index.html'), html); copy(hosting, ''); }
  /* content packs for Supabase */
  fs.rmSync(PACKS, { recursive: true, force: true });
  Object.keys(mode.packs).forEach(k => write(path.join(PACKS, k + '.json'), mode.packs[k]));
  write(path.join(PACKS, 'manifest.json'), JSON.stringify({ version, built: new Date().toISOString(), packs: Object.keys(mode.packs).sort() }, null, 1));
  return { bytes, version, packs: Object.keys(mode.packs).length };
}

const args = process.argv.slice(2);
if (args.includes('--public')) {
  const r = buildPublic();
  console.log('built dist/public/index.html (' + r.bytes.length + ' bytes, week 1 only) and ' + r.packs + ' content packs, version ' + r.version);
  process.exit(0);
}
const bytes = buildFull();
console.log('built ' + path.relative(process.cwd(), OUT) + ' (' + bytes.length + ' bytes)');

const ci = args.indexOf('--check');
if (ci >= 0) {
  const ref = args[ci + 1];
  if (!ref) { console.error('--check needs a file'); process.exit(2); }
  const want = fs.readFileSync(ref);
  if (want.equals(bytes)) { console.log('check OK: byte-identical to ' + ref); process.exit(0); }
  let i = 0;
  while (i < want.length && i < bytes.length && want[i] === bytes[i]) i++;
  const line = want.slice(0, i).toString('utf8').split('\n').length;
  console.error('check FAILED: sizes ' + bytes.length + ' vs ' + want.length + ', first difference at byte ' + i + ' (line ' + line + ')');
  console.error('  expected: ' + JSON.stringify(want.slice(i, i + 80).toString('utf8')));
  console.error('  got:      ' + JSON.stringify(bytes.slice(i, i + 80).toString('utf8')));
  process.exit(1);
}
