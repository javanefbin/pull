#!/usr/bin/env node
/* Upload the locked content packs to Supabase.
     npm run build:public && npm run seed
   Reads dist/content/*.json (written by build.js --public) and upserts one row
   per pack into public.content_packs, tagged with the content version. Run it
   whenever lessons, quizzes, tests or workshops change, then redeploy. */
import fs from 'node:fs';
import path from 'node:path';
import { sb } from './_supabase.mjs';
const dir = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'dist', 'content');
const man = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
console.log(`content version ${man.version}: ${man.packs.length} packs`);
for (const key of man.packs) {
  const text = fs.readFileSync(path.join(dir, key + '.json'), 'utf8');
  const body = '[{"key":' + JSON.stringify(key) + ',"version":' + JSON.stringify(man.version) + ',"bytes":' + Buffer.byteLength(text) + ',"updated_at":' + JSON.stringify(new Date().toISOString()) + ',"data":' + text + '}]';
  await sb('/rest/v1/content_packs?on_conflict=key', { method: 'POST', headers: { 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=minimal' }, body });
  console.log(`  ✓ ${key.padEnd(16)} ${(Buffer.byteLength(text) / 1024).toFixed(0)} KB`);
}
const rows = await sb('/rest/v1/content_packs?select=key,version');
const stale = rows.filter(r => r.version !== man.version);
if (stale.length) console.log('  note: packs not in this build (left as they are): ' + stale.map(r => r.key).join(', '));
console.log('done. Deploy the matching dist/public (same version) so pages request this content.');
