#!/usr/bin/env node
/* Anonymous usage counts (functions/api/usage.js): what is used, per day.
     npm run usage                    last 30 days, totals by event
     npm run usage -- --days 7        last 7 days
     npm run usage -- --prefix lesson only events starting "lesson"
     npm run usage -- --csv > usage.csv
   Events: lesson:<grade>:<week>, quiz:<grade>:<week>, workshop-run:<grade>, gameshow,
   live-player, panel:<name>, session:<role>, edition:<free|licensed>, lang:<es|pt>,
   device:<phone|tablet|desktop>. Nothing identifies a person, device or school. */
import { sb } from './_supabase.mjs';
const args = process.argv.slice(2), opt = k => { const i = args.indexOf('--' + k); return i > -1 ? args[i + 1] : undefined; };
const days = +(opt('days') || 30), prefix = opt('prefix') || '';
const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
const rows = await sb('/rest/v1/usage_daily?select=day,event,n&day=gte.' + since + (prefix ? '&event=like.' + encodeURIComponent(prefix + '*') : '') + '&order=day.asc&limit=100000');
if (args.includes('--csv')) { console.log('day,event,count'); rows.forEach(r => console.log([r.day, r.event, r.n].join(','))); process.exit(0); }
const tot = {}; rows.forEach(r => { tot[r.event] = (tot[r.event] || 0) + Number(r.n); });
const list = Object.entries(tot).sort((a, b) => b[1] - a[1]);
console.log(`\nMoney Matters usage, last ${days} days (since ${since})${prefix ? ', events starting "' + prefix + '"' : ''}\n`);
console.table(list.slice(0, 60).map(([event, count]) => ({ event, count })));
const by = p => list.filter(([e]) => e.startsWith(p)).reduce((s, [, c]) => s + c, 0);
console.log(`lessons opened ${by('lesson:')} · quizzes ${by('quiz:')} · workshop runs ${by('workshop-run')} · Game Show ${by('gameshow')} · sessions ${by('session:')}\n`);
