/* Shared helper for the Supabase scripts. Needs two environment variables:
     SUPABASE_URL         https://<project>.supabase.co
     SUPABASE_SECRET_KEY  a secret key (sb_secret_…) or the legacy service_role key
   Put them in a .env file next to package.json (never commit it) or export them. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const envFile = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', '.env');
if (fs.existsSync(envFile)) for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
  const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
}
export const URL_ = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const KEY = process.env.SUPABASE_SECRET_KEY || '';
if (!URL_ || !KEY) { console.error('Set SUPABASE_URL and SUPABASE_SECRET_KEY (in .env or the environment).'); process.exit(2); }
export async function sb(p, init = {}) {
  const headers = Object.assign({ apikey: KEY, Accept: 'application/json' }, KEY.startsWith('eyJ') ? { Authorization: 'Bearer ' + KEY } : {}, init.headers || {});
  const r = await fetch(URL_ + p, Object.assign({}, init, { headers }));
  if (!r.ok) { const t = await r.text(); throw new Error(`${init.method || 'GET'} ${p} → ${r.status} ${t.slice(0, 300)}`); }
  return r.status === 204 ? null : (r.headers.get('content-type') || '').includes('json') ? r.json() : r.text();
}
export const normalize = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
