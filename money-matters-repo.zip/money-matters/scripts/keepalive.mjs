#!/usr/bin/env node
/* Supabase's free plan pauses a project after a week with no activity, which
   would lock licensed schools out over a break. GitHub Actions runs this every
   3 days (see .github/workflows/keepalive.yml): one tiny read plus pruning old
   usage events. */
import { sb } from './_supabase.mjs';
const rows = await sb('/rest/v1/content_packs?select=key,version&limit=1');
await sb('/rest/v1/rpc/prune_license_events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
console.log('Supabase is awake. Content version: ' + (rows[0] ? rows[0].version : 'none uploaded yet'));
