#!/usr/bin/env node
/* School licenses: access codes, and email domains / emails for Google, Microsoft and Facebook sign-in.
     node scripts/license.mjs new --label "Lincoln Elementary" [--expires 2027-07-31] [--seats 30] [--contact email]
                                  [--domain lincoln.k12.us] [--emails a@x.org,b@y.org] [--no-code]
     node scripts/license.mjs emails <id or label> [--add a@x.org,b@y.org] [--remove c@z.org] [--domain d.org|none]
     node scripts/license.mjs list
     node scripts/license.mjs disable <id or label>
     node scripts/license.mjs enable  <id or label>
     node scripts/license.mjs extend  <id or label> --expires 2028-07-31
   A new code is printed ONCE. Only its SHA-256 hash is stored, so write it down
   and send it to the school. Codes look like MM-7KQ2-X9PD-H4TW (60 random bits). */
import crypto from 'node:crypto';
import { sb, normalize, sha256 } from './_supabase.mjs';
const [cmd, ...rest] = process.argv.slice(2);
const opt = k => { const i = rest.indexOf('--' + k); return i > -1 ? rest[i + 1] : undefined; };
const ALPHA = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; /* no 0/O, 1/I */
function newCode() { const b = crypto.randomBytes(12); let s = ''; for (let i = 0; i < 12; i++) s += ALPHA[b[i] % 32]; return 'MM-' + s.slice(0, 4) + '-' + s.slice(4, 8) + '-' + s.slice(8); }
async function find(q) {
  if (!q) throw new Error('give an id or label');
  const rows = /^[0-9a-f-]{36}$/.test(q) ? await sb('/rest/v1/licenses?select=id,label&id=eq.' + q) : await sb('/rest/v1/licenses?select=id,label&label=ilike.' + encodeURIComponent(q));
  if (rows.length !== 1) throw new Error(rows.length ? `"${q}" matches ${rows.length} licenses; use the id` : `no license "${q}"`);
  return rows[0];
}
const list = v => String(v || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);
const patch = (id, o) => sb('/rest/v1/licenses?id=eq.' + id, { method: 'PATCH', headers: { 'Content-Type': 'application/json', Prefer: 'return=minimal' }, body: JSON.stringify(o) });
try {
  if (cmd === 'new') {
    const label = opt('label'); if (!label) throw new Error('--label is required');
    const noCode = rest.includes('--no-code'), code = noCode ? null : newCode(), expires = opt('expires');
    const domain = (opt('domain') || '').toLowerCase().replace(/^@/, '') || null, emails = list(opt('emails'));
    if (noCode && !domain && !emails.length) throw new Error('--no-code needs --domain or --emails, or nobody could use the license');
    await sb('/rest/v1/licenses', { method: 'POST', headers: { 'Content-Type': 'application/json', Prefer: 'return=minimal' }, body: JSON.stringify({ code_hash: code ? sha256(normalize(code)) : null, email_domain: domain, emails, label, contact: opt('contact') || null, seats: opt('seats') ? +opt('seats') : null, expires_at: expires ? new Date(expires + 'T23:59:59Z').toISOString() : null }) });
    console.log(`\n  License for ${label}${expires ? ', expires ' + expires : ', no expiry'}.`);
    if (code) console.log(`\n  Access code:  ${code}\n  This is the only time the code is shown.`);
    if (domain) console.log(`  Anyone signing in with Google, Microsoft or Facebook as …@${domain} is covered.`);
    if (emails.length) console.log(`  Covered sign-in emails: ${emails.join(', ')}`);
    console.log('');
  } else if (cmd === 'emails') {
    const l = await find(rest[0]);
    const cur = (await sb('/rest/v1/licenses?select=emails,email_domain&id=eq.' + l.id))[0];
    const set = new Set(cur.emails || []); list(opt('add')).forEach(e => set.add(e)); list(opt('remove')).forEach(e => set.delete(e));
    const body = { emails: [...set] }; if (opt('domain')) body.email_domain = opt('domain') === 'none' ? null : opt('domain').toLowerCase().replace(/^@/, '');
    await patch(l.id, body);
    console.log(`${l.label}: domain ${body.email_domain !== undefined ? body.email_domain || '(none)' : cur.email_domain || '(none)'}; emails ${[...set].join(', ') || '(none)'}`);
  } else if (cmd === 'list') {
    const rows = await sb('/rest/v1/license_usage?select=*&order=label');
    console.table(rows.map(r => ({ id: r.id, label: r.label, active: r.active, expires: r.expires_at ? r.expires_at.slice(0, 10) : '—', loads: r.loads, last_used: r.last_used ? r.last_used.slice(0, 10) : '—' })));
  } else if (cmd === 'disable' || cmd === 'enable') {
    const l = await find(rest[0]); await patch(l.id, { active: cmd === 'enable' });
    console.log(`${l.label}: ${cmd}d. Devices that already have the content keep it until their 7-day cache expires.`);
  } else if (cmd === 'extend') {
    const l = await find(rest[0]); const e = opt('expires'); if (!e) throw new Error('--expires YYYY-MM-DD is required');
    await patch(l.id, { expires_at: new Date(e + 'T23:59:59Z').toISOString(), active: true }); console.log(`${l.label}: now expires ${e}.`);
  } else {
    console.log('usage: license.mjs new --label "School" [--expires YYYY-MM-DD] [--seats N] [--domain d.org] [--emails a@x,b@y] [--no-code] | emails <id|label> [--add …] [--remove …] [--domain d.org|none] | list | disable <id|label> | enable <id|label> | extend <id|label> --expires YYYY-MM-DD');
  }
} catch (e) { console.error('error: ' + e.message); process.exit(1); }
